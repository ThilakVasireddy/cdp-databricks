# cdp-cicd

* Create docker image for cicd:
  * cdp-ci: base docker image with java, python and maven
  * cdp-databricks-cli: docker image with python and azure-cli
* Store templates for cici