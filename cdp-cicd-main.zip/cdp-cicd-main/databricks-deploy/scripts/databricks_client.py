import datetime
import os
from typing import Iterator

import pytest
from databricks.sdk import WorkspaceClient
from databricks.sdk.service.jobs import BaseJob, TerminationCodeCode


class DatabricksClient:
    def __init__(self):
        self.w = WorkspaceClient()

    def run_job(self, job_name, timeout):
        base_job_it: Iterator[BaseJob] = self.w.jobs.list(name=job_name)
        base_job_list = list(base_job_it)
        if len(base_job_list) == 0:
            pytest.fail(f"Job with name '{job_name}' not found")
        job_id = base_job_list[0].job_id
        return self.w.jobs.run_now_and_wait(job_id=job_id, timeout=timeout)

    def run_job_with_env_name(self, env_name, env_timeout_name):
        job_name = os.getenv(env_name)
        if job_name is None:
            print(f"Environment variables ${env_name} is not set. There is no job to run.")
            return True

        timeout_minutes = os.getenv(env_timeout_name)
        if timeout_minutes is None:
            timeout_minutes = 20
        timeout = datetime.timedelta(minutes=timeout_minutes)

        result = self.run_job(job_name, timeout)
        print(f"Job with status: {result}")
        return result.status.termination_details.code == TerminationCodeCode.SUCCESS
