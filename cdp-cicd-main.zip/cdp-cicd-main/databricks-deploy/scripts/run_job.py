import sys

from databricks_client import DatabricksClient

if __name__ == '__main__':
    client = DatabricksClient()
    result = client.run_job_with_env_name(sys.argv[1], sys.argv[2])
    if not result:
        sys.exit(1)
