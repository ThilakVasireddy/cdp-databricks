import datetime
import os

import pytest
from databricks.sdk.service.jobs import TerminationCodeCode

from .databricks_client import DatabricksClient


def test_main():
    job_name = os.getenv('INTEGRATION_NOTEBOOK')
    if job_name is None:
        pytest.fail("Environment variables INTEGRATION_NOTEBOOK is not set. There is no integration test to run.")

    timeout_minutes = os.getenv('INTEGRATION_TIMEOUT')
    if timeout_minutes is None:
        timeout_minutes = 20

    timeout = datetime.timedelta(minutes=timeout_minutes)
    client = DatabricksClient()
    result = client.run_job(job_name, timeout)
    assert result.status.termination_details.code == TerminationCodeCode.SUCCESS, f"Job failed with status: {result}"
