# cdp-common

This project is used to generate python lib. The project includes:
* config: 
  * read configure file, which is in json format
  * provide configure value as following:
```python
config = Config()
# if a specific configure file is used, then
# config = Config("test/config_personal.json")
value = config[key]
```

## How to generate a wheel package manually
1. Update version in pyproject.toml when some change is make for features or issues.
2. Run commands:
```shell
python3 -m pip install --upgrade build
python3 -m build
```
package could be found under dist/

## How to push package to BAMS locally
Run commands:
```shell
python3 -m pip install --upgrade twine
python -m twine upload \
  --verbose \
  --repository-url https://bams-aws.refinitiv.com/artifactory/api/pypi/default.pypi.cloud/ \
  --username ${username} \
  --password ${password} \
  dist/*.whl
```

## How to run coverage locally
Run commands:
```shell
python3 -m pip install coverage
coverage run -m unittest discover -s tests/
coverage xml
```