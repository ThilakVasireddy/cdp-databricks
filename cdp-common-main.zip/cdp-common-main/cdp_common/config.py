import json
import os


class Config:
    def __init__(self, path=None):
        if path is None:
            env = os.environ.get('ENV', 'dev')
            stage = os.environ.get('STAGE', 'sandbox')

            current_directory = os.path.dirname(os.path.abspath(__file__))
            self.config_file_path = os.path.join(current_directory, env, stage, "config.json")
        else:
            self.config_file_path = path
        # Read the content of the config.json file
        with open(self.config_file_path, 'r') as config_file:
            self._config_content = json.load(config_file)

    def __getitem__(self, key):
        return self._config_content[key]

    def __str__(self):
        return json.dumps(self._config_content, indent=4)
