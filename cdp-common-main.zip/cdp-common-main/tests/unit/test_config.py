import os

import pytest

from cdp_common.config import Config


def test_config_with_file_path():
    config_file = os.path.join(os.path.dirname(__file__), 'config.json')
    config = Config(config_file)
    catalog_name = config["shipping"]["catalog_name"]
    assert catalog_name == "hive_metastore"


def test_config_default():
    try:
        Config()
    except FileNotFoundError:
        pass
    else:
        pytest.fail('ExpectedException not raised')
