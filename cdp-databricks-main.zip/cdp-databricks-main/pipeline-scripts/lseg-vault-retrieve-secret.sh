#!/bin/bash

function info_message() {
  echo -e "${GREEN}---${CLR}"
  echo -e "${GREEN}---${CLR} Connecting to Vault Server: ${BLUE}${VAULT_ADDR}${CLR}"
  echo -e "${GREEN}---${CLR} ${BLUE}vault-client:           ${GREEN}$(vault --version)${CLR}"
  echo -e "${GREEN}---${CLR} ${BLUE}vault-service-function: ${GREEN}${VS_FUNCTION}${CLR}"
  echo -e "${GREEN}---${CLR} ${BLUE}vault-path:             ${GREEN}${VS_SECRET_PATH}${CLR}"
  echo -e "${GREEN}---${CLR} ${BLUE}vault-role:             ${GREEN}${VS_ROLE}${CLR}"
  echo -e "${GREEN}---${CLR} ${BLUE}attempt:                ${GREEN}${i} / 5${CLR}"
}
#-------------------------------------------------------------------------
# failure_message function
#-------------------------------------------------------------------------
function failure_message() {
  echo -e "${RED}---${CLR}"
  echo -e "${RED}---${CLR} Retriving secret failed. attempt ${i} / 5. RETRY ATTEMPTS EXHAUSTED.${CLR}"
  echo -e "${RED}---${CLR}"
  echo -e "${RED}---${CLR} Check the error messages above for information."
  echo -e "${RED}---${CLR}"
  echo -e "${RED}---${CLR} Access the Vault UI using OIDC authentication and check the following are valid:"
  echo -e "${RED}---${CLR} vault-role: ${GREEN}${VS_ROLE}${CLR}"
  echo -e "${RED}---${CLR} vault-path: ${GREEN}${VS_SECRET_PATH}${CLR}"
  echo -e "${RED}---${CLR}"
  echo -e "${RED}---${CLR} Contact DX1 Support if you continue to experience issues."
  echo -e "${RED}---${CLR}"
}
#-------------------------------------------------------------------------
# retry_message function
#-------------------------------------------------------------------------
function retry_message() {
  echo -e "${RED}---${CLR} Interaction with ${VAULT_ADDR} failed. Attempt ${i} / 5. RETRYING...${CLR}"
  echo -e "${RED}---${CLR}"
}
#-------------------------------------------------------------------------
# success_message function
#-------------------------------------------------------------------------
function success_message() {
  echo -e "${GREEN}---${CLR} Successful interaction with: ${BLUE}${VAULT_ADDR}${CLR}"
  echo -e "${GREEN}---${CLR}"
}


apk add jq openssl ca-certificates curl

#export VS_ROLE=${LMP_ASSET_ID}-developer
#export VAULT_TOKEN="$(vault write -field=token auth/dx1_gitlab_jwt/login role=${VS_ROLE} jwt=${VAULT_ID_TOKEN})"

if [ "${LSEG_PPE_VAULT}" == "true" ] ; then
  export VS_MODE=LSEG
  export VAULT_ADDR="https://vaultent.ppe.lseg.com"
elif [ "${LSEG_PROD_VAULT}" == "true" ] ;  then
  export VS_MODE=LSEG
  export VAULT_ADDR="https://vault.lseg.com"
else
  echo "nothing to create"
  exit 0
fi

if [ "${VS_MODE}" == "LSEG" ] ; then
  echo -e "${GREEN}---${CLR} ${BLUE}Configuring LSEG Vault CA Certificates.${CLR}"
  mkdir -p /etc/certificates/
  if [ ${LSEG_PPE_VAULT} == "true" ] ; then
    echo "" | openssl s_client -host vaultent.ppe.lseg.com -port 443 | awk '/BEGIN CERT/ {p=1} ; p==1; /END CERT/ {p=0}' > /etc/certificates/vaultent.ppe.lseg.com.pem
  elif [ ${LSEG_PROD_VAULT} == "true" ] ; then
    echo "" | openssl s_client -host vault.lseg.com -port 443 | awk '/BEGIN CERT/ {p=1} ; p==1; /END CERT/ {p=0}' > /etc/certificates/vault.lseg.com.pem
  fi
  chmod -R 600 /etc/certificates
  export VAULT_CAPATH=/etc/certificates
fi

if [ "${SECRET_KEY_LIST}" == "" ] ; then
 echo -e "${RED}---${CLR} You must set a value for the variable SECRET_KEY_LIST."
 exit 1
fi

for VS_SECRET in ${SECRET_KEY_LIST} ; do
  # Set Secret Env Var Name
  export VS_SR_ENV_VAR=$(echo ${VS_SECRET} | awk -F '@' '{print $1}')
  # Set Secret Path
  export VS_SECRET_PATH=$(echo ${VS_SECRET} | awk -F '@' '{print $2}')
  # Set Secret Key
  export VS_SR_KEY=$(echo ${VS_SECRET} | awk -F '@' '{print $3}')

  if [ "${VS_SECRET_PATH}" == "" ] ; then
    echo -e "${RED}---${CLR}"
    echo -e "${RED}--- The value of VS_SECRET_PATH is not set. Please set this value and retry."
    echo -e "${RED}---${CLR}"
  fi

  echo -e "${GREEN}---${CLR}"
  echo -e "${GREEN}---${CLR} Attempting to pull secret: ${BLUE}${VS_SECRET_PATH}${CLR}"
  echo -e "${GREEN}---${CLR} Secret key:                ${BLUE}${VS_SR_KEY}${CLR}"
  for i in `seq 1 5`; do
    if [ "${VS_MODE}" == "LSEG" ] ; then
      export VS_ROLE=${LMP_ASSET_ID}-developer
      export VAULT_TOKEN="$(vault write -field=token auth/dx1_gitlab_jwt/login role=${VS_ROLE} jwt=${VAULT_ID_TOKEN})"
    elif [ "${VS_MODE}" == "REFINITIV" ] ; then
      vault_configuration_refinitiv
    fi

    info_message

    export VAULT_NAMESPACE=${VAULT_APP_NAMESPACE}
    export VS_FORMAT=${VS_FORMAT:=table}
    export VS_FORMAT_VALID_OPTIONS="table yaml json"
    if ! echo "$VS_FORMAT_VALID_OPTIONS" | grep -wq "$VS_FORMAT"; then
      echo "VS_FORMAT is not valid. Valid options are: $VS_FORMAT_VALID_OPTIONS" >&2
      exit 1
    fi

    export VS_SR_VALUE=$(vault kv get -format=${VS_FORMAT} -field=${VS_SR_KEY} ${VS_SECRET_PATH})

    if [ "${VS_SR_VALUE}" == "" ] && [ ${i} -le 4 ] ; then
      retry_message
      export VAULT_NAMESPACE=
    elif [ "${VS_SR_VALUE}" = "" ] && [ ${i} == 5 ]; then
      failure_message
      exit 1
    else
      if [ ${VS_SR_ENV_VAR} == "ECMWF_CERTIFICATE" ]; then
        echo ${VS_SR_VALUE} >> ecmwf_certificate.pfx.b64
        cat ecmwf_certificate.pfx.b64 | base64 -d > ecmwf_certificate.pfx
      elif [ ${VS_SR_ENV_VAR} == "CERTIFICATE" ]; then
        echo ${VS_SR_VALUE} >> certificate.pfx.b64
        cat certificate.pfx.b64 | base64 -d > certificate.pfx
      else
        echo ${VS_SR_ENV_VAR}=${VS_SR_VALUE} >> ${CI_PIPELINE_ID}-${CI_JOB_NAME}-${CI_JOB_ID}.env
        success_message
        export VAULT_NAMESPACE=
        break
      fi
    fi
  done
done


#export CI_VAULT_INTEGRATOR_MODE=vault-secret-retriever
#export CI_VAULT_INTEGRATOR_ENGINE="Vault KV Secrets Engine"
#export CI_VAULT_INTEGRATOR_APP_ID=${LMP_ASSET_ID}
#if echo ${CI_VAULT_INTEGRATOR_APP_ID} | grep -E ${CI_VAULT_INTEGRATOR_REGEX} >/dev/null; then
#  echo -e "${BLUE}--- LSEG Vault Mode ---${CLR}"
#  export CI_VAULT_INTEGRATOR_VAULT_ROLE=${CI_VAULT_INTEGRATOR_APP_ID}-developer
#  export CI_VAULT_INTEGRATOR_VAULT_PATH=gitlab/${CI_VAULT_INTEGRATOR_APP_ID}/kv/${SECRET_PATH}
#  export CI_VAULT_INTEGRATOR_AUTH_PATH=auth/dx1_gitlab_jwt/login
#else
#  echo -e "${BLUE}--- Refinitiv Vault Mode ---${CLR}"
#  if [ "${CI_PROJECT_ROOT_NAMESPACE}" == "ci" ] ; then
#    export CI_VAULT_INTEGRATOR_VAULT_ROLE=${CI_PROJECT_ROOT_NAMESPACE}-kv-owners
#    export CI_VAULT_INTEGRATOR_VAULT_PATH=gitlab/${CI_PROJECT_ROOT_NAMESPACE}/kv/${SECRET_PATH}
#  else
#    if [ "${CI_PROJECT_ROOT_NAMESPACE}" == "app" ] ; then
#      export CI_VAULT_INTEGRATOR_PROJECT_ASSET_ID=${CI_VAULT_INTEGRATOR_APP_ID}
#      export CI_VAULT_INTEGRATOR_VAULT_ROLE=${CI_VAULT_INTEGRATOR_PROJECT_ASSET_ID}
#      export CI_VAULT_INTEGRATOR_VAULT_PATH=gitlab/${CI_VAULT_INTEGRATOR_PROJECT_ASSET_ID}/kv/${SECRET_PATH}
#     else
#       export CI_VAULT_INTEGRATOR_VAULT_ROLE=${CI_PROJECT_ROOT_NAMESPACE}
#       export CI_VAULT_INTEGRATOR_VAULT_PATH=gitlab/${CI_PROJECT_ROOT_NAMESPACE}/kv/${SECRET_PATH}
#     fi
#   fi
#   export CI_VAULT_INTEGRATOR_AUTH_PATH=auth/jwt/login
#fi
#export VAULT_TOKEN="$(vault write -field=token ${CI_VAULT_INTEGRATOR_AUTH_PATH} role=${CI_VAULT_INTEGRATOR_VAULT_ROLE} jwt=$CI_JOB_JWT)"
#export VAULT_NAMESPACE=${VAULT_APP_NAMESPACE}
#export CI_VAULT_INTEGRATOR_FORMAT=${CI_VAULT_INTEGRATOR_FORMAT:=table}

FORMAT_VALID_OPTIONS="table yaml json"
#if ! echo "$FORMAT_VALID_OPTIONS" | grep -wq "$CI_VAULT_INTEGRATOR_FORMAT"; then
#  echo "CI_VAULT_INTEGRATOR_FORMAT is not valid. Valid options are: $FORMAT_VALID_OPTIONS" >&2
#  exit 1
#fi

#if [ "${VAULT_TOKEN}" == "" ] ; then
#  export CI_VAULT_INTEGRATOR_FAILURE=true
#else
#  if [ -z "${SECRET_KEY_LIST}" ] ; then
#    echo -e "${RED}❌ SECRET_KEY_LIST variable is not set or is empty! Please provide valid value for SECRET_KEY_LIST!❌${CLR}"
#    exit 1
#  fi

#  for SECRET_KEY in ${SECRET_KEY_LIST} ; do
#  echo "$SECRET_KEY"
#  export SECRET_VALUE=$(vault kv get -format=${CI_VAULT_INTEGRATOR_FORMAT} -field=${SECRET_KEY} ${CI_VAULT_INTEGRATOR_VAULT_PATH})

#  if [ "${SECRET_VALUE}" == "" ] ; then
#    export CI_VAULT_INTEGRATOR_FAILURE=true
#    export VAULT_NAMESPACE=
#  else
#    echo "getting artifacts"
#    if [ ${SECRET_KEY} == "ECMWF_CERTIFICATE" ]; then
#      echo ${SECRET_VALUE} >> ecmwf_certificate.pfx.b64
#      cat ecmwf_certificate.pfx.b64 | base64 -d > ecmwf_certificate.pfx
#    elif [ ${SECRET_KEY} == "CERTIFICATE" ]; then
#      echo ${SECRET_VALUE} >> certificate.pfx.b64
#      cat certificate.pfx.b64 | base64 -d > certificate.pfx
#    else
#      echo ${SECRET_KEY}=${SECRET_VALUE} >> ${CI_PIPELINE_ID}-${CI_JOB_NAME}-${CI_JOB_ID}.env
#    fi
#  fi
#  done
#fi
