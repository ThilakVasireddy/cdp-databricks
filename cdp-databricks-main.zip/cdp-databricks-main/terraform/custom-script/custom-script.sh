# Required parameters
export DD_API_KEY=${DD_API_KEY}
export DD_SITE=datadoghq.eu
export DATABRICKS_WORKSPACE=app_51162_${ENV}_${STAGE}
export DRIVER_LOGS_ENABLED=true # Collect spark driver logs in Datadog (false by default)
export WORKER_LOGS_ENABLED=true # Collect spark worker logs in Datadog (false by default)

# Download and run the latest init script
curl -L https://install.datadoghq.com/scripts/install-databricks.sh > djm-install-script
bash djm-install-script || true