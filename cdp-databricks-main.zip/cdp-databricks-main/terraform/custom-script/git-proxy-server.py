%pip install databricks-sdk==0.9.0
dbutils.library.restartPython()
import requests
from databricks.sdk import WorkspaceClient
from databricks.sdk.core import ApiClient
from databricks.sdk.service import compute
from databricks.sdk.service import iam
from databricks.sdk.service.compute import AwsAttributes, AzureAttributes, GcpAttributes
w = WorkspaceClient()
api_client = ApiClient()

cluster_name = "Repos Git Proxy"

create_cluster_data = {
    "cluster_name": cluster_name,
    "spark_version": "12.2.x-scala2.12",
    "autotermination_minutes": 0,
    "num_workers": 0,
    "spark_conf": {
        "spark.databricks.cluster.profile": "singleNode",
        "spark.master": "local[*]",
    },
    "custom_tags": {"ResourceClass": "SingleNode"},
}
# get list of node types to determine whether this workspace is on AWS or Azure
nodes = w.clusters.list_node_types()
node_type_ids = [t.node_type_id for t in nodes.node_types]
aws_node_type_id = "m5.large"
aws_nitro_node_type_id = "m5n.large"
azure_node_type_id = "Standard_DS3_v2"
gcp_node_type_id = "e2-standard-4"

if w.config.is_aws:
    if (aws_node_type_id and aws_nitro_node_type_id) not in node_type_ids:
        raise ValueError(
            f"Node types {aws_node_type_id & aws_nitro_node_type_id} do not exist in your workspace. Make sure the node type specified is available in your workspace, or contact support."
        )
    if aws_node_type_id in node_type_ids:
        node_type_id = aws_node_type_id
    else: 
        node_type_id = aws_nitro_node_type_id
    create_cluster_data["aws_attributes"] = AwsAttributes.from_dict({"ebs_volume_count": "1", "ebs_volume_size": "32", "first_on_demand": "1"})
elif w.config.is_azure:
    if azure_node_type_id not in node_type_ids:
        raise ValueError(
            f"Node types {azure_node_type_id} does not exist in your workspace. Make sure the node type specified is available in your workspace, or contact support."
        )
    node_type_id = azure_node_type_id
    create_cluster_data["azure_attributes"] = AzureAttributes.from_dict({
                        "availability": "ON_DEMAND_AZURE"
                        })
    
elif w.config.is_gcp:
    if gcp_node_type_id not in node_type_ids:
        raise ValueError(
            f"Node types {gcp_node_type_id} does not exist in your workspace. Make sure the node type specified is available in your workspace, or contact support."
        )
    node_type_id = gcp_node_type_id
    create_cluster_data["gcp_attributes"] = GcpAttributes.from_dict({
            "use_preemptible_executors": False
            })
else: 
   raise ValueError(
        f"The Databricks git proxy server only supports AWS, Azure and GCP. Running on an unsupported cloud. Please contact support."
    )

create_cluster_data["node_type_id"] = node_type_id
# Note: Return information about all pinned clusters, active clusters, up to 200 of the most recently terminated all-purpose clusters in the past 30 days, and up to 30 of the most recently terminated job clusters in the past 30 days. See https://github.com/databricks/databricks-sdk-py/blob/349216706aeac81828a807f40a21a1b0c80ed717/docs/workspace/clusters.rst?plain=1#L592
all_clusters = w.clusters.list()
clusters_names = [c.cluster_name for c in all_clusters]
print(f"List of existing clusters: {clusters_names}")

if cluster_name in clusters_names:
    #raise ValueError(
    print(
        f"Cluster called {cluster_name} already exists."
    )
else:
    # Create a new cluster named cluster_name that will proxy requests to the private Git server
    print(f"Create cluster POST request data: {create_cluster_data}")
    clusters_create_response = w.clusters.create(**create_cluster_data).result()
    print(f"Create cluster response: {clusters_create_response}")
    cluster_id = clusters_create_response.cluster_id
    print(f"Created new cluster with id {cluster_id}")

    api_client.do("PATCH", "/api/2.0/workspace-conf", body={"enableGitProxy": "true"}, headers={"Content-Type": "application/json"})
    api_client.do("PATCH", "/api/2.0/workspace-conf", body={"gitProxyClusterId": cluster_id}, headers={"Content-Type": "application/json"})
    #get_flag_response = api_client.do("GET", "/api/2.0/workspace-conf", {"keys": "enableGitProxy"})
    get_flag_response = api_client.do("GET", "/api/2.0/workspace-conf?keys=enableGitProxy")
    get_cluster_id_response = api_client.do("GET", "/api/2.0/workspace-conf?keys=gitProxyClusterId")
    print(f"Get enableGitProxy response: {get_flag_response}")
    print(f"Get gitProxyClusterId response: {get_cluster_id_response}")