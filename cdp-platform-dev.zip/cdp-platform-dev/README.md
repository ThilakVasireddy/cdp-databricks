# cdp-platform-dashboards

## Asset Bundles

### Introduction

[Databricks Asset Bundles](https://learn.microsoft.com/en-us/azure/databricks/dev-tools/bundles/) are designed to facilitate good engineering practices, such as source control, testing, and CI/CD.

See also: [CDP SDLC for data pipelines (Databricks)](https://confluence.refinitiv.com/pages/viewpage.action?pageId=1134535173)

### Deployment protection

This project has three branches for protected environments:

1. dev - Development
1. ppr - Pre-production
1. prd - Production

Code on each of these branches can be deployed to the *sandbox*, *staging* and *live* stages for each of these environments.

There are two roles relevant to this: *approvers* and *deployers*. These are maintained through *Settings -> CI/CD -> Protected Environments*.

To deploy: In the left-hand menu, click through to *Build -> Pipelines*.

For approvals: In the left-hand menu, click through to *Operate -> Environments*.


### Asset Bundle: ops_bundle

Contains dashboards and the data pipelines that are used for populating the tables that drive them.

See [./ops_bundle/README.md](ops_bundle/README.md) for details of how to build and deploy the asset bundle.