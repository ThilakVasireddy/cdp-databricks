# Databricks notebook source
import os

from databricks.sdk import WorkspaceClient
from databricks.sdk.errors import InvalidParameterValue
from databricks.sdk.service.jobs import PauseStatus

BASE_EXCEPT_JOBS = [
    "stop_all_jobs",
    "shipping_ingest_cdb_vessel_master",
    "shipping_ingest_cdb_vessel_name_history",
    "shipping_vesseltracker_vessels_history_delete_data",
    "shipping_vesseltracker_vessels_history",
    "shipping_data_onboarding_initialisation_db_migration_scripts",
    "shipping_data_onboarding_integration_tests",
    "shipping_ingest_shipdb_master_data",
    "shipping_ingest_shipdb_new_building",
    "shipping_ingest_spire_vessels",
    "shipping_ingest_vesseltracker_vessels",
    "shipping_kml_bad_positions",
    "shipping_optimize_shipdb",
    "shipping_optimize_spire",
    "shipping_optimize_vesseltracker_vessels",
    "shipping_shared_mapping_tables",
    "shipping_spire_mapping_tables",
    "shipping_vesseltracker_mapping_tables",
]

EXCEPT_JOB_NAMES = {
    "dev_sandbox": [*BASE_EXCEPT_JOBS, "replicate_cdb_vessel_permid"],
    "dev_staging": [*BASE_EXCEPT_JOBS],
    "ppr_sandbox": [*BASE_EXCEPT_JOBS],
    "ppr_staging": [*BASE_EXCEPT_JOBS],
    "ppr_live": [*BASE_EXCEPT_JOBS],
    "prd_sandbox": [*BASE_EXCEPT_JOBS, "replicate_cdb_vessel_permid"],
    "prd_staging": [*BASE_EXCEPT_JOBS],
}

RUNNING_ENV_STAGE = EXCEPT_JOB_NAMES.keys()

env = os.getenv("ENV").lower()
stage = os.getenv("STAGE").lower()
env_stage = f"{env}_{stage}"
print(f"env_stage: {env_stage}")
if env_stage not in RUNNING_ENV_STAGE:
    dbutils.notebook.exit(f"early exit in env_stage: {env_stage}")


def stop_job(w, job):
    job_settings = job.settings
    name = job_settings.name
    if name in EXCEPT_JOB_NAMES[env_stage]:
        return
    print(f"Canceling {name}")
    w.jobs.cancel_all_runs(job_id=job.job_id)

    for setting in [
        job_settings.schedule,
        job_settings.continuous,
        job_settings.trigger,
    ]:
        if setting:
            setting.pause_status = PauseStatus.PAUSED
            try:
                w.jobs.update(job_id=job.job_id, new_settings=job_settings)
                print(f"Paused {name}")
            except InvalidParameterValue as e:
                print(f"Can not pause {name}")
                raise InvalidParameterValue(f"Can not pause {name}") from e
            break


w = WorkspaceClient()
job_list = w.jobs.list()
exceptions = []
for job in job_list:
    try:
        stop_job(w, job)
    except Exception as e:
        exceptions.append(e)

if exceptions:
    raise ExceptionGroup("Failed to stop jobs", exceptions)
