from datetime import datetime, timedelta
from pyspark.sql import SparkSession, DataFrame
from platform_bundle.reports.schema_evolution_report import SchemaEvolutionReport


def get_recent_schema_changes(spark: SparkSession) -> DataFrame:
    report = SchemaEvolutionReport(spark=spark)
    month_ago = (datetime.today() - timedelta(days=30)).date()
    return report.find_schema_changes_since(month_ago)


# Create a new Databricks Connect session. If this fails,
# check that you have configured Databricks Connect correctly.
# See https://docs.databricks.com/dev-tools/databricks-connect.html.
def get_spark() -> SparkSession:
    try:
        from databricks.connect import DatabricksSession
        return DatabricksSession.builder.getOrCreate()
    except ImportError:
        return SparkSession.builder.getOrCreate()


def main():
    get_recent_schema_changes(spark=get_spark()).show(5)


if __name__ == '__main__':
    main()
