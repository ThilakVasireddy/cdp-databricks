# Databricks notebook source
import requests
from pyspark.sql.functions import parse_json
from pyspark.sql import functions as F

import uuid
from datetime import datetime, timezone

# Function to get cluster information
# Databricks REST API configuration
workspace_url = spark.conf.get("spark.databricks.workspaceUrl")
if workspace_url.startswith("http"):
    DATABRICKS_HOST = workspace_url
else:
    DATABRICKS_HOST = "https://" + workspace_url
# Retrieve the notebook context
notebook_context = dbutils.notebook.entry_point.getDbutils().notebook().getContext()

# Extract the API token
DATABRICKS_TOKEN = notebook_context.apiToken().get()

# Define runid and timestamp

runid_full = uuid.uuid4().int
runid      = int(runid_full & ((1 << 63) - 1))
ts         = datetime.now(timezone.utc)


# Function to get cluster information
def get_clusters():
    url = f"{DATABRICKS_HOST}/api/2.0/clusters/list"
    headers = {"Authorization": f"Bearer {DATABRICKS_TOKEN}"}
    response = requests.get(url, headers=headers)
    response.raise_for_status()
    clusters = response.json().get("clusters", [])
    return [{"name": cluster["cluster_name"], "id": cluster["cluster_id"]} for cluster in clusters]

# Function to get service principals information
def get_service_principals():
    url = f"{DATABRICKS_HOST}/api/2.0/preview/scim/v2/ServicePrincipals"
    headers = {"Authorization": f"Bearer {DATABRICKS_TOKEN}"}
    response = requests.get(url, headers=headers)
    response.raise_for_status()
    service_principals = response.json().get("Resources", [])
    result = []
    for sp in service_principals:
        name = sp.get("displayName", "default_admin")
        sp_id = sp.get("applicationId")
        result.append({"name": name, "id": sp_id})
    return result

def check_health_status_and_save_result(data_df):
    # Group by cluster name and count occurrences
    health_result_df = (
        data_df.groupBy("name")
        .agg(F.count("*").alias("count"))
        .withColumn("runid", F.lit(runid).cast("long"))
        .withColumn(
            "checkname", F.concat(F.lit("checking "), F.col("name"), F.lit(" duplication"))
        )
        .withColumn("timestamp", F.lit(ts).cast("timestamp"))
        .withColumn(
            "status", F.when(F.col("count") > 1, F.lit("unhealthy")).otherwise(F.lit("healthy"))
        )
        .withColumn(
            "level", F.when(F.col("count") > 1, F.lit("critical")).otherwise(F.lit("info"))
        )
        .withColumn(
            "message",
            F.when(F.col("count") > 1, F.lit("Has duplication")).otherwise(
                F.lit("No duplication")
            ),
        )
        .withColumn(
            "extended_properties",
            parse_json(
                F.when(
                    F.col("count") > 1,
                    F.to_json(
                        F.struct(
                            F.col("name").alias("duplicate_name"),
                            F.col("count").alias("duplicate_count"),
                        )
                    ),
                ).otherwise(F.lit(None)),
            ),
        )
        .drop("name", "count")
    )

    # Write the DataFrame to a Delta table
    health_result_df.write \
        .format("delta") \
        .mode("append") \
        .option("mergeSchema", "false") \
        .saveAsTable("platform.health_check_results")

# Main execution
if __name__ == "__main__":
    # Get cluster and service principal data
    clusters_data = get_clusters()
    cluster_df = spark.createDataFrame(clusters_data)
    display(cluster_df)
    service_principals_data = get_service_principals()
    service_principals_df = spark.createDataFrame(service_principals_data)
    display(service_principals_df)

    # Save data to Delta tables
    check_health_status_and_save_result(cluster_df)
    check_health_status_and_save_result(service_principals_df)
