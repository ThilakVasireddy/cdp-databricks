# Databricks notebook source
import requests
from pyspark.sql.types import (
    StructType,
    StructField,
    StringType,
    BooleanType,
    ArrayType,
    MapType,
    IntegerType
)
from pyspark.sql.functions import col, parse_json, explode_outer
from pyspark.sql import functions as F

import uuid
from datetime import datetime, timezone

# Define runid and timestamp
runid_full = uuid.uuid4().int
runid      = int(runid_full & ((1 << 63) - 1))
ts         = datetime.now(timezone.utc)

# GitLab API configuration
GITLAB_HOST = "https://gitlab.dx1.lseg.com"
# Retrieve GitLab token from Databricks secret scope
GITLAB_TOKEN = dbutils.secrets.get(scope="platform-secretscope", key="cdp-devops-token")

project_ids = ["88282",
                 "86829",
                 "94056",
                 "85223",
                 "85221",
                 "85222",
                 "88144",
                 "86401",
                 "85220",
                 "92446",
                 "85354"
                ]
# Function to fetch project name by ID
def get_project_name_by_id(project_id):
    url = f"{GITLAB_HOST}/api/v4/projects/{project_id}"
    headers = {"Authorization": f"Bearer {GITLAB_TOKEN}"}
    response = requests.get(url, headers=headers)
    response.raise_for_status()
    project = response.json()
    return project.get("name")

# Function to fetch branch protection settings
def get_protected_branches_settings(project_id, project_name):
    url = f"{GITLAB_HOST}/api/v4/projects/{project_id}/protected_branches"
    headers = {"Authorization": f"Bearer {GITLAB_TOKEN}"}
    response = requests.get(url, headers=headers)
    response.raise_for_status()
    branches = response.json()
    # print(branches)
    return [
        {
            "project_name": project_name,
            "branch_name": branch["name"],
            "push_access_levels": branch.get("push_access_levels", []),
            "merge_access_levels": branch.get("merge_access_levels", []),
            "allow_force_push": branch.get("allow_force_push", False),
            "unprotect_access_levels": branch.get("unprotect_access_levels", []),
            "code_owner_approval_required": branch.get("code_owner_approval_required", False),
        }
        for branch in branches
    ]

# Function to fetch environment settings
def get_protected_environments_settings(project_id, project_name):
    url = f"{GITLAB_HOST}/api/v4/projects/{project_id}/protected_environments"
    headers = {"Authorization": f"Bearer {GITLAB_TOKEN}"}
    response = requests.get(url, headers=headers)
    response.raise_for_status()
    environments = response.json()
    # rint(environments)
    return [
        {
            "project_name": project_name,
            "environment_name": env["name"],
            "deploy_access_levels": env.get("deploy_access_levels", []),
            "required_approval_count": env.get("required_approval_count", []),
            "approval_rules": env.get("approval_rules", []),
        }
        for env in environments
    ]

# Function to save data to Delta table
def check_protected_branches_status_and_save_result(data_df):
    data_df = data_df.withColumn(
        "merge_access_levels_exploded",
        explode_outer(col("merge_access_levels"))
    )

# Extract the access_level from the map
    data_df = data_df.withColumn(
        "merge_access_levels_access_level",
        col("merge_access_levels_exploded.access_level").cast("int")
    )
    health_result_df = (
        data_df.withColumn("runid", F.lit(runid).cast("long"))
        .withColumn(
            "checkname",
            F.concat(
                F.lit("checking "),
                F.col("project_name"),
                F.lit(" protected_branch "),
                F.col("branch_name"),
            ),
        )
        .withColumn("timestamp", F.lit(ts).cast("timestamp"))
        .withColumn(
            "status",
            F.when(
                (F.col("branch_name") != "feature/*")
                & (
                    F.col("allow_force_push")
                    | (F.size(F.col("push_access_levels")) != 0)
                    | (F.size(F.col("unprotect_access_levels")) != 0)
                    | (~F.col("code_owner_approval_required"))
                    | (F.col("merge_access_levels_access_level") != 30)
                ),
                F.lit("unhealthy"),
            )
            .when(
                (F.col("branch_name") == "feature/*")
                & (F.size(F.col("unprotect_access_levels")) != 0),
                F.lit("unhealthy"),
            )
            .otherwise(F.lit("healthy")),
        )
        .withColumn(
            "level",
            F.when(F.col("status") == "unhealthy", F.lit("critical")).otherwise(F.lit("info")),
        )
        .withColumn(
            "message",
            F.when(
                F.col("status") == "unhealthy", F.lit("Branch settings do not meet requirements")
            ).otherwise(F.lit("Branch settings are valid")),
        )
        .withColumn(
            "extended_properties",
            parse_json(
                F.when(
                    F.col("status") == "unhealthy",
                    F.to_json(
                        F.struct(
                            F.col("project_name"),
                            F.col("branch_name"),
                            F.col("status"),
                        )
                    ),
                ).otherwise(F.lit(None)),
            ),
        )
        .drop(
            "project_name",
            "branch_name",
            "push_access_levels",
            "merge_access_levels",
            "allow_force_push",
            "unprotect_access_levels",
            "code_owner_approval_required",
            "merge_access_levels_exploded",
            "merge_access_levels_access_level",
        )
    )
    display(health_result_df)

    # Write the DataFrame to a Delta table
    health_result_df.write \
        .format("delta") \
        .mode("append") \
        .option("mergeSchema", "false") \
        .saveAsTable("platform.health_check_results")

def check_protected_environments_status_and_save_result(data_df):
    data_df = data_df.withColumn("approval_rules_exploded", explode_outer(col("approval_rules")))

    # Extract the access_level from the map
    data_df = data_df.withColumn(
        "required_approvals_num",
        col("approval_rules_exploded.required_approvals").cast("int")
    )
    health_result_df = (
        data_df.withColumn("runid", F.lit(runid).cast("long"))
        .withColumn(
            "checkname",
            F.concat(
                F.lit("checking "),
                F.col("project_name"),
                F.lit(" protected_environment "),
                F.col("environment_name")
            ),
        )
        .withColumn("timestamp", F.lit(ts).cast("timestamp"))
        .withColumn(
            "status",
            F.when(
                (F.col("environment_name") == "prd")
                & ((F.size(F.col("approval_rules")) == 0) | (F.col("required_approvals_num") < 2)),
                F.lit("unhealthy"),
            )
            .when(
                (F.col("environment_name") != "prd")
                & (F.size(F.col("deploy_access_levels")) == 0),
                F.lit("unhealthy"),
            )
            .otherwise(F.lit("healthy")),
        )
        .withColumn(
            "level",
            F.when(F.col("status") == "unhealthy", F.lit("critical")).otherwise(F.lit("info")),
        )
        .withColumn(
            "message",
            F.when(
                F.col("status") == "unhealthy",
                F.lit("Environment settings do not meet requirements"),
            ).otherwise(F.lit("Environment settings are valid")),
        )
        .withColumn(
            "extended_properties",
            parse_json(
                F.when(
                    F.col("status") == "unhealthy",
                    F.to_json(
                        F.struct(
                            F.col("project_name"),
                            F.col("environment_name"),
                            F.col("status")
                        )
                    ),
                ).otherwise(F.lit(None)),
            ),
        )
        .drop(
            "project_name",
            "environment_name",
            "deploy_access_levels",
            "required_approval_count",
            "approval_rules",
            "approval_rules_exploded",
            "required_approvals_num",
        )
    )
    display(health_result_df)

    # Write the DataFrame to a Delta table
    health_result_df.write.format("delta").mode("append").option(
        "mergeSchema", "false"
    ).saveAsTable("platform.health_check_results")


# Main execution
if __name__ == "__main__":
    # Fetch branch and environment protection settings
    all_protected_branches_data = []
    all_protected_environments_data = []
    for project_id in project_ids:
        project_name = get_project_name_by_id(project_id)
        protected_branches_data = get_protected_branches_settings(project_id, project_name)
        all_protected_branches_data.extend(protected_branches_data)
        protected_environments_data = get_protected_environments_settings(project_id, project_name)
        all_protected_environments_data.extend(protected_environments_data)
    # Define the schema for the protected branches DataFrame
    protected_branches_schema = StructType(
        [
            StructField("project_name", StringType(), True),
            StructField("branch_name", StringType(), True),
            StructField(
                "push_access_levels", ArrayType(MapType(StringType(), StringType())), True
            ),
            StructField(
                "merge_access_levels", ArrayType(MapType(StringType(), StringType())), True
            ),
            StructField("allow_force_push", BooleanType(), True),
            StructField(
                "unprotect_access_levels", ArrayType(MapType(StringType(), StringType())), True
            ),
            StructField("code_owner_approval_required", BooleanType(), True),
        ]
    )

    protected_branches_df = spark.createDataFrame(
        all_protected_branches_data, schema=protected_branches_schema
    )
    display(protected_branches_df)
    check_protected_branches_status_and_save_result(protected_branches_df)

    protected_environments_schema = StructType(
        [
            StructField("project_name", StringType(), True),
            StructField("environment_name", StringType(), True),
            StructField(
                "deploy_access_levels", ArrayType(MapType(StringType(), StringType())), True
            ),
            StructField("required_approval_count", IntegerType(), True),
            StructField("approval_rules", ArrayType(MapType(StringType(), StringType())), True),
        ]
    )

    protected_environments_df = spark.createDataFrame(
        all_protected_environments_data, schema=protected_environments_schema
    )
    display(protected_environments_df)
    check_protected_environments_status_and_save_result(protected_environments_df)