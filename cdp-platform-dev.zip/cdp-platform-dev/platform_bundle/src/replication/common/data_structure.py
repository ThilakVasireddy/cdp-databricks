import os
from dataclasses import dataclass
from datetime import datetime

from replicate_utils import convert_datatime_to_str


@dataclass
class OracleTableName:
    schema_name: str
    table_name: str
    column_name: str
    table_full_name: str

    def __init__(self, schema_name, table_name, column_name):
        self.schema_name = schema_name
        self.table_name = table_name
        self.column_name = column_name
        self.table_full_name = f'{self.schema_name}.{self.table_name}'


@dataclass
class DeltaTableName:
    catalog_name: str
    schema_name: str
    table_name: str
    table_full_name: str
    temp_view_name: str
    temp_view_full_name: str

    def __init__(self, catalog_name, schema_name, table_name):
        self.catalog_name = catalog_name
        self.schema_name = schema_name
        self.table_name = table_name
        self.table_full_name = f'{self.catalog_name}.{self.schema_name}.{self.table_name}'
        self.temp_view_name = f'{table_name}_temp_view'
        self.temp_view_full_name = f'global_temp.{self.temp_view_name}'


@dataclass
class UpdateRange:
    start_time: str
    end_time: str

    def __init__(self, start_date_time: datetime, end_date_time: datetime):
        self.start_time = convert_datatime_to_str(start_date_time)
        self.end_time = convert_datatime_to_str(end_date_time)


@dataclass
class OracleConfig:
    jdbc_url: str
    user_name: str
    password_name: str
    driver: str

    ORACLE_HOST_MAP = {
        'dev': {
            'host': 'oracle2.beta.commodities.int.thomsonreuters.com',
            'service_name': 'pocbt.int.thomsonreuters.com',
            'password_name_format': 'oracle_common_password'
        },
        'ppr': {
            'host': 'oracle2.beta.commodities.int.thomsonreuters.com',
            'service_name': 'pocbt.int.thomsonreuters.com',
            'password_name_format': 'oracle_common_password'
        },
        'prd': {
            'host': 'oracle2.commodities.int.thomsonreuters.com',
            'service_name': 'pocb.int.thomsonreuters.com',
            'password_name_format': 'oracle_{}_password'
        }
    }

    def __init__(self, user_name):
        env = os.getenv("ENV").lower()
        env_config = self.ORACLE_HOST_MAP.get(env)
        host = env_config.get('host')
        service_name = env_config.get('service_name')
        self.jdbc_url = f'jdbc:oracle:thin:@//{host}:1521/{service_name}'
        self.user_name = user_name

        password_name_format = env_config.get('password_name_format')
        self.password_name = password_name_format.format(user_name).replace('_', '-')
        self.driver = 'oracle.jdbc.driver.OracleDriver'

    def get_properties(self, oracle_password):
        return {
            "driver": self.driver,
            "url": self.jdbc_url,
            "user": self.user_name,
            "password": oracle_password
        }


@dataclass
class KeyVaultScope:
    scope: str

    SCOPE_MAP = {
        'dev': 'platform-secretscope',
        'ppr': 'platform-secretscope',
        'prd': 'platform-secretscope',
    }

    def __init__(self):
        env = os.getenv("ENV").lower()
        self.scope = self.SCOPE_MAP.get(env)
