import datetime

from pyspark.sql import DataFrame, SparkSession

from data_structure import (
    OracleTableName,
    DeltaTableName,
    OracleConfig,
    UpdateRange,
    KeyVaultScope,
)
from replicate_utils import get_current_time, get_one_day_before, read_sql


class DatabricksWrapper:
    def __init__(
            self,
            dbutils,
            spark: SparkSession,
            source_table: OracleTableName,
            target_table: DeltaTableName,
            process_table: DeltaTableName
    ):
        self.dbutils = dbutils
        self.spark = spark
        self.oracle_config = OracleConfig(source_table.schema_name)
        self.key_vault_scope = KeyVaultScope()
        self.source_table = source_table
        self.target_table = target_table
        self.process_table = process_table

    def get_oracle_properties(self) -> dict:
        password = self.dbutils.secrets.get(
            scope=self.key_vault_scope.scope,
            key=self.oracle_config.password_name
        )
        return self.oracle_config.get_properties(password)

    def extract_from_oracle_with_sql(self, query_sql: str) -> DataFrame:
        oracle_properties = self.get_oracle_properties()
        return (
            self.spark.read.format("jdbc")
            .options(**oracle_properties)
            .option("query", query_sql)
            .load()
        )

    def extract_from_oracle_with_sql_path(
        self,
        query_sql_relative_path: str,
        parameter_map: dict
    ) -> DataFrame:
        query = read_sql(query_sql_relative_path, parameter_map)
        return self.extract_from_oracle_with_sql(query)

    def extract_from_oracle(self) -> DataFrame:
        oracle_properties = self.get_oracle_properties()
        return (self.spark.read.format("jdbc")
                .options(**oracle_properties)
                .option("dbtable", self.source_table.table_full_name).load())

    def append_to_delta_table(self, df: DataFrame):
        if df.count() > 0:
            df.write.format("delta").mode("append").saveAsTable(
                f'{self.target_table.table_full_name}'
            )

    def overwrite_to_delta_table(self, df: DataFrame):
        df.write.format("delta").mode("overwrite").saveAsTable(
            f'{self.target_table.table_full_name}'
        )

    def save_to_delta_table(
        self,
        df: DataFrame,
        merge_sql_relative_path: str,
        parameter_map: dict
    ):
        temp_view_name = self.target_table.temp_view_name
        print(
            f"Saving data to {self.target_table.table_full_name} using temp view {temp_view_name}"
        )
        df.createOrReplaceTempView(temp_view_name)

        query = read_sql(merge_sql_relative_path, parameter_map)
        self.spark.sql(query)
        self.spark.sql(f"DROP VIEW IF EXISTS {temp_view_name}")

    def get_last_update_time(self) -> datetime.datetime:
        df = self.spark.sql(
            f"""
            SELECT last_api_call_timestamp
            FROM {self.process_table.table_full_name}
            WHERE process_name = '{self.source_table.table_full_name}'"""
        )
        updated_after = get_one_day_before()
        if df.count() > 0:
            updated_after = df.select("last_api_call_timestamp").first()[0]
        print(updated_after)
        return updated_after

    def save_last_update_time(self, last_update_time: datetime):
        parameter_map = {
            "table_name": self.process_table.table_full_name,
            "process_name": self.source_table.table_full_name,
            "last_api_call_timestamp": last_update_time
        }
        query = read_sql("merge_process.sql", parameter_map)
        self.spark.sql(query)

    def get_update_range(self):
        current_time = get_current_time()
        last_update_time = self.get_last_update_time()
        return UpdateRange(last_update_time, current_time)
