import datetime
import os
import re


def convert_datatime_to_str(date_time: datetime) -> str:
    return date_time.strftime('%Y-%m-%d %H:%M:%S')


def convert_datetime_to_int(date_time: datetime) -> int:
    return int(date_time.timestamp())


def convert_int_to_datetime(timestamp: int) -> datetime:
    return datetime.datetime.fromtimestamp(timestamp, datetime.timezone.utc)


def get_current_time() -> datetime:
    return datetime.datetime.now(datetime.timezone.utc).replace(microsecond=0)


def get_one_day_before() -> datetime:
    return (
        datetime.datetime.now(datetime.timezone.utc)
        .replace(microsecond=0)
        - datetime.timedelta(days=1)
    )


def read_sql(relative_path: str, parameter_map: dict) -> str:
    dir_path = re.split(r"replication", os.getcwd())[0]
    file_path = os.path.abspath(os.path.join(dir_path, "replication/sql", relative_path))
    with open(file_path, 'r') as file:
        sql = file.read().format_map(parameter_map)
        print(sql)
        return sql
