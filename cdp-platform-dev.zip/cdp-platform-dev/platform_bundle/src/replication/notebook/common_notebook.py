# Databricks notebook source
import os
import sys

common_path = os.path.abspath('../common')
if common_path not in sys.path:
    sys.path.append(common_path)

# COMMAND ----------
from data_structure import OracleTableName, DeltaTableName, UpdateRange


TARGET_CATALOG_NAME = spark.catalog.currentCatalog()
TARGET_SCHEMA_NAME = 'cdb'
PROCESS_TABLE = DeltaTableName(TARGET_CATALOG_NAME, TARGET_SCHEMA_NAME, "process")


# COMMAND ----------
def get_merge_base_map(delta_table: DeltaTableName) -> dict:
    return {
        'catalog_name': delta_table.catalog_name,
        'schema_name': delta_table.schema_name,
        'table_name': delta_table.table_name,
        'source_view': delta_table.temp_view_name
    }


def get_query_base_map(oracle_table: OracleTableName, update_range: UpdateRange) -> dict:
    return {
        'table_name': oracle_table.table_full_name,
        'column_name': oracle_table.column_name,
        'start_time': update_range.start_time,
        'end_time': update_range.end_time
    }


env = os.getenv('ENV')
if env == 'prd':
    CURVE_ID_LIST = [
        '115683560', '112770779', '112770751', '112770782', '112770783',
        '112770754', '115242131', '160199181', '117425209', '117973909',
        '145923085', '157397308', '157585146', '160133510', '157320518',
        '157392995', '158810364', '154200902', '141780268', '141985070',
        '106952677', '159115791', '157365878', '159427074', '159427035',
        '159427081', '159427022', '159427056', '159427052', '159427059',
        '159427030', '159427057', '159427025', '159427058', '159427060',
        '159427063', '159427043', '159427039', '159427084', '159427082',
        '159427051', '159427090', '159427031', '159427091', '159427064',
        '159427029', '159427070', '159427075', '159427027', '159427061',
        '159427036', '159427062', '159427032', '159427065', '159427033',
        '159427076', '159427046', '159427053', '159427044', '159427085',
        '159427083', '159427092', '159427086', '159427071', '159427047',
        '159427045', '159427087', '159427048', '159427026', '159427054',
        '159427088', '159427028', '159427067', '159427072', '159427066',
        '159427037'
    ]
else:
    CURVE_ID_LIST = [
        '106952677', '112770751', '112770754', '112770779', '112770782',
        '112770783', '115242131', '115683560', '117425209', '117973909',
        '141780268', '141985070', '145923085', '154200902', '157320518',
        '157365878', '157392995', '157397308', '157585146', '158810364'
    ]


def get_curve_id_list() -> list:
    return CURVE_ID_LIST


def get_curve_id_list_str() -> str:
    return ",".join(CURVE_ID_LIST)
