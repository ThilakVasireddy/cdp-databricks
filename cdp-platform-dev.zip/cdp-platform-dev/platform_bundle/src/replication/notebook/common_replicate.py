# Databricks notebook source
dbutils.widgets.text('schema_name', 'dw')
dbutils.widgets.text('table_name', 'DATA_TABLE')
dbutils.widgets.text('column_name', 'UPDATED_DATE')
dbutils.widgets.text('merge_sql_path', '')

# COMMAND ----------
schema_name = dbutils.widgets.get('schema_name')
table_name = dbutils.widgets.get('table_name')
column_name = dbutils.widgets.get('column_name')
merge_sql_path = dbutils.widgets.get('merge_sql_path')

# COMMAND ----------
%run ./common_notebook

# COMMAND ----------
from databricks_wrapper import DatabricksWrapper
oracle_table = OracleTableName(schema_name, table_name, column_name)
delta_table = DeltaTableName(TARGET_CATALOG_NAME, TARGET_SCHEMA_NAME, table_name)
databricks_wrapper = DatabricksWrapper(dbutils, spark, oracle_table, delta_table, PROCESS_TABLE)

update_range = databricks_wrapper.get_update_range()

# COMMAND ----------
query_map = get_query_base_map(oracle_table, update_range)
df_from_oracle = databricks_wrapper.extract_from_oracle_with_sql_path(
    'query_common.sql',
    query_map
)

merge_map = get_merge_base_map(delta_table)
databricks_wrapper.save_to_delta_table(df_from_oracle, merge_sql_path, merge_map)

databricks_wrapper.save_last_update_time(update_range.end_time)
