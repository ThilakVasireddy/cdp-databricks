# Databricks notebook source
dbutils.widgets.text('schema_name', 'dw')
dbutils.widgets.text('table_name', 'CURVE_DATA')

# COMMAND ----------
schema_name = dbutils.widgets.get('schema_name')
table_name = dbutils.widgets.get('table_name')

# COMMAND ----------
%run ./common_notebook

# COMMAND ----------
from databricks_wrapper import DatabricksWrapper
oracle_table = OracleTableName(schema_name, table_name, 'CHANGED_DATE')
delta_table = DeltaTableName(TARGET_CATALOG_NAME, TARGET_SCHEMA_NAME, table_name)
databricks_wrapper = DatabricksWrapper(dbutils, spark, oracle_table, delta_table, PROCESS_TABLE)

update_range = databricks_wrapper.get_update_range()

# COMMAND ----------
query_base_map = get_query_base_map(oracle_table, update_range)
merge_map = get_merge_base_map(delta_table)

# COMMAND ----------
from itertools import islice

# Helper function to chunk the curve_id list into groups of 10
def chunk_curve_ids(curve_id_list, chunk_size=10):
    it = iter(curve_id_list)
    while chunk := list(islice(it, chunk_size)):
        yield f"({', '.join(map(str, chunk))})"

for curve_id_chunk in chunk_curve_ids(get_curve_id_list(), 100):
    query_map = {'curve_id_chunk': curve_id_chunk, **query_base_map}
    curve_df = databricks_wrapper.extract_from_oracle_with_sql_path(
        "query_curve_data.sql",
        query_map
    )
    databricks_wrapper.save_to_delta_table(curve_df, "merge_curve_data.sql", merge_map)

databricks_wrapper.save_last_update_time(update_range.end_time)