# Databricks notebook source
%run ./common_notebook

# COMMAND ----------
from databricks_wrapper import DatabricksWrapper
oracle_table = OracleTableName('dw', 'CURVE_INFO', 'UPDATED_DATE')
delta_table = DeltaTableName(TARGET_CATALOG_NAME, TARGET_SCHEMA_NAME, 'CURVE_INFO')
databricks_wrapper = DatabricksWrapper(dbutils, spark, oracle_table, delta_table, PROCESS_TABLE)

update_range = databricks_wrapper.get_update_range()

# COMMAND ----------
curve_id_list_str = get_curve_id_list_str()
query_map = {
    'curve_id': curve_id_list_str
}
df_from_oracle = databricks_wrapper.extract_from_oracle_with_sql_path(
    'query_curve_info.sql',
    query_map
)

merge_map = get_merge_base_map(delta_table)
databricks_wrapper.save_to_delta_table(df_from_oracle, 'merge_curve_info.sql', merge_map)

databricks_wrapper.save_last_update_time(update_range.end_time)