# Databricks notebook source
import os
import sys


common_path = os.path.abspath('../common')
if common_path not in sys.path:
    sys.path.append(common_path)

sql_files = [
    # common
    "create_process.sql",

    # dw
    "create_curve.sql",
    "create_curve_data.sql",
    "create_curve_data_fc.sql",
    "create_curve_info.sql",
    "create_curve_type.sql",
    "create_data_table.sql",
    "create_load_set2_curve.sql",

    # meta
    "create_attribute.sql",
    "create_entity_name.sql",
    "create_entity_name_group.sql",
    "create_entity_name_language.sql",
    "create_entity_name_type.sql",
    "create_entity_type.sql",
    "create_hierarchies.sql",
    "create_hierarchy_data.sql",
    "create_levels.sql",
    "create_object_meta.sql",
    "create_object_type.sql",
    "create_verb.sql",
    "create_dimension_data.sql",

    # sources
    "create_dataset.sql",

    # common
    "create_safe_groups.sql",
    "create_safe_user.sql",
    "create_safe_user_groups.sql",

    # mule
    "create_matlab_model.sql",

    # cef_cnr
    "create_vessel.sql"
]

# COMMAND ----------
from replicate_utils import read_sql


catalog_name = spark.catalog.currentCatalog()
schema_name = 'cdb'
for sql_file in sql_files:
    sql = read_sql(sql_file, {'catalog_name': catalog_name, 'schema_name': schema_name})
    spark.sql(sql)
