# Databricks notebook source
%run ./common_notebook

# COMMAND ----------
from databricks_wrapper import DatabricksWrapper
oracle_table = OracleTableName('meta', 'OBJECT_META', 'UPDATED_DATE')
delta_table = DeltaTableName(TARGET_CATALOG_NAME, TARGET_SCHEMA_NAME, 'OBJECT_META')
databricks_wrapper = DatabricksWrapper(dbutils, spark, oracle_table, delta_table, PROCESS_TABLE)

update_range = databricks_wrapper.get_update_range()

# COMMAND ----------
query_base_map = get_query_base_map(oracle_table, update_range)
merge_map = get_merge_base_map(delta_table)

for a_curve_id in get_curve_id_list():
    query_map = {'curve_id': a_curve_id, **query_base_map}
    curve_df = databricks_wrapper.extract_from_oracle_with_sql_path(
        "query_object_meta.sql",
        query_map
    )
    databricks_wrapper.save_to_delta_table(curve_df, "merge_object_meta.sql", merge_map)

databricks_wrapper.save_last_update_time(update_range.end_time)