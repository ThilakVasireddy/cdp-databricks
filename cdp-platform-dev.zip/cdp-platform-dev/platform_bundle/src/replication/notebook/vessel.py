# Databricks notebook source
%run ./common_notebook

# COMMAND ----------
from databricks_wrapper import DatabricksWrapper
oracle_table = OracleTableName('cef_cnr', 'VESSEL', 'MODIFY_DATE')
delta_table = DeltaTableName(TARGET_CATALOG_NAME, TARGET_SCHEMA_NAME, 'VESSEL_PERM_IDS')
databricks_wrapper = DatabricksWrapper(dbutils, spark, oracle_table, delta_table, PROCESS_TABLE)

update_range = databricks_wrapper.get_update_range()
display(update_range)
# COMMAND ----------
query_map = get_query_base_map(oracle_table, update_range)

df_from_oracle = databricks_wrapper.extract_from_oracle_with_sql_path(
    'query_vessel.sql',
    query_map
)
display(df_from_oracle.count())
merge_map = get_merge_base_map(delta_table)
databricks_wrapper.save_to_delta_table(df_from_oracle, 'merge_vessel.sql', merge_map)

databricks_wrapper.save_last_update_time(update_range.end_time)