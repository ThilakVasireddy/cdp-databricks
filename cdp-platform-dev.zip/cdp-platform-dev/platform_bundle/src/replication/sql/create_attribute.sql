CREATE TABLE IF NOT EXISTS {catalog_name}.{schema_name}.ATTRIBUTE
(
    ID                          decimal(8,0),
    NAME                        varchar(50),
    DIMENSION_ID                decimal(8,0),
    SHORT_NAME                  varchar(25),
    DESCRIPTION                 varchar(500)
)
USING DELTA