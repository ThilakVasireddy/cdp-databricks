CREATE TABLE IF NOT EXISTS {catalog_name}.{schema_name}.CURVE
(
    ID                                                  decimal(38,0),
	NAME                                                varchar(200),
	DESCRIPTION                                         varchar(255),
	COMMENTS                                            varchar(1000),
	CURVE_TYPE_ID                                       decimal(38,0),
	DATA_TABLE_ID                                       decimal(38,0),
	TIMEZONE_ID                                         decimal(38,0),
	CREATED_DATE                                        timestamp,
	CREATED_BY                                          binary,
	CALENDAR_ID                                         decimal(38,0),
	RESOLUTION_ID                                       decimal(38,0),
	FORECAST_RESOLUTION_ID                              decimal(38,0),
	DEFAULT_INTERVAL_ID                                 decimal(38,0),
	STATUS_ID                                           decimal(38,0),
	UPDATED_DATE                                        timestamp,
	UPDATED_BY                                          binary,
	OBJECT_VERSION                                      decimal(38,0),
	LOCAL_TIMEZONE_ID                                   decimal(38,0),
	ORIGIN_TIMEZONE_ID                                  decimal(38,0)
)
USING DELTA