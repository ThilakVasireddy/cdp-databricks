CREATE TABLE IF NOT EXISTS {catalog_name}.{schema_name}.CURVE_DATA
(
    CURVE_ID                        decimal(38,0),
    FORECAST_DATE                   timestamp,
    VALUE_DATE                      timestamp,
    LOCAL_FORECAST_DATE             timestamp,
    LOCAL_VALUE_DATE                timestamp,
    VALUE                           double,
    CHANGED_DATE                    timestamp
)
USING DELTA
CLUSTER BY (FORECAST_DATE, VALUE_DATE);