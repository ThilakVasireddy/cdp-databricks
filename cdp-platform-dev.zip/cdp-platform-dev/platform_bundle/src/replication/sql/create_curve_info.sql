CREATE TABLE IF NOT EXISTS {catalog_name}.{schema_name}.CURVE_INFO
(
    CURVE_ID                        decimal(38,0),
    MAX_FORECAST_DATE               timestamp,
    MIN_FORECAST_DATE               timestamp,
	MAX_VALUE_DATE                  timestamp,
	MIN_VALUE_DATE                  timestamp,
	ROW_COUNT                       decimal(38,0),
	UPDATE_SCHEDULE_ID              decimal(38,0),
	LAST_UPDATED                    timestamp,
	MAX_ALLOWED_DATE                timestamp,
	MIN_ALLOWED_DATE                timestamp,
	MAX_OPERATION_TIMESTAMP         timestamp
)
USING DELTA