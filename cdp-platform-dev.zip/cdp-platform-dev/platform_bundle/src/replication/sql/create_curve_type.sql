CREATE TABLE IF NOT EXISTS {catalog_name}.{schema_name}.CURVE_TYPE
(
  ID                            decimal(38,0),
  NAME                          varchar(100),
  DESCRIPTION                   varchar(255),
  COMMENTS                      varchar(1000),
  USE_FORECAST_DATE             char(1),
  CREATED_DATE                  timestamp,
  CREATED_BY                    binary,
  DEFAULT_DATA_TABLE_ID         decimal(38,0),
  DEFAULT_PROCESS_CHAIN_ID      decimal(38,0),
  UPDATED_DATE                  timestamp,
  UPDATED_BY                    binary,
  OBJECT_VERSION                decimal(38,0),
  IS_TEXT                       varchar(1)
)
USING DELTA