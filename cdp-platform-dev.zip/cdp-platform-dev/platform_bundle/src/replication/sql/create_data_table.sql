CREATE TABLE IF NOT EXISTS {catalog_name}.{schema_name}.DATA_TABLE
(
  ID                            decimal(38,0),
  NAME                          varchar(100),
  DESCRIPTION                   varchar(255),
  TABLE_NAME                    varchar(100),
  DATABASE_NAME                 varchar(100),
  SCHEMA_NAME                   varchar(100),
  COMMENTS                      varchar(1000),
  NO_ROWS                       decimal(38,0),
  CREATED_DATE                  timestamp,
  CREATED_BY                    binary,
  CURVE_TYPE_ID                 decimal(38,0),
  STATUS_ID                     decimal(38,0),
  UPDATED_DATE                  timestamp,
  UPDATED_BY                    binary,
  OBJECT_VERSION                decimal(38,0),
  VIRTUAL                       varchar(1)
)
USING DELTA