CREATE TABLE IF NOT EXISTS {catalog_name}.{schema_name}.DATASET
(
    ID                          long,
    NAME                        string,
    SET_TYPE_ID                 long,
    DATA_TYPE_ID                long,
    INPUT_SYSTEM                string,
    CREATED_DATE                timestamp,
    UPDATED_DATE                timestamp,
    CREATED_BY                  binary,
    UPDATED_BY                  binary,
    OBJECT_VERSION              long,
    EXTERNAL_SET_ID             string
)
USING DELTA