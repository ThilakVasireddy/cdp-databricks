CREATE TABLE IF NOT EXISTS {catalog_name}.{schema_name}.DIMENSION_DATA
(
    ELEMENT_ID                              long,
    NAME                                    string,
    DESCRIPTION                             string,
    SHORT_NAME                              string,
    ABBREVIATION                            string,
    COMMENTS                                string,
    SOURCE                                  string,
    STANDARD_VALUE                          string,
    STANDARD_REFERENCE                      string,
    LEVEL_ID                                long,
    CREATED_BY                              string,
    CREATED_DATE                            timestamp,
    SORT_COLUMN                             long,
    STATUS_ID                               long,
    DIMENSION_ID                            long,
    CHANGED_DATE                            timestamp,
    CHANGED_BY                              string,
    INCLUDE_IN_EXTERNAL_DICTIONARY          string,
    SHORT_DESCRIPTION                       string,
    RESPONSIBLE_ID                          long,
    PERM_ID                                 long,
    RIC                                     string
)
USING DELTA