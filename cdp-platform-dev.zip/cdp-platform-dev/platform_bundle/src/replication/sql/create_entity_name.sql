CREATE TABLE IF NOT EXISTS {catalog_name}.{schema_name}.ENTITY_NAME
(
    ID                          decimal(38,0),
    ENTITY_ID                   decimal(38,0),
    ENTITY_TYPE_ID              decimal(38,0),
    TYPE_ID                     decimal(38,0),
    LANGUAGE_ID                 decimal(38,0),
    VALUE                       varchar(4000),
    IS_DEFAULT                  varchar(1),
    SORT_ORDER                  decimal(38,0),
    VALID_FROM_DATE             timestamp,
    VALID_TO_DATE               timestamp,
    REPLACED_BY                 decimal(38,0),
    REASON                      varchar(1),
    COMMENTS                    varchar(200),
    CREATED_DATE                timestamp,
    CREATED_BY                  binary,
    UPDATED_DATE                timestamp,
    UPDATED_BY                  binary,
    OBJECT_VERSION              decimal(38,0),
    GROUP_ID                    decimal(38,0)
)
USING DELTA