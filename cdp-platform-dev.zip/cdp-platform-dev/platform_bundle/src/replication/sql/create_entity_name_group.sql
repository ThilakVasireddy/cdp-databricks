CREATE TABLE IF NOT EXISTS {catalog_name}.{schema_name}.ENTITY_NAME_GROUP
(
    ID                          decimal(38,0),
    NAME                        varchar(100),
    DESCRIPTION                 varchar(1000),
    CREATED_DATE                timestamp,
    CREATED_BY                  binary,
    UPDATED_DATE                timestamp,
    UPDATED_BY                  binary,
    OBJECT_VERSION              decimal(38,0)
)