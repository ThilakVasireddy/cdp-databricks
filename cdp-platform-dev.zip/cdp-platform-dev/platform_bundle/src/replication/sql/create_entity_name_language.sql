CREATE TABLE IF NOT EXISTS {catalog_name}.{schema_name}.ENTITY_NAME_LANGUAGE
(
    ID                          int,
    CODE                        varchar(3),
    STANDARD_REFERENCE          varchar(50),
    NAME                        varchar(100),
    IS_DEFAULT                  varchar(1),
    CREATED_DATE                timestamp,
    CREATED_BY                  binary,
    UPDATED_DATE                timestamp,
    UPDATED_BY                  binary,
    OBJECT_VERSION              decimal(38,0)
)