CREATE TABLE IF NOT EXISTS {catalog_name}.{schema_name}.ENTITY_NAME_TYPE
(
    ID                          decimal(38,0),
    NAME                        varchar(50),
    DESCRIPTION                 varchar(200),
    CREATED_DATE                timestamp,
    CREATED_BY                  binary,
    UPDATED_DATE                timestamp,
    UPDATED_BY                  binary,
    OBJECT_VERSION              decimal(38,0)
)
USING DELTA