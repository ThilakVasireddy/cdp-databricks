CREATE TABLE IF NOT EXISTS {catalog_name}.{schema_name}.ENTITY_TYPE
(
    ID                          decimal(38,0),
    NAME                        varchar(100),
    TABLE_NAME                  varchar(100),
    DESCRIPTION                 varchar(300),
    SHORT_NAME                  varchar(50)
)
USING DELTA