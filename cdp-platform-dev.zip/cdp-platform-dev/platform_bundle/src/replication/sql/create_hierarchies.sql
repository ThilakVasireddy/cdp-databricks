CREATE TABLE IF NOT EXISTS {catalog_name}.{schema_name}.HIERARCHIES
(
    ID                          decimal(38,0),
    NAME                        varchar(100),
    DESCRIPTION                 varchar(255),
    SHORT_NAME                  varchar(50),
    ABBREVIATION                varchar(20),
    COMMENTS                    varchar(1000),
    STANDARD                    char(1),
    CREATED_BY                  varchar(100),
    CREATED_DATE                timestamp,
    DIMENSION_ID                decimal(38,0),
    SORT_COLUMN                 decimal(38,0)
)
USING DELTA