CREATE TABLE IF NOT EXISTS {catalog_name}.{schema_name}.HIERARCHY_DATA
(
    HIERARCHY_ID                decimal(38,0),
    PARENT_ID                   decimal(38,0),
    CHILD_ID                    decimal(38,0),
    PATH                        varchar(512),
    NODE_ID                     decimal(38,0),
    DIMENSION_ID                decimal(38,0)
)
USING DELTA