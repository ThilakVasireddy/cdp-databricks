CREATE TABLE IF NOT EXISTS {catalog_name}.{schema_name}.LOAD_SET2_CURVE
(
    ID                  decimal(38,0),
	CURVE_ID            decimal(38,0),
	LOAD_SET_ID         decimal(38,0),
	EXTERNAL_ID         varchar(255),
	EXTERNAL_NAME       varchar(255),
	AUTO_TAGGED         decimal(38,0),
	AUTO_TAG_ERROR      decimal(38,0),
	STATUS_ID           decimal(38,0),
	LOG_LEVEL           decimal(38,0),
	CHAIN_ID            decimal(38,0),
	EXPORT_ENABLED      decimal(38,0),
	CREATED_DATE        timestamp,
	CREATED_BY          binary,
	UPDATED_DATE        timestamp,
	UPDATED_BY          binary,
	OBJECT_VERSION      decimal(38,0),
	META_STR            varchar(255)
)
USING DELTA