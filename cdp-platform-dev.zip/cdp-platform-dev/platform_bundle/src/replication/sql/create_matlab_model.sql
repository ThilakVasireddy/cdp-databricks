CREATE TABLE IF NOT EXISTS {catalog_name}.{schema_name}.MATLAB_MODEL
(
    ID                      long,
    MODEL_NAME              string,
    MODEL_RUN               string,
    MESSAGE_ID              long,
    STATUS_ID               long,
    CREATED_DATE            timestamp,
    CREATED_BY              binary,
    UPDATED_DATE            timestamp,
    UPDATED_BY              binary,
    OBJECT_VERSION          long,
    DESCRIPTION             string,
    PROFILING               long,
    NOTIFY_GROUP_ID         long
)
USING DELTA