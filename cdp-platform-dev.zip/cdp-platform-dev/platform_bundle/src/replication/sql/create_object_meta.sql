CREATE TABLE IF NOT EXISTS {catalog_name}.{schema_name}.OBJECT_META
(
    META_ID                         decimal(38,0),
    DIMENSION_ID                    decimal(38,0),
    OBJECT_ID                       decimal(38,0),
    SEARCH_TEXT                     varchar(4000),
    ATTRIBUTE_ID                    decimal(38,0),
    FREE_TEXT                       varchar(100),
    OBJECT_TYPE_ID                  decimal(38,0),
    VERB_ID                         decimal(38,0),
    ID                              decimal(38,0),
    ELEMENT_NAME                    varchar(1024),
    OBJECT_NAME                     varchar(1024),
    CREATED_DATE                    timestamp,
    CREATED_BY                      binary,
    UPDATED_DATE                    timestamp,
    UPDATED_BY                      binary,
    OBJECT_VERSION                  decimal(38,0),
    STATUS_ID                       decimal(38,0)
)
USING DELTA