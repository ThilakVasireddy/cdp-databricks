CREATE TABLE IF NOT EXISTS {catalog_name}.{schema_name}.OBJECT_TYPE
(
    ID                          decimal(38,0),
    NAME                        varchar(100),
    DESCRIPTION                 varchar(255),
    COMMENTS                    varchar(1000),
    CREATED_DATE                timestamp,
    CREATED_BY                  binary,
    UPDATED_DATE                timestamp,
    UPDATED_BY                  binary,
    OBJECT_VERSION              decimal(38,0),
    ID_COLUMN_NAME              varchar(100),
    DISPLAY_NAME                varchar(100),
    PLURAL_DISPLAY_NAME         varchar(100),
    NAME_COLUMN_NAME            varchar(100),
    ENTITY                      decimal(38,0),
    TABLE_NAME                  varchar(100),
    SCHEMA                      varchar(100)
)
USING DELTA