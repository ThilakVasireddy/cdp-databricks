CREATE TABLE IF NOT EXISTS {catalog_name}.{schema_name}.process
(
    process_name              STRING,
    last_api_call_timestamp   TIMESTAMP
)
USING DELTA
CLUSTER BY (process_name)