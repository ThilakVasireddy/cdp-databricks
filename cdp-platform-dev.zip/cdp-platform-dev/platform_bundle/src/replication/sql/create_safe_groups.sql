CREATE TABLE IF NOT EXISTS {catalog_name}.{schema_name}.SAFE_GROUPS
(
    ID                          long,
    NAME                        string,
    DESCRIPTION                 string,
    USER_LEVEL                  long,
    CREATED_DATE                timestamp,
    CREATED_BY                  binary,
    UPDATED_DATE                timestamp,
    UPDATED_BY                  binary,
    OBJECT_VERSION              int,
    PARENT_ID                   long,
    DISPLAY_NAME                string,
    GROUP_OWNER                 string,
    PERMISSION_LEVEL            string,
    PERMITTED_GROUP_IDS         string
)
USING DELTA