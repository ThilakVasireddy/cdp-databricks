CREATE TABLE IF NOT EXISTS {catalog_name}.{schema_name}.SAFE_USER
(
    ID                          binary,
    SAFE_UID                    string,
    FIRST_NAME                  string,
    LAST_NAME                   string,
    EMAIL                       string,
    TR_AD_USER_NAME             string,
    PC_AD_USER_NAME             string,
    CREATED_DATE                timestamp,
    CREATED_BY                  binary,
    UPDATED_DATE                timestamp,
    UPDATED_BY                  binary,
    OBJECT_VERSION              int,
    LAST_LOGIN                  timestamp
)
USING DELTA