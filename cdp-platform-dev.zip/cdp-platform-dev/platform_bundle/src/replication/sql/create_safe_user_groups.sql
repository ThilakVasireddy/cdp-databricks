CREATE TABLE IF NOT EXISTS {catalog_name}.{schema_name}.SAFE_USER_GROUPS
(
    ID                          binary,
    SAFE_GROUPS_ID              long,
    CREATED_DATE                timestamp,
    CREATED_BY                  binary,
    UPDATED_DATE                timestamp,
    UPDATED_BY                  binary,
    OBJECT_VERSION              int
)
USING DELTA