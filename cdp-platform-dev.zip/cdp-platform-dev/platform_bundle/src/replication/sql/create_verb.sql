CREATE TABLE IF NOT EXISTS {catalog_name}.{schema_name}.VERB
(
    ID                          decimal(8,0),
    NAME                        varchar(50)
)
USING DELTA