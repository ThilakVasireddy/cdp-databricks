CREATE TABLE IF NOT EXISTS {catalog_name}.{schema_name}.VESSEL_PERM_IDS
(
    VES_ID              decimal(38,0),
	VES_NAME            varchar(300),
	PERM_ID             decimal(38,0),
	ASSET_RIC           varchar(17),
	IMO                 varchar(8),
	MMSI                decimal(15,0),
	VT_BRL_SHIP_ID      decimal(38,0),
	VT_SHIP_ID          decimal(38,0),
    VT_SHIP_TYPE_ID     decimal(38,0),
	CREATE_DATE        timestamp,
	CREATE_BY          varchar(20),
	MODIFY_DATE         timestamp,
	MODIFY_BY           varchar(30)
)
USING DELTA