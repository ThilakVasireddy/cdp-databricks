MERGE INTO {catalog_name}.{schema_name}.{table_name} AS target
USING {source_view} AS source
ON target.ID = source.ID
WHEN MATCHED THEN
UPDATE SET
    target.NAME                         = source.NAME,
    target.DIMENSION_ID                 = source.DIMENSION_ID,
    target.SHORT_NAME                   = source.SHORT_NAME,
    target.DESCRIPTION                  = source.DESCRIPTION
WHEN NOT MATCHED THEN
INSERT
(
    ID,
    NAME,
    DIMENSION_ID,
    SHORT_NAME,
    DESCRIPTION
)
VALUES
(
    source.ID,
    source.NAME,
    source.DIMENSION_ID,
    source.SHORT_NAME,
    source.DESCRIPTION
)