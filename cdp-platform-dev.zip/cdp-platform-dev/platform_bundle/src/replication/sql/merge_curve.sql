MERGE INTO {catalog_name}.{schema_name}.CURVE AS target
USING {source_view} AS source
ON target.ID = source.ID
WHEN MATCHED THEN
UPDATE SET
    target.NAME                     = source.NAME,
    target.DESCRIPTION              = source.DESCRIPTION,
    target.COMMENTS                 = source.COMMENTS,
    target.CURVE_TYPE_ID            = source.CURVE_TYPE_ID,
    target.DATA_TABLE_ID            = source.DATA_TABLE_ID,
    target.TIMEZONE_ID              = source.TIMEZONE_ID,
    target.CREATED_DATE             = source.CREATED_DATE,
    target.CREATED_BY               = source.CREATED_BY,
    target.CALENDAR_ID              = source.CALENDAR_ID,
    target.RESOLUTION_ID            = source.RESOLUTION_ID,
    target.FORECAST_RESOLUTION_ID   = source.FORECAST_RESOLUTION_ID,
    target.DEFAULT_INTERVAL_ID      = source.DEFAULT_INTERVAL_ID,
    target.STATUS_ID                = source.STATUS_ID,
    target.UPDATED_DATE             = source.UPDATED_DATE,
    target.UPDATED_BY               = source.UPDATED_BY,
    target.OBJECT_VERSION           = source.OBJECT_VERSION,
    target.LOCAL_TIMEZONE_ID        = source.LOCAL_TIMEZONE_ID,
    target.ORIGIN_TIMEZONE_ID       = source.ORIGIN_TIMEZONE_ID
WHEN NOT MATCHED THEN
INSERT
(
    ID,
    NAME,
    DESCRIPTION,
    COMMENTS,
    CURVE_TYPE_ID,
    DATA_TABLE_ID,
    TIMEZONE_ID,
    CREATED_DATE,
    CREATED_BY,
    CALENDAR_ID,
    RESOLUTION_ID,
    FORECAST_RESOLUTION_ID,
    DEFAULT_INTERVAL_ID,
    STATUS_ID,
    UPDATED_DATE,
    UPDATED_BY,
    OBJECT_VERSION,
    LOCAL_TIMEZONE_ID,
    ORIGIN_TIMEZONE_ID
)
VALUES
(
    source.ID,
    source.NAME,
    source.DESCRIPTION,
    source.COMMENTS,
    source.CURVE_TYPE_ID,
    source.DATA_TABLE_ID,
    source.TIMEZONE_ID,
    source.CREATED_DATE,
    source.CREATED_BY,
    source.CALENDAR_ID,
    source.RESOLUTION_ID,
    source.FORECAST_RESOLUTION_ID,
    source.DEFAULT_INTERVAL_ID,
    source.STATUS_ID,
    source.UPDATED_DATE,
    source.UPDATED_BY,
    source.OBJECT_VERSION,
    source.LOCAL_TIMEZONE_ID,
    source.ORIGIN_TIMEZONE_ID
)