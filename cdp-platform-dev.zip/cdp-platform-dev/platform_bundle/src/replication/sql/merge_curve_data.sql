MERGE INTO {catalog_name}.{schema_name}.{table_name} AS target
USING {source_view} AS source
ON target.CURVE_ID = source.CURVE_ID
    AND target.FORECAST_DATE = source.FORECAST_DATE
    AND target.VALUE_DATE == source.VALUE_DATE
WHEN MATCHED THEN
UPDATE SET
    target.LOCAL_FORECAST_DATE                     = source.LOCAL_FORECAST_DATE,
    target.LOCAL_VALUE_DATE                        = source.LOCAL_VALUE_DATE,
    target.VALUE                                   = source.VALUE,
    target.CHANGED_DATE                            = source.CHANGED_DATE
WHEN NOT MATCHED THEN
INSERT
(
    CURVE_ID,
    FORECAST_DATE,
    VALUE_DATE,
    LOCAL_FORECAST_DATE,
    LOCAL_VALUE_DATE,
    VALUE,
    CHANGED_DATE
)
VALUES
(
    source.CURVE_ID,
    source.FORECAST_DATE,
    source.VALUE_DATE,
    source.LOCAL_FORECAST_DATE,
    source.LOCAL_VALUE_DATE,
    source.VALUE,
    source.CHANGED_DATE
)