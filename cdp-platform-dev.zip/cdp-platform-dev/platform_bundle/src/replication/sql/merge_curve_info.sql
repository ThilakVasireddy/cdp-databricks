MERGE INTO {catalog_name}.{schema_name}.CURVE_INFO AS target
USING {source_view} AS source
ON target.CURVE_ID = source.CURVE_ID
WHEN MATCHED THEN
UPDATE SET
    target.MAX_FORECAST_DATE                        = source.MAX_FORECAST_DATE,
    target.MIN_FORECAST_DATE                        = source.MIN_FORECAST_DATE,
    target.MAX_VALUE_DATE                           = source.MAX_VALUE_DATE,
    target.MIN_VALUE_DATE                           = source.MIN_VALUE_DATE,
    target.ROW_COUNT                                = source.ROW_COUNT,
    target.UPDATE_SCHEDULE_ID                       = source.UPDATE_SCHEDULE_ID,
    target.LAST_UPDATED                             = source.LAST_UPDATED,
    target.MAX_ALLOWED_DATE                         = source.MAX_ALLOWED_DATE,
    target.MIN_ALLOWED_DATE                         = source.MIN_ALLOWED_DATE,
    target.MAX_OPERATION_TIMESTAMP                  = source.MAX_OPERATION_TIMESTAMP
WHEN NOT MATCHED THEN
INSERT
(
    CURVE_ID,
    MAX_FORECAST_DATE,
    MIN_FORECAST_DATE,
    MAX_VALUE_DATE,
    MIN_VALUE_DATE,
    ROW_COUNT,
    UPDATE_SCHEDULE_ID,
    LAST_UPDATED,
    MAX_ALLOWED_DATE,
    MIN_ALLOWED_DATE,
    MAX_OPERATION_TIMESTAMP
)
VALUES
(
    source.CURVE_ID,
    source.MAX_FORECAST_DATE,
    source.MIN_FORECAST_DATE,
    source.MAX_VALUE_DATE,
    source.MIN_VALUE_DATE,
    source.ROW_COUNT,
    source.UPDATE_SCHEDULE_ID,
    source.LAST_UPDATED,
    source.MAX_ALLOWED_DATE,
    source.MIN_ALLOWED_DATE,
    source.MAX_OPERATION_TIMESTAMP
)