MERGE INTO {catalog_name}.{schema_name}.CURVE_TYPE AS target
USING {source_view} AS source
ON target.ID = source.ID AND target.NAME = source.NAME
WHEN MATCHED THEN
UPDATE SET
    target.DESCRIPTION                  = source.DESCRIPTION,
    target.COMMENTS                     = source.COMMENTS,
    target.USE_FORECAST_DATE            = source.USE_FORECAST_DATE,
    target.CREATED_DATE                 = source.CREATED_DATE,
    target.CREATED_BY                   = source.CREATED_BY,
    target.DEFAULT_DATA_TABLE_ID        = source.DEFAULT_DATA_TABLE_ID,
    target.DEFAULT_PROCESS_CHAIN_ID     = source.DEFAULT_PROCESS_CHAIN_ID,
    target.UPDATED_DATE                 = source.UPDATED_DATE,
    target.UPDATED_BY                   = source.UPDATED_BY,
    target.OBJECT_VERSION               = source.OBJECT_VERSION,
    target.IS_TEXT                      = source.IS_TEXT
WHEN NOT MATCHED THEN
INSERT (
    ID, 
    NAME, 
    DESCRIPTION, 
    COMMENTS, 
    USE_FORECAST_DATE, 
    CREATED_DATE, 
    CREATED_BY, 
    DEFAULT_DATA_TABLE_ID, 
    DEFAULT_PROCESS_CHAIN_ID, 
    UPDATED_DATE, 
    UPDATED_BY, 
    OBJECT_VERSION, 
    IS_TEXT
)
VALUES
(
    source.ID, 
    source.NAME, 
    source.DESCRIPTION, 
    source.COMMENTS, 
    source.USE_FORECAST_DATE, 
    source.CREATED_DATE, 
    source.CREATED_BY, 
    source.DEFAULT_DATA_TABLE_ID, 
    source.DEFAULT_PROCESS_CHAIN_ID, 
    source.UPDATED_DATE, 
    source.UPDATED_BY, 
    source.OBJECT_VERSION, 
    source.IS_TEXT
)