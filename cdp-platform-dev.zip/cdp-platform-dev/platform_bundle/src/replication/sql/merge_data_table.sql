MERGE INTO {catalog_name}.{schema_name}.DATA_TABLE AS target
USING {source_view} AS source
ON target.ID = source.ID AND target.NAME = source.NAME
WHEN MATCHED THEN
UPDATE SET
    target.DESCRIPTION                  = source.DESCRIPTION,
    target.TABLE_NAME                   = source.TABLE_NAME,
    target.DATABASE_NAME                = source.DATABASE_NAME,
    target.SCHEMA_NAME                  = source.SCHEMA_NAME,
    target.COMMENTS                     = source.COMMENTS,
    target.NO_ROWS                      = source.NO_ROWS,
    target.CREATED_DATE                 = source.CREATED_DATE,
    target.CREATED_BY                   = source.CREATED_BY,
    target.CURVE_TYPE_ID                = source.CURVE_TYPE_ID,
    target.STATUS_ID                    = source.STATUS_ID,
    target.UPDATED_DATE                 = source.UPDATED_DATE,
    target.UPDATED_BY                   = source.UPDATED_BY,
    target.OBJECT_VERSION               = source.OBJECT_VERSION,
    target.VIRTUAL                      = source.VIRTUAL
WHEN NOT MATCHED THEN
INSERT
(
    ID,
    NAME,
    DESCRIPTION,
    TABLE_NAME,
    DATABASE_NAME,
    SCHEMA_NAME,
    COMMENTS,
    NO_ROWS,
    CREATED_DATE,
    CREATED_BY,
    CURVE_TYPE_ID,
    STATUS_ID,
    UPDATED_DATE,
    UPDATED_BY,
    OBJECT_VERSION,
    VIRTUAL
)
VALUES
(
    source.ID,
    source.NAME,
    source.DESCRIPTION,
    source.TABLE_NAME,
    source.DATABASE_NAME,
    source.SCHEMA_NAME,
    source.COMMENTS,
    source.NO_ROWS,
    source.CREATED_DATE,
    source.CREATED_BY,
    source.CURVE_TYPE_ID,
    source.STATUS_ID,
    source.UPDATED_DATE,
    source.UPDATED_BY,
    source.OBJECT_VERSION,
    source.VIRTUAL
);