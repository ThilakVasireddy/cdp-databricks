MERGE INTO {catalog_name}.{schema_name}.DATASET AS target
USING {source_view} AS source
ON target.ID = source.ID
WHEN MATCHED THEN
UPDATE SET
    target.NAME             = source.NAME,
    target.SET_TYPE_ID      = source.SET_TYPE_ID,
    target.DATA_TYPE_ID     = source.DATA_TYPE_ID,
    target.INPUT_SYSTEM     = source.INPUT_SYSTEM,
    target.CREATED_DATE     = source.CREATED_DATE,
    target.UPDATED_DATE     = source.UPDATED_DATE,
    target.CREATED_BY       = source.CREATED_BY,
    target.UPDATED_BY       = source.UPDATED_BY,
    target.OBJECT_VERSION   = source.OBJECT_VERSION,
    target.EXTERNAL_SET_ID  = source.EXTERNAL_SET_ID
WHEN NOT MATCHED THEN
INSERT 
(
    ID,
    NAME,
    SET_TYPE_ID,
    DATA_TYPE_ID,
    INPUT_SYSTEM,
    CREATED_DATE,
    UPDATED_DATE,
    CREATED_BY,
    UPDATED_BY,
    OBJECT_VERSION,
    EXTERNAL_SET_ID
)
VALUES 
(
    source.ID,
    source.NAME,
    source.SET_TYPE_ID,
    source.DATA_TYPE_ID,
    source.INPUT_SYSTEM,
    source.CREATED_DATE,
    source.UPDATED_DATE,
    source.CREATED_BY,
    source.UPDATED_BY,
    source.OBJECT_VERSION,
    source.EXTERNAL_SET_ID
);