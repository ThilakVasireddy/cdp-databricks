MERGE INTO {catalog_name}.{schema_name}.DIMENSION_DATA AS target
USING {source_view} AS source
ON target.ELEMENT_ID = source.ELEMENT_ID AND target.DIMENSION_ID = source.DIMENSION_ID
WHEN MATCHED THEN
UPDATE SET
    target.NAME                                 = source.NAME,
    target.DESCRIPTION                          = source.DESCRIPTION,
    target.SHORT_NAME                           = source.SHORT_NAME,
    target.ABBREVIATION                         = source.ABBREVIATION,
    target.COMMENTS                             = source.COMMENTS,
    target.SOURCE                               = source.SOURCE,
    target.STANDARD_VALUE                       = source.STANDARD_VALUE,
    target.STANDARD_REFERENCE                   = source.STANDARD_REFERENCE,
    target.LEVEL_ID                             = source.LEVEL_ID,
    target.CREATED_BY                           = source.CREATED_BY,
    target.CREATED_DATE                         = source.CREATED_DATE,
    target.SORT_COLUMN                          = source.SORT_COLUMN,
    target.STATUS_ID                            = source.STATUS_ID,
    target.CHANGED_DATE                         = source.CHANGED_DATE,
    target.CHANGED_BY                           = source.CHANGED_BY,
    target.INCLUDE_IN_EXTERNAL_DICTIONARY       = source.INCLUDE_IN_EXTERNAL_DICTIONARY,
    target.SHORT_DESCRIPTION                    = source.SHORT_DESCRIPTION,
    target.RESPONSIBLE_ID                       = source.RESPONSIBLE_ID,
    target.PERM_ID                              = source.PERM_ID,
    target.RIC                                  = source.RIC
WHEN NOT MATCHED THEN
INSERT
(
    ELEMENT_ID,
    NAME,
    DESCRIPTION,
    SHORT_NAME,
    ABBREVIATION,
    COMMENTS,
    SOURCE,
    STANDARD_VALUE,
    STANDARD_REFERENCE,
    LEVEL_ID,
    CREATED_BY,
    CREATED_DATE,
    SORT_COLUMN,
    STATUS_ID,
    DIMENSION_ID,
    CHANGED_DATE,
    CHANGED_BY,
    INCLUDE_IN_EXTERNAL_DICTIONARY,
    SHORT_DESCRIPTION,
    RESPONSIBLE_ID,
    PERM_ID,
    RIC
)
VALUES
(
    source.ELEMENT_ID,
    source.NAME,
    source.DESCRIPTION,
    source.SHORT_NAME,
    source.ABBREVIATION,
    source.COMMENTS,
    source.SOURCE,
    source.STANDARD_VALUE,
    source.STANDARD_REFERENCE,
    source.LEVEL_ID,
    source.CREATED_BY,
    source.CREATED_DATE,
    source.SORT_COLUMN,
    source.STATUS_ID,
    source.DIMENSION_ID,
    source.CHANGED_DATE,
    source.CHANGED_BY,
    source.INCLUDE_IN_EXTERNAL_DICTIONARY,
    source.SHORT_DESCRIPTION,
    source.RESPONSIBLE_ID,
    source.PERM_ID,
    source.RIC
)