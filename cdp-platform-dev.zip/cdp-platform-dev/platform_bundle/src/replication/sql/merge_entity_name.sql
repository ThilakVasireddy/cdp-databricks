MERGE INTO {catalog_name}.{schema_name}.{table_name} AS target
USING {source_view} AS source
ON target.ID = source.ID
WHEN MATCHED THEN
UPDATE SET
    target.ENTITY_ID                  = source.ENTITY_ID,
    target.ENTITY_TYPE_ID             = source.ENTITY_TYPE_ID,
    target.TYPE_ID                    = source.TYPE_ID,
    target.LANGUAGE_ID                = source.LANGUAGE_ID,
    target.VALUE                      = source.VALUE,
    target.IS_DEFAULT                 = source.IS_DEFAULT,
    target.SORT_ORDER                 = source.SORT_ORDER,
    target.VALID_FROM_DATE            = source.VALID_FROM_DATE,
    target.VALID_TO_DATE              = source.VALID_TO_DATE,
    target.REPLACED_BY                = source.REPLACED_BY,
    target.REASON                     = source.REASON,
    target.COMMENTS                   = source.COMMENTS,
    target.CREATED_DATE               = source.CREATED_DATE,
    target.CREATED_BY                 = source.CREATED_BY,
    target.UPDATED_DATE               = source.UPDATED_DATE,
    target.UPDATED_BY                 = source.UPDATED_BY,
    target.OBJECT_VERSION             = source.OBJECT_VERSION,
    target.GROUP_ID                   = source.GROUP_ID
WHEN NOT MATCHED THEN
INSERT
(
    ID,
    ENTITY_ID,
    ENTITY_TYPE_ID,
    TYPE_ID,
    LANGUAGE_ID,
    VALUE,
    IS_DEFAULT,
    SORT_ORDER,
    VALID_FROM_DATE,
    VALID_TO_DATE,
    REPLACED_BY,
    REASON,
    COMMENTS,
    CREATED_DATE,
    CREATED_BY,
    UPDATED_DATE,
    UPDATED_BY,
    OBJECT_VERSION,
    GROUP_ID
)
VALUES
(
    source.ID,
    source.ENTITY_ID,
    source.ENTITY_TYPE_ID,
    source.TYPE_ID,
    source.LANGUAGE_ID,
    source.VALUE,
    source.IS_DEFAULT,
    source.SORT_ORDER,
    source.VALID_FROM_DATE,
    source.VALID_TO_DATE,
    source.REPLACED_BY,
    source.REASON,
    source.COMMENTS,
    source.CREATED_DATE,
    source.CREATED_BY,
    source.UPDATED_DATE,
    source.UPDATED_BY,
    source.OBJECT_VERSION,
    source.GROUP_ID
)