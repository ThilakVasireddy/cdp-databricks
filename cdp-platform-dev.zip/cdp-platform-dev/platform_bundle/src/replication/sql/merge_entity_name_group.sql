MERGE INTO {catalog_name}.{schema_name}.{table_name} AS target
USING {source_view} AS source
ON target.ID = source.ID
WHEN MATCHED THEN
UPDATE SET
    target.NAME                         = source.NAME,
    target.DESCRIPTION                  = source.DESCRIPTION,
    target.CREATED_DATE                 = source.CREATED_DATE,
    target.CREATED_BY                   = source.CREATED_BY,
    target.UPDATED_DATE                 = source.UPDATED_DATE,
    target.UPDATED_BY                   = source.UPDATED_BY,
    target.OBJECT_VERSION               = source.OBJECT_VERSION
WHEN NOT MATCHED THEN
INSERT
(
    ID,
    NAME,
    DESCRIPTION,
    CREATED_DATE,
    CREATED_BY,
    UPDATED_DATE,
    UPDATED_BY,
    OBJECT_VERSION
)
VALUES
(
    source.ID,
    source.NAME,
    source.DESCRIPTION,
    source.CREATED_DATE,
    source.CREATED_BY,
    source.UPDATED_DATE,
    source.UPDATED_BY,
    source.OBJECT_VERSION
)