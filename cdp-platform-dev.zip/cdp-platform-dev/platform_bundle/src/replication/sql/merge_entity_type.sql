MERGE INTO {catalog_name}.{schema_name}.{table_name} AS target
USING {source_view} AS source
ON target.ID = source.ID
WHEN MATCHED THEN
UPDATE SET
    target.NAME                         = source.NAME,
    target.TABLE_NAME                   = source.TABLE_NAME,
    target.DESCRIPTION                  = source.DESCRIPTION,
    target.SHORT_NAME                   = source.SHORT_NAME
WHEN NOT MATCHED THEN
INSERT
(
    ID,
    NAME,
    TABLE_NAME,
    DESCRIPTION,
    SHORT_NAME
)
VALUES
(
    source.ID,
    source.NAME,
    source.TABLE_NAME,
    source.DESCRIPTION,
    source.SHORT_NAME
)