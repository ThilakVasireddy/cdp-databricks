MERGE INTO {catalog_name}.{schema_name}.{table_name} AS target
USING {source_view} AS source
ON target.ID = source.ID
WHEN MATCHED THEN
UPDATE SET
    target.NAME                         = source.NAME,
    target.DESCRIPTION                  = source.DESCRIPTION,
    target.SHORT_NAME                   = source.SHORT_NAME,
    target.ABBREVIATION                 = source.ABBREVIATION,
    target.COMMENTS                     = source.COMMENTS,
    target.STANDARD                     = source.STANDARD,
    target.CREATED_BY                   = source.CREATED_BY,
    target.CREATED_DATE                 = source.CREATED_DATE,
    target.DIMENSION_ID                 = source.DIMENSION_ID,
    target.SORT_COLUMN                  = source.SORT_COLUMN
WHEN NOT MATCHED THEN
INSERT
(
    ID,
    NAME,
    DESCRIPTION,
    SHORT_NAME,
    ABBREVIATION,
    COMMENTS,
    STANDARD,
    CREATED_BY,
    CREATED_DATE,
    DIMENSION_ID,
    SORT_COLUMN
)
VALUES
(
    source.ID,
    source.NAME,
    source.DESCRIPTION,
    source.SHORT_NAME,
    source.ABBREVIATION,
    source.COMMENTS,
    source.STANDARD,
    source.CREATED_BY,
    source.CREATED_DATE,
    source.DIMENSION_ID,
    source.SORT_COLUMN
)