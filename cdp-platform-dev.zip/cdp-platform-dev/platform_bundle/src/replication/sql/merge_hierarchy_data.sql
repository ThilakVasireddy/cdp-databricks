MERGE INTO {catalog_name}.{schema_name}.{table_name} AS target
USING {source_view} AS source
ON target.HIERARCHY_ID = source.HIERARCHY_ID
    AND target.NODE_ID = source.NODE_ID
WHEN MATCHED THEN
UPDATE SET
    target.CHILD_ID                           = source.CHILD_ID,
    target.PATH                               = source.PATH,
    target.PARENT_ID                          = source.PARENT_ID,
    target.DIMENSION_ID                       = source.DIMENSION_ID
WHEN NOT MATCHED THEN
INSERT
(
    HIERARCHY_ID,
    PARENT_ID,
    CHILD_ID,
    PATH,
    NODE_ID,
    DIMENSION_ID
)
VALUES
(
    source.HIERARCHY_ID,
    source.PARENT_ID,
    source.CHILD_ID,
    source.PATH,
    source.NODE_ID,
    source.DIMENSION_ID
)