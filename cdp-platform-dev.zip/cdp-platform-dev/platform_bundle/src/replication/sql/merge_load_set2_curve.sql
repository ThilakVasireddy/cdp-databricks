MERGE INTO {catalog_name}.{schema_name}.LOAD_SET2_CURVE AS target
USING {source_view} AS source
ON target.ID = source.ID AND target.CURVE_ID = source.CURVE_ID AND target.LOAD_SET_ID = source.LOAD_SET_ID
WHEN MATCHED THEN
UPDATE SET
    target.EXTERNAL_ID       = source.EXTERNAL_ID,
    target.EXTERNAL_NAME     = source.EXTERNAL_NAME,
    target.AUTO_TAGGED       = source.AUTO_TAGGED,
    target.AUTO_TAG_ERROR    = source.AUTO_TAG_ERROR,
    target.STATUS_ID         = source.STATUS_ID,
    target.LOG_LEVEL         = source.LOG_LEVEL,
    target.CHAIN_ID          = source.CHAIN_ID,
    target.EXPORT_ENABLED    = source.EXPORT_ENABLED,
    target.CREATED_DATE      = source.CREATED_DATE,
    target.CREATED_BY        = source.CREATED_BY,
    target.UPDATED_DATE      = source.UPDATED_DATE,
    target.UPDATED_BY        = source.UPDATED_BY,
    target.OBJECT_VERSION    = source.OBJECT_VERSION,
    target.META_STR          = source.META_STR
WHEN NOT MATCHED THEN
INSERT
(
    ID,
    CURVE_ID,
    LOAD_SET_ID,
    EXTERNAL_ID,
    EXTERNAL_NAME,
    AUTO_TAGGED,
    AUTO_TAG_ERROR,
    STATUS_ID,
    LOG_LEVEL,
    CHAIN_ID,
    EXPORT_ENABLED,
    CREATED_DATE,
    CREATED_BY,
    UPDATED_DATE,
    UPDATED_BY,
    OBJECT_VERSION,
    META_STR
)
VALUES
(
    source.ID,
    source.CURVE_ID,
    source.LOAD_SET_ID,
    source.EXTERNAL_ID,
    source.EXTERNAL_NAME,
    source.AUTO_TAGGED,
    source.AUTO_TAG_ERROR,
    source.STATUS_ID,
    source.LOG_LEVEL,
    source.CHAIN_ID,
    source.EXPORT_ENABLED,
    source.CREATED_DATE,
    source.CREATED_BY,
    source.UPDATED_DATE,
    source.UPDATED_BY,
    source.OBJECT_VERSION,
    source.META_STR
);