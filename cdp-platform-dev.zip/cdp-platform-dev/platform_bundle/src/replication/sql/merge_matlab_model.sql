MERGE INTO {catalog_name}.{schema_name}.MATLAB_MODEL AS target
USING {source_view} AS source
ON target.ID = source.ID
WHEN MATCHED THEN
UPDATE SET
    target.MODEL_NAME        = source.MODEL_NAME,
    target.MODEL_RUN         = source.MODEL_RUN,
    target.MESSAGE_ID        = source.MESSAGE_ID,
    target.STATUS_ID         = source.STATUS_ID,
    target.CREATED_DATE      = source.CREATED_DATE,
    target.CREATED_BY        = source.CREATED_BY,
    target.UPDATED_DATE      = source.UPDATED_DATE,
    target.UPDATED_BY        = source.UPDATED_BY,
    target.OBJECT_VERSION    = source.OBJECT_VERSION,
    target.DESCRIPTION       = source.DESCRIPTION,
    target.PROFILING         = source.PROFILING,
    target.NOTIFY_GROUP_ID   = source.NOTIFY_GROUP_ID
WHEN NOT MATCHED THEN
INSERT 
(
    ID,
    MODEL_NAME,
    MODEL_RUN,
    MESSAGE_ID,
    STATUS_ID,
    CREATED_DATE,
    CREATED_BY,
    UPDATED_DATE,
    UPDATED_BY,
    OBJECT_VERSION,
    DESCRIPTION,
    PROFILING,
    NOTIFY_GROUP_ID
)
VALUES
(
    source.ID,
    source.MODEL_NAME,
    source.MODEL_RUN,
    source.MESSAGE_ID,
    source.STATUS_ID,
    source.CREATED_DATE,
    source.CREATED_BY,
    source.UPDATED_DATE,
    source.UPDATED_BY,
    source.OBJECT_VERSION,
    source.DESCRIPTION,
    source.PROFILING,
    source.NOTIFY_GROUP_ID
);