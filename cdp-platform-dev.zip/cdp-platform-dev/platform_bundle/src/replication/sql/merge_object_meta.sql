MERGE INTO {catalog_name}.{schema_name}.{table_name} AS target
USING {source_view} AS source
ON target.META_ID = source.META_ID
    AND target.DIMENSION_ID = source.DIMENSION_ID
    AND target.OBJECT_ID = source.OBJECT_ID
    AND target.ATTRIBUTE_ID = source.ATTRIBUTE_ID
    AND target.OBJECT_TYPE_ID = source.OBJECT_TYPE_ID
    AND target.VERB_ID = source.VERB_ID
WHEN MATCHED THEN
UPDATE SET
    target.SEARCH_TEXT      = source.SEARCH_TEXT,
    target.FREE_TEXT        = source.FREE_TEXT,
    target.ID               = source.ID,
    target.ELEMENT_NAME     = source.ELEMENT_NAME,
    target.OBJECT_NAME      = source.OBJECT_NAME,
    target.CREATED_DATE     = source.CREATED_DATE,
    target.CREATED_BY       = source.CREATED_BY,
    target.UPDATED_DATE     = source.UPDATED_DATE,
    target.UPDATED_BY       = source.UPDATED_BY,
    target.OBJECT_VERSION   = source.OBJECT_VERSION,
    target.STATUS_ID        = source.STATUS_ID
WHEN NOT MATCHED THEN
INSERT
(
    META_ID,
    DIMENSION_ID,
    OBJECT_ID,
    SEARCH_TEXT,
    ATTRIBUTE_ID,
    FREE_TEXT,
    OBJECT_TYPE_ID,
    VERB_ID,
    ID,
    ELEMENT_NAME,
    OBJECT_NAME,
    CREATED_DATE,
    CREATED_BY,
    UPDATED_DATE,
    UPDATED_BY,
    OBJECT_VERSION,
    STATUS_ID
)
VALUES
(
    source.META_ID,
    source.DIMENSION_ID,
    source.OBJECT_ID,
    source.SEARCH_TEXT,
    source.ATTRIBUTE_ID,
    source.FREE_TEXT,
    source.OBJECT_TYPE_ID,
    source.VERB_ID,
    source.ID,
    source.ELEMENT_NAME,
    source.OBJECT_NAME,
    source.CREATED_DATE,
    source.CREATED_BY,
    source.UPDATED_DATE,
    source.UPDATED_BY,
    source.OBJECT_VERSION,
    source.STATUS_ID
  )