MERGE INTO {catalog_name}.{schema_name}.{table_name} AS target
USING {source_view} AS source
ON target.ID = source.ID
WHEN MATCHED THEN
UPDATE SET
    target.NAME = source.NAME,
    target.DESCRIPTION = source.DESCRIPTION,
    target.COMMENTS = source.COMMENTS,
    target.CREATED_DATE = source.CREATED_DATE,
    target.CREATED_BY = source.CREATED_BY,
    target.UPDATED_DATE = source.UPDATED_DATE,
    target.UPDATED_BY = source.UPDATED_BY,
    target.OBJECT_VERSION = source.OBJECT_VERSION,
    target.ID_COLUMN_NAME = source.ID_COLUMN_NAME,
    target.DISPLAY_NAME = source.DISPLAY_NAME,
    target.PLURAL_DISPLAY_NAME = source.PLURAL_DISPLAY_NAME,
    target.NAME_COLUMN_NAME = source.NAME_COLUMN_NAME,
    target.ENTITY = source.ENTITY,
    target.TABLE_NAME = source.TABLE_NAME,
    target.SCHEMA = source.SCHEMA
WHEN NOT MATCHED THEN
INSERT
(
    ID,
    NAME,
    DESCRIPTION,
    COMMENTS,
    CREATED_DATE,
    CREATED_BY,
    UPDATED_DATE,
    UPDATED_BY,
    OBJECT_VERSION,
    ID_COLUMN_NAME,
    DISPLAY_NAME,
    PLURAL_DISPLAY_NAME,
    NAME_COLUMN_NAME,
    ENTITY,
    TABLE_NAME,
    SCHEMA
)
VALUES
(
    source.ID,
    source.NAME,
    source.DESCRIPTION,
    source.COMMENTS,
    source.CREATED_DATE,
    source.CREATED_BY,
    source.UPDATED_DATE,
    source.UPDATED_BY,
    source.OBJECT_VERSION,
    source.ID_COLUMN_NAME,
    source.DISPLAY_NAME,
    source.PLURAL_DISPLAY_NAME,
    source.NAME_COLUMN_NAME,
    source.ENTITY,
    source.TABLE_NAME,
    source.SCHEMA
);