MERGE INTO {catalog_name}.{schema_name}.SAFE_GROUPS AS target
USING {source_view} AS source
ON target.ID = source.ID
WHEN MATCHED THEN
UPDATE SET
    target.NAME = source.NAME,
    target.DESCRIPTION = source.DESCRIPTION,
    target.USER_LEVEL = source.USER_LEVEL,
    target.CREATED_DATE = source.CREATED_DATE,
    target.CREATED_BY = source.CREATED_BY,
    target.UPDATED_DATE = source.UPDATED_DATE,
    target.UPDATED_BY = source.UPDATED_BY,
    target.OBJECT_VERSION = source.OBJECT_VERSION,
    target.PARENT_ID = source.PARENT_ID,
    target.DISPLAY_NAME = source.DISPLAY_NAME,
    target.GROUP_OWNER = source.GROUP_OWNER,
    target.PERMISSION_LEVEL = source.PERMISSION_LEVEL,
    target.PERMITTED_GROUP_IDS = source.PERMITTED_GROUP_IDS
WHEN NOT MATCHED THEN
INSERT
(
    ID,
    NAME,
    DESCRIPTION,
    USER_LEVEL,
    CREATED_DATE,
    CREATED_BY,
    UPDATED_DATE,
    UPDATED_BY,
    OBJECT_VERSION,
    PARENT_ID,
    DISPLAY_NAME,
    GROUP_OWNER,
    PERMISSION_LEVEL,
    PERMITTED_GROUP_IDS
)
VALUES
(
    source.ID,
    source.NAME,
    source.DESCRIPTION,
    source.USER_LEVEL,
    source.CREATED_DATE,
    source.CREATED_BY,
    source.UPDATED_DATE,
    source.UPDATED_BY,
    source.OBJECT_VERSION,
    source.PARENT_ID,
    source.DISPLAY_NAME,
    source.GROUP_OWNER,
    source.PERMISSION_LEVEL,
    source.PERMITTED_GROUP_IDS
);