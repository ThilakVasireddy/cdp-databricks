MERGE INTO {catalog_name}.{schema_name}.SAFE_USER AS target
USING {source_view} AS source
ON target.ID = source.ID
WHEN MATCHED THEN
UPDATE SET
    target.SAFE_UID = source.SAFE_UID,
    target.FIRST_NAME = source.FIRST_NAME,
    target.LAST_NAME = source.LAST_NAME,
    target.EMAIL = source.EMAIL,
    target.TR_AD_USER_NAME = source.TR_AD_USER_NAME,
    target.PC_AD_USER_NAME = source.PC_AD_USER_NAME,
    target.CREATED_DATE = source.CREATED_DATE,
    target.CREATED_BY = source.CREATED_BY,
    target.UPDATED_DATE = source.UPDATED_DATE,
    target.UPDATED_BY = source.UPDATED_BY,
    target.OBJECT_VERSION = source.OBJECT_VERSION,
    target.LAST_LOGIN = source.LAST_LOGIN
WHEN NOT MATCHED THEN
INSERT (
    ID,
    SAFE_UID,
    FIRST_NAME,
    LAST_NAME,
    EMAIL,
    TR_AD_USER_NAME,
    PC_AD_USER_NAME,
    CREATED_DATE,
    CREATED_BY,
    UPDATED_DATE,
    UPDATED_BY,
    OBJECT_VERSION,
    LAST_LOGIN
)
VALUES (
    source.ID,
    source.SAFE_UID,
    source.FIRST_NAME,
    source.LAST_NAME,
    source.EMAIL,
    source.TR_AD_USER_NAME,
    source.PC_AD_USER_NAME,
    source.CREATED_DATE,
    source.CREATED_BY,
    source.UPDATED_DATE,
    source.UPDATED_BY,
    source.OBJECT_VERSION,
    source.LAST_LOGIN
);