MERGE INTO {catalog_name}.{schema_name}.{table_name} AS target
USING {source_view} AS source
ON target.ID = source.ID
WHEN MATCHED THEN
    UPDATE SET
        target.NAME = source.NAME
WHEN NOT MATCHED THEN
    INSERT (
        ID,
        NAME
    ) 
    VALUES (
        source.ID,
        source.NAME
    );