MERGE INTO {catalog_name}.{schema_name}.VESSEL_PERM_IDS AS target
USING {source_view} AS source
ON target.VES_ID = source.VES_ID AND target.PERM_ID = source.PERM_ID
WHEN MATCHED THEN
UPDATE SET
    target.VES_ID            = source.VES_ID,
    target.VES_NAME          = source.VES_NAME,
    target.PERM_ID           = source.PERM_ID,
    target.ASSET_RIC         = source.ASSET_RIC,
    target.IMO               = source.IMO,
    target.MMSI              = source.MMSI,
    target.VT_BRL_SHIP_ID    = source.VT_BRL_SHIP_ID,
    target.VT_SHIP_ID        = source.VT_SHIP_ID,
    target.VT_SHIP_TYPE_ID   = source.VT_SHIP_TYPE_ID,
    target.CREATE_DATE       = source.CREATE_DATE,
    target.CREATE_BY         = source.CREATE_BY,
    target.MODIFY_DATE       = source.MODIFY_DATE,
    target.MODIFY_BY         = source.MODIFY_BY
WHEN NOT MATCHED THEN
INSERT
(
    VES_ID,
	VES_NAME,
	PERM_ID,
	ASSET_RIC,
	IMO,
	MMSI,
	VT_BRL_SHIP_ID,
	VT_SHIP_ID,
    VT_SHIP_TYPE_ID,
	CREATE_DATE,
	CREATE_BY,
	MODIFY_DATE,
	MODIFY_BY
)
VALUES
(
    source.VES_ID,
	source.VES_NAME,
	source.PERM_ID,
	source.ASSET_RIC,
	source.IMO,
	source.MMSI,
	source.VT_BRL_SHIP_ID,
	source.VT_SHIP_ID,
    source.VT_SHIP_TYPE_ID,
	source.CREATE_DATE,
	source.CREATE_BY,
	source.MODIFY_DATE,
	source.MODIFY_BY
);