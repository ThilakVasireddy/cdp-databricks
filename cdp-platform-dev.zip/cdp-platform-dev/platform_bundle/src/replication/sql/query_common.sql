SELECT *
FROM {table_name}
WHERE {column_name} >= TO_TIMESTAMP('{start_time}', 'YYYY-MM-DD HH24:MI:SS')
    AND {column_name} < TO_TIMESTAMP('{end_time}', 'YYYY-MM-DD HH24:MI:SS')