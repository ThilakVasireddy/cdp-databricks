SELECT *
FROM dw.CURVE
WHERE ID IN ({curve_id})
