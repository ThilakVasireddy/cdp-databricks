SELECT *
FROM {table_name}
WHERE CURVE_ID = {curve_id_chunk}
    AND FORECAST_DATE >= TO_TIMESTAMP('{start_time}', 'YYYY-MM-DD HH24:MI:SS')
    AND FORECAST_DATE < TO_TIMESTAMP('{end_time}', 'YYYY-MM-DD HH24:MI:SS')