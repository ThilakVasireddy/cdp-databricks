SELECT *
FROM {table_name} en
WHERE en.ENTITY_ID  IN (
	SELECT element_id
	FROM OBJECT_META_V omv 
	WHERE OBJECT_ID = {curve_id} AND OBJECT_TYPE_ID = 1
)