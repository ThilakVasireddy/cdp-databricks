SELECT *
FROM {table_name}
WHERE OBJECT_ID = {curve_id} AND OBJECT_TYPE_ID = 1