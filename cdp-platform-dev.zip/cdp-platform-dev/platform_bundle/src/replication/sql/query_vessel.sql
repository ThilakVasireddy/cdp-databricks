SELECT
    ves.id AS ves_id,
    pan.value AS ves_name,
    pas.perm_id,
    pas.asset_ric,
    ves.imo AS imo,
    ves.mmsi AS mmsi,
    ves.vt_brl_ship_id,
    ves.vt_ship_id,
    ves.vt_ship_type_id,
    ves.create_date,
    ves.create_by,
    ves.modify_date,
    ves.modify_by

FROM
    cef_cnr.PHYSICAL_ASSET pas
LEFT OUTER JOIN
    cef_cnr.PHYSICAL_ASSET_NAME pan
ON
    pas.perm_id = pan.pas_perm_id
JOIN
    {table_name} ves
ON
    pas.ves_id = ves.id
WHERE
    pas.ves_id IS NOT NULL
    AND pan.effective_to IS NULL
    AND ves.modify_date >= TO_TIMESTAMP('{start_time}', 'YYYY-MM-DD HH24:MI:SS')
    AND ves.modify_date < TO_TIMESTAMP('{end_time}', 'YYYY-MM-DD HH24:MI:SS')