import time
from dataclasses import dataclass
from datetime import date

# The following imports cause exceptions when not running in a spark environment.
try:
    from pyspark.sql.functions import (
        col,
        udf,
        from_json,
        from_unixtime,
        to_utc_timestamp,
        lit,
        lag
    )
    import pyspark.sql.functions as SQLFunctions
    from pyspark.sql import Window
    from pyspark.sql.types import StructType, StructField, StringType, ArrayType, LongType
    from delta.tables import DeltaTable
except ImportError:
    # When running outside a spark environment, these imports cause exceptions.
    pass


@dataclass
class TableRef:
    catalog_name: str
    schema_name: str
    table_name: str


class SchemaEvolutionReport:
    """Schema evolution report."""

    def __init__(
        self,
        spark,
        schema_name="platform",
        table_name="delta_table_schema_evolution_history",
    ):
        """Initialise the report with the defined (or default) table for tracking history.

        Arguments:
        spark           -- A reference to an active spark session.
        schema_name     -- The schema containing the schema evolution history report table
        table_name      -- The name of the schema evolution history report table
        """

        self.spark = spark
        self.unity_catalog_name = spark.catalog.currentCatalog()
        self.history_table = TableRef(
            catalog_name=self.unity_catalog_name, schema_name=schema_name, table_name=table_name
        )
        self.history_table_uri = self.get_table_uri(
            self.history_table.catalog_name,
            self.history_table.schema_name,
            self.history_table.table_name,
        )

    def get_table_uri(self, catalog: str, schema: str, table_name: str) -> str:
        """Converts catalog, schema, and table_name
        into a single string of the form: {catalog}.{schema}.{table_name}"""

        return f"{catalog}.{schema}.{table_name}"

    def get_table_files_location(self, catalog: str, schema: str, table_name: str):
        """Find the file location of the table.
        The `describe detail` command for a table includes a `location` in its results
        which is the file location for the delta table."""

        table_uri = self.get_table_uri(catalog, schema, table_name)

        try:
            table_details = self.spark.sql(f"describe detail {table_uri}")
            table_location = table_details.select(
                "location").collect()[0]["location"]
            return table_location
        except Exception:
            # It's not a delta table, so "describe detail" threw an exception. We can ignore it.
            print(f"Table {schema}.{table_name} is not a delta table.")
            return None

    def get_delta_log(
        self, catalog_name: str, schema_name: str, table_name: str
    ):
        """Each Delta Table maintains logs of its history in a JSON format
        and this includes metadata relating to schema changes. This notebook"""
        table_files_location = self.get_table_files_location(
            catalog_name, schema_name, table_name
        )
        if table_files_location is None:
            return None
        delta_log_df = (
            DeltaTable.forName(self.spark, f"{catalog_name}.{schema_name}.{table_name}")
            .history()
            .selectExpr("to_json(struct(*)) as value")
        )
        return delta_log_df

    def get_schema_changes(
        self, catalog_name: str, schema_name: str, table_name: str, since: date
    ):
        """Finds the transaction log files that back the table being examined.
        And returns a DataFrame of the schema changes.
        If `since` is specified, only schema changes after that date will be returned.
        """

        table_uri = self.get_table_uri(catalog_name, schema_name, table_name)

        delta_log_df = self.get_delta_log(catalog_name, schema_name, table_name)
        if delta_log_df is None:
            # Early return if the database object is not a delta table.
            return None

        delta_log_schema = StructType(
            [
                StructField("commitInfo", StructType([
                    StructField("timestamp", LongType(), True),
                ]), True),
                StructField("metaData", StructType([
                    StructField("schemaString", StringType(), True),
                ]), True)
            ]
        )

        schema_change_schema = StructType(
            [
                StructField("type", StringType(), True),
                StructField(
                    "fields",
                    ArrayType(
                        StructType(
                            [
                                StructField("name", StringType(), True),
                                StructField("type", StringType(), True),
                            ]
                        )
                    ),
                    True,
                ),
            ]
        )

        # Create a window to get the previous schema.

        w = Window.partitionBy("table_uri").orderBy("event_timestamp")

        # Create UDF. Enables us to join up the invalid JSON delta log structures into
        # something that can be converted to JSON.
        join_json_udf = udf(lambda z: z.replace("}\n{", ","), StringType())

        since_timestamp = int(time.mktime(since.timetuple())) * 1000

        schema_change_df = (
            delta_log_df.select(join_json_udf(col("value")).alias("event"))
            .withColumn("event_json", from_json(col("event"), delta_log_schema))
            .select(col("event_json"))
            .filter("event_json.metaData.schemaString is not null")
            .filter(col("event_json.commitInfo.timestamp") > since_timestamp)
            .select(
                col("event_json.commitInfo.timestamp").alias("event_timestamp"),
                col("event_json.metaData.schemaString").alias("schema_string"))
            .withColumn(
                "event_utc",
                to_utc_timestamp(from_unixtime(col("event_timestamp") / 1000), 'GMT')
            )
            .withColumn("catalog_name", lit(catalog_name))
            .withColumn("schema_name", lit(schema_name))
            .withColumn("table_name", lit(table_name))
            .withColumn("table_uri", lit(table_uri))
            .withColumn("previous_schema_string", lag("schema_string").over(w))
            .withColumn(
                "new_parsed_schema_string",
                from_json("schema_string", schema_change_schema)
            )
            .withColumn(
                "previous_parsed_schema_string",
                from_json("previous_schema_string", schema_change_schema)
            )
            .withColumn("new_schema_fields", col("new_parsed_schema_string.fields"))
            .withColumn("previous_schema_fields", col("previous_parsed_schema_string.fields"))
        ).select(
            col("catalog_name"),
            col("schema_name"),
            col("table_name"),
            col("table_uri"),
            col("event_timestamp"),
            col("event_utc"),
            col("previous_schema_fields"),
            col("new_schema_fields")
        ).where(
            (col("previous_schema_fields").eqNullSafe(None))
            | (col("new_schema_fields") != col("previous_schema_fields"))
        )

        print(f"Found {schema_change_df.count()} schema changes for {schema_name}.{table_name}")

        return schema_change_df

    def get_tables_in_schemas(self, reported_schemas):
        """Returns a DataFrame of all tables in the schemas that are being reported."""

        reported_tables = []
        for reported_schema in reported_schemas:
            catalog_name = self.unity_catalog_name
            schema_name = reported_schema
            schema_tables_df = self.spark.sql(
                f"show tables from {catalog_name}.{schema_name}"
            )
            schema_tables_df = schema_tables_df.filter(
                condition=SQLFunctions.col("isTemporary") == False  # noqa: E712
            )  # noqa: E712
            schema_tables_df = (
                schema_tables_df.withColumn(
                    "catalog_name", SQLFunctions.lit(catalog_name)
                )
                .withColumnRenamed("database", "schema_name")
                .withColumnRenamed("tableName", "table_name")
            )
            reported_tables.extend(schema_tables_df.collect())
        return reported_tables

    def get_history_for_tables(self, reported_tables, since: date):
        """Given a list of tables to report on,
        produce a dataframe of all metadata history (schema evolution) for those tables."""
        history_df = None
        for table in reported_tables:
            table_df = self.get_schema_changes(
                table["catalog_name"], table["schema_name"], table["table_name"], since
            )
            if history_df is None:
                history_df = table_df
            else:
                if table_df is not None:
                    history_df = history_df.union(table_df)
        return history_df

    def persist_history_for_tables(self, history_df):
        """Persist the history into a delta table for faster querying."""

        if history_df is None:
            return

        if not self.spark.catalog.databaseExists(self.history_table.schema_name):
            self.spark.sql(
                f"create schema if not exists "
                f"{self.history_table.catalog_name}.{self.history_table.schema_name}"
            )

        if not self.spark.catalog.tableExists(self.history_table_uri):
            history_df.write.saveAsTable(self.history_table_uri)
        else:
            history_table_df = DeltaTable.forName(
                self.spark, self.history_table_uri
            ).alias("t")
            history_table_df.merge(
                history_df.alias("s"),
                """s.catalog_name = t.catalog_name
                AND s.schema_name = t.schema_name
                AND s.table_name = t.table_name
                AND s.event_timestamp = t.event_timestamp
                """,
            ).whenNotMatchedInsertAll().execute()

    def find_schema_changes_since(self, since: date):
        since_timestamp = 0
        if since is not None:
            since_timestamp = int(time.mktime(since.timetuple())) * 1000

        query = (
            f"select * from {self.history_table_uri} "
            f"where schema_change_timestamp > {since_timestamp}"
        )
        print(query)
        df = self.spark.sql(query)
        return df
