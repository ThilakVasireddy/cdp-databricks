import sys
sys.path.append('../../')

from datetime import datetime, timedelta
from utils.databricks import get_spark
from reports.schema_evolution.schema_evolution_report import SchemaEvolutionReport


def run_schema_evolution_report():
    """Executes the schema evolution report for a defined set of schemas.
    This creates a history table if it doesn't exist and saves the results into it.
    You can run this on Databricks to test the job.
    """ 

    report = SchemaEvolutionReport(get_spark())

    reported_schemas = [
        'agriculture_bronze', 'agriculture_enriched', 'agriculture_gold',
        'agriculture_silver', 'agriculture_system', 'agriculture_tests',
        'gas_bronze', 'gas_enriched', 'gas_gold',
        'gas_silver', 'gas_system', 'gas_tests',
        'power_bronze', 'power_enriched', 'power_gold',
        'power_silver', 'power_system', 'power_tests',
        'shipping_bronze', 'shipping_enriched', 'shipping_gold',
        'shipping_silver', 'shipping_system', 'shipping_tests',
        'weather_bronze', 'weather_enriched', 'weather_gold',
        'weather_silver', 'weather_system', 'weather_tests'
    ]
    reported_tables = report.get_tables_in_schemas(reported_schemas=reported_schemas)

    print("Analysing schemas for tables:")
    for table in reported_tables:
        print(f"    {table.schema_name}.{table.table_name}")

    # Get the past month of schema changes.
    month_ago = (datetime.today() - timedelta(days=30)).date()
    history_df = report.get_history_for_tables(reported_tables=reported_tables, since=month_ago)

    report.persist_history_for_tables(history_df=history_df)


if __name__ == '__main__':
    run_schema_evolution_report()
