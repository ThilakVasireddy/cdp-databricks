-- Databricks notebook source
CREATE WIDGET TEXT schema_name DEFAULT 'platform';
CREATE WIDGET TEXT table_name DEFAULT 'health_check_results';

-- COMMAND ----------

-- This is initial table with key columns
CREATE TABLE IF NOT EXISTS IDENTIFIER(:schema_name || '.' || :table_name)
(
  runid               BIGINT,            -- unique ID per notebook run
  checkname           STRING,            -- e.g. "catalogs_visible", "schemas_visible"
  timestamp           TIMESTAMP,         -- when this particular check executed
  status              STRING,            -- "healthy" | "unhealthy" | "unknown" | …
  level               STRING,            -- "fatal" | "critical" | "warn" | "info" | …
  message             STRING,            -- free-text details
  extended_properties VARIANT            -- JSON-style map of any extra info
)
USING DELTA;
