-- Databricks notebook source
CREATE WIDGET TEXT schema_name DEFAULT 'platform';
CREATE WIDGET TEXT table_name DEFAULT 'delta_table_schema_evolution_history';

-- COMMAND ----------

-- This is initial table with key columns, all the other columns are added automatically as withSchemaEvolution is set in merge statement
CREATE TABLE IF NOT EXISTS IDENTIFIER(:schema_name || '.' || :table_name)
(
  catalog_name             STRING,
  schema_name              STRING,
  table_name               STRING,
  table_uri                STRING,
  event_timestamp          BIGINT,
  event_utc                TIMESTAMP,
  previous_schema_fields   ARRAY<STRUCT<name: STRING, type: STRING>>,
  new_schema_fields        ARRAY<STRUCT<name: STRING, type: STRING>>
)
USING DELTA