import pytest
from pyspark.sql import SparkSession


@pytest.fixture(scope="session")
def spark():
    try:
        from databricks.connect import DatabricksSession
        return DatabricksSession.builder.getOrCreate()
    except ImportError:
        return SparkSession.builder.getOrCreate()


@pytest.fixture
def dbutils(spark):
    from pyspark.dbutils import DBUtils
    return DBUtils(spark)
