# Databricks notebook source
import sys                           # Careful that a code formatter doesn't move this down.
sys.path.append('../../../../src/')  # Careful that a code formatter doesn't move this down.

from reports.schema_evolution.schema_evolution_report import SchemaEvolutionReport
from datetime import datetime
import time
import json

from utils.databricks import get_spark
from pyspark.sql.types import StructType, StructField, StringType, TimestampType


# COMMAND ----------

def get_table_uri(catalog_name: str, schema_name: str, table_name: str):
    """Converts catalog, schema, and table_name into a single string of the form: {catalog_name}.{schema_name}.{table_name}"""
    return f"{catalog_name}.{schema_name}.{table_name}"


def create_evolution_test_table(catalog_name: str, schema_name: str, table_name: str, df):
    # If we're re-creating the table, we should clear out any previous history records relating to it.
    spark.sql(f"""delete from hive_metastore.platform.delta_table_schema_evolution_history
                  where catalog_name = '{catalog_name}' 
                      and schema_name = '{schema_name}' 
                      and table_name = '{table_name}'""")
    spark.sql(f"CREATE SCHEMA IF NOT EXISTS {catalog_name}.{schema_name}")
    spark.sql(
        f"DROP TABLE IF EXISTS {catalog_name}.{schema_name}.{table_name}")
    df.write.option('mergeSchema', 'true').saveAsTable(
        get_table_uri(catalog_name, schema_name, table_name))


def insert_df_with_schema_evolution(catalog_name: str, schema_name: str, table_name: str, df):
    df.write.option('mergeSchema', 'true').mode("append").insertInto(
        get_table_uri(catalog_name, schema_name, table_name))

# COMMAND ----------

def create_test_table_and_evolve_it():
    """Create a test table: hive_metastore.scratch.evolution_test
    Merge a dataframe into it, then merge another dataframe into it with additional columns.
    This will cause the table schema to evolve and record the change in the delta log."""
    #catalog_name = 'hive_metastore' not use hive_metastore anymore
    schema_name = 'scratch'
    table_name = 'evolution_test_again'

    initial_schema = StructType([
        StructField("col_one", StringType(), True),
        StructField("event_timestamp", TimestampType(), True),
        StructField("col_two", StringType(), True)
    ])

    # Create an initial table based on an initial dataframe.
    create_evolution_test_table(catalog_name, schema_name, table_name, spark.createDataFrame(
        [(1, datetime.now(), 'two')], schema=initial_schema))
    time.sleep(2)

    # Do one insert compatible with the initial schema.
    insert_df_with_schema_evolution(catalog_name, schema_name, table_name, spark.createDataFrame([
        (2, datetime.now(), 'two')], schema=initial_schema))
    time.sleep(2)

    evolved_schema = StructType([
        StructField("col_one", StringType(), True),
        StructField("event_timestamp", TimestampType(), True),
        StructField("col_two", StringType(), True),
        StructField("col_three", StringType(), True)
    ])

    # Insert a row using schema evolution to add an extra column.
    insert_df_with_schema_evolution(catalog_name, schema_name, table_name, spark.createDataFrame([
        (3, datetime.now(), 'two', 'three')], schema=evolved_schema))
    time.sleep(2)

    # And insert another row using that same new schema.
    insert_df_with_schema_evolution(catalog_name, schema_name, table_name, spark.createDataFrame([
        (4, datetime.now(), 'two', 'three')], schema=evolved_schema))

    time.sleep(2)

    evolved_schema = StructType([
        StructField("col_one", StringType(), True),
        StructField("event_timestamp", TimestampType(), True),
        StructField("col_two", StringType(), True),
        StructField("col_three", StringType(), True),
        StructField("col_four", StringType(), True)
    ])

    # Insert a row using schema evolution to add an extra column.
    insert_df_with_schema_evolution(catalog_name, schema_name, table_name, spark.createDataFrame([
        (5, datetime.now(), 'two', 'three', 'four')], schema=evolved_schema))


# COMMAND ----------

def test_schema_evolution_report():
    """Integration test needs to be executed on a Spark cluster. Relies on finding a database and querying it."""

    print('Running test: test_schema_evolution_report')

    report = SchemaEvolutionReport(spark=get_spark())

    reported_schemas = [
        {'catalog': 'hive_metastore', 'schema': 'default'},
        {'catalog': 'hive_metastore', 'schema': 'scratch'}
    ]
    reported_tables = report.get_tables_in_schemas(
        reported_schemas=reported_schemas)

    for table in reported_tables:
        print(table)

# COMMAND ----------


# First create a test table and apply an evolution.
#create_test_table_and_evolve_it()
# Run the report to generate updates into the schema history table.
#test_schema_evolution_report()

dbutils.notebook.exit(json.dumps({"status":"passed"}))
