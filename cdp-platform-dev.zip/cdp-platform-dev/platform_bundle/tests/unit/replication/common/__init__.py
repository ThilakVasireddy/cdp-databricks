import os
import sys

project_path = os.path.dirname(__file__)
source_dir = os.path.abspath(os.path.join(project_path, "../../../../src/replication/common"))
print(source_dir)
if source_dir not in sys.path:
    sys.path.append(source_dir)
