from datetime import datetime

import pytest
from data_structure import OracleTableName, DeltaTableName, UpdateRange, OracleConfig
from databricks_wrapper import DatabricksWrapper


def test_oracle_table_name():
    oracle_table_name = OracleTableName("test_schema_name", "test_table_name", "test_column_name")
    assert oracle_table_name.table_full_name == "test_schema_name.test_table_name"
    assert oracle_table_name.column_name == "test_column_name"


def test_delta_table_name():
    delta_table_name = DeltaTableName("test_catalog_name", "test_schema_name", "test_table_name")
    assert delta_table_name.table_full_name == "test_catalog_name.test_schema_name.test_table_name"
    assert delta_table_name.temp_view_name == "test_table_name_temp_view"


def test_update_range():
    start_time = datetime.fromisocalendar(2024, 1, 5).replace(minute=21)
    end_time = datetime.fromisocalendar(2025, 2, 4).replace(minute=22)
    update_range = UpdateRange(start_time, end_time)
    assert update_range.start_time == "2024-01-05 00:21:00"
    assert update_range.end_time == "2025-01-09 00:22:00"


@pytest.mark.parametrize("env, expected_jdbc, expected_password", [
    (
            'dev',
            'jdbc:oracle:thin:@//oracle2.beta.commodities.int.thomsonreuters.com:1521/pocbt.int.thomsonreuters.com',
            'oracle-common-password'
    ),
    (
            'ppr',
            'jdbc:oracle:thin:@//oracle2.beta.commodities.int.thomsonreuters.com:1521/pocbt.int.thomsonreuters.com',
            'oracle-common-password'
    ),
    (
            'prd',
            'jdbc:oracle:thin:@//oracle2.commodities.int.thomsonreuters.com:1521/pocb.int.thomsonreuters.com',
            'oracle-test-user-password'
    )
], ids=["dev_env", "ppr_env", "prd_env"])
def test_oracle_config_dev(env, expected_jdbc, expected_password, mocker):
    mocker.patch('os.getenv', return_value=env)
    oracle_config = OracleConfig('test_user')

    assert oracle_config.jdbc_url == expected_jdbc
    assert oracle_config.user_name == 'test_user'
    assert oracle_config.password_name == expected_password
    assert oracle_config.driver == 'oracle.jdbc.driver.OracleDriver'
