import datetime
import os
import re
from unittest import mock
from unittest.mock import MagicMock

import pytest
from data_structure import OracleTableName, DeltaTableName
from databricks_wrapper import DatabricksWrapper


@pytest.fixture
def mock_dbutils(mocker):
    return mocker.Mock()


@pytest.fixture
def mock_spark(mocker):
    return mocker.Mock()


@pytest.fixture
def databricks_wrapper(mocker, mock_dbutils, mock_spark):
    mocker.patch('os.getenv', side_effect=return_os_env)
    mocker.patch('re.split', side_effect=mock_split)
    source_table = OracleTableName("dw", "test_source_table", "test_column_name")
    target_table = DeltaTableName("test_catalog", "test_schema", "test_target_table")
    process_table = DeltaTableName("test_catalog", "test_schema", "test_process_table")
    return DatabricksWrapper(mock_dbutils, mock_spark, source_table, target_table, process_table)


def return_os_env(key):
    if key == 'ENV':
        return 'dev'
    return None


def mock_split(pattern, string, maxsplit=0):
    dir = os.getcwd().split('platform_bundle')[0]
    dir_path = os.path.abspath(os.path.join(dir, "platform_bundle", "tests", "unit"))
    if pattern == "replication":
        return [dir_path, 'common']
    return re.split(pattern, string, maxsplit)


def test_get_oracle_properties(databricks_wrapper, mock_dbutils):
    mock_dbutils.secrets.get.return_value = "test_secret"
    oracle_properties = databricks_wrapper.get_oracle_properties()

    assert oracle_properties == {
        'url': 'jdbc:oracle:thin:@//oracle2.beta.commodities.int.thomsonreuters.com:1521/pocbt.int.thomsonreuters.com',
        'driver': 'oracle.jdbc.driver.OracleDriver',
        'user': 'dw',
        'password': 'test_secret'
    }
    mock_dbutils.secrets.get.assert_called_once_with(scope="platform-secretscope", key="oracle-common-password")


def test_extract_from_oracle_with_sql(databricks_wrapper, mock_dbutils, mock_spark):
    mock_dbutils.secrets.get.return_value = "test_secret"
    mock_df = mock.Mock()
    mock_spark.read.format.return_value.options.return_value.option.return_value.load.return_value = mock_df
    query = "select * from test_table"
    df = databricks_wrapper.extract_from_oracle_with_sql(query)
    assert df == mock_df


def test_extract_from_oracle_with_sql_path(databricks_wrapper, mock_dbutils, mock_spark):
    mock_dbutils.secrets.get.return_value = "test_secret"
    mock_df = mock.Mock()
    mock_spark.read.format.return_value.options.return_value.option.return_value.load.return_value = mock_df

    create_sql_relative_path = "create_table.sql"
    parameter_map = {"table_name": "test_catalog.test_schema.test_target_table"}
    df = databricks_wrapper.extract_from_oracle_with_sql_path(create_sql_relative_path, parameter_map)

    assert df == mock_df
    mock_spark.read.format.assert_called_once_with("jdbc")
    mock_spark.read.format.return_value.options.assert_called_once_with(
        url='jdbc:oracle:thin:@//oracle2.beta.commodities.int.thomsonreuters.com:1521/pocbt.int.thomsonreuters.com',
        driver='oracle.jdbc.driver.OracleDriver',
        user='dw',
        password='test_secret'
    )
    mock_spark.read.format.return_value \
        .options.return_value \
        .option.assert_called_once_with(
        "query",
        "CREATE TABLE IF NOT EXISTS test_catalog.test_schema.test_target_table (CURVE_ID decimal(38,0)) USING DELTA"
    )


def test_extract_from_oracle(databricks_wrapper, mock_dbutils, mock_spark):
    mock_dbutils.secrets.get.return_value = "test_secret"
    mock_df = mock.Mock()
    mock_spark.read.format.return_value.options.return_value.option.return_value.load.return_value = mock_df

    df = databricks_wrapper.extract_from_oracle()

    assert df == mock_df
    mock_spark.read.format.assert_called_once_with("jdbc")
    mock_spark.read.format.return_value \
        .options.return_value \
        .option.assert_called_once_with("dbtable", "dw.test_source_table")


def test_append_to_delta_table(databricks_wrapper, mock_spark):
    mock_df = mock.Mock()
    mock_df.count.return_value = 1
    databricks_wrapper.append_to_delta_table(mock_df)

    mock_df.write.format.assert_called_once_with("delta")
    mock_df.write.format.return_value.mode.assert_called_once_with("append")
    mock_df.write.format.return_value.mode.return_value.saveAsTable.assert_called_once_with(
        'test_catalog.test_schema.test_target_table')


def test_overwrite_to_delta_table(databricks_wrapper, mock_spark):
    mock_df = mock.Mock()
    databricks_wrapper.overwrite_to_delta_table(mock_df)

    mock_df.write.format.assert_called_once_with("delta")
    mock_df.write.format.return_value.mode.assert_called_once_with("overwrite")
    mock_df.write.format.return_value.mode.return_value.saveAsTable.assert_called_once_with(
        'test_catalog.test_schema.test_target_table')


def test_save_to_delta_table(databricks_wrapper, mock_spark):
    mock_df = mock.Mock()
    merge_sql_relative_path = "merge.sql"
    parameter_map = {
        "table_name": "test_catalog.test_schema.test_target_table",
        "source_view": "test_target_table_temp_view"
    }
    databricks_wrapper.save_to_delta_table(mock_df, merge_sql_relative_path, parameter_map)

    mock_df.createOrReplaceTempView.assert_called_once_with("test_target_table_temp_view")
    expected_sql = '''MERGE INTO test_catalog.test_schema.test_target_table AS target
USING test_target_table_temp_view AS source
ON target.ID = source.ID AND target.NAME = source.NAME
WHEN MATCHED THEN
UPDATE SET
    target.DESCRIPTION                  = source.DESCRIPTION,
WHEN NOT MATCHED THEN
INSERT (
    ID,
    DESCRIPTION
)
VALUES (
    source.ID,
    source.DESCRIPTION
)'''
    mock_spark.sql.assert_any_call(f"DROP VIEW IF EXISTS test_target_table_temp_view")
    mock_spark.sql.assert_any_call(expected_sql)


def test_get_last_update_time(databricks_wrapper, mock_spark):
    mock_df = mock.Mock()
    mock_spark.sql.return_value = mock_df
    mock_df.count.return_value = 1
    mock_df.select.return_value.first.return_value = [datetime.datetime(2023, 1, 1)]
    last_update_time = databricks_wrapper.get_last_update_time()
    assert last_update_time == datetime.datetime(2023, 1, 1)

    expected_sql = f"""
            SELECT last_api_call_timestamp
            FROM test_catalog.test_schema.test_process_table
            WHERE process_name = 'dw.test_source_table'"""
    mock_spark.sql.assert_called_once_with(expected_sql)


def test_save_last_update_time(databricks_wrapper, mock_spark):
    last_update_time = datetime.datetime(2023, 1, 1)
    databricks_wrapper.save_last_update_time(last_update_time)
    mock_spark.sql.assert_called_once_with("""MERGE INTO test_catalog.test_schema.test_process_table AS target
USING (
    SELECT 
        'dw.test_source_table'                               AS process_name,
        CAST('2023-01-01 00:00:00' AS TIMESTAMP) AS last_api_call_timestamp
) AS source
ON target.process_name = source.process_name
WHEN MATCHED THEN
    UPDATE SET
        target.last_api_call_timestamp = source.last_api_call_timestamp
WHEN NOT MATCHED THEN
    INSERT 
    (
        process_name, 
        last_api_call_timestamp
    ) 
    VALUES 
    (
        source.process_name, 
        source.last_api_call_timestamp
    );""")


def test_get_update_range(databricks_wrapper, mock_spark, monkeypatch):
    fake_date = datetime.datetime(2022, 10, 21, 22, 22, 22, tzinfo=datetime.timezone.utc)
    print_date_mock = MagicMock(wraps=datetime.datetime)
    print_date_mock.now.return_value = fake_date
    monkeypatch.setattr(datetime, "datetime", print_date_mock)

    mock_df = mock.Mock()
    mock_spark.sql.return_value = mock_df
    mock_df.count.return_value = 1
    mock_df.select.return_value.first.return_value = [datetime.datetime(2023, 1, 1)]
    update_range = databricks_wrapper.get_update_range()
    assert update_range.start_time == '2023-01-01 00:00:00'
    assert update_range.end_time == "2022-10-21 22:22:22"
