import datetime
import os
from typing import re
from unittest.mock import MagicMock

from replicate_utils import convert_datatime_to_str
from replicate_utils import convert_datetime_to_int
from replicate_utils import convert_int_to_datetime
from replicate_utils import get_current_time
from replicate_utils import read_sql

FAKE_DATE = datetime.datetime(2022, 10, 21, 22, 22, 22, tzinfo=datetime.timezone.utc)


def test_convert_datatime_to_str():
    assert convert_datatime_to_str(FAKE_DATE) == '2022-10-21 22:22:22'


def test_convert_datetime_to_int():
    assert convert_datetime_to_int(FAKE_DATE) == 1666390942


def test_convert_int_to_datetime():
    timestamp = 1666390942
    assert convert_int_to_datetime(timestamp) == FAKE_DATE


def test_get_print_date(monkeypatch):
    print_date_mock = MagicMock(wraps=datetime.datetime)
    print_date_mock.now.return_value = FAKE_DATE
    monkeypatch.setattr(datetime, "datetime", print_date_mock)

    assert get_current_time() == datetime.datetime(2022, 10, 21, 22, 22, 22, tzinfo=datetime.timezone.utc)


def test_read_sql(mocker):
    mocker.patch('re.split', side_effect=mock_split)
    parameter_map = {
        "table_name": "test_table_name",
        "partition_name": "test_partition_name",
        "curve_id": "23456"
    }
    expected_sql = '''SELECT *
FROM test_table_name PARTITION(test_partition_name)
WHERE CURVE_ID = 23456'''
    assert read_sql("test_sql.sql", parameter_map) == expected_sql


def mock_split(pattern, string, maxsplit=0):
    dir = os.getcwd().split('platform_bundle')[0]
    dir_path = os.path.abspath(os.path.join(dir, "platform_bundle", "tests", "unit"))
    if pattern == "replication":
        return [dir_path, 'common']
    return re.split(pattern, string, maxsplit)
