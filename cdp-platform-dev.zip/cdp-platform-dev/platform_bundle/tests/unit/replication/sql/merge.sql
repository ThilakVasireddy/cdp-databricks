MERGE INTO {table_name} AS target
USING {source_view} AS source
ON target.ID = source.ID AND target.NAME = source.NAME
WHEN MATCHED THEN
UPDATE SET
    target.DESCRIPTION                  = source.DESCRIPTION,
WHEN NOT MATCHED THEN
INSERT (
    ID,
    DESCRIPTION
)
VALUES (
    source.ID,
    source.DESCRIPTION
)