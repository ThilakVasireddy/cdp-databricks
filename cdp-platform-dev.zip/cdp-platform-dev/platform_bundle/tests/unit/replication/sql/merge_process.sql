MERGE INTO {table_name} AS target
USING (
    SELECT 
        '{process_name}'                               AS process_name,
        CAST('{last_api_call_timestamp}' AS TIMESTAMP) AS last_api_call_timestamp
) AS source
ON target.process_name = source.process_name
WHEN MATCHED THEN
    UPDATE SET
        target.last_api_call_timestamp = source.last_api_call_timestamp
WHEN NOT MATCHED THEN
    INSERT 
    (
        process_name, 
        last_api_call_timestamp
    ) 
    VALUES 
    (
        source.process_name, 
        source.last_api_call_timestamp
    );