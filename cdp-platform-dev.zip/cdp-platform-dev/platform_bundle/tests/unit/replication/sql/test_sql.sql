SELECT *
FROM {table_name} PARTITION({partition_name})
WHERE CURVE_ID = {curve_id}