## cdb python common functions


* 1.0.1
1. update cdbwriter.Loadset.add() function, add rules for special values of NaN
   the dataFrame should have valueDate in isostr format as index,
    other columns are curve values, column name is curve name
   e.g.
                              ;cid1;   ;cid2;	;cid3;  ;cid4; ;cid5;
       2024-06-28T00:00:00	1.4226	   -0.4	    0.982   NaN     inf
       2024-06-28T03:00:00   -1.0739	-1.4	NaN     NaN     inf
    valueDate must be index of dataFrame

   some rules for special values:
   a) if a curve with whole 'NaN' values, this curve won't be inserted into DB,
      in above sample,;cid4; will not be in DB
   b) if a curve with some 'NaN' values, these 'NaN' cell won't be inserted into DB,
      in above sample,;cid3; will only one value record in DB
   c) if a curve with value of 'inf' (very big number, library will not do any specific operation,
      it will failed at Putloadset* app with java.lang.NumberFormatException, ;cid5; will not be in DB
2. fix the bug in cdbdatareader.get_series() function get error when curve_id length > 1000 

* 1.0.0
1. change the package name from cdb_pycomm_lib to cdbpycommlib
2. upload cdbpycommlib packages into bams, user could download from bams repostiory
#####   usage, in pyproject.toml
 from
```commandline
cdb-pycomm-lib = {url = "http://release.commodities.int.thomsonreuters.com/models/cdb-pycomm-lib/cdb_pycomm_lib-0.0.9.dev9-py3-none-any.whl"}
#cdb-pycomm-lib = { version = "0.0.9.dev9", source = "dxone_cdb_comm_lib" }

[[tool.poetry.source]]
name = 'dxone_cdb_comm_lib'
url = 'https://gitlab.dx1.lseg.com/api/v4/projects/31146/packages/pypi/simple'
priority = "supplemental"
```
to
```commandline
cdbpycommlib = "1.0.0"
```
#####in model *.py, change "cdb_pycomm_lib" to "cdbpycommlib" 
from
```commandline
import cdb_pycomm_lib as wf
...
from cdb_pycomm_lib.cdbtasks import cdbtask,CdbTaskWithDB
...
import cdb_pycomm_lib.cdblogging
logger=cdb_pycomm_lib.cdblogging.get_logger(__name__)
flushlog=cdb_pycomm_lib.cdblogging.flushlog
...
import cdb_pycomm_lib as cdb
import cdb_pycomm_lib.cdbdatareader as reader
import cdb_pycomm_lib.cdbwriter as writer
import cdb_pycomm_lib.cdbutils as util
import cdb_pycomm_lib.cdbmetareader as metareader
```
to
```commandline
import cdbpycommlib as wf
...
from cdbpycommlib.cdbtasks import cdbtask,CdbTaskWithDB
...
import cdbpycommlib.cdblogging
logger=cdbpycommlib.cdblogging.get_logger(__name__)
flushlog=cdbpycommlib.cdblogging.flushlog
...
import cdbpycommlib as cdb
import cdbpycommlib.cdbdatareader as reader
import cdbpycommlib.cdbwriter as writer
import cdbpycommlib.cdbutils as util
import cdbpycommlib.cdbmetareader as metareader
```



* 0.0.9.dev9
1. add get_series_by_name() in cdbdatareader.py, the parametersand return columns are similar as get_series except by entering curve_name list
2. function_db_package_mapping:

| file                 | API function               | Inner class                  | DB package                   | DB functions            |
|:---------------------|:---------------------------|:-----------------------------|:-----------------------------|:------------------------|
| cdbmetareader.py     | get_object_id              | ObjIdByMetaParameter         | meta.pkg_mjapi               | get_by_meta             |
|                      | get_object_meta            | ObjectMetaParameter          | meta.pkg_mjapi               | get_meta                |
|                      | get_children_node          | ChildrenNodeParameter        | meta.pkg_mjapi               | get_element_children    |
| -------------------- | ---------------------------| ------------------------     | --------------------------   | ----------------------  | 
| cdbdatareader.py     | send_notification          | MailNotification             | dw.pkg_mjapi                 | get_data                |
|                      | get_series_by_name         | SeriasDataByNameParameter    | dw.pkg_mjapi                 | get_data_by_name        |
|                      | get_series_name            | SeriasIdToNameParameter      | dw.pkg_mjapi_desktop         | get_curve               |
|                      | get_series_loadset         | SeriesLoadsetParameter       | dw.pkg_mjapi_desktop         | get_loadset_for_curve   |
|                      | _get_series_pivoted        | SeriesDataPivotedParameter   | dw.pkg_mjapi                 | get_pivoted_data        |
|                      | _get_series_id_desktop     | SeriasNameToIdParameter      | dw.pkg_mjapi_desktop         | get_curve               |
|                      | _get_loadset_info_desktop  | LoadsetInfoParameter         | dw.pkg_mjapi_desktop         | get_loadset_info        |
|                      | _get_curve_info_desktop    | CurveInfoParameter           | dw.pkg_mjapi_desktop         | get_curve_info          |
| -------------------- | ---------------------------| ------------------------     | --------------------------   | ----------------------  | 
| cdbflowreader.py     | _get_series_info_desktop   | SeriesInfoParameter          | facility.pkg_flows_mjapi     | get_vessel_port         |
|                      | get_vessel_position        | VesselPositionParameter      | facility.pkg_flows_mjapi     | get_vessel_position     |
|                      | get_vessel_flow            | VesselFlowParameter          | facility.pkg_flows_mjapi     | get_vessel_flow         |
|                      | get_vessel_charac          | VesselEventsParameter        | facility.pkg_flows_mjapi     | get_vessel_event        |
|                      | get_vessel_fixture         | VesselFixtureParameter       | facility.pkg_flows_mjapi     | get_vessel_fixture      |
|                      | get_vessel_zone            | VesselZoneParameter          | facility.pkg_flows_mjapi     | get_vessel_zone         |
|                      | get_charterer_list         | ListChartererParameter       | facility.pkg_flows_mjapi     | get_charterer_list      |
|                      | get_org_list               | ListOrgParameter             | facility.pkg_flows_mjapi     | get_org_list            |
|                      | get_vessel_list            | ListVesselParameter          | facility.pkg_flows_mjapi     | get_vessel_list         |
|                      | get_port_list              | ListPortParameter            | facility.pkg_flows_mjapi     | get_port_list           |
|                      | get_commodity_lis          | ListCommodityParameter       | facility.pkg_flows_mjapi     | get_commodity_list      |
|                      | get_value_list             | ListValueParameter           | facility.pkg_flows_mjapi     | get_common_value_list   |
|                      | get_gun_list               | ListGunParameter             | facility.pkg_flows_mjapi     | get_gun_list            |
|                      | get_grade_list             | ListGradeParameter           | facility.pkg_flows_mjapi     | get_grade_list          |
| -------------------- | ---------------------------| ------------------------     | --------------------------   | ----------------------  | 
| cdbfacilityrader.py  | get_installed_capacity     | InstalledCapacityParameter   | facility.pkg_facility_mjapi  | get_installed_capacity  |
|                      | get_available_capacity     | AvailableCapacityParameter   | facility.pkg_facility_mjapi  | get_available_capacity  |
|                      | get_capacity_impact        | CapacityImpactParameter      | facility.pkg_facility_mjapi  | get_capacity_impact     |
|                      | get_facility_attributes    | FacilityAttributesParameter  | facility.pkg_facility_mjapi  | get_facility_attributes |
|                      | get_facility_ids           | FacilityIdsParameter         | facility.pkg_facility_mjapi  | get_facilities          |
|                      | get_facility_iir_details   | FacilityIIRDetailsParameter  | facility.pkg_facility_mjapi  | get_iir_details         |
|                      | get_facility_umm_incident  | FacilityUmmIncidentParameter | facility.pkg_facility_mjapi3 | get_umm_incident        |
| -------------------- | ---------------------------| ------------------------     | --------------------------   | ----------------------  |   


* 0.0.9.dev8
1. Allow to change the cdbconfig 'dbread' to other environment, if it is deployed into non-prod server, in both Jupyter and poetry mode.
2. Meanwhile dbwrite is not allow to change.

usage
```commandline
import datetime, sys, os
import pandas as pd
import numpy as np
 
#IMPORT cdb_pycomm_lib FIRST
import cdb_pycomm_lib as wf
wf.CDBCONFIG.reset_config(dbwrite=wf.CDBCONFIG.BETA, dbread=wf.CDBCONFIG.PROD)
 
# CDB methods - need to be imported after config changes
import cdb_pycomm_lib.cdbdatareader as reader
 
[flows_data, sql] = reader.get_series([104840823],            
                                fd_from=forecast_start_date,
                                fd_to=forecast_end_date,
                                vd_from=value_start_date,
                                vd_to=value_end_date,       
                                ret_sql=True)

```


* 0.0.9.dev7
1. add get_facility_umm_incident in cdbfacilityreader.py
2. update Loadset class in cdbwriter.py, allow input dataframe index dtype as datetime64[ns],
   no need convert into string, but it should be in UTC timezone.
3. add format_date_of_dataframe in cdbutils.py


* 0.0.9.dev6
1. fix the ModelRunConfig issue in CdbConfig.py, so the esb message header will have correct script name
   as pyv-v-v.modelname.modelrun
2. add stage "increase_version" in gitlab-ci.yaml, it could upgrader pyproject.toml version automatacally,
   user could run this step before building new release, without manually maintain the release version

* 0.0.9.dev5
1. add class ErrorLevelFilter,
   in logging.yaml, this filter could be added for  to log just ERROR and above log into stderr
   sample local logging config file:
``` 
version: 1

formatters:
  simple :
    format: "%(asctime)s - [%(levelname)s] - [%(pathname)s:%(lineno)d] - %(message)s"
  extended :
    format: '%(asctime)s - [%(levelname)s] - [%(pathname)s:%(lineno)d] - [%(modelname)s - %(modelrun)s - %(pid)s] - %(message)s'

filters:
  logFilter:
    (): cdb_pycomm_lib.cdblogfilter.CdbLogFilter
    modelname: {{modelname}}
    modelrun:  {{modelrun}}
    pid: {{pid}}
  show_only_errorFilter:
    (): cdb_pycomm_lib.cdblogfilter.ErrorLevelFilter

handlers:
  error_console_handler:
    class: logging.StreamHandler
    formatter: simple
    filters: [show_only_errorFilter ]

  file_handler:
    class: logging.handlers.RotatingFileHandler
    filename: /local/logs/esb/repydemo.log
    formatter: simple
    mode: a
    maxBytes: 10240000
    backupCount: 5

  model_console_handler:
    class: logging.StreamHandler
    stream: ext://sys.stdout
    formatter: extended
    filters: [logFilter ]

  model_file_handler:
    class: logging.handlers.RotatingFileHandler
    filename: /local/logs/esb/repydemo.log
    formatter: extended
    mode: a
    maxBytes: 10240000
    backupCount: 5
    filters: [ logFilter ]


loggers:
  repydemo.testrun:
    handlers: [model_console_handler, model_file_handler ]
    level: DEBUG
    propagate: False

  repydemo.EUGas_Balance:
    handlers: [ model_console_handler, model_file_handler ]
    level: DEBUG
    propagate: False

  repydemo.EUGas_Prices:
    handlers: [ model_console_handler, model_file_handler ]
    level: DEBUG
    propagate: False

  cdb_pycomm_lib.cdbdatareader:
    handlers: [model_console_handler, model_file_handler ]
    level: DEBUG
    propagate: False

root:
  level: INFO
  handlers: [error_console_handler, file_handler]
  propagate: True

```

2. server mode config files requires only main_config section
##### sample "pytharuncomm_beta.cfg"
``` 
[main_config]
CallingSystem=MATLAB
DataRepository=/data/matlab/
Rdp_app_key=8daxxxxxxxxxxxx
Rdp_username=XXX
Rdp_password=XXXX
Rdp_proxy=http://proxy-server:port
```
3. remove db parameters in most query related functions
4. provding cdbfacilityreader functions for testing purpose, do not use it in prod

* 0.0.9.dev4
1. bug fix
2. remove db parameters in some query related functions
3. allow using config file in server mode, which help to add project level config items,
   but database connection
#####    sample "pytharuncomm_beta.cfg"
``` 
[main_config]
CallingSystem=MATLAB
DataRepository=/data/matlab/
Rdp_app_key=8daxxxxxxxxxxxx
Rdp_username=XXX
Rdp_password=XXXX
Rdp_proxy=http://proxy-server:port

[Alpha-DTC]

[Beta]
DwFetchSize = 10000
DwHost = oracle2.beta.commodities.int.thomsonreuters.com
DwPort = 1521
DwUser = MATLAB
DwPassword = XXXX
DwService = pocbt.int.thomsonreuters.com
MessageReceiver = messagereceiver-rerun.beta.commodities.int.thomsonreuters.com:9099

[Production-DTC]

```


* 0.0.9.dev3
    1. from version of 0.0.9, cdb-pycomm-lib requires python version >= 3.10,
       cdb-pycomm-lib is mainly used for python new ecosystem development
    2. replaced the cx_Oracle with oracledb, currently it support only thick connect for CDB DB connection
    3. support local configuration and log configuration files
    4. allow cdbwriter to write EsbMessage to local files ( by adding config in local configuration file)

  Use cdp_pycomm_lib in Jupyter:
    ```
    import cdp_pycomm_lib as wf
  
    from cdp_pycomm_lib import cdbconfig
    # if you have local config files, you can use it, to swtich the dbread, dbwrite and other config items,
    #wf.CDBCONFIG=cdbconfig.AppConfig('C:\\pythonPrj\\conf\\pytharuncomm.cfg')
    #otherwise, please use below items for config with matlab config items, and invoke reset_config and reset_location to point out the required items
    if wf.cdbconfig.AppConfig.is_desktop():
    # On desktop, set reader and writer environment
    wf.CDBCONFIG.reset_config(dbwrite=wf.CDBCONFIG.ALPHA, dbread=wf.CDBCONFIG.PROD) #read from Prod, write to Beta
    wf.CDBCONFIG.reset_localoracleclientpath('c:/refinitiv/app/instantclient_21_6')
    wf.CDBCONFIG.reset_localmessagereceiverfile('c:/refinitiv/log/localmessagereceiver.dat')
    wf.CDBCONFIG.save()
  
    #config the log 
    import logging
    from cdp_pycomm_lib import cdblogging
    logconfig=cdblogging.logconfig
    #if no specific required, just run logconfig()
    #logconfig()
    #if you have specific log requirement, like put into log files, you need to use logging.yaml, and run below commands:
    import os
    pid= os.getpid()
    modeldict={'modelname':'you_model','modelrun':'your_run','pid':pid}
    logconfig(modeldict=modeldict,logconfigfile='C:\\pythonPrj\\conf\\logging.yaml')
  
    #now get logger
    logger=logging.getLogger()
  
    import cdp_pycomm_lib.cdbdatareader as cdbdatareader
    logger.info("this is info")
    warn_msg='marnning!!!!'
    logger.debug(f'*****this is warn:  {warn_msg}')
    logger.debug( 'debug')
    ```
sample local config file:
   ```
   #----------------------C:\\pythonPrj\\conf\\pytharuncomm.cfg---------------------#
    [main_config]
    #dbread and dbwrite config item only used in local environment, in server, it is not useful
    dbread=Beta
    dbwrite=Alpha-DTC
    OracleClientPathinWindows=c:/refinitiv/app/instantclient_21_6
    LocalMessageReceiverFile=c:/refinitiv/log/localmessagereceiver.dat
    
    [Alpha-DTC]
    DwFetchSize = 10000
    DwHost = oracle2.beta.commodities.int.thomsonreuters.com
    DwPort = 1521
    DwUser = MATLAB
    DwPassword = XXXX
    DwService = pocbd.int.thomsonreuters.com
    MessageReceiver = c34sm2rcdbd17.int.refinitiv.com:9099
    
    [Beta]
    DwFetchSize = 10000
    DwHost = oracle2.beta.commodities.int.thomsonreuters.com
    DwPort = 1521
    DwUser = MATLAB
    DwPassword = XXXX
    DwService = pocbt.int.thomsonreuters.com
    MessageReceiver = messagereceiver-rerun.beta.commodities.int.thomsonreuters.com:9099
    
    [Production-DTC]
   ```

sample local logging config file:
 ```
    #----------------------C:\\pythonPrj\\conf\\logging.yaml---------------------#
    `version: 1
    
    formatters:
      simple :
        format: "%(asctime)s - [%(levelname)s] - [%(pathname)s:%(lineno)d] - %(message)s"
      extended :
        format: '%(asctime)s - [%(levelname)s] - [%(pathname)s:%(lineno)d] - [%(modelname)s - %(modelrun)s - %(pid)s] - %(message)s'
    
    filters:
      logFilter:
        (): cdp_pycomm_lib.cdblogfilter.CdbLogFilter
        modelname: {{modelname}}
        modelrun:  {{modelrun}}
        pid: {{pid}}
    
    handlers:
      console_handler:
        class: logging.StreamHandler
        stream: ext://sys.stdout
        formatter: simple
    
      file_handler:
        class: logging.handlers.RotatingFileHandler
        filename: /local/logs/esb/repydemo.log
        formatter: simple
        mode: a
        maxBytes: 10240000
        backupCount: 5
   
      model_console_handler:
        class: logging.StreamHandler
        stream: ext://sys.stdout
        formatter: extended
        filters: [logFilter ]
 
      model_file_handler:
        class: logging.handlers.RotatingFileHandler
        filename: /local/logs/esb/repydemo_model.log
        formatter: simple
        mode: a
        maxBytes: 10240000
        backupCount: 5
   
    loggers:
      repydemo.testrun:
        handlers: [model_console_handler, model_file_handler ]
        level: DEBUG
        propagate: False
    
      cdp_pycomm_lib.cdbdatareader:
        handlers: [model_console_handler, model_file_handler ]
        level: DEBUG
        propagate: False
    
    root:
      level: INFO
      handlers: [console_handler, file_handler]
      propagate: True
` 
 ```

run unittest locally:
  ```
      poetry run python -m unittest -v
      or 
      poetry run pytest --capture=no -v

  
  ```

log() function in cdbutils.py is removed.

* 0.0.9.dev1
    1. from version of 0.0.9, cdb-pycomm-lib requires python version >= 3.10,
       cdb-pycomm-lib is mainly used for python new ecosystem development
    2. integrate with poetry and dxOne pipleline


* 0.0.8
    1. fix the p_sql local variable not exist issue (see CDB-5750)
    2. change the time_zone parameter in get_series() function, remove time_zone, add time_zone_in and time_zone_out
    3. import logging, to replace cdbutils.log() function, allow to output the log into a file

  How to use logging?<br/>
  a. in module \_\_init\_\_.py <br/>
  ```
    import cdp_pycomm_lib as cdb
    LOGGER = cdb.CDBLOGGER
    LOGGER.loglevel = 'INFO'
    LOGGER.logfilename='/local/logs/matlab/cdblog.log'
   ```
  b. write log <br/>
   ``` 
    import cdp_pycomm_lib as wf
    LIBLOGGER=wf.CDBLOGGER.liblogger
  
    def func1():
        LIBLOGGRT.info("enter func1()")  
    def func2():
        LIBLOGGER.warn("this is warn")
   
   ```

  log() function in cdbutils.py is still available, but will be deprecated soon.

  log() function in cdbutils.py is still available, but will be deprecated soon.


* 0.0.7
    1. Allow select * for cdbflowreader queries
    2. Allow IMO_List parameter in cdbflowreader queries, works in backend as a bind variable, which was highlighted by cx_oracle
    3. Fix some issues on SQLs

* 0.0.6
    1. change the mail sender for send_notification() function


* 0.0.5
    1. first main published version, provding cdbdatareader,cdbflowreader and cdbwriter

