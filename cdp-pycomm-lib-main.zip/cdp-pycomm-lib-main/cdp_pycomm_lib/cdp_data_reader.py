# -*-coding:utf-8-*-
"""
this module try to read series data

"""
from datetime import datetime
from typing import Optional

from pyspark.sql import DataFrame

from cdp_pycomm_lib.common import cdp_common_utils, cdp_common_logging
from cdp_pycomm_lib.common.cdp_config import CDP_MODEL, CDP_CONFIG
from cdp_pycomm_lib.common.cdp_constants import DEFAULT_TIMEZONE
from cdp_pycomm_lib.common.cdp_error import ParameterError, MetaError
from cdp_pycomm_lib.dw import mjapi_services, curve_services
from cdp_pycomm_lib.mule import mule_services

log = cdp_common_logging.get_logger(__name__)


def send_notification(mail_subject=None, mail_content=None, content_type='text/plain'):
    """
    An example to send notification email by model_name and model_run

    Usage
    -----
    import cdp_pycomm_lib.cdp_data_reader as cdp_data_reader
    mail_content=['<html><head><title>my_title</title></head>','<body><h1>hello , this is html test</h1><table border=1><tr><th>column1</th><th>column2</th></tr><tr><td>value1</td><td>value2</td></tr></table><body></html>']
    datat_bl=cdp_data_reader.send_notification('html subject',mail_content,'text/html')
    or
    mail_content_1 = 'this is text plain test!!!'
    datat_bl=cdp_data_reader.send_notification('plain subject',mail_content_1,'text/plain')

    Parameters
    ------
    :param mail_subject: subject of an email
    :param mail_content: string or string list, if it is string list, each item should less than 256 characters
    :param content_type:'text/html' or 'text/plain', the default value is 'text/plain'
    :return: status and description data framework
    """
    if content_type == 'text/plain':
        line_break = '\n\n'
    else:
        line_break = '<BR><BR>'

    messages = ""
    if isinstance(mail_content, str):
        messages += mail_content
    elif isinstance(mail_content, list):
        messages = line_break.join(mail_content)
    else:
        messages = 'test'

    caller_guid = CDP_MODEL.caller_guid
    caller = '[CallerGUID %s (from %s)]' % (caller_guid.upper(), CDP_CONFIG.get_env().upper())
    messages = messages + line_break + caller

    try:
        out_data = mule_services.send_model_notification(
            model_name=CDP_MODEL.model_name,
            model_run=CDP_MODEL.model_run,
            message=messages,
            subject=mail_subject,
            content_type=content_type
        )
    except Exception as e:
        log.exception(e)
        out_data = None

    return out_data


def get_series_name(curve_ids: list[int]) -> DataFrame:
    """
    An example to query series Id to Name

    Usage
    -----
    import cdp_pycomm_lib.cdp_data_reader as cdp_data_reader
    curve_ids= [101658360,112829829,106271940,106271941,106271941,106271941]
    datat_bl = cdp_data_reader.get_series_name(curve_ids)

    Parameters
    ----------
    :param curve_ids:
    :return:
    """
    log.debug("enter cdp_data_reader::get_series_name")
    try:
        return curve_services.get_curve(list(filter(None, curve_ids)))
    except ParameterError as e:
        log.error(e)
        raise e


def get_series_by_name(
        curve_name_list: list[str],
        fd_from: datetime = None,
        fd_to: datetime = None,
        vd_from: datetime = None,
        vd_to: datetime = None,
        time_zone_in='UTC',
        time_zone_out=None,
        partial_match_flag: bool = False
) -> Optional[DataFrame]:
    """
    An example to query series info by curve names

    Usage
    -----
    import cdp_pycomm_lib.cdp_data_reader as cdp_data_reader

    f1 = datetime.datetime.strptime('2016-04-30','%Y-%m-%d')
    f2 = f1+datetime.timedelta(days=300)
    names= ['AgWeaWdtVisibility;WDT;UTC;Actual;min.15;min.1;Visibility;m;NHSFD',
            'FLOWZONE.GLOBAL_DIRTY;Oil / Oil Products;From;Tunisia;To;Malta;W.1;UTC;kt;Sch;EXC;Exports',
            'FLOWZONE.GLOBAL_DIRTY;Crude Oil;From;Europe, Middle East, Africa;To;North Sea;M.1;UTC;kt;Sch;EXC;Imports',
            'FLOWZONE.GLOBAL_DIRTY;Crude Oil;From;Gabon;To;Russia, FSU;M.1;UTC;kt;Sch;EXC;Imports',
            'FLOWZONE.GLOBAL_DIRTY;Crude Oil;From;Norway;To;North Sea;W.1;UTC;kt;Sch;EXC;Imports',
            'FLOWZONE.GLOBAL_DIRTY;Oil / Oil Products;From;USA - Gulf Coast (PADD III);To;Belgium;W.1;UTC;kt;Sch;EXC;Imports',
            'FLOWZONE.GLOBAL_DIRTY;Crude Oil;From;Europe, Middle East, Africa;To;North Sea;M.1;UTC;kt;Sch;EXC;Imports']
    datat_bl = cdp_data_reader.get_series_by_name( names, f1, f2, f1, f2,partial_match_flag='N', output_star_flag=True)

    Parameters
    ----------
    curve_name_list: list of curve name or  partial curve name
        A single curve name or list of curve names where each curve name is a String.
        If partial_match_flag is 'N', the list length should be less or equal than 20000,
        If partial_match_flag is 'Y', the list length should be less or equal than 10.
    fd_from: datetime.datetime
        The forecast date from which data is to be retrieved. this is a required parameter unless both fd_from and fd_to is null.
    fd_to: datetime.datetime
        The forecast date up to which data is to be retrieved. this is a required parameter.
    vd_from: datetime.datetime
        The value date from which data is to be retrieved. this is a required parameter.
    vd_to: datetime.datetime
        The value date up to which data is to be retrieved. this is a required parameter.
    time_zone_in: str (the default is 'UTC')
        The time zone to be used for forecast and value dates input, e.g. 'CET'.
        If this parameter is set value and time_zone_out is None, then both in and date will use timezone of this parameter.
        Do not set this parameter value to None.
    time_zone_out: str (the default is None)
        The time zone to be used for forecast and value dates output, e.g. 'CET'.
        If this parameter is set Not None value, the output date will use this value,
        otherwise, the output data timezone will be same as the parameter of 'time_zone_in'.
    partial_match_flag: str (the default is 'N')
        Identify the query is exact name match or partial match.
        If partial_match_flag='Y', the inner query is like , whose query time will be longer than exact match

    Returns
    -------

    Pyspark DataFrame containing data retrieved from the curves specified by
    curve_ids. The columns are labelled as follows:
        ID : the curve IDs (int)
        FD : forecast dates (datetime)
        VD : value dates (datetime)
        V  : returned values (type depends on the data in the curve)
        NM : the curve names
    A tuple will be returned containing the output dataframe, the columns description of dataframe.

    """

    log.debug("enter cdp_data_reader::get_series_by_name")
    start_time = cdp_common_utils.now()

    # check the curve_name_list lens:
    # if partial_match_flag = False, the list length should be <= 20000,
    # if partial_match_flag = True the list length should be <= 10
    if not partial_match_flag and len(curve_name_list) > 20000:
        raise ParameterError("The curve name list size should be less than 20000 if the Partial Match flag is N")
    if partial_match_flag and len(curve_name_list) > 10:
        raise ParameterError("The curve name list size should be less than 10 if the Partial Match flag is Y")

    if time_zone_out is None:
        time_zone_out = time_zone_in
    if time_zone_in is None:
        time_zone_in = DEFAULT_TIMEZONE
        time_zone_out = DEFAULT_TIMEZONE

    # for timeSeries curve query, fd_from= vd_from, fd_to=vd_to
    if fd_from is None and fd_to is None and vd_from is not None and vd_to is not None:
        fd_from = vd_from
        fd_to = vd_to
    log.debug(f"{fd_from}, {fd_to}, {vd_from}, {vd_to}")

    out_data = None
    try:
        out_data = mjapi_services.get_data(
            curve_name_list, fd_from, fd_to, vd_from, vd_to, time_zone_in, time_zone_out, partial_match_flag
        )
    except (MetaError, ParameterError) as e:
        log.exception(e)
    except Exception as e1:
        log.exception(e1)
    finally:
        end_time = cdp_common_utils.now()
        log.info({
            'curve_name_list': curve_name_list,
            'fd_from': fd_from,
            'fd_to': fd_to,
            'vd_from': vd_from,
            'vd_to': vd_to,
            'time_zone_in': time_zone_in,
            'time_zone_out': time_zone_out,
            'partial_match_flag': partial_match_flag,
            'modelName': CDP_MODEL.model_name,
            'modelRun': CDP_MODEL.model_run,
            'callerGuid': CDP_MODEL.caller_guid,
            'runDate': CDP_MODEL.run_datetime,
            'method': 'get_object_meta',
            'duration': end_time - start_time
        })
    return out_data


def get_series_loadset(curve_inputs) -> DataFrame:
    """
    An example to query LoadSet of curves

    Usage
    -----
    import cdp_pycomm_lib.cdp_data_reader as cdp_data_reader
    curve_ids= [101658360]
    datat_bl = cdp_data_reader.get_series_loadset(curve_ids)

    Parameters
    ----------
    :param curve_inputs:
    :return:
    """
    log.debug("enter cdp_data_reader::get_series_loadset")
    out_data = None
    try:
        if isinstance(curve_inputs, list) and len(curve_inputs) >= 1:
            if isinstance(curve_inputs[0], int):
                out_data = curve_services.get_loadset_for_curve_by_id(curve_inputs)
            elif isinstance(curve_inputs[0], str):
                out_data = curve_services.get_loadset_for_curve_by_curve_name(curve_inputs)
    except ParameterError as e:
        log.exception(e)
    return out_data
