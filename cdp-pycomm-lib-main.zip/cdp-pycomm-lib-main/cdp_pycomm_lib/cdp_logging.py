# -*-coding:utf-8-*-
"""
Module handling log functions.

Usage:
--------
import logging
from cdp_pycomm_lib import cdp_logging

# If no specific required, just run log_config(), it will apply default LOGGING_CONF inside the module.
cdp_logging.log_config()

# If you have specific log requirement, like put into log files, you need to use logging.yaml, and run below commands:
import os
pid= os.getpid()
model_dict={'model_name':'you_model','model_run':'your_run','pid':pid}
cdp_logging.log_config(model_dict=model_dict,log_config_file='C:\\pythonPrj\\conf\\logging.yaml')

# Now get logger
logger = cdp_logging.getLogger()

import cdp_pycomm_lib.cdp_data_reader as cdp_data_reader
logger.info("this is info")
warn_msg='warning!!!!'
logger.debug(f'*****this is warning:  {warn_msg}')
logger.debug( 'debug')
"""

from cdp_pycomm_lib.common import cdp_common_logging


def log_config(model_dict=None, log_config_file=None):
    cdp_common_logging.log_config(model_dict, log_config_file)


def flush_log():
    cdp_common_logging.flush_log()


def get_logger(name_in=None):
    return cdp_common_logging.get_logger(name_in)
