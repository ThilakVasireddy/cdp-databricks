# -*-coding:utf-8-*-
"""
this module try to read metadata

"""
from typing import Optional

from pyspark.sql import DataFrame

from cdp_pycomm_lib.common import cdp_common_utils, cdp_common_logging
from cdp_pycomm_lib.common.cdp_config import CDP_MODEL
from cdp_pycomm_lib.common.cdp_error import ParameterError, MetaError
from cdp_pycomm_lib.common.cdp_object import parse_meta
from cdp_pycomm_lib.meta import mjapi_services

log = cdp_common_logging.get_logger(__name__)


def get_object_id(obj_type, obj_meta, b_ret_objname=False) -> Optional[DataFrame]:
    """
    an example to query curve id by meta

    Usage
    -----
    import cdp_pycomm_lib.cdp_meta_reader as cdp_meta_reader
    meta=('',('Var','','FX.rate'),'')
    datat_bl = cdp_meta_reader.get_object_id('Curve',meta)

    Parameters
    ----------
    :param obj_type:
    :param obj_meta:
    :param b_ret_objname:
    :return:
    """
    log.info('inside get_object_ids_by_meta')
    start_time = cdp_common_utils.now()

    try:
        args = parse_meta(obj_meta)
        df = mjapi_services.get_by_meta(obj_type, args, b_ret_objname)
        return df
    except (MetaError, ParameterError) as e:
        log.error("Failed to retrieve object id")
        raise e
    finally:
        end_time = cdp_common_utils.now()
        log.info({
            'ojb_type': obj_type,
            'obj_meta': obj_meta,
            'b_ret_objname': b_ret_objname,
            'modelName': CDP_MODEL.model_name,
            'modelRun': CDP_MODEL.model_run,
            'callerGuid': CDP_MODEL.caller_guid,
            'runDate': CDP_MODEL.run_datetime,
            'method': 'get_object_id',
            'duration': end_time - start_time
        })


def get_object_meta(ids_or_meta, obj_type='Curve') -> Optional[DataFrame]:
    """
    an example to query Obj attributes by id or meta
    Usage
    -----
    import cdp_pycomm_lib.cdp_meta_reader as cdp_meta_reader
    datat_bl = cdp_meta_reader.get_object_meta([101658360,112829829,106271940,106271941,106271942],'Curve')

    Parameters
    ----------
    :param ids_or_meta:
    :param obj_type:
        default value is 'Curve'
    """
    log.info('inside get_object_meta')
    start_time = cdp_common_utils.now()

    try:
        if isinstance(ids_or_meta, list) and len(ids_or_meta) >= 1 and isinstance(ids_or_meta[0], int):
            result_df = mjapi_services.get_meta_by_id(obj_type, ids_or_meta)
        elif isinstance(ids_or_meta, tuple):
            args = parse_meta(ids_or_meta)
            result_df = mjapi_services.get_meta_by_meta(obj_type, args)
        else:
            return None

        return result_df
    except (MetaError, ParameterError) as e:
        log.error("Failed to retrieve object id")
        raise e
    finally:
        end_time = cdp_common_utils.now()
        log.info({
            'ids_or_meta': ids_or_meta,
            'obj_type': obj_type,
            'modelName': CDP_MODEL.model_name,
            'modelRun': CDP_MODEL.model_run,
            'callerGuid': CDP_MODEL.caller_guid,
            'runDate': CDP_MODEL.run_datetime,
            'method': 'get_object_meta',
            'duration': end_time - start_time
        })
