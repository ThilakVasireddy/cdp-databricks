# -*-coding:utf-8-*-
"""
Utility module for cdp workflow.
"""
from datetime import datetime

from pyspark.sql import SparkSession

from cdp_pycomm_lib.common.cdp_config import CDP_MODEL, CDP_CONFIG
from cdp_pycomm_lib.common.spark_wrapper import CDP_SPARK


def reset_app_config(config_file_path: str):
    CDP_CONFIG.reset_config(config_file_path)


def add_app_config(name, value):
    CDP_CONFIG.add_config(name, value)


def set_model_run_config(
        run_datetime: datetime,
        caller_guid: str,
        model_run: str = 'pyAbc.desktop.test'
):
    """
    server len(file_parts) = 8
    #in Spyder console #4: ['C:', 'matlab', 'python', 'pyCdb-trunk']
    #in jupyter cell #3: ['c:\\python36...ipykernel_launcher.py', '-f', 'C:\\Users\\...json']
    """
    CDP_MODEL.model_run = model_run
    CDP_MODEL.run_datetime = run_datetime
    CDP_MODEL.caller_guid = caller_guid


def set_spark(remote_spark: SparkSession):
    CDP_SPARK.spark_local = remote_spark
