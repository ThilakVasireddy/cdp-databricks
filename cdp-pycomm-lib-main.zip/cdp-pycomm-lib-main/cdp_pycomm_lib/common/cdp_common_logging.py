import logging
import logging.config
import os
import pathlib

import yaml

LOGGING_CONF = {
    'version': 1,
    'formatters': {
        'simple': {
            'format': '%(asctime)s - [%(levelname)s] - [%(pathname)s:%(lineno)d] - %(message)s'
        }
    },
    'handlers': {
        'console_handler': {
            'class': 'logging.StreamHandler',
            'formatter': 'simple'
        }
    },
    'root': {
        'level': 'ERROR',
        'handlers': ['console_handler']
    },
}


def log_config(model_dict=None, log_config_file=None):
    if model_dict is None:
        pid = os.getpid()
        model_dict = {'model_name': 'model_name', 'model_run': '', 'pid': pid}

    if log_config_file is None:
        pwd_path = pathlib.Path.cwd()
        log_config_file = os.path.join(pwd_path, 'conf', "logging.yaml")
    if os.path.exists(log_config_file):
        with open(log_config_file, 'r') as f:
            log_config_content = f.read()
            log_config_content = log_config_content.replace('{{', '{').replace('}}', '}')
            log_config_content = log_config_content.format(**model_dict)
            log_cfg = yaml.safe_load(log_config_content)
            logging.config.dictConfig(log_cfg)
    else:
        logging.config.dictConfig(LOGGING_CONF)


def flush_log():
    mylogger = logging.getLogger(__name__)
    for handler in mylogger.handlers:
        handler.flush()


def get_logger(name_in=None):
    name = 'root' if name_in is None else name_in
    return logging.getLogger(name)
