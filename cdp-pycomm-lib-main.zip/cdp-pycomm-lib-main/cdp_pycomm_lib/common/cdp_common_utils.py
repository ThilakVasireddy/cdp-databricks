import json
import os
import secrets
import xml.etree.ElementTree as elementTree
from datetime import datetime, date, timedelta, timezone
from importlib.resources import files

from cdp_pycomm_lib.common import cdp_common_logging

log = cdp_common_logging.get_logger(__name__)


def guid() -> str:
    """Generate caller guid if missing from workflow."""
    return secrets.token_hex(16)


def today() -> datetime:
    """Today's UTC datetime, return a datetime object"""
    today_datetime = datetime.now(timezone.utc)
    return datetime(today_datetime.year, today_datetime.month, today_datetime.day, 0, 0, 0)


def today_date() -> date:
    """Today's UTC date, return a date object"""
    today_datetime = datetime.now(timezone.utc)
    return date(today_datetime.year, today_datetime.month, today_datetime.day)


def now() -> datetime:
    return datetime.now(timezone.utc)


def delta_date(delta) -> date:
    """ today plus or minors several days mentioned as delta, return a date object"""
    return today_date() + timedelta(days=delta)


def iso_time(date_str=None, sep='T'):
    """Convert date time text into a datetime object."""
    if isinstance(date_str, str):
        date_object = datetime.strptime(date_str, '%Y-%m-%d' + sep + '%H:%M:%S')
    else:
        date_object = date_str
    return date_object


def iso_str(date_object=None, sep='T'):
    """Convert datetime object into date time text."""
    if isinstance(date_object, datetime):
        date_str = date_object.strftime('%Y-%m-%d' + sep + '%H:%M:%S')
    else:
        date_str = date_object
    return date_str


def generate_id() -> int:
    return -1


def xml2dict(xmlstr):
    """Parsing parameter xml message from criteria service."""

    tree = elementTree.fromstring(xmlstr)
    xml_dict = {}
    for items in tree:
        xml_dict[items.tag] = items.text
    return xml_dict


def read_config_file_in_package(package_name, config_file_name) -> dict:
    config_file = files(package_name).joinpath(config_file_name)
    log.debug(f"Loading configuration from {config_file}")
    if config_file.is_file():
        with config_file.open('r', encoding='utf-8') as file:
            return json.load(file)
    else:
        log.info(f"Configuration file {config_file} does not exist.")
        return {}


def read_config_file(config_file) -> dict:
    log.debug(f"Loading configuration from {config_file}")
    if os.path.exists(config_file):
        with open(config_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
            log.info(f'{config_file} is loaded')
            return data
    else:
        log.info(f"Configuration file {config_file} does not exist.")
        return {}
