# -*-coding:utf-8-*-
"""
Module handling CDP Config.
This module is not dependent on any other cdp_pycomm_lib module.
cdp_config gets initiated with default settings from cdp_pycomm_lib.

Classes:
--------

* AppConfig       -  Environment related configurations.
* ModelRunConfig  -  Workflow related configurations.

"""
import os

from cdp_pycomm_lib import config
from cdp_pycomm_lib.common import cdp_common_utils, cdp_common_logging
from cdp_pycomm_lib.common.cdp_constants import PYAPP

log = cdp_common_logging.get_logger(__name__)


class AppConfig:
    """
    CDP Config class
    """
    DEFAULT_ENV = 'local'
    DEFAULT_STAGE = 'test'
    ENV = os.getenv('ENV', DEFAULT_ENV).lower()
    STAGE = os.getenv('STAGE', DEFAULT_STAGE).lower()
    SERVER_CONFIG_DIR = f'/Volumes/cdp_{ENV}_{STAGE}_catalog_01/platform/platform/config'
    DESK_CONFIG_FILE = '/lseg/python/pytha_run_configs.json'

    def __init__(self):
        self.config = self.__load_config()

    def __load_config(self):
        internal_config_file = f"{self.ENV}_{self.STAGE}.json"
        internal_config = cdp_common_utils.read_config_file_in_package(config, internal_config_file)

        if self.is_server():
            config_file = f"{self.SERVER_CONFIG_DIR}/config.json"
        else:
            config_file = self.DESK_CONFIG_FILE
        config_server = cdp_common_utils.read_config_file(config_file)

        internal_config.update(config_server)
        return internal_config

    def reset_config(self, config_file: str):
        new_config = cdp_common_utils.read_config_file(config_file)
        self.config.update(new_config)

    def get_config(self, param_name):
        """
        NAME:     get_config
        PURPOSE:  Get the value of a system parameter
        """
        param_names = param_name.split('.')
        cfg = self.config[param_names[0]]
        for param in param_names[1:]:
            cfg = cfg[param]
        return cfg

    def add_config(self, name, value):
        self.config[name] = value

    def get_env(self):
        return self.ENV

    def get_config_dir(self):
        return self.SERVER_CONFIG_DIR

    def is_server(self):
        return self.ENV != self.DEFAULT_ENV


class ModelRunConfig:
    """
    Model run properties for logging and cdb read/write.
    """

    def __init__(self, model_run=None):
        if not model_run:
            model_run = 'cdp_pycomm_lib.' + ModelRunConfig.get_user()
        self.model_run = model_run
        self.model_name = PYAPP
        self.run_datetime = cdp_common_utils.today()
        self.caller_guid = cdp_common_utils.guid()
        self.pid = [os.getppid(), os.getpid()]

    @staticmethod
    def get_user():
        """
        Returns the current username if environment is desktop.
        """
        return os.getenv('USERNAME', default='server')

    def __repr__(self):
        return str(
            {
                'model_run': self.model_run,
                'run_datetime': str(self.run_datetime),
                'caller_guid': self.caller_guid,
                'p_pid': self.pid[0], 'pid': self.pid[1]
            }
        )

    def __str__(self):
        return f'{self.model_run}({str(self.run_datetime)}, {self.caller_guid}'


CDP_CONFIG = AppConfig()
CDP_MODEL = ModelRunConfig()
