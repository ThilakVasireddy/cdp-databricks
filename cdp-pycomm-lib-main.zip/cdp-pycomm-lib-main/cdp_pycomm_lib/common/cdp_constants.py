MAX_ARGUMENTS: int = 4
QUOTE = '"'
DEFAULT_SET_OPERATOR = ' INTERSECT '
FUNC_GETCHILDREN = 'GETCHILDREN'
VALID_FUNCTIONS = [FUNC_GETCHILDREN]

LCB = '{'  # left curly brace
RCB = '}'  # right curly brace
LBR = '('  # left brace(parenthesis)
RBR = ')'  # right brace(parenthesis)
SEP = ','  # separator

# set operators
OP_INTERSECT = 'INTERSECT'
OP_MINUS = 'MINUS'
OP_UNION = 'UNION'
VALID_OPERATORS = [OP_INTERSECT, OP_MINUS, OP_UNION]

HQ_ALL = 'ALL'  # all levels
HQ_ALL_P = 'ALLP'  # all levels, include parent
HQ_DIRECT = 'DIRECT'  # current level
HQ_DIRECT_P = 'DIRECTP'  # current level, include parent (slow)
HQ_LEVEL = 'LEVEL'  # named level

LOAD_SET = 'loadset'

REGEX_PATTERN = r'{?"[^"]*"}?'

DEFAULT_CURVE_TYPE_ID = 2  # forecast
SERIES_SET_TYPE_ID = 1  # forecast

DEFAULT_SENDER = 'no-reply@mrelay.lseg.com'

DATEFORMAT_DATE_ONLY = '%Y-%m-%d'
DATEFORMAT_DATE_TIME = '%Y-%m-%d %H:%M:%S'
DATEFORMAT_DATE_TIME_WITH_T = '%Y-%m-%dT%H:%M:%S'

PYAPP = 'Pytharun'

DEFAULT_ENTITY_NAME_GROUP_NAME = 'PC-META'
DEFAULT_LANGUAGE_STANDARD_REFERENCE = 'ISO 639-1'

DEFAULT_TIMEZONE = 'UTC'
