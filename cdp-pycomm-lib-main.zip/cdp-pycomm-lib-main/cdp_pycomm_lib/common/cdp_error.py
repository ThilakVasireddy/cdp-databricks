class CdpAppError(Exception):
    def __init__(self, message: str):
        super().__init__(message)
        self.message = message


class CdpPkgError(Exception):
    """
    Custom error class for the application.
    """

    def __init__(self, error_code: int, message: str):
        super().__init__(message)
        self.message = message
        self.error_code = error_code


class MetaError(Exception):
    """
    an Exception class when validating Meta input
    """

    def __init__(self, *args):
        super().__init__()
        self.error_str = ''
        for error_str in args:
            self.error_str += str(error_str)

    def __str__(self):
        return self.error_str

    def __repr__(self):
        return f'MetaError({self.error_str!r})'


class ParameterError(Exception):
    """
    a Exception class when validating query criteria Parameter
    """

    def __init__(self, *args):
        super().__init__()
        self.error_str = ''
        for error_str in args:
            self.error_str += str(error_str)

    def __str__(self):
        return self.error_str

    def __repr__(self):
        return f'ParameterError({self.error_str!r})'
