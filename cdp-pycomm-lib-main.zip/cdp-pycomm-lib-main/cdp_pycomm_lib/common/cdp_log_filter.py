import logging


class CdpLogFilter(logging.Filter):
    def __init__(self, model_name, model_run=None, pid=None):
        self.model_name = model_name
        self.model_run = model_run
        self.pid = pid
        super(CdpLogFilter, self).__init__()

    def filter(self, record):
        record.model_name = f"{self.model_name}"
        record.model_run = f"{self.model_run}"
        record.pid = f"{self.pid}"
        return True


class ErrorLevelFilter:
    def filter(self, log_record) -> bool:
        return log_record.levelno in {logging.ERROR, logging.CRITICAL}
