from dataclasses import dataclass

from delta import DeltaTable
from pyspark.sql import DataFrame

from cdp_pycomm_lib.common.cdp_constants import VALID_OPERATORS, VALID_FUNCTIONS, OP_INTERSECT
from cdp_pycomm_lib.common.cdp_error import MetaError


class BaseRepository:
    def __init__(self, spark_wrapper, schema_name: str, table_name: str):
        self.spark_wrapper = spark_wrapper
        self.schema_name = schema_name
        self.table_name = f'{schema_name}.{table_name}'

    def get(self) -> DataFrame:
        return self.spark_wrapper.table(self.table_name)

    def delta_table(self) -> DeltaTable:
        return self.spark_wrapper.delta_table(self.table_name)


@dataclass
class MjApiArguments:
    operator: str
    attribute: str
    verbs: list[str]
    values: list[str]
    function: str
    function_args: list[str]
    """
    a string tuple with blank str at start and end
    ('', ('attribute' 'verb' 'value' 'function') \
     {{,'OPERATOR',('attribute' 'verb' 'value' 'function')}} (zero or more...),'']

    OPERATORs: can be (intersect/union/minus/ and parentheses)
    verb (is/to/from...)and function (getchildren...) are optional,
    attribute and value are required

    Examples:
    ---------------------------
    Meta = ('',
             ('Var', 'is', 'CON', ''),
              'intersect' ,
              ('Com', '', 'Pwr', ''),
              'intersect',
             ('Geo','is', ('GBR', 'NLD'), 'getchildren(ALL)'),
          '')

    or
     Meta = ('',
             ('Var', 'is', 'CON'),
              'intersect' ,
              ('Com', '', 'Pwr'),
              'intersect',
             ('Geo','is', ('GBR', 'NLD'), 'getchildren(ALL)'),
          '')

    """

    def __init__(self, operator: str, attribute: str, verb: list[str], value: list[str], function: str = '',
                 function_args: list[str] = None):
        if function_args is None:
            function_args = []
        self.operator = operator
        self.attribute = attribute
        self.verbs = verb
        self.values = value
        self.function = function
        self.function_args = function_args

    @classmethod
    def empty_one(cls):
        return cls('', '', [], [])

    def append_verbs(self, verbs):
        if isinstance(verbs, tuple):
            for verb in verbs:
                self.__append_verb__(verb)
        else:
            self.__append_verb__(verbs)

    def __append_verb__(self, verb):
        valid_str('verb', verb)
        a_verb = verb.strip()
        if a_verb == '':
            self.verbs.append('is')
        else:
            self.verbs.append(a_verb.lower())

    def set_attribute(self, attribute):
        valid_str('attribute', attribute)
        a_attribute = attribute.strip()
        valid_not_empty('attribute', a_attribute)
        self.attribute = a_attribute

    def append_values(self, values):
        if isinstance(values, tuple):
            for value in values:
                self.__append_value__(value)
        else:
            self.__append_value__(values)

    def __append_value__(self, value):
        valid_str('value', value)
        a_value = value.strip()
        valid_not_empty('value', a_value)
        self.values.append(a_value)

    def set_function(self, str_value):
        valid_str('function', str_value)
        function_name, function_args = extract_function(str_value)
        validate_function(function_name)
        self.function = function_name
        self.function_args = function_args

    def set_operation(self, str_value):
        valid_str('operation', str_value)
        str_item = str_value.strip().upper()
        if not str_item:
            str_item = OP_INTERSECT
        operator = str_item.strip('(').strip(')')
        validate_operator(operator)
        self.operator = str_item


def parse_meta(meta_tuple) -> list[MjApiArguments]:
    """
    parse the input tuple to output string, raise MetaError of any error
    """
    parentheses_num = 0
    valid_tuple(meta_tuple)

    first_bracket_is_set = meta_tuple[0] == '('
    last_bracket_is_set = meta_tuple[-1] == ')'

    if first_bracket_is_set:
        valid_begin_end(meta_tuple[0], 'BEGIN')
        parentheses_num = 1
    if last_bracket_is_set:
        valid_begin_end(meta_tuple[-1], 'END')
        parentheses_num -= 1

    args_len = (len(meta_tuple) // 2)
    args = [MjApiArguments.empty_one() for _ in range(args_len)]

    for (i, meta_item) in enumerate(meta_tuple[1:-1]):
        index = i + 1
        api_arg = args[(index // 2)]
        if index % 2 == 1:
            valid_detail(meta_item)
            parse_meta_item(api_arg, meta_item)
        else:
            api_arg.set_operation(meta_item)
            parentheses_num = parentheses_num + 1 if '(' in meta_item else parentheses_num
            parentheses_num = parentheses_num - 1 if ')' in meta_item else parentheses_num

    if first_bracket_is_set:
        args[0].operator = '('
    if last_bracket_is_set:
        last_arg = MjApiArguments.empty_one()
        last_arg.operator = ')'
        args.append(last_arg)
    valid_parentheses_operators(parentheses_num)
    return args


def parse_meta_item(api_arg, meta_item):
    for (i_detail, meta_detail) in enumerate(meta_item):
        if i_detail == 0:
            api_arg.set_attribute(meta_detail)
        elif i_detail == 1:
            api_arg.append_verbs(meta_detail)
        elif i_detail == 2:
            api_arg.append_values(meta_detail)
        elif i_detail == 3:
            api_arg.set_function(meta_detail)


def valid_tuple(meta_tuple):
    if meta_tuple is None:
        raise MetaError("meta should not be None!!!")
    if not isinstance(meta_tuple, tuple):
        raise MetaError('meta should be tuple!!!')
    if len(meta_tuple) < 3:
        raise MetaError(f'meta should have at least 3 items: {meta_tuple}')
    if len(meta_tuple) % 2 == 0:
        raise MetaError(f'meta should have odd number of items: {meta_tuple}')


def valid_detail(meta_item):
    if not isinstance(meta_item, tuple):
        raise MetaError(f'meta Detail is not tuple: {meta_item}')
    if len(meta_item) not in range(3, 5):
        raise MetaError(f'meta Detail should have 3 or 4 items: {meta_item}')


def valid_begin_end(meta_item, flag):
    if (flag == 'BEGIN') and (meta_item not in ('', '(')):
        raise MetaError('meta is not start with blank')
    if (flag == 'END') and (meta_item not in ('', ')')):
        raise MetaError('Operators is not match with Details')


def valid_parentheses_operators(parentheses):
    if parentheses != 0:
        raise MetaError('Parentheses is not enclosed')


def valid_str(str_type, str_value):
    if not isinstance(str_value, str):
        raise MetaError(f'value {str_value} should be string, required by type of {str_type}')


def valid_not_empty(str_type, str_value):
    if str_value == '':
        raise MetaError(f'value should not be empty, required by type of {str_type}')


def extract_function(p_arg_function: str):
    """
    NAME:     extract_function_name and function_arguments
    PURPOSE:  Extracts and returns function name and function arguments from p_function_string, for instance:
                "getChildren(Nation, City)" returns the string 'GETCHILDREN', ['Nation', 'City']
    """
    arg_function = p_arg_function.strip()
    if not arg_function:
        return '', []

    if arg_function.count('(') != 1 or arg_function.count(')') != 1:
        raise MetaError(f'Invalid function format: {arg_function}')

    left_index = arg_function.find('(')
    right_index = arg_function.find(')')
    length = len(arg_function)
    if left_index > right_index or left_index == 0 or right_index != length - 1:
        raise MetaError(f'Invalid function format: {arg_function}')

    function_name = arg_function[0:left_index].strip().upper()
    function_args_str = arg_function[left_index + 1:right_index]
    function_args = [] if function_args_str == '' else [value.strip() for value in function_args_str.split(',')]
    return function_name, function_args


def validate_operator(p_string: str):
    """
    NAME:       validate_operators
    PURPOSE:    Validates a string for valid operator(s)
    EXCEPTIONS: e_illegal_operator        - raises MetaError
    """
    operator = p_string.strip().upper()
    if operator not in VALID_OPERATORS:
        raise MetaError(f'value {p_string} should be valid operator')


def validate_function(p_function: str):
    """
    NAME:       validate_function
    PURPOSE:    Validates a string for valid function(s)
    EXCEPTIONS: e_illegal_function        - raises MetaError
    """
    if p_function not in VALID_FUNCTIONS:
        raise MetaError(f'value {p_function} should be valid function')
