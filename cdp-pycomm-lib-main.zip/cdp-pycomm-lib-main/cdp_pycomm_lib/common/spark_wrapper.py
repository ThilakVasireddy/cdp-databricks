from delta import DeltaTable
from pyspark.sql import SparkSession

from cdp_pycomm_lib.common import cdp_common_logging

log = cdp_common_logging.get_logger(__name__)


class SparkWrapper:
    def __init__(self):
        self.spark_local = None

    def table(self, table_name: str):
        return self.spark_local.table(table_name)

    def delta_table(self, table_name):
        return DeltaTable.forName(self.spark_local, table_name)

    def create_data_frame(self, data, schema):
        return self.spark_local.createDataFrame(data, schema)

    def sql(self, sql_query: str):
        return self.spark_local.sql(sql_query)

    def set_spark(self, remote_spark: SparkSession):
        self.spark_local = remote_spark

    def start_transaction(self):
        self.sql("START TRANSACTION")

    def commit_transaction(self):
        self.sql("COMMIT")

    def rollback_transaction(self):
        self.sql("ROLLBACK")


CDP_SPARK = SparkWrapper()
