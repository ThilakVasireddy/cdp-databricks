from pyspark.sql import DataFrame
from pyspark.sql.functions import col, expr

from cdp_pycomm_lib.common.spark_wrapper import CDP_SPARK
from cdp_pycomm_lib.dw.repository.init_repositories import (
    curve_repository,
    load_set2_curve_repository,
    dataset_repository
)


def get_curve(curve_ids: list[int]) -> DataFrame:
    """
    NAME:     get_curve
    PURPOSE:  Return curve id and name for the specified curves
    """
    return curve_repository.get_by_ids(curve_ids)


def get_loadset_for_curve_by_id(curve_ids: list[int]) -> DataFrame:
    load_set2_curve_df = load_set2_curve_repository.get_by_curve_ids(curve_ids).alias('lsc')
    dataset_df = dataset_repository.get_df_for_load_set().alias('ls')
    return (
        load_set2_curve_df
        .join(dataset_df, col('ls.ID') == col('lsc.LOAD_SET_ID'))
        .select(col('ls.ID').alias('ID'), col('ls.NAME').alias('NAME'))
        .distinct()
    )


def get_loadset_for_curve_by_curve_name(curve_names: list[str]) -> DataFrame:
    load_set2_curve_df = load_set2_curve_repository.get().alias('lsc')
    dataset_df = dataset_repository.get_df_for_load_set().alias('ds')
    curve_df = curve_repository.get().alias('c')
    curve_names_df = CDP_SPARK.create_data_frame(
        [(f"%{name.strip().lower()}%",) for name in curve_names], ["c_name"]
    ).alias("d")
    return (
        curve_names_df
        .join(curve_df, expr('LOWER(c.name) LIKE d.c_name'))
        .join(load_set2_curve_df, col('lsc.CURVE_ID') == col('c.ID'))
        .join(dataset_df, col('ds.ID') == col('lsc.LOAD_SET_ID'))
        .select(col('ds.ID').alias('ID'), col('ds.NAME').alias('NAME'))
        .distinct()
    )


def get_curve_ids_by_load_set_names(load_set_names: list[str]) -> DataFrame:
    """
    NAME:     get_object_ids_from_load_set
    PURPOSE:  Returns curve_id as object_id by loadSet names
    """
    df_load_set2_curve = load_set2_curve_repository.get()
    df_dataset = dataset_repository.get_df_for_load_set().filter(col('NAME').isin(load_set_names))
    return (
        df_dataset.alias('d').join(df_load_set2_curve.alias('l'), col('LOAD_SET_ID') == col('d.ID'))
        .select(col('CURVE_ID').alias('OBJECT_ID'))
        .distinct()
    )
