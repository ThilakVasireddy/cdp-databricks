from datetime import datetime

from pyspark.sql import DataFrame
from pyspark.sql.functions import col, lit, expr, udf
from pyspark.sql.types import TimestampType

from cdp_pycomm_lib.common import cdp_common_logging
from cdp_pycomm_lib.common.cdp_constants import DEFAULT_TIMEZONE
from cdp_pycomm_lib.dw import timezone_services
from cdp_pycomm_lib.dw.repository.init_repositories import (
    curve_repository,
    data_table_repository,
    create_curve_data_repository
)

log = cdp_common_logging.get_logger(__name__)


def get_curve_info(curve_names: list[str], partial_match: bool):
    if partial_match:
        df = curve_repository.get_by_partial_names(curve_names)
    else:
        df = curve_repository.get_by_names(curve_names)
    curve_ids = []
    data_table_ids = []
    curve_id_name_map = {}
    for row in df.collect():
        curve_ids.append(row.ID)
        data_table_ids.append(row.DATA_TABLE_ID)
        curve_id_name_map[row.ID] = row.NAME
    data_table_ids = list(set(data_table_ids))
    return curve_ids, data_table_ids, curve_id_name_map


def get_dates(
        f_date_from_in, f_date_to_in, v_date_from_in, v_date_to_in, timezone
) -> (str, str, str, str):
    if timezone and timezone != DEFAULT_TIMEZONE:
        f_date_from_out = timezone_services.change_timezone(f_date_from_in, timezone, DEFAULT_TIMEZONE)
        f_date_to_out = timezone_services.change_timezone(f_date_to_in, timezone, DEFAULT_TIMEZONE)
        v_date_from_out = timezone_services.change_timezone(v_date_from_in, timezone, DEFAULT_TIMEZONE)
        v_date_to_out = timezone_services.change_timezone(v_date_to_in, timezone, DEFAULT_TIMEZONE)
    else:
        f_date_from_out = f_date_from_in
        f_date_to_out = f_date_to_in
        v_date_from_out = v_date_from_in
        v_date_to_out = v_date_to_in

    f_date_from_out = f_date_from_out or f_date_from_in or datetime.strptime('0001-01-01', '%Y-%m-%d')
    f_date_to_out = f_date_to_out or f_date_to_in or datetime.strptime('4444-12-31', '%Y-%m-%d')
    v_date_from_out = v_date_from_out or v_date_from_in or datetime.strptime('0001-01-01', '%Y-%m-%d')
    v_date_to_out = v_date_to_out or v_date_to_in or datetime.strptime('4444-12-31', '%Y-%m-%d')
    return (
        date_to_str(f_date_from_out),
        date_to_str(f_date_to_out),
        date_to_str(v_date_from_out),
        date_to_str(v_date_to_out)
    )


def date_to_str(date_time: datetime):
    return date_time.strftime('%Y-%m-%d %H:%M:%S')


z2z_udf = udf(
    lambda date, timezone_in, timezone_out: timezone_services.change_timezone(
        date, timezone_in, timezone_out
    ) if date else None,
    TimestampType()
)


def get_curve_data_from_one_table(
        table_name: str, curve_ids: list[int], f_data_from, f_date_to, v_date_from, v_data_to, time_zone: str
) -> DataFrame:
    curve_table_df = create_curve_data_repository(table_name).get()
    df = curve_table_df.filter(
        expr(f"FORECAST_DATE >= TO_TIMESTAMP('{f_data_from}', 'yyyy-MM-dd HH:mm:ss')") &
        expr(f"FORECAST_DATE <= TO_TIMESTAMP('{f_date_to}', 'yyyy-MM-dd HH:mm:ss')") &
        expr(f"VALUE_DATE >= TO_TIMESTAMP('{v_date_from}', 'yyyy-MM-dd HH:mm:ss')") &
        expr(f"VALUE_DATE <= TO_TIMESTAMP('{v_data_to}', 'yyyy-MM-dd HH:mm:ss')") &
        col('CURVE_ID').isin(curve_ids)
    )
    if time_zone != DEFAULT_TIMEZONE:
        df = df.withColumn(
            'FORECAST_DATE', z2z_udf(col('FORECAST_DATE'), lit(DEFAULT_TIMEZONE), lit(time_zone))
        ).withColumn(
            'VALUE_DATE', z2z_udf(col('VALUE_DATE'), lit(DEFAULT_TIMEZONE), lit(time_zone))
        ).withColumn(
            'CHANGED_DATE', z2z_udf(col('CHANGED_DATE'), lit(DEFAULT_TIMEZONE), lit(time_zone))
        )
    return df.select('CURVE_ID', 'FORECAST_DATE', 'VALUE_DATE', 'VALUE', 'CHANGED_DATE')


def get_data(
        curve_names: list[str],
        f_date_from_in: datetime,
        f_date_to_in: datetime,
        v_date_from_in: datetime,
        v_date_to_in: datetime,
        timezone_in: str,
        timezone_out: str,
        partial_match: bool
):
    curve_ids, data_table_ids, curve_id_name_map = get_curve_info(curve_names, partial_match)
    id_map_udf = udf(lambda a_id: curve_id_name_map.get(a_id, None))
    table_names = data_table_repository.get_table_names(data_table_ids)
    f_date_from, f_date_to, v_date_from, v_date_to = get_dates(
        f_date_from_in, f_date_to_in, v_date_from_in, v_date_to_in, timezone_in
    )
    result_df = None
    for table_name in table_names:
        df = get_curve_data_from_one_table(
            table_name, curve_ids, f_date_from, f_date_to, v_date_from, v_date_to, timezone_out
        )
        if result_df is None:
            result_df = df
        else:
            result_df = result_df.union(df)
    if result_df is None:
        return None
    result_df = result_df.withColumn('CURVE_NAME', id_map_udf(col('CURVE_ID')))
    return result_df
