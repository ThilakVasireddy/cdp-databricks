from pyspark.sql import DataFrame
from pyspark.sql.functions import col, expr

from cdp_pycomm_lib.common.cdp_object import BaseRepository


class CurveRepository(BaseRepository):
    def __init__(self, spark_wrapper, schema_name: str):
        super().__init__(spark_wrapper, schema_name, 'CURVE')

    def get_by_ids(self, ids: list[int]) -> DataFrame:
        return self.get().select('ID', 'NAME').filter(col('ID').isin(ids))

    def get_ids_by_names(self, names: list[str], partial_match: bool) -> list[int]:
        if partial_match:
            df = self.get_by_partial_names(names)
        else:
            df = self.get_by_names(names)
        return [row.ID for row in df.collect()]

    def get_by_partial_names(self, curve_names: list[str]) -> DataFrame:
        curve_df = self.get()
        data_df = self.spark_wrapper.create_data_frame(
            [(f"%{name.strip().lower()}%",) for name in curve_names], ["c_name"]
        )
        return (
            curve_df.join(data_df, expr('LOWER(NAME) LIKE c_name'))
            .select('ID', 'NAME').distinct()
        )

    def get_by_names(self, curve_names: list[str]) -> DataFrame:
        curve_names_strip = [curve_name.strip() for curve_name in curve_names]
        return self.get().filter(col('NAME').isin(curve_names_strip)).select('ID', 'NAME').distinct()


class LoadSet2CurveRepository(BaseRepository):
    def __init__(self, spark_wrapper, schema_name: str):
        super().__init__(spark_wrapper, schema_name, 'LOAD_SET2_CURVE')

    def get_by_curve_ids(self, curve_ids: list[int]) -> DataFrame:
        return self.get().filter(col('CURVE_ID').isin(curve_ids))


class DataTableRepository(BaseRepository):
    def __init__(self, spark_wrapper, schema_name: str):
        super().__init__(spark_wrapper, schema_name, 'DATA_TABLE')

    def get_table_names(self, ids: list[int]) -> list[str]:
        df = self.get().filter(col('ID').isin(ids)).select('TABLE_NAME').distinct()
        return [row[0] for row in df.collect()]
