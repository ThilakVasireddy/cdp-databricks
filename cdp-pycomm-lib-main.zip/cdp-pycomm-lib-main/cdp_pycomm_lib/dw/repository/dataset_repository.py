from pyspark.sql import DataFrame

from cdp_pycomm_lib.common.cdp_object import BaseRepository


class DatasetRepository(BaseRepository):
    def __init__(self, spark_wrapper, schema_name: str):
        super().__init__(spark_wrapper, schema_name, 'DATASET')

    def get_df_for_load_set(self) -> DataFrame:
        return self.get().filter('SET_TYPE_ID = 1')
