from cdp_pycomm_lib.common.cdp_object import BaseRepository
from cdp_pycomm_lib.common.spark_wrapper import CDP_SPARK
from cdp_pycomm_lib.dw.repository.curve_repositories import (
    CurveRepository,
    LoadSet2CurveRepository,
    DataTableRepository
)
from cdp_pycomm_lib.dw.repository.dataset_repository import DatasetRepository

SCHEMA_NAME = 'cdb'

curve_repository = CurveRepository(CDP_SPARK, SCHEMA_NAME)
load_set2_curve_repository = LoadSet2CurveRepository(CDP_SPARK, SCHEMA_NAME)
data_table_repository = DataTableRepository(CDP_SPARK, SCHEMA_NAME)
dataset_repository = DatasetRepository(CDP_SPARK, SCHEMA_NAME)


def create_curve_data_repository(table_name: str):
    return BaseRepository(CDP_SPARK, SCHEMA_NAME, table_name)
