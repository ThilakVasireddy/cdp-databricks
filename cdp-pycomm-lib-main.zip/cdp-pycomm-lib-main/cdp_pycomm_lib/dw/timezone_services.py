from datetime import datetime
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from cdp_pycomm_lib.common import cdp_common_logging

log = cdp_common_logging.get_logger(__name__)


def change_timezone(old_date: datetime, old_timezone: str, new_timezone: str) -> datetime:
    if old_timezone == new_timezone:
        return old_date

    try:
        old_date_with_timezone = old_date.replace(tzinfo=ZoneInfo(old_timezone))
        return old_date_with_timezone.astimezone(ZoneInfo(new_timezone)).replace(tzinfo=None)
    except ZoneInfoNotFoundError:
        raise ValueError("Invalid timezone provided")
