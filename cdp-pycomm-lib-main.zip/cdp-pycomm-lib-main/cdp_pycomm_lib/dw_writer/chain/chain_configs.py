from typing import Optional

from cdp_pycomm_lib.common import cdp_common_logging, cdp_common_utils
from cdp_pycomm_lib.dw_writer import chain
from cdp_pycomm_lib.dw_writer.dw_objects import ChainConfig

log = cdp_common_logging.get_logger(__name__)


class ChainConfigs:
    def __init__(self):
        self.chain_id_map = {}
        self.chain_type_map = {}
        self.__load_config()

    def __load_config(self):
        config_items = cdp_common_utils.read_config_file_in_package(chain, 'chain.json')
        for chain_config in config_items:
            chain_id = chain_config["id"]
            chain_type = chain_config["chain_type"]
            name = chain_config["name"]
            steps = chain_config["steps"]
            chain_config = ChainConfig(chain_id, name, chain_type, steps)
            self.chain_id_map[chain_id] = chain_config
            if chain_type not in self.chain_type_map:
                self.chain_type_map[chain_type] = [chain_config]
            else:
                self.chain_type_map[chain_type].append(chain_config)
        log.info("Chain configurations are loaded.")

    def get_chain(self, chain_id: Optional[int]) -> Optional[ChainConfig]:
        if chain_id is None:
            return None
        chain_config = self.chain_id_map.get(chain_id)
        if chain_config is None:
            raise ValueError(f"Chain ID {chain_id} not found in configuration.")
        return chain_config

    def get_chain_name_list(self, chain_type: str) -> list:
        return self.chain_type_map.get(chain_type.upper(), [])


CDP_CHAIN_CONFIGS = ChainConfigs()
