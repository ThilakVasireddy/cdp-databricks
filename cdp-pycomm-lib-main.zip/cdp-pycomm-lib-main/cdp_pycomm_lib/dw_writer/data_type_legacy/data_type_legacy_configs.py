from typing import Optional

from cdp_pycomm_lib.common import cdp_common_utils
from cdp_pycomm_lib.dw_writer import data_type_legacy


class DataTypeLegacyConfigs:
    def __init__(self):
        self.map = {}
        self.__load_config()

    def __load_config(self):
        config_items = cdp_common_utils.read_config_file_in_package(data_type_legacy, 'data_type_legacy.json')
        for entry in config_items:
            curve_type_id = entry['curve_type_id']
            data_type_id = entry['data_type_id']
            self.map[curve_type_id] = data_type_id

    def get_data_type_id(self, curve_type_id) -> Optional[int]:
        return self.map.get(curve_type_id, None)

    def get_curve_type_id(self, data_type_id) -> Optional[int]:
        if data_type_id is None:
            return None
        result = []
        for curve_type_id, dt_id in self.map.items():
            if dt_id == data_type_id:
                result.append(curve_type_id)
        if len(result) == 0:
            return None
        return sorted(result)[0]


CDP_DATA_TYPE_LEGACY_CONFIGS = DataTypeLegacyConfigs()
