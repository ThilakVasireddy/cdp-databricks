from dataclasses import dataclass
from datetime import datetime
from typing import Optional


class ProcessorStep:
    def __init__(self, module_name, method_name):
        self.module_name = module_name
        self.method_name = method_name
        self.exit_status = 0
        self.exit_message = ''


class ChainConfig:
    def __init__(self, chain_id, name, chain_type, steps):
        self.id = chain_id
        self.name = name
        self.chain_type = chain_type
        self.steps = [ProcessorStep(**step) for step in steps]


class RunDateFilterConfig:
    def __init__(self, run_date_filter_id, name, timezone_enabled, module_name, method_name):
        self.id = run_date_filter_id
        self.name = name
        self.timezone_enabled = timezone_enabled
        self.step = ProcessorStep(module_name, method_name)


@dataclass
class CurveMetadata:
    external_set_id: str
    external_set_name: str
    external_system: str
    curve_type_id: int
    curve_id: int
    chain_id: int
    data_table_name: str
    use_forecast_date: bool
    log_level: int
    export_enabled: bool


@dataclass
class LoadSetRequest:
    domain_name: str
    external_system: str
    external_set_id: str
    external_set_name: str
    curve_type_id: int
    run_date: datetime
    session_guid: str
    msg_id: str
    info_message: str
    partial_number: int = 1
    partial_total: int = 1
    code: str = 'Partial'


@dataclass
class LoadSetResponse:
    dataset_id: int
    chain_id: Optional[int]
    timezone_id: Optional[int] = None
    local_timezone_id: Optional[int] = None
    run_data_filter_id: Optional[int] = None


@dataclass
class CurveDataEntry:
    value: float | str
    value_date: datetime
    forecast_date: Optional[datetime] = None
    local_forecast_date: Optional[datetime] = None
    local_value_date: Optional[datetime] = None


class RawData:
    def __init__(self, curve_name, forecast_date: Optional[datetime] = None):
        self.curve_name = curve_name
        self.forecast_date = forecast_date
        self.curve_data = []

    def add(self, value: float, value_date: datetime):
        if value is not None:
            self.curve_data.append(CurveDataEntry(value, value_date))

    def is_not_empty(self):
        return len(self.curve_name) > 0


@dataclass
class CurveUpsertInfo:
    curve_id: int
    forecast_range: (datetime, datetime)
    value_range: (datetime, datetime)
    processed_in_ms: int
    rows_inserted: int
    rows_updated: int
    rows_processed: int
    error_code: int
    failed_proc_id: int
    operation_timestamp: datetime


@dataclass
class CurveData:
    msg_id: str  # Message id
    curve_id: int  # Source curve id
    source_system: str  # Source system
    sending_system: str  # Sending system not the same as source system.
    data_table: str  # The table to insert data into
    values_numeric: list[CurveDataEntry]  # List of points
    # values_text: list[CurveDataTextEntry]  # List of text(points)
    operation_timestamp: datetime  # Timestamp from sending system (group indicator)
    use_forecast: bool  # True if forecastN, False if timeseries
    user_id: Optional[str]  # User guid
    priority: int  # Queue priority(not in use)
    parameters: Optional[str]  # For future extensions
    curve_info_timestamp: Optional[datetime]  # Timestamp for last update operation on curve (from operation_timestamp)
    export_group_id: int  # Target group id, output queue identifier
    log_level: int  # plog log level
    chain: ChainConfig  # The processing chain
    upsert_info: Optional[CurveUpsertInfo]  # Results


@dataclass
class LoadSetPut:
    curve_id: int
    table_name: str
    use_forecast_date: bool
    log_level: int
    export_enabled: bool


@dataclass
class DatasetMetadata:
    chain_id: int
    data_table: str
    run_date_filter_id: int
    timezone_id: int
    local_timezone_id: int


@dataclass
class CurveMetadata:
    curve_name: str
    curve_id: int
    data_table_name: str
