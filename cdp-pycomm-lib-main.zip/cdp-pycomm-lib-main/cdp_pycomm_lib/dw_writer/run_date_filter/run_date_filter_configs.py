from cdp_pycomm_lib.common import cdp_common_logging, cdp_common_utils
from cdp_pycomm_lib.dw_writer import run_date_filter
from cdp_pycomm_lib.dw_writer.dw_objects import RunDateFilterConfig

log = cdp_common_logging.get_logger(__name__)


class RunDateFilterConfigs:
    def __init__(self):
        self.id_map = {}
        self.__load_config()

    def __load_config(self):
        config_items = cdp_common_utils.read_config_file_in_package(run_date_filter, 'run_date_filter.json')
        for config_item in config_items:
            run_date_filter_id = config_item["id"]
            name = config_item["name"]
            timezone_enabled = config_item["timezone_enabled"]
            module_name = config_item["module_name"]
            method_name = config_item["method_name"]
            filter_config = RunDateFilterConfig(run_date_filter_id, name, timezone_enabled, module_name, method_name)
            self.id_map[run_date_filter_id] = filter_config
        log.info("Chain configurations are loaded.")

    def get_run_date_filter_config(self, run_date_filter_id: int) -> RunDateFilterConfig:
        filter_config = self.id_map.get(run_date_filter_id)
        if filter_config is None:
            raise ValueError(f"ID {run_date_filter_id} not found in configuration.")
        return filter_config


CDP_RUN_DATE_FILTER_CONFIGS = RunDateFilterConfigs()
