from typing import Optional

from cdp_pycomm_lib.meta.repository.init_repositories import (
    entity_name_group_repository,
    entity_name_type_repository,
    entity_name_repository
)


def prepare_parameters(group_name, type_name):
    """
    NAME:     prepare_parameters
    PURPOSE:  Prepares the parameters for get_name() and get_names()
    """
    group_id = entity_name_group_repository.get_id(group_name) if group_name else None
    type_id = entity_name_type_repository.get_id(type_name) if type_name else None
    return {
        "group_id": group_id,
        "type_id": type_id
    }


def get_name(entity_id: int, entity_type_id: int, group_name: str, type_name: str) -> Optional[str]:
    """
    NAME:     get_name
    PURPOSE:  Return entity name by element-ID and optionally more parameters.
              If more than one name is found, only the first name (internally
              determined by sort order) is returned.

              This routine can replace search on shortest name among
              abbreviation, short_name, and name.
    """
    params = prepare_parameters(group_name, type_name)
    return entity_name_repository.get_value(entity_id, entity_type_id, params["group_id"], params["type_id"])
