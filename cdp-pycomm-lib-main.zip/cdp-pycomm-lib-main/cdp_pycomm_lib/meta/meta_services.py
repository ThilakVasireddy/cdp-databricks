from pyspark.sql import DataFrame
from pyspark.sql.functions import col, udf
from pyspark.sql.types import StringType

from cdp_pycomm_lib.common.cdp_constants import (
    LOAD_SET,
    FUNC_GETCHILDREN,
    OP_MINUS,
    HQ_ALL,
    HQ_LEVEL,
    HQ_DIRECT,
    HQ_DIRECT_P,
    HQ_ALL_P,
    OP_UNION
)
from cdp_pycomm_lib.common.cdp_object import MjApiArguments
from cdp_pycomm_lib.common.spark_wrapper import CDP_SPARK
from cdp_pycomm_lib.dw import curve_services
from cdp_pycomm_lib.meta import entity_services
from cdp_pycomm_lib.meta.repository.init_repositories import (
    attribute_repository,
    verb_repository,
    object_meta_repository,
    entity_name_repository,
    hierarchy_data_repository,
    levels_repository,
    dimension_data_repository
)


def get_object_ids_from_om(
        object_type_id: int,
        attribute_name: str,
        verb_names: list[str],
        values: list[str]
) -> DataFrame:
    """
    NAME:     get_object_ids_from_om
    PURPOSE:  Returns object-ID from OBJECT_META (OM) by object_type, attribute, verbs, and values
    """
    attribute_id, dimension_id = attribute_repository.get_id_and_dimension_id(attribute_name)
    verb_ids = verb_repository.get_ids_by_names(verb_names)
    meta_ids = entity_name_repository.get_entity_ids_by_values(values, dimension_id)
    return object_meta_repository.get_object_id_dataframe(
        object_type_id, attribute_id, dimension_id, verb_ids, meta_ids
    )


def get_object_ids_from_getchildren(
        attribute_name: str,
        values: list[str],
        p_function_args: list[str]
):
    """
    NAME:       get_object_ids_from_getchildren
    PURPOSE:    Returns object-ID by the query for function GETCHILDREN
    """
    _, dimension_id = attribute_repository.get_id_and_dimension_id(attribute_name)
    entity_ids = entity_name_repository.get_entity_ids_by_values(values, dimension_id)
    base_node_ids = hierarchy_data_repository.get_node_ids(entity_ids, dimension_id)

    object_meta_df = object_meta_repository.get()
    dimension_df = dimension_data_repository.get()

    option = get_hi_option(p_function_args)
    if option == HQ_DIRECT:
        child_ids = hierarchy_data_repository.get_child_ids_direct(base_node_ids, dimension_id)
    elif option == HQ_DIRECT_P:
        child_ids = hierarchy_data_repository.get_child_ids_direct(base_node_ids, dimension_id)
        child_ids.extend(entity_ids)
    elif option == HQ_ALL:
        child_ids = hierarchy_data_repository.get_child_ids_all(base_node_ids, dimension_id)
    elif option == HQ_ALL_P:
        child_ids = hierarchy_data_repository.get_child_ids_all(base_node_ids, dimension_id)
        child_ids.extend(entity_ids)
    elif option == HQ_LEVEL:
        child_ids = hierarchy_data_repository.get_child_ids_all(base_node_ids, dimension_id)
        level_ids = levels_repository.get_ids_by_names(p_function_args, dimension_id)
        dimension_df = dimension_df.filter(col('LEVEL_ID').isin(level_ids))
    else:
        return None

    return (
        dimension_df
        .filter(col('ELEMENT_ID').isin(child_ids))
        .join(object_meta_df, col('META_ID') == col('ELEMENT_ID'))
        .select('OBJECT_ID')
        .distinct()
    )


def get_hi_option(p_function_args: list[str]) -> str:
    if len(p_function_args) == 0:
        return HQ_ALL
    if len(p_function_args) > 1:
        return HQ_LEVEL

    return {
        'direct': HQ_DIRECT,
        'directp': HQ_DIRECT_P,
        'all': HQ_ALL,
        'allp': HQ_ALL_P
    }.get(p_function_args[0].lower(), HQ_LEVEL)


def get_object_ids(p_object_type_id: int, p_arg: MjApiArguments):
    if p_arg.function == '':
        if p_object_type_id == 1 and p_arg.attribute.strip().lower() == LOAD_SET:
            return curve_services.get_curve_ids_by_load_set_names(p_arg.values)
        return get_object_ids_from_om(p_object_type_id, p_arg.attribute, p_arg.verbs, p_arg.values)

    if p_arg.function.upper() == FUNC_GETCHILDREN:
        return get_object_ids_from_getchildren(p_arg.attribute, p_arg.values, p_arg.function_args)
    return None


def combine_dataframes(df_final: DataFrame, df: DataFrame, operator: str) -> DataFrame:
    if df_final is None:
        return df
    if df is None:
        return df_final

    if operator == OP_UNION:
        return df_final.union(df)
    elif operator == OP_MINUS:
        return df_final.subtract(df)
    return df_final.intersect(df)


def apply_top_operator(df_stack: list, op_stack: list):
    op_stack_temp = []
    df_stack_temp = []
    while op_stack and op_stack[-1] != '(':
        op_stack_temp.append(op_stack.pop())
        df_stack_temp.append(df_stack.pop())
    df_stack_temp.append(df_stack.pop())
    while op_stack_temp:
        df1 = df_stack_temp.pop()
        df2 = df_stack_temp.pop()
        operator = op_stack_temp.pop()
        df_stack_temp.append(combine_dataframes(df1, df2, operator))
    if op_stack:
        op_stack.pop()
    df_stack.append(df_stack_temp.pop())


def compute_dataframes_with_operators(p_object_type_id: int, p_args: list[MjApiArguments]):
    op_stack = []
    df_stack = []

    for p_arg in p_args:
        df = None if not p_arg.attribute else get_object_ids(p_object_type_id, p_arg)
        op = p_arg.operator
        if not op:
            df_stack.append(df)
            continue
        if ('(' not in op and ')' not in op) or op == '(':
            op_stack.append(op)
            df_stack.append(df)
            continue
        if ')' in op:
            apply_top_operator(df_stack, op_stack)
            op = op.replace(')', '')
        if '(' in op:
            op = op.replace('(', '')
            op_stack.append(op)
            op_stack.append('(')
            df_stack.append(df)

    if op_stack:
        apply_top_operator(df_stack, op_stack)
    return df_stack[0] if df_stack else None


def get_by_meta_query(p_object_type_id: int, p_args: list[MjApiArguments], p_return_name: bool):
    """
    NAME:     get_by_meta_query
    PURPOSE:
    """
    df_final = compute_dataframes_with_operators(p_object_type_id, p_args)
    if df_final is None:
        return None

    if p_return_name:
        df_with_object_name = object_meta_repository.group_by_object_ids().alias('m')
        return (
            df_final.alias('dm')
            .join(df_with_object_name, col('dm.OBJECT_ID') == col('m.OBJECT_ID'))
            .select(col('m.OBJECT_ID').alias('object_id'), col('m.OBJECT_NAME').alias('object_name'))
        )
    return df_final.select(col('OBJECT_ID').alias('object_id')).distinct()


def get_name_maps(df: DataFrame) -> dict:
    df = df.select(col('om.META_ID'), col('om.DIMENSION_ID'), col('om.ATTRIBUTE_ID'), col('d.NAME'))
    name_maps = {}
    for row in df.collect():
        element_id = row['META_ID']
        dimension_id = row['DIMENSION_ID']
        key = f"{element_id}_{dimension_id}"
        if key in name_maps:
            continue

        abb_name = entity_services.get_name(element_id, dimension_id, 'PC-META', 'Abbreviation')
        if abb_name is not None:
            name_maps[key] = abb_name
            continue

        short_name = entity_services.get_name(element_id, dimension_id, 'PC-META', 'Shortname')
        if short_name is not None:
            name_maps[key] = short_name
            continue

        attribute_id = row['ATTRIBUTE_ID']
        if attribute_id == 22 or attribute_id == 169:
            name_maps[key] = row['NAME']
        else:
            full_name = entity_services.get_name(element_id, dimension_id, 'PC-META', 'Fullname')
            name_maps[key] = full_name
    return name_maps


def get_meta_common(object_type_id: int, object_id_df: DataFrame) -> DataFrame:
    """
    NAME:     get_meta_common
    PURPOSE:  Returns the dataframe
    """
    object_meta_df = object_meta_repository.get().alias('om').filter(col('OBJECT_TYPE_ID') == object_type_id)
    attribute_df = attribute_repository.get().alias('a')
    verb_df = verb_repository.get().alias('v')
    dimension_data_df = dimension_data_repository.get().alias('d')
    result_df = (
        object_id_df.alias('meta_id')
        .join(object_meta_df, col('om.OBJECT_ID') == col('meta_id.OBJECT_ID'))
        .join(attribute_df, col('a.ID') == col('om.ATTRIBUTE_ID'))
        .join(verb_df, col('v.ID') == col('om.VERB_ID'))
        .join(dimension_data_df,
              (col('d.ELEMENT_ID') == col('om.META_ID')) &
              (col('d.DIMENSION_ID') == col('om.DIMENSION_ID'))
              )
    )

    name_maps = get_name_maps(result_df)
    get_name_udf = udf(
        lambda element_id, dimension_id: name_maps[f"{element_id}_{dimension_id}"],
        StringType()
    )
    return (
        result_df
        .withColumn('VALUE_NAME', get_name_udf(col('d.ELEMENT_ID'), col('d.DIMENSION_ID')))
        .select(
            col('meta_id.OBJECT_ID').alias('object_id'),
            col('a.SHORT_NAME').alias('attr'),
            col('v.NAME').alias('verb'),
            col('VALUE_NAME').alias("alias")
        )
    )


def get_meta_char_array_dataframe(object_type_id: int, object_id_df: DataFrame) -> DataFrame:
    """
    NAME:     get_meta_char_array_sql
    PURPOSE:  Returns the dataframe used by mjapi_services.get_meta()
    """
    return get_meta_common(object_type_id, object_id_df)


def get_meta_num_array_dataframe(object_type_id: int, num_array: list[int]) -> DataFrame:
    """
    NAME:     get_meta_num_array_sql
    PURPOSE:  Returns the dataframe used by mjapi_services.get_meta()
    """
    array_df = CDP_SPARK.create_data_frame([(num,) for num in num_array], ['OBJECT_ID'])
    return get_meta_common(object_type_id, array_df)
