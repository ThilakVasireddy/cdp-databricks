from typing import Optional

from pyspark.sql import DataFrame

from cdp_pycomm_lib.common import cdp_common_logging
from cdp_pycomm_lib.common.cdp_object import MjApiArguments
from cdp_pycomm_lib.meta import meta_services
from cdp_pycomm_lib.meta.repository.init_repositories import object_type_repository

log = cdp_common_logging.get_logger(__name__)


def get_by_meta(p_object_type: str, p_args: list[MjApiArguments], p_return_name: bool):
    """
    NAME:     get_by_meta
    PURPOSE:  function returning object-IDs, and if p_return_name = 'Y',
              then object (element) name (value) is returned get_object_meta as well.
    """
    object_type_id = object_type_repository.get_id(p_object_type)
    if object_type_id is None:
        return None
    return meta_services.get_by_meta_query(object_type_id, p_args, p_return_name)


def get_meta_by_id(
        p_object_type: str,
        p_args: list[int]
) -> Optional[DataFrame]:
    """
    NAME:     get_meta_by_id
    PURPOSE:  return one-dimensional collection
    """
    object_type_id = object_type_repository.get_id(p_object_type)
    if object_type_id is None:
        return None
    return meta_services.get_meta_num_array_dataframe(object_type_id, p_args)


def get_meta_by_meta(
        p_object_type: str,
        p_args: list[MjApiArguments]
) -> Optional[DataFrame]:
    """
    NAME:     get_meta_by_meta
    PURPOSE:  return one-dimensional collection
    """
    object_type_id = object_type_repository.get_id(p_object_type)
    if object_type_id is None:
        return None
    object_id_df = get_by_meta(p_object_type, p_args, False)
    if object_id_df is None:
        return None
    return meta_services.get_meta_char_array_dataframe(object_type_id, object_id_df)
