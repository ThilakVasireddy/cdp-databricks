from typing import Optional

from pyspark.sql.functions import col, expr, coalesce, lit

from cdp_pycomm_lib.common.cdp_constants import DEFAULT_LANGUAGE_STANDARD_REFERENCE
from cdp_pycomm_lib.common.cdp_error import CdpPkgError
from cdp_pycomm_lib.common.cdp_object import BaseRepository


class EntityNameRepository(BaseRepository):
    def __init__(self, spark_wrapper, schema_name: str):
        super().__init__(spark_wrapper, schema_name, 'ENTITY_NAME')

    def get_entity_ids(self, value: str, operator: str, entity_type_id: int) -> list[int]:
        df = self.get().select('ENTITY_ID').filter(
            (col('ENTITY_TYPE_ID') == entity_type_id) &
            expr(f"VALUE {operator} '{value}'")
        ).distinct()

        return [row[0] for row in df.collect()]

    def get_entity_id(self, value: str, entity_type_id: int) -> Optional[int]:
        """
        NAME:       get_entity_id
        Returns:    entity_name.entity_id from entity_name.value and entity_name.entity_type_id
        EXCEPTIONS: no_data_found - returns None
                    too_many_rows - raises application error -20003
        """
        element = value.strip()
        ids = self.get_entity_ids(element, '=', entity_type_id)
        if len(ids) > 1:
            raise CdpPkgError(
                -20003,
                f"More than one element-ID (meta-ID) returned from element '{value}' with dimension-ID {entity_type_id}"
            )
        if len(ids) == 0:
            return None
        return ids[0]

    def get_entity_ids_by_values(self, values: list[str], entity_type_id: int) -> list[int]:
        entity_ids = []
        for value in values:
            entity_id = self.get_entity_id(value, entity_type_id)
            if entity_id is not None:
                entity_ids.append(entity_id)
        return entity_ids

    def get_value(
            self, entity_id: int, entity_type_id: Optional[int], group_id: Optional[int], type_id: Optional[int]
    ) -> Optional[str]:
        """
        NAME:     get_value
        PURPOSE:  Returns the entity_name.value by entity_name.id and optionally more parameters.
                  If more than one name is found, only the first name (internally
                  determined by sort order) is returned.
        """
        result_df = self.get().filter(
            (col('ENTITY_ID') == entity_id) &
            (col('ID') == coalesce(col('REPLACED_BY'), col('ID'))) &
            (col('ENTITY_TYPE_ID') == coalesce(lit(entity_type_id), col('ENTITY_TYPE_ID'))) &
            (col('GROUP_ID') == coalesce(lit(group_id), col('GROUP_ID'))) &
            (col('TYPE_ID') == coalesce(lit(type_id), col('TYPE_ID')))
        ).orderBy(
            col('VALID_FROM_DATE').asc_nulls_last(),
            col('SORT_ORDER')
        ).select('VALUE')
        row = result_df.first()
        return row[0] if row else None


class EntityTypeRepository(BaseRepository):
    def __init__(self, spark_wrapper, schema_name: str):
        super().__init__(spark_wrapper, schema_name, 'ENTITY_TYPE')

    def get_id(self, name: str) -> Optional[int]:
        """
        NAME:     get_id
        PURPOSE:  Returns entity_type.id by entity_type.name
        """
        df = self.get().select('ID').filter(col('NAME') == name)
        row = df.first()
        return row[0] if row else None


class EntityNameGroupRepository(BaseRepository):
    def __init__(self, spark_wrapper, schema_name: str):
        super().__init__(spark_wrapper, schema_name, 'ENTITY_NAME_GROUP')

    def get_id(self, name: str) -> Optional[int]:
        """
        NAME:     get_id
        PURPOSE:  Return entity_name_group.id by entity_name_group.name.
        """
        df = self.get().select('ID').filter(col('NAME') == name)
        row = df.first()
        return row[0] if row else None


class EntityNameTypeRepository(BaseRepository):
    def __init__(self, spark_wrapper, schema_name: str):
        super().__init__(spark_wrapper, schema_name, 'ENTITY_NAME_TYPE')

    def get_id(self, name: str) -> Optional[int]:
        """
        NAME:     get_id
        PURPOSE:  Return entity_name_type.id by entity_name_type.name.
        """
        df = self.get().select('ID').filter(col('NAME') == name)
        row = df.first()
        return row[0] if row else None


class EntityNameLanguageRepository(BaseRepository):
    def __init__(self, spark_wrapper, schema_name: str):
        super().__init__(spark_wrapper, schema_name, 'ENTITY_NAME_LANGUAGE')

    def get_id(self, code: str) -> Optional[int]:
        """
        NAME:     get_id
        PURPOSE:  Return entity_name_language.id by entity_name_language.code.
        """
        df = self.get().select('ID').filter(
            (col('CODE') == code) &
            (col('STANDARD_REFERENCE') == DEFAULT_LANGUAGE_STANDARD_REFERENCE)
        )
        row = df.first()
        return row[0] if row else None
