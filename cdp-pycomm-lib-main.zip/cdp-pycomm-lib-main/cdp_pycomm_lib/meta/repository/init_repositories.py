from cdp_pycomm_lib.common.spark_wrapper import CDP_SPARK
from cdp_pycomm_lib.meta.repository.entity_repositories import (
    EntityNameRepository,
    EntityTypeRepository,
    EntityNameGroupRepository,
    EntityNameLanguageRepository,
    EntityNameTypeRepository,
)
from cdp_pycomm_lib.meta.repository.meta_repositories import (
    AttributeRepository,
    HierarchyDataRepository,
    LevelsRepository,
    ObjectTypeRepository,
    ObjectMetaRepository,
    VerbRepository, DimensionDataRepository
)

DEFAULT_SCHEMA = 'cdb'

# Initialize entity repositories
entity_type_repository = EntityTypeRepository(CDP_SPARK, DEFAULT_SCHEMA)
entity_name_repository = EntityNameRepository(CDP_SPARK, DEFAULT_SCHEMA)
entity_name_type_repository = EntityNameTypeRepository(CDP_SPARK, DEFAULT_SCHEMA)
entity_name_group_repository = EntityNameGroupRepository(CDP_SPARK, DEFAULT_SCHEMA)
entity_name_language_repository = EntityNameLanguageRepository(CDP_SPARK, DEFAULT_SCHEMA)

# Initialize meta repositories
attribute_repository = AttributeRepository(CDP_SPARK, DEFAULT_SCHEMA)
verb_repository = VerbRepository(CDP_SPARK, DEFAULT_SCHEMA)
hierarchy_data_repository = HierarchyDataRepository(CDP_SPARK, DEFAULT_SCHEMA)
levels_repository = LevelsRepository(CDP_SPARK, DEFAULT_SCHEMA)
object_type_repository = ObjectTypeRepository(CDP_SPARK, DEFAULT_SCHEMA)
object_meta_repository = ObjectMetaRepository(CDP_SPARK, DEFAULT_SCHEMA)
dimension_data_repository = DimensionDataRepository(CDP_SPARK, DEFAULT_SCHEMA)
