from typing import Optional

from pyspark.sql import DataFrame, Window
from pyspark.sql.functions import col, upper, first

from cdp_pycomm_lib.common.cdp_error import CdpPkgError
from cdp_pycomm_lib.common.cdp_object import BaseRepository


class AttributeRepository(BaseRepository):
    def __init__(self, spark_wrapper, schema_name: str):
        super().__init__(spark_wrapper, schema_name, 'ATTRIBUTE')

    def get_id_and_dimension_id(self, name: str) -> (Optional[int], Optional[int]):
        """
        NAME:           get_id_and_dimension_id
        PURPOSE:        Returns attribute.id and attribute.dimension_id from attribute.name or attribute.short_name
        EXCEPTIONS:     no_data_found - returns (None, None) for attribute.ID and attribute.dimension_id
                        too_many_rows - raises application error -20002
        """
        df = self.get().select('ID', 'DIMENSION_ID').filter(
            (col('NAME') == name) | (col('SHORT_NAME') == name)
        )
        if df.count() == 0:
            return None, None
        if df.count() > 1:
            raise CdpPkgError(
                -20002, f"More than one attribute-ID or dimension-ID returned from attribute '{name}'"
            )
        row = df.first()
        return row[0], row[1]


class VerbRepository(BaseRepository):
    def __init__(self, spark_wrapper, schema_name: str):
        super().__init__(spark_wrapper, schema_name, 'VERB')

    def get_id(self, name: str) -> Optional[int]:
        """
        NAME:     get_id
        PURPOSE:  verbs.id from verbs.name or None if not found
        """
        verb = name.strip()
        df = self.get().select('ID').filter(col("NAME") == verb)
        row = df.first()
        return row[0] if row else None

    def get_ids_by_names(self, names: list[str]) -> list[int]:
        df = self.get().select('ID').filter(col("NAME").isin(names))
        return [row[0] for row in df.collect()]


class HierarchyDataRepository(BaseRepository):
    def __init__(self, spark_wrapper, schema_name: str):
        super().__init__(spark_wrapper, schema_name, 'HIERARCHY_DATA')

    def get_node_ids(self, child_ids: list[int], dimension_id: int) -> list[int]:
        df = self.get().select('NODE_ID').filter(
            (col('CHILD_ID').isin(child_ids)) &
            (col('DIMENSION_ID') == dimension_id)
        )
        return [row[0] for row in df.collect()]

    def get_child_ids_and_node_ids(self, parend_ids: list[int], dimension_id: int) -> (list[int], list[int]):
        """
        NAME:     get_child_ids_and_node_ids
        PURPOSE:  Returns child_ids and node_ids from hierarchy_data
        """
        df = self.get().select('CHILD_ID', 'NODE_ID').filter(
            (col('PARENT_ID').isin(parend_ids)) &
            (col('DIMENSION_ID') == dimension_id)
        ).distinct()
        child_ids = []
        node_ids = []
        for row in df.collect():
            child_ids.append(row[0])
            node_ids.append(row[1])
        return child_ids, node_ids

    def get_child_ids_direct(self, parend_ids: list[int], dimension_id: int) -> list[int]:
        child_ids, _ = self.get_child_ids_and_node_ids(parend_ids, dimension_id)
        return child_ids

    def get_child_ids_all(self, parend_ids: list[int], dimension_id: int) -> (list[int], list[int]):
        child_ids = []
        node_ids = parend_ids
        while True:
            a_child_ids, node_ids = self.get_child_ids_and_node_ids(node_ids, dimension_id)
            if len(a_child_ids) == 0:
                break
            child_ids.extend(a_child_ids)
        return child_ids


class LevelsRepository(BaseRepository):
    def __init__(self, spark_wrapper, schema_name: str):
        super().__init__(spark_wrapper, schema_name, 'LEVELS')

    def get_id(self, name: str, dimension_id: int) -> Optional[int]:
        """
        NAME:     get_id
        PURPOSE:  levels.id from (levels.name or levels.short_name) and levels.dimension_id or None if not found
        """
        level_name = name.strip().upper()
        df = self.get().select('ID').filter(
            ((upper(col("NAME")) == level_name) | (upper(col("SHORT_NAME")) == level_name)) &
            (col("DIMENSION_ID") == dimension_id)
        )
        row = df.first()
        return row[0] if row else None

    def get_ids_by_names(self, names: list[str], dimension_id: int) -> list[int]:
        ids = []
        for name in names:
            a_id = self.get_id(name, dimension_id)
            if a_id is not None:
                ids.append(a_id)
        return ids


class ObjectTypeRepository(BaseRepository):
    def __init__(self, spark_wrapper, schema_name: str):
        super().__init__(spark_wrapper, schema_name, 'OBJECT_TYPE')

    def get_id(self, name: str) -> Optional[int]:
        """
        NAME:     get_id
        PURPOSE:  object_type.id from object_type.name or None if not found
        """
        df = self.get().select('ID').filter(col("NAME") == name.strip())
        row = df.first()
        return row[0] if row else None


class ObjectMetaRepository(BaseRepository):
    def __init__(self, spark_wrapper, schema_name: str):
        super().__init__(spark_wrapper, schema_name, 'OBJECT_META')

    def get_object_id_dataframe(
            self,
            object_type_id: int,
            attribute_id: int,
            dimension_id: int,
            verb_ids: list[int],
            meta_ids: list[int]
    ) -> DataFrame:
        return self.get().select('OBJECT_ID').filter(
            (col('OBJECT_TYPE_ID') == object_type_id) &
            (col('ATTRIBUTE_ID') == attribute_id) &
            (col('DIMENSION_ID') == dimension_id) &
            (col('VERB_ID').isin(verb_ids)) &
            (col('META_ID').isin(meta_ids))
        ).distinct()

    def group_by_object_ids(self) -> DataFrame:
        return (
            self.get().select('OBJECT_ID', first("OBJECT_NAME").over(
                Window.partitionBy("OBJECT_ID").orderBy(col("UPDATED_DATE").desc())
            ).alias("OBJECT_NAME"))
            .distinct()
        )


class DimensionDataRepository(BaseRepository):
    def __init__(self, spark_wrapper, schema_name: str):
        super().__init__(spark_wrapper, schema_name, 'DIMENSION_DATA')
