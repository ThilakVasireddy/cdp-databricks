import smtplib
from datetime import datetime
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from cdp_pycomm_lib.common import cdp_common_logging
from cdp_pycomm_lib.common.cdp_config import CDP_CONFIG
from cdp_pycomm_lib.mule.repository.init_repositories import (
    safe_user_repository,
    safe_user_groups_repository,
    safe_groups_repository,
    matlab_model_repository
)

log = cdp_common_logging.get_logger(__name__)

MAIL_SERVER = CDP_CONFIG.get_config('mail_server')
MAIL_PORT = int(CDP_CONFIG.get_config('mail_port'))


def send_model_notification(
        model_name: str,
        model_run: str,
        message,
        subject=None,
        from_address='noreply@mrelay.lseg.com',
        attachments=None,
        content_type='text/plain'
):
    recipients = get_recipients(model_name, model_run)
    if len(recipients) > 0:
        # Assuming common.pkg_mail.send_mail is a function to send emails
        send_mail(
            recipients,
            message,
            subject,
            from_address,
            attachments,
            content_type
        )
        return {"status": 1, "description": "Message sent"}
    return {"status": -1, "description": "Failed to get the list of recipients"}


def get_recipients(model_name: str, model_run: str) -> list[str]:
    df_safe_user = safe_user_repository.get()
    df_safe_user_groups = safe_user_groups_repository.get()
    df_safe_groups = safe_groups_repository.get()
    df_matlab_model = matlab_model_repository.get()

    df = (df_safe_user
          .join(df_safe_user_groups, "ID")
          .join(df_safe_groups, df_safe_groups["ID"] == df_safe_user_groups["SAFE_GROUPS_ID"])
          .join(df_matlab_model, df_safe_groups["ID"] == df_matlab_model["NOTIFY_GROUP_ID"])
          .filter((df_matlab_model["MODEL_NAME"] == model_name) & (df_matlab_model["MODEL_RUN"] == model_run))
          .select("EMAIL")
          .distinct()
          )
    return [row[0] for row in df.collect()]


def send_mail(
        recipients,
        message,
        subject,
        from_address,
        attachments,
        content_type
):
    try:
        # Set up the SMTP server
        server = smtplib.SMTP(MAIL_SERVER, MAIL_PORT)
        server.starttls()

        # Create the email headers
        msg = MIMEMultipart()
        msg['From'] = from_address
        msg['To'] = ','.join(recipients)
        msg['Subject'] = subject if subject else ''
        msg['Date'] = datetime.now().strftime('%a, %d %b %Y %H:%M:%S')

        # Attach the message body
        msg.attach(MIMEText(message, content_type))

        # Attach any files
        if attachments:
            for attachment in attachments:
                part = MIMEBase('application', 'octet-stream')
                part.set_payload(open(attachment, 'rb').read())
                encoders.encode_base64(part)
                part.add_header('Content-Disposition', f'attachment; filename={attachment}')
                msg.attach(part)

        # Send the email
        server.sendmail(from_address, recipients, msg.as_string())
        server.quit()
    except Exception as e:
        log.error(f"Failed to send email: {e}")
