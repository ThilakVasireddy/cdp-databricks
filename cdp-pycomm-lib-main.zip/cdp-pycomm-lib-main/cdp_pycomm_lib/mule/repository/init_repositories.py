from cdp_pycomm_lib.common.spark_wrapper import CDP_SPARK
from cdp_pycomm_lib.mule.repository.mule_repositories import (
    SafeUserRepository,
    SafeUserGroupsRepository,
    SafeGroupsRepository,
    MatlabModelRepository
)

DEFAULT_SCHEMA = 'cdb'

# Initialize repositories
safe_user_repository = SafeUserRepository(CDP_SPARK, DEFAULT_SCHEMA)
safe_user_groups_repository = SafeUserGroupsRepository(CDP_SPARK, DEFAULT_SCHEMA)
safe_groups_repository = SafeGroupsRepository(CDP_SPARK, DEFAULT_SCHEMA)
matlab_model_repository = MatlabModelRepository(CDP_SPARK, DEFAULT_SCHEMA)
