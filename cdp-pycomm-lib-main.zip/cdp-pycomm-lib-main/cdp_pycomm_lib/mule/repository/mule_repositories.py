from cdp_pycomm_lib.common.cdp_object import BaseRepository


class SafeUserRepository(BaseRepository):
    def __init__(self, spark_wrapper, schema_name: str):
        super().__init__(spark_wrapper, schema_name, 'SAFE_USER')


class SafeUserGroupsRepository(BaseRepository):
    def __init__(self, spark_wrapper, schema_name: str):
        super().__init__(spark_wrapper, schema_name, 'SAFE_USER_GROUPS')


class SafeGroupsRepository(BaseRepository):
    def __init__(self, spark_wrapper, schema_name: str):
        super().__init__(spark_wrapper, schema_name, 'SAFE_GROUPS')


class MatlabModelRepository(BaseRepository):
    def __init__(self, spark_wrapper, schema_name: str):
        super().__init__(spark_wrapper, schema_name, 'MATLAB_MODEL')
