
import pytest
from cdp_pycomm_lib.cdp_data_reader import (
    get_series_name,
    get_series_by_name,
    get_series_loadset
)
from datetime import datetime, timedelta

from tests.util import spark_fixture

import os
import shutil

@pytest.fixture(scope="module")
def setup_data(spark_fixture):
    # Create mock data for repositories
    curve_data = [(101658360, "Curve1"), (112829829, "Curve2"), (106271940, "Curve3")]
    load_set2_curve_data = [(101658360, 1), (112829829, 2), (106271940, 3)]
    dataset_data = [(1, "LoadSet1", 1), (2, "LoadSet2", 1), (3, "LoadSet3", 2)]

    # Create DataFrames
    curve_df = spark_fixture.createDataFrame(curve_data, ["ID", "NAME"])
    load_set2_curve_df = spark_fixture.createDataFrame(
        load_set2_curve_data, ["CURVE_ID", "LOAD_SET_ID"]
    )
    dataset_df = spark_fixture.createDataFrame(
        dataset_data, ["ID", "NAME", "SET_TYPE_ID"]
    )

    # Register as temporary views
    spark_fixture.sql("CREATE DATABASE IF NOT EXISTS cdb")

    # Drop tables if they already exist
    spark_fixture.sql("DROP TABLE IF EXISTS cdb.CURVE")
    spark_fixture.sql("DROP TABLE IF EXISTS cdb.LOAD_SET2_CURVE")
    spark_fixture.sql("DROP TABLE IF EXISTS cdb.DATASET")

    # Remove directories associated with the tables
    warehouse_dir = "tests/integration_test/spark-warehouse/cdb.db"
    for table in ["curve", "load_set2_curve", "dataset"]:
        table_path = os.path.join(warehouse_dir, table)
        if os.path.exists(table_path):
            shutil.rmtree(table_path)

    # Save tables with overwrite mode
    curve_df.write.mode("overwrite").saveAsTable("cdb.CURVE")
    load_set2_curve_df.write.mode("overwrite").saveAsTable("cdb.LOAD_SET2_CURVE")
    dataset_df.write.mode("overwrite").saveAsTable("cdb.DATASET")

    print(spark_fixture.sql("SHOW TABLES IN cdb").show())

def test_get_series_name(spark_fixture, setup_data):
    result = get_series_name([101658360, 112829829])
    print(result.collect())
    assert result.count() == 2
    assert result.filter(result.NAME == "Curve1").count() == 1
    assert result.filter(result.NAME == "Curve2").count() == 1

def test_get_series_by_name(spark_fixture, setup_data):
    fd_from = datetime.strptime("2025-06-20", "%Y-%m-%d")
    fd_to = fd_from + timedelta(days=10)
    vd_from = datetime.strptime("2025-06-20", "%Y-%m-%d")
    vd_to = vd_from + timedelta(days=10)
    curve_names = ["Curve1", "Curve2"]

    result = get_series_by_name(curve_names, fd_from, fd_to, vd_from, vd_to, partial_match_flag=False)
    #assert result is not None
    assert result is None

def test_get_series_loadset(spark_fixture, setup_data):
    result_by_id = get_series_loadset([101658360, 112829829])
    assert result_by_id.count() == 2
    assert result_by_id.filter(result_by_id.NAME == "LoadSet1").count() == 1

    result_by_name = get_series_loadset(["Curve1", "Curve2"])
    assert result_by_name.count() == 2
    assert result_by_name.filter(result_by_name.NAME == "LoadSet1").count() == 1