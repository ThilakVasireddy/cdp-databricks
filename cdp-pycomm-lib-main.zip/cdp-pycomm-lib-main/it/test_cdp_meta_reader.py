import pytest
from tests.util import spark_fixture as spark_fixture
from cdp_pycomm_lib.cdp_meta_reader import get_object_id, get_object_meta
import os
import shutil
from decimal import Decimal
from pyspark.sql.types import (
    StructType,
    StructField,
    DecimalType,
    StringType,
    TimestampType,
    BinaryType,
    LongType,
)


@pytest.fixture(scope="module")
def setup_data(spark_fixture):

    # Create mock data for OBJECT_TYPE table
    object_type_data = [
        (1, "Curve", 11),
        (2, "Surface", 22),
        (3, "Cube", 33)
    ]
    object_type_df = spark_fixture.createDataFrame(object_type_data, ["ID", "NAME", "DIMENSION_ID"])

    # Create mock data for OBJECT_META table
    object_meta_schema = StructType([
        StructField("META_ID", DecimalType(38, 0), True),
        StructField("DIMENSION_ID", DecimalType(38, 0), True),
        StructField("OBJECT_ID", DecimalType(38, 0), True),
        StructField("SEARCH_TEXT", StringType(), True),
        StructField("ATTRIBUTE_ID", DecimalType(38, 0), True),
        StructField("FREE_TEXT", StringType(), True),
        StructField("OBJECT_TYPE_ID", DecimalType(38, 0), True),
        StructField("VERB_ID", DecimalType(38, 0), True),
        StructField("ID", DecimalType(38, 0), True),
        StructField("ELEMENT_NAME", StringType(), True),
        StructField("OBJECT_NAME", StringType(), True),
        StructField("CREATED_DATE", TimestampType(), True),
        StructField("CREATED_BY", BinaryType(), True),
        StructField("UPDATED_DATE", TimestampType(), True),
        StructField("UPDATED_BY", BinaryType(), True),
        StructField("OBJECT_VERSION", DecimalType(38, 0), True),
        StructField("STATUS_ID", DecimalType(38, 0), True),
    ])

    object_meta_data = [
        (Decimal(101), Decimal(11), Decimal(1001), "SearchText1", Decimal(1), "FreeText1", Decimal(1), Decimal(1), Decimal(1), "ElementName1", "ObjectName1", None, None, None, None, Decimal(1), Decimal(1)),
        (Decimal(102), Decimal(22), Decimal(1002), "SearchText2", Decimal(2), "FreeText2", Decimal(2), Decimal(2), Decimal(2), "ElementName2", "ObjectName2", None, None, None, None, Decimal(1), Decimal(2)),
        (Decimal(103), Decimal(33), Decimal(1003), "SearchText3", Decimal(3), "FreeText3", Decimal(3), Decimal(3), Decimal(3), "ElementName3", "ObjectName3", None, None, None, None, Decimal(1), Decimal(3)),
    ]

    object_meta_df = spark_fixture.createDataFrame(object_meta_data, schema=object_meta_schema)

    # Create mock data for ATTRIBUTE table
    attribute_data = [
        (1, "Attribute1", 11, "ShortName1"),
        (2, "Attribute2", 22, "ShortName2"),
        (3, "Attribute3", 33, "ShortName3"),
    ]
    attribute_df = spark_fixture.createDataFrame(attribute_data, ["ID", "NAME", "DIMENSION_ID", "SHORT_NAME"])

    # Create mock data for VERB table
    verb_data = [
        (1, "from"),
        (2, "to"),
        (3, "at"),
        (4, "is"),
        (5, "by"),
        (6, "along"),
        (7, "excl")
    ]
    verb_df = spark_fixture.createDataFrame(
        verb_data, ["ID", "NAME"]
    )

    # Create mock data for ENTITY_NAME table
    entity_name_schema = StructType([
        StructField("ID", DecimalType(38, 0), True),
        StructField("ENTITY_ID", DecimalType(38, 0), True),
        StructField("ENTITY_TYPE_ID", DecimalType(38, 0), True),
        StructField("TYPE_ID", DecimalType(38, 0), True),
        StructField("LANGUAGE_ID", DecimalType(38, 0), True),
        StructField("VALUE", StringType(), True),
        StructField("IS_DEFAULT", StringType(), True),
        StructField("SORT_ORDER", DecimalType(38, 0), True),
        StructField("VALID_FROM_DATE", TimestampType(), True),
        StructField("VALID_TO_DATE", TimestampType(), True),
        StructField("REPLACED_BY", DecimalType(38, 0), True),
        StructField("REASON", StringType(), True),
        StructField("COMMENTS", StringType(), True),
        StructField("CREATED_DATE", TimestampType(), True),
        StructField("CREATED_BY", BinaryType(), True),
        StructField("UPDATED_DATE", TimestampType(), True),
        StructField("UPDATED_BY", BinaryType(), True),
        StructField("OBJECT_VERSION", DecimalType(38, 0), True),
        StructField("GROUP_ID", DecimalType(38, 0), True),
    ])

    entity_name_data = [
        (Decimal(1), Decimal(101), Decimal(1), Decimal(11), Decimal(1001), "EntityValue1", "Y", Decimal(1), None, None, None, "A", "Comment1", None, None, None, None, Decimal(1), Decimal(1)),
        (Decimal(2), Decimal(102), Decimal(2), Decimal(22), Decimal(1002), "EntityValue2", "N", Decimal(2), None, None, None, "B", "Comment2", None, None, None, None, Decimal(1), Decimal(2)),
        (Decimal(3), Decimal(103), Decimal(3), Decimal(33), Decimal(1003), "EntityValue3", "Y", Decimal(3), None, None, None, "C", "Comment3", None, None, None, None, Decimal(1), Decimal(3)),
    ]

    entity_name_df = spark_fixture.createDataFrame(entity_name_data, schema=entity_name_schema)

    # Create mock data for DIMENSION_DATA table
    dimension_data_schema = StructType([
        StructField("ELEMENT_ID", LongType(), True),
        StructField("NAME", StringType(), True),
        StructField("DESCRIPTION", StringType(), True),
        StructField("SHORT_NAME", StringType(), True),
        StructField("ABBREVIATION", StringType(), True),
        StructField("COMMENTS", StringType(), True),
        StructField("SOURCE", StringType(), True),
        StructField("STANDARD_VALUE", StringType(), True),
        StructField("STANDARD_REFERENCE", StringType(), True),
        StructField("LEVEL_ID", LongType(), True),
        StructField("CREATED_BY", StringType(), True),
        StructField("CREATED_DATE", TimestampType(), True),
        StructField("SORT_COLUMN", LongType(), True),
        StructField("STATUS_ID", LongType(), True),
        StructField("DIMENSION_ID", LongType(), True),
        StructField("CHANGED_DATE", TimestampType(), True),
        StructField("CHANGED_BY", StringType(), True),
        StructField("INCLUDE_IN_EXTERNAL_DICTIONARY", StringType(), True),
        StructField("SHORT_DESCRIPTION", StringType(), True),
        StructField("RESPONSIBLE_ID", LongType(), True),
        StructField("PERM_ID", LongType(), True),
        StructField("RIC", StringType(), True),
    ])

    dimension_data = [
        (1, "Dimension1", "Description1", "ShortName1", "Abbr1", "Comment1", "Source1", "StandardValue1", "StandardRef1", 101, "User1", None, 1, 1, 1001, None, "User1", "Y", "ShortDesc1", 201, 301, "RIC1"),
        (2, "Dimension2", "Description2", "ShortName2", "Abbr2", "Comment2", "Source2", "StandardValue2", "StandardRef2", 102, "User2", None, 2, 2, 1002, None, "User2", "N", "ShortDesc2", 202, 302, "RIC2"),
        (3, "Dimension3", "Description3", "ShortName3", "Abbr3", "Comment3", "Source3", "StandardValue3", "StandardRef3", 103, "User3", None, 3, 3, 1003, None, "User3", "Y", "ShortDesc3", 203, 303, "RIC3"),
    ]

    dimension_data_df = spark_fixture.createDataFrame(dimension_data, schema=dimension_data_schema)

    # Create the database if it does not exist
    spark_fixture.sql("CREATE DATABASE IF NOT EXISTS cdb")

    # Remove directories associated with the tables
    warehouse_dir = "tests/integration_test/spark-warehouse/cdb.db"
    for table in [ "object_type", "object_meta", "attribute", "verb", "entity_name", "dimension_data"]:
        table_path = os.path.join(warehouse_dir, table)
        if os.path.exists(table_path):
            shutil.rmtree(table_path)

    # Save tables with overwrite mode
    object_type_df.write.mode("overwrite").saveAsTable("cdb.OBJECT_TYPE")
    attribute_df.write.mode("overwrite").saveAsTable("cdb.ATTRIBUTE")
    object_meta_df.write.mode("overwrite").saveAsTable("cdb.OBJECT_META")
    verb_df.write.mode("overwrite").saveAsTable("cdb.VERB")
    entity_name_df.write.mode("overwrite").saveAsTable("cdb.ENTITY_NAME")
    dimension_data_df.write.mode("overwrite").saveAsTable("cdb.DIMENSION_DATA")

    print(spark_fixture.sql("SHOW TABLES IN cdb").show())

def test_get_object_id(spark_fixture, setup_data):
    obj_meta = ("", ("Var", "", "FX.rate"), "")
    result = get_object_id("Surface", obj_meta, b_ret_objname=True)
    result.show()
    assert result is not None
    #assert result.count() == 1
    #assert result.filter(result.NAME == "Surface").count() == 1


def test_get_object_meta_by_id(spark_fixture, setup_data):
    ids = [102, 103]
    result = get_object_meta(ids, obj_type="Surface")
    result.show()
    assert result is not None
    #assert result.count() == 2
    #assert result.filter(result.NAME == "Surface").count() == 1


def test_get_object_meta_by_meta(spark_fixture, setup_data):
    obj_meta = ("", ("Var", "", "FX.rate"), "")
    result = get_object_meta(obj_meta, obj_type="Cube")
    result.show()
    assert result is not None
    #assert result.count() == 1
    #assert result.filter(result.NAME == "Cube").count() == 1