from unittest.mock import patch, MagicMock

import pytest

from cdp_pycomm_lib.cdp_meta_reader import get_object_id, get_object_meta
from cdp_pycomm_lib.common.cdp_error import MetaError, ParameterError


@patch('cdp_pycomm_lib.cdp_meta_reader.mjapi_services.get_by_meta')
@patch('cdp_pycomm_lib.cdp_meta_reader.parse_meta')
def test_returns_dataframe(mock_parse_meta, mock_get_by_meta):
    mock_parse_meta.return_value = ['parsed', 'meta']
    mock_df = MagicMock()
    mock_get_by_meta.return_value = mock_df

    result = get_object_id('Curve', ['meta'])
    assert result == mock_df

    mock_parse_meta.assert_called_once_with(['meta'])
    mock_get_by_meta.assert_called_once_with('Curve', ['parsed', 'meta'], False)


@patch('cdp_pycomm_lib.cdp_meta_reader.mjapi_services.get_by_meta')
@patch('cdp_pycomm_lib.cdp_meta_reader.parse_meta')
def test_handles_meta_error(mock_parse_meta, mock_get_by_meta):
    mock_parse_meta.side_effect = MetaError('meta error')

    with pytest.raises(MetaError):
        get_object_id('Curve', ['meta'])
    mock_parse_meta.assert_called_once_with(['meta'])
    mock_get_by_meta.assert_not_called()


@patch('cdp_pycomm_lib.cdp_meta_reader.mjapi_services.get_by_meta')
@patch('cdp_pycomm_lib.cdp_meta_reader.parse_meta')
def test_handles_parameter_error(mock_parse_meta, mock_get_by_meta):
    mock_parse_meta.side_effect = ParameterError('parameter error')

    with pytest.raises(ParameterError):
        get_object_id('Curve', ['meta'])
    mock_parse_meta.assert_called_once_with(['meta'])
    mock_get_by_meta.assert_not_called()


@patch('cdp_pycomm_lib.cdp_meta_reader.mjapi_services.get_by_meta')
@patch('cdp_pycomm_lib.cdp_meta_reader.parse_meta')
def test_returns_none_when_no_dataframe(mock_parse_meta, mock_get_by_meta):
    mock_parse_meta.return_value = ['parsed', 'meta']
    mock_get_by_meta.return_value = None

    result = get_object_id('Curve', ['meta'])
    assert result is None
    mock_parse_meta.assert_called_once_with(['meta'])
    mock_get_by_meta.assert_called_once_with('Curve', ['parsed', 'meta'], False)


@patch('cdp_pycomm_lib.meta.mjapi_services.get_meta_by_id')
def test_get_object_meta_returns_dataframe_for_valid_ids(mock_get_meta_by_id):
    mock_df = MagicMock()
    mock_get_meta_by_id.return_value = mock_df
    result = get_object_meta([1, 2, 3], "Curve")
    assert result == mock_df


@patch('cdp_pycomm_lib.meta.mjapi_services.get_meta_by_meta')
def test_get_object_meta_returns_dataframe_for_valid_meta(mock_get_meta_by_meta):
    mock_df = MagicMock()
    mock_get_meta_by_meta.return_value = mock_df
    result = get_object_meta(("", ("Var", "", "FX.rate"), ""), "Curve")
    assert result == mock_df


def test_get_object_meta_returns_none_for_invalid_input():
    result = get_object_meta("InvalidInput", "Curve")
    assert result is None


@patch('cdp_pycomm_lib.meta.mjapi_services.get_meta_by_meta')
def test_get_object_meta_raises_error_for_invalid_meta(mock_get_meta_by_meta):
    with pytest.raises(MetaError):
        get_object_meta(("Invalid", "", "Meta"), "Curve")
