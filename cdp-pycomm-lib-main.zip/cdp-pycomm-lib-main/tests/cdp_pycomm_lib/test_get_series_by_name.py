import datetime
from unittest.mock import patch, MagicMock

import pytest
from pyspark.sql import DataFrame

from cdp_pycomm_lib.cdp_data_reader import get_series_by_name
from cdp_pycomm_lib.common.cdp_error import ParameterError, MetaError


@patch("cdp_pycomm_lib.cdp_data_reader.mjapi_services.get_data")
def test_returns_series_data_for_exact_names(mock_get_data):
    mock_df = MagicMock(spec=DataFrame)
    mock_get_data.return_value = mock_df
    fd_from = datetime.datetime(2023, 1, 1)
    fd_to = datetime.datetime(2023, 1, 1)
    result = get_series_by_name(["Curve A"], fd_from=fd_from, fd_to=fd_to, time_zone_in=None)
    assert result == mock_df
    mock_get_data.assert_called_once_with(
        ["Curve A"], fd_from, fd_to, None, None, 'UTC', 'UTC', False
    )


@patch("cdp_pycomm_lib.cdp_data_reader.mjapi_services.get_data")
def test_returns_series_data_for_partial_names(mock_get_data):
    mock_df = MagicMock(spec=DataFrame)
    mock_get_data.return_value = mock_df
    result = get_series_by_name(["Curve"], partial_match_flag=True)
    assert result == mock_df
    mock_get_data.assert_called_once_with(
        ["Curve"], None, None, None, None, 'UTC', 'UTC', True
    )


@patch("cdp_pycomm_lib.cdp_data_reader.mjapi_services.get_data")
def test_returns_series_data_for_time_series(mock_get_data):
    mock_df = MagicMock(spec=DataFrame)
    mock_get_data.return_value = mock_df
    vd_from = datetime.datetime(2023, 1, 1)
    vd_to = datetime.datetime(2023, 2, 1)
    result = get_series_by_name(["Curve"], vd_from=vd_from, vd_to=vd_to, time_zone_in=None)
    assert result == mock_df
    mock_get_data.assert_called_once_with(
        ["Curve"], vd_from, vd_to, vd_from, vd_to, 'UTC', 'UTC', False
    )


def test_raises_error_for_exceeding_exact_name_list_limit():
    curve_name_list = ["Curve"] * 20001
    with pytest.raises(
            ParameterError,
            match="The curve name list size should be less than 20000 if the Partial Match flag is N"
    ):
        get_series_by_name(curve_name_list, partial_match_flag=False)


def test_raises_error_for_exceeding_partial_name_list_limit():
    curve_name_list = ["Curve"] * 11
    with pytest.raises(
            ParameterError,
            match="The curve name list size should be less than 10 if the Partial Match flag is Y"
    ):
        get_series_by_name(curve_name_list, partial_match_flag=True)


@patch("cdp_pycomm_lib.cdp_data_reader.mjapi_services.get_data")
def test_handle_parameter_error(mock_get_data):
    mock_get_data.side_effect = ParameterError("Invalid input")
    result = get_series_by_name(['Curve'])
    assert result is None


@patch("cdp_pycomm_lib.cdp_data_reader.mjapi_services.get_data")
def test_handle_meta_error(mock_get_data):
    mock_get_data.side_effect = MetaError("Invalid input")
    result = get_series_by_name(['Curve'])
    assert result is None


@patch("cdp_pycomm_lib.cdp_data_reader.mjapi_services.get_data")
def test_handle_other_exception(mock_get_data):
    mock_get_data.side_effect = Exception("Invalid input")
    result = get_series_by_name(['Curve'])
    assert result is None
