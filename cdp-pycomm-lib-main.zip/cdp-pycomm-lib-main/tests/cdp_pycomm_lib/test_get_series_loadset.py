from unittest.mock import patch, MagicMock

from pyspark.sql import DataFrame

from cdp_pycomm_lib.cdp_data_reader import get_series_loadset
from cdp_pycomm_lib.common.cdp_error import ParameterError


@patch("cdp_pycomm_lib.cdp_data_reader.curve_services.get_loadset_for_curve_by_id")
def test_returns_loadset_when_valid_curve_ids_provided(mock_get_loadset_by_id):
    mock_df = MagicMock(spec=DataFrame)
    mock_get_loadset_by_id.return_value = mock_df
    curve_inputs = [101658360, 112829829]
    result = get_series_loadset(curve_inputs)
    assert result == mock_df
    mock_get_loadset_by_id.assert_called_once_with(curve_inputs)


@patch("cdp_pycomm_lib.cdp_data_reader.curve_services.get_loadset_for_curve_by_curve_name")
def test_returns_loadset_when_valid_curve_names_provided(mock_get_loadset_by_nm):
    mock_df = MagicMock(spec=DataFrame)
    mock_get_loadset_by_nm.return_value = mock_df
    curve_inputs = ["Curve1", "Curve2"]
    result = get_series_loadset(curve_inputs)
    assert result == mock_df
    mock_get_loadset_by_nm.assert_called_once_with(curve_inputs)


@patch("cdp_pycomm_lib.cdp_data_reader.curve_services.get_loadset_for_curve_by_id")
def test_returns_none_when_invalid_curve_ids_provided(mock_get_loadset_by_id):
    curve_inputs = [None, 112829829]
    result = get_series_loadset(curve_inputs)
    assert result is None
    mock_get_loadset_by_id.assert_not_called()


@patch("cdp_pycomm_lib.cdp_data_reader.curve_services.get_loadset_for_curve_by_curve_name")
def test_returns_none_when_invalid_curve_names_provided(mock_get_loadset_by_nm):
    curve_inputs = [None, ""]
    result = get_series_loadset(curve_inputs)
    assert result is None
    mock_get_loadset_by_nm.assert_not_called()


def test_returns_none_when_invalid_input_provided():
    assert get_series_loadset(1234) is None
    assert get_series_loadset("curve name") is None
    assert get_series_loadset([]) is None


@patch("cdp_pycomm_lib.cdp_data_reader.curve_services.get_loadset_for_curve_by_id")
def test_handles_parameter_error_gracefully(mock_get_loadset_by_id):
    mock_get_loadset_by_id.side_effect = ParameterError("Invalid input")
    curve_inputs = [101658360]
    result = get_series_loadset(curve_inputs)
    assert result is None
    mock_get_loadset_by_id.assert_called_once_with(curve_inputs)
