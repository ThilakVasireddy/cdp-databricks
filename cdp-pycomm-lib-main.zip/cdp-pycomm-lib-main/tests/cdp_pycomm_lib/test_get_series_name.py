from unittest.mock import patch, MagicMock

import pytest
from pyspark.sql import DataFrame

from cdp_pycomm_lib.cdp_data_reader import get_series_name
from cdp_pycomm_lib.common.cdp_error import ParameterError


@patch("cdp_pycomm_lib.cdp_data_reader.curve_services.get_curve")
def test_returns_curve_names_when_valid_ids_provided(mock_get_curve):
    mock_df = MagicMock(spec=DataFrame)
    mock_get_curve.return_value = mock_df
    curve_ids = [101658360, 112829829]
    result = get_series_name(curve_ids)
    assert result == mock_df
    mock_get_curve.assert_called_once_with(curve_ids)


@patch("cdp_pycomm_lib.cdp_data_reader.curve_services.get_curve")
def test_raises_error_when_invalid_ids_provided(mock_get_curve):
    mock_get_curve.side_effect = ParameterError("Invalid curve IDs")
    curve_ids = [None, 112829829]
    with pytest.raises(ParameterError, match="Invalid curve IDs"):
        get_series_name(curve_ids)
    mock_get_curve.assert_called_once_with([112829829])


@patch("cdp_pycomm_lib.cdp_data_reader.curve_services.get_curve")
def test_returns_empty_list_when_no_ids_provided(mock_get_curve):
    mock_get_curve.return_value = None
    result = get_series_name([])
    assert result is None
