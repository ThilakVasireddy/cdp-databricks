from unittest.mock import patch

from cdp_pycomm_lib import cdp_data_reader


@patch('cdp_pycomm_lib.cdp_data_reader.mule_services.send_model_notification')
def test_send_notification_plain_text(mock_send_model_notification):
    message = 'this is text plain test!!!'
    mock_send_model_notification.return_value = {"status": 1, "message": "Message sent"}
    result = cdp_data_reader.send_notification('plain subject', message, 'text/plain')
    assert result is not None
    assert result['status'] == 1
    assert result['message'] == 'Message sent'
    assert mock_send_model_notification.call_args[1]['model_name'] == 'Pytharun'
    assert mock_send_model_notification.call_args[1]['model_run'].startswith('cdp_pycomm_lib')
    assert mock_send_model_notification.call_args[1]['message'].startswith(message)
    assert mock_send_model_notification.call_args[1]['subject'] == 'plain subject'
    assert mock_send_model_notification.call_args[1]['content_type'] == 'text/plain'


@patch('cdp_pycomm_lib.cdp_data_reader.mule_services.send_model_notification')
def test_send_notification_html_content(mock_send_model_notification):
    mock_send_model_notification.return_value = {"status": 1, "message": "Message sent"}
    mail_content = [
        '<html><head><title>mytitle</title></head>',
        '<body><h1>hello , this is html test</h1><table border=1><tr><th>column1</th><th>column2</th></tr><tr><td>value1</td><td>value2</td></tr></table><body></html>'
    ]
    result = cdp_data_reader.send_notification('html subject', mail_content, 'text/html')
    assert result is not None
    assert result['status'] == 1
    assert result['message'] == 'Message sent'
    assert mock_send_model_notification.call_args[1]['content_type'] == 'text/html'


@patch('cdp_pycomm_lib.cdp_data_reader.mule_services.send_model_notification')
def test_send_notification_empty_content(mock_send_model_notification):
    mock_send_model_notification.return_value = {"status": 1, "message": "Message sent"}
    result = cdp_data_reader.send_notification('empty subject', None, 'text/plain')
    assert result is not None
    assert result['status'] == 1
    assert result['message'] == 'Message sent'
    assert mock_send_model_notification.call_args[1]['message'].startswith('test')


@patch('cdp_pycomm_lib.cdp_data_reader.mule_services.send_model_notification')
def test_send_notification_exception_handling(mock_send_model_notification):
    mock_send_model_notification.side_effect = Exception('Notification failed')
    result = cdp_data_reader.send_notification('exception subject', 'this will fail', 'text/plain')
    assert result is None
