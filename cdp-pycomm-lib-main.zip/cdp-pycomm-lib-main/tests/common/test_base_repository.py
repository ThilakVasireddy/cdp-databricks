from unittest.mock import MagicMock

from cdp_pycomm_lib.common.cdp_object import BaseRepository


def test_init_correctly():
    mock_spark_wrapper = MagicMock()
    repository = BaseRepository(mock_spark_wrapper, 'schema_name', 'table_name')
    assert repository.spark_wrapper == mock_spark_wrapper
    assert repository.schema_name == 'schema_name'
    assert repository.table_name == 'schema_name.table_name'


def test_return_table_successfully():
    mock_spark_wrapper = MagicMock()
    repository = BaseRepository(mock_spark_wrapper, 'schema_name', 'table_name')
    mock_df = MagicMock()
    mock_spark_wrapper.table.return_value = mock_df

    result = repository.get()
    assert result == mock_df
    mock_spark_wrapper.table.assert_called_once_with('schema_name.table_name')


def test_retrieves_delta_table_for_valid_table_name():
    mock_spark_wrapper = MagicMock()
    mock_delta_table = MagicMock()
    mock_spark_wrapper.delta_table.return_value = mock_delta_table
    repository = BaseRepository(mock_spark_wrapper, 'schema_name', 'table_name')

    result = repository.delta_table()
    assert result == mock_delta_table
    mock_spark_wrapper.delta_table.assert_called_once_with("schema_name.table_name")
