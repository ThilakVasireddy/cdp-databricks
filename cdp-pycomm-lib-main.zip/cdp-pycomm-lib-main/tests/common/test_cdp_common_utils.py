from unittest.mock import patch, MagicMock

from cdp_pycomm_lib.common.cdp_common_utils import read_config_file_in_package, read_config_file


@patch("cdp_pycomm_lib.common.cdp_common_utils.files")
def test_loads_config_file_from_package_when_file_exists(mock_files):
    mock_file = MagicMock()
    mock_file.is_file.return_value = True
    mock_file.open.return_value.__enter__.return_value.read.return_value = '{"key": "value"}'
    mock_files.return_value.joinpath.return_value = mock_file

    result = read_config_file_in_package("test_package", "test_config.json")
    assert result == {"key": "value"}
    mock_file.is_file.assert_called_once()
    mock_file.open.assert_called_once_with('r', encoding='utf-8')


@patch("cdp_pycomm_lib.common.cdp_common_utils.files")
def test_returns_empty_dict_from_package_when_file_does_not_exist(mock_files):
    mock_file = MagicMock()
    mock_file.is_file.return_value = False
    mock_files.return_value.joinpath.return_value = mock_file

    result = read_config_file_in_package("test_package", "nonexistent_config.json")
    assert result == {}
    mock_file.is_file.assert_called_once()
    mock_file.open.assert_not_called()


@patch("os.path.exists")
@patch("builtins.open", new_callable=MagicMock)
def test_loads_config_file_when_file_exists(mock_open, mock_exists):
    mock_exists.return_value = True
    mock_open.return_value.__enter__.return_value.read.return_value = '{"key": "value"}'

    result = read_config_file("test_config.json")
    assert result == {"key": "value"}
    mock_exists.assert_called_once_with("test_config.json")
    mock_open.assert_called_once_with("test_config.json", 'r', encoding='utf-8')


@patch("os.path.exists")
@patch("builtins.open", new_callable=MagicMock)
def test_returns_empty_dict_when_file_does_not_exist(mock_open, mock_exists):
    mock_exists.return_value = False

    result = read_config_file("nonexistent_config.json")
    assert result == {}
    mock_exists.assert_called_once_with("nonexistent_config.json")
    mock_open.assert_not_called()
