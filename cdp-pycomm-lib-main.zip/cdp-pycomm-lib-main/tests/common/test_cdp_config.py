from datetime import datetime
from unittest.mock import patch

import pytest

from cdp_pycomm_lib import config
from cdp_pycomm_lib.common.cdp_config import CDP_CONFIG, CDP_MODEL, AppConfig, ModelRunConfig


def test_get_config_returns_correct_value():
    result = CDP_CONFIG.get_config('mail_server')
    assert result == 'localhost'


def test_get_config_returns_correct_value_when_in_hierarchy():
    result = CDP_CONFIG.get_config('databricks.host')
    assert result == 'https://adb-2123484989296422.2.azuredatabricks.net'


def test_get_config_raises_key_error_for_missing_param():
    with pytest.raises(KeyError):
        CDP_CONFIG.get_config('missing_param')


def test_add_config():
    original_value = CDP_CONFIG.get_config('mail_server')
    CDP_CONFIG.add_config('mail_server', 'test')
    assert CDP_CONFIG.get_config('mail_server') == 'test'
    CDP_CONFIG.add_config('mail_server', original_value)


def test_get_env():
    assert CDP_CONFIG.get_env() == 'local'


def test_get_config_dir():
    assert CDP_CONFIG.get_config_dir() == '/Volumes/cdp_local_test_catalog_01/platform/platform/config'


def test_is_server():
    assert CDP_CONFIG.is_server() == False
    original_value = CDP_CONFIG.DEFAULT_ENV
    CDP_CONFIG.DEFAULT_ENV = 'server'
    assert CDP_CONFIG.is_server() == True
    CDP_CONFIG.DEFAULT_ENV = original_value


@patch("cdp_pycomm_lib.common.cdp_common_utils.read_config_file")
def test_reset_act_correctly(mock_read_config_file):
    mock_read_config_file.return_value = {"param1": {"subparam": "value"}}
    CDP_CONFIG.reset_config("test_file")
    assert CDP_CONFIG.get_config('param1.subparam') == 'value'
    mock_read_config_file.assert_called_once_with("test_file")


@patch("cdp_pycomm_lib.common.cdp_common_utils.read_config_file_in_package")
@patch("cdp_pycomm_lib.common.cdp_common_utils.read_config_file")
def test_app_config_init_on_desk(mock_read_config_file, mock_read_config_file_in_package):
    mock_read_config_file.return_value = {"param1": {"subparam": "value"}}
    mock_read_config_file_in_package.return_value = {"param2": {"subparam": "value"}}

    app_config = AppConfig()
    assert app_config.get_config('param2.subparam') == 'value'
    mock_read_config_file_in_package.assert_called_once_with(config, 'local_test.json')
    mock_read_config_file.assert_called_once_with("/lseg/python/pytha_run_configs.json")


@patch("cdp_pycomm_lib.common.cdp_common_utils.read_config_file_in_package")
@patch("cdp_pycomm_lib.common.cdp_common_utils.read_config_file")
@patch.object(AppConfig, 'is_server')
def test_app_config_init_on_servers(mock_is_server, mock_read_config_file, mock_read_config_file_in_package):
    mock_read_config_file.return_value = {"param1": {"subparam": "value"}}
    mock_read_config_file_in_package.return_value = {"param2": {"subparam": "value"}}
    mock_is_server.return_value = True

    app_config = AppConfig()
    assert app_config.get_config('param2.subparam') == 'value'
    mock_read_config_file_in_package.assert_called_once_with(config, 'local_test.json')
    mock_read_config_file.assert_called_once_with(
        "/Volumes/cdp_local_test_catalog_01/platform/platform/config/config.json"
    )


@patch("cdp_pycomm_lib.common.cdp_common_utils.today")
@patch("cdp_pycomm_lib.common.cdp_common_utils.guid")
def test_model_run_config_initializes_with_default_values(mock_guid, mock_today):
    mock_guid.return_value = "test-guid"
    today_datetime = datetime(2023, 1, 1)
    mock_today.return_value = today_datetime

    model_run_config = ModelRunConfig()
    assert model_run_config.model_name == 'Pytharun'
    assert model_run_config.model_run.startswith("cdp_pycomm_lib.")
    assert model_run_config.run_datetime == today_datetime
    assert model_run_config.caller_guid == "test-guid"
    assert len(model_run_config.pid) == 2


@patch("os.getenv")
def test_model_run_config_get_user(mock_getenv):
    mock_getenv.side_effect = lambda key, default: "server_test" if key == "USERNAME" else default
    assert CDP_MODEL.get_user() == "server_test"


def test_string_representation():
    model_run_config = ModelRunConfig("test_run")
    assert "test_run" in str(model_run_config)
    assert "test_run" in repr(model_run_config)
    assert "caller_guid" in repr(model_run_config)
    assert "run_datetime" in repr(model_run_config)
