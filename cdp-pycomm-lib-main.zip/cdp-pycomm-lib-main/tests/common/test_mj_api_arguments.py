import pytest

from cdp_pycomm_lib.common.cdp_error import MetaError
from cdp_pycomm_lib.common.cdp_object import (
    valid_tuple,
    valid_detail,
    valid_begin_end,
    valid_parentheses_operators,
    valid_str,
    valid_not_empty,
    validate_operator,
    validate_function,
    extract_function,
    MjApiArguments,
    parse_meta_item,
    parse_meta
)


def test_valid_tuple_with_valid_input():
    try:
        valid_tuple(('', ('attribute', 'verb', 'value', 'function'), ''))
    except MetaError:
        pytest.fail("MetaError should not be raised")


def test_valid_tuple_with_none_input():
    with pytest.raises(MetaError) as context:
        valid_tuple(None)
    assert context.value.error_str == "meta should not be None!!!"


def test_valid_tuple_with_non_tuple_input():
    with pytest.raises(MetaError) as context:
        valid_tuple(['not', 'a', 'tuple'])
    assert context.value.error_str == "meta should be tuple!!!"


def test_valid_tuple_with_less_than_three_items():
    with pytest.raises(MetaError) as context:
        valid_tuple(('only', 'two'))
    assert context.value.error_str == "meta should have at least 3 items: ('only', 'two')"


def test_valid_tuple_with_even_number_of_items():
    with pytest.raises(MetaError) as context:
        valid_tuple(('', ('attribute', 'verb', 'value', 'function'), ('attribute', 'verb', 'value'), ''))
    expected_msg = "meta should have odd number of items: ('', ('attribute', 'verb', 'value', 'function'), ('attribute', 'verb', 'value'), '')"
    assert context.value.error_str == expected_msg


def test_valid_detail_with_valid_input():
    try:
        valid_detail(('attribute', 'verb', 'value', 'function'))
    except MetaError:
        pytest.fail("MetaError should not be raised")


def test_valid_detail_with_non_tuple_input():
    with pytest.raises(MetaError) as context:
        valid_detail(['not', 'a', 'tuple'])
    assert context.value.error_str == "meta Detail is not tuple: ['not', 'a', 'tuple']"


def test_valid_detail_with_less_than_three_items():
    with pytest.raises(MetaError) as context:
        valid_detail(('only', 'two'))
    assert context.value.error_str == "meta Detail should have 3 or 4 items: ('only', 'two')"


def test_valid_detail_with_more_than_four_items():
    with pytest.raises(MetaError) as context:
        valid_detail(('one', 'two', 'three', 'four', 'five'))
    expected_msg = "meta Detail should have 3 or 4 items: ('one', 'two', 'three', 'four', 'five')"
    assert context.value.error_str == expected_msg


def test_valid_begin_with_blank():
    try:
        valid_begin_end('', 'BEGIN')
    except MetaError:
        pytest.fail("MetaError should not be raised")


def test_valid_begin_with_parenthesis():
    try:
        valid_begin_end('(', 'BEGIN')
    except MetaError:
        pytest.fail("MetaError should not be raised")


def test_valid_begin_invalid_begin():
    with pytest.raises(MetaError) as context:
        valid_begin_end('invalid', 'BEGIN')
    assert context.value.error_str == 'meta is not start with blank'


def test_valid_end_with_blank():
    try:
        valid_begin_end('', 'END')
    except MetaError:
        pytest.fail("MetaError should not be raised")


def test_valid_end_with_parenthesis():
    try:
        valid_begin_end(')', 'END')
    except MetaError:
        pytest.fail("MetaError should not be raised")


def test_invalid_end():
    with pytest.raises(MetaError) as context:
        valid_begin_end('invalid', 'END')
    assert context.value.error_str == "Operators is not match with Details"


def test_valid_parentheses():
    try:
        valid_parentheses_operators(0)
    except MetaError:
        pytest.fail("MetaError should not be raised")


def test_invalid_parentheses():
    with pytest.raises(MetaError) as context:
        valid_parentheses_operators(1)
    assert context.value.error_str == 'Parentheses is not enclosed'


def test_valid_str():
    try:
        valid_str('test_type', 'test_value')
    except MetaError:
        pytest.fail("MetaError should not be raised")


def test_invalid_str():
    with pytest.raises(MetaError) as context:
        valid_str('test_type', 123)
    assert context.value.error_str == 'value 123 should be string, required by type of test_type'


def test_valid_not_empty():
    try:
        valid_not_empty('test_type', 'test_value')
    except MetaError:
        pytest.fail("MetaError should not be raised")


def test_invalid_not_empty():
    with pytest.raises(MetaError) as context:
        valid_not_empty('test_type', '')
    assert context.value.error_str == 'value should not be empty, required by type of test_type'


def test_valid_operator():
    try:
        validate_operator('INTERSECT')
    except MetaError:
        pytest.fail("MetaError should not be raised")


def test_invalid_operator():
    with pytest.raises(MetaError) as context:
        validate_operator('INVALID')
    assert context.value.error_str == 'value INVALID should be valid operator'


def test_valid_function():
    try:
        validate_function('GETCHILDREN')
    except MetaError:
        pytest.fail("MetaError should not be raised")


def test_invalid_function():
    with pytest.raises(MetaError) as context:
        validate_function('INVALID')
    assert context.value.error_str == 'value INVALID should be valid function'


def test_extract_function_name_with_valid_input():
    function_name, function_args = extract_function('getChildren(Nation, City)')
    assert function_name == 'GETCHILDREN'
    assert function_args == ['Nation', 'City']


def test_extract_function_name_with_no_arguments():
    function_name, function_args = extract_function('getChildren()')
    assert function_name == 'GETCHILDREN'
    assert function_args == []


def test_extract_function_name_with_spaces():
    function_name, function_args = extract_function('  getChildren  (  Nation  ,  City  )  ')
    assert function_name == 'GETCHILDREN'
    assert function_args == ['Nation', 'City']


def test_extract_function_name_with_empty_string():
    function_name, function_args = extract_function(' ')
    assert function_name == ''
    assert function_args == []


def test_extract_function_name_with_invalid_format():
    with pytest.raises(MetaError): extract_function('invalid_format')
    with pytest.raises(MetaError): extract_function('invalid_format(')
    with pytest.raises(MetaError): extract_function('invalid_format)')
    with pytest.raises(MetaError): extract_function('invalid_format((')
    with pytest.raises(MetaError): extract_function('invalid_format())')
    with pytest.raises(MetaError): extract_function('invalid_format())')
    with pytest.raises(MetaError): extract_function('(invalid_format)')
    with pytest.raises(MetaError): extract_function('invalid_(form)at')


def test_item_with_valid_input():
    api_arg = MjApiArguments.empty_one()
    meta_item = ('attribute', 'is', 'value', 'getChildren(Nation, City)')
    parse_meta_item(api_arg, meta_item)
    assert api_arg.attribute == 'attribute'
    assert api_arg.verbs == ['is']
    assert api_arg.values == ['value']
    assert api_arg.function == 'GETCHILDREN'
    assert api_arg.function_args == ['Nation', 'City']


def test_item_with_missing_function():
    api_arg = MjApiArguments.empty_one()
    meta_item = ('attribute', 'is', 'value')
    parse_meta_item(api_arg, meta_item)
    assert api_arg.attribute == 'attribute'
    assert api_arg.verbs == ['is']
    assert api_arg.values == ['value']
    assert api_arg.function == ''
    assert api_arg.function_args == []


def test_parse_meta_with_valid_input():
    meta_tuple = ('', ('Var', 'from', 'CON', 'getChildren(Nation, City)'), 'intersect', ('Com', '', 'Pwr'), '')
    result = parse_meta(meta_tuple)
    assert len(result) == 2
    assert result[0].attribute == 'Var'
    assert result[0].verbs == ['from']
    assert result[0].values == ['CON']
    assert result[0].operator == ''
    assert result[0].function == 'GETCHILDREN'
    assert result[0].function_args == ['Nation', 'City']
    assert result[1].attribute == 'Com'
    assert result[1].verbs == ['is']
    assert result[1].values == ['Pwr']
    assert result[1].function == ''
    assert result[1].function_args == []
    assert result[1].operator == 'INTERSECT'


def test_parse_meta_with_valid_input_brackets():
    meta_tuple = ('(', ('Var', 'from', 'CON', 'getChildren(Nation, City)'), ')')
    result = parse_meta(meta_tuple)
    assert len(result) == 2
    assert result[0].attribute == 'Var'
    assert result[0].verbs == ['from']
    assert result[0].values == ['CON']
    assert result[0].operator == '('
    assert result[0].function == 'GETCHILDREN'
    assert result[0].function_args == ['Nation', 'City']
    assert result[1].attribute == ''
    assert result[1].verbs == []
    assert result[1].values == []
    assert result[1].function == ''
    assert result[1].function_args == []
    assert result[1].operator == ')'


def test_parse_meta_with_invalid_meta_tuple():
    meta_tuple = ['not', 'a', 'tuple']
    with pytest.raises(MetaError):
        parse_meta(meta_tuple)


def test_parse_meta_with_invalid_end():
    meta_tuple = (
        '', ('Var', 'is', 'CON', 'getChildren(Nation, City)'), 'intersect', ('Com', '', 'Pwr', ''), 'invalid'
    )
    with pytest.raises(MetaError):
        parse_meta(meta_tuple)


def test_parse_meta_with_unenclosed_parentheses():
    meta_tuple = ('(', ('Var', 'is', 'CON', 'getChildren(Nation, City)'), 'intersect', ('Com', '', 'Pwr', ''), '')
    with pytest.raises(MetaError):
        parse_meta(meta_tuple)


def test_empty_one_creates_empty_instance():
    api_arg = MjApiArguments.empty_one()
    assert api_arg.operator == ''
    assert api_arg.attribute == ''
    assert api_arg.verbs == []
    assert api_arg.values == []
    assert api_arg.function == ''
    assert api_arg.function_args == []


def test_set_attribute_sets_valid_attribute():
    api_arg = MjApiArguments.empty_one()
    api_arg.set_attribute('attribute')
    assert api_arg.attribute == 'attribute'


def test_set_attribute_raises_error_on_invalid_attribute():
    api_arg = MjApiArguments.empty_one()
    with pytest.raises(MetaError):
        api_arg.set_attribute('')


def test_append_verbs_a_verb():
    api_arg = MjApiArguments.empty_one()
    api_arg.append_verbs('is')
    assert api_arg.verbs == ['is']


def test_append_verbs_verbs():
    api_arg = MjApiArguments.empty_one()
    api_arg.append_verbs(('is', 'from'))
    assert api_arg.verbs == ['is', 'from']


def test_append_verbs_empty_verb():
    api_arg = MjApiArguments.empty_one()
    api_arg.append_verbs('   ')
    assert api_arg.verbs == ['is']


def test_append_verbs_invalid():
    api_arg = MjApiArguments.empty_one()
    with pytest.raises(MetaError):
        api_arg.append_verbs(345)


def test_append_values_a_value():
    api_arg = MjApiArguments.empty_one()
    api_arg.append_values('value')
    assert api_arg.values == ['value']


def test_append_values_values():
    api_arg = MjApiArguments.empty_one()
    api_arg.append_values(('value1', 'value2'))
    assert api_arg.values == ['value1', 'value2']


def test_append_values_raises_error_on_invalid_values():
    api_arg = MjApiArguments.empty_one()
    with pytest.raises(MetaError):
        api_arg.append_values('         ')
    with pytest.raises(MetaError):
        api_arg.append_values(345)


def test_set_function_valid_function():
    api_arg = MjApiArguments.empty_one()
    api_arg.set_function('getChildren(Nation, City)')
    assert api_arg.function == 'GETCHILDREN'
    assert api_arg.function_args == ['Nation', 'City']


def test_set_function_raises_error_on_invalid_function():
    api_arg = MjApiArguments.empty_one()
    with pytest.raises(MetaError):
        api_arg.set_function('invalidFunction')


def test_set_operation_sets_valid_operation():
    api_arg = MjApiArguments.empty_one()
    api_arg.set_operation('(intersect')
    assert api_arg.operator == '(INTERSECT'
    api_arg.set_operation('')
    assert api_arg.operator == 'INTERSECT'


def test_set_operation_raises_error_on_invalid_operation():
    api_arg = MjApiArguments.empty_one()
    with pytest.raises(MetaError):
        api_arg.set_operation('invalidOperation')
