from unittest.mock import MagicMock, patch

import pytest
from pyspark.sql import SparkSession

from cdp_pycomm_lib.common.spark_wrapper import SparkWrapper


@pytest.fixture(scope='function')
def mock_spark():
    return MagicMock()


@pytest.fixture(scope='class')
def spark_wrapper():
    return SparkWrapper()


def test_table(spark_wrapper, mock_spark):
    mock_df = MagicMock()
    mock_spark.table.return_value = mock_df
    spark_wrapper.set_spark(mock_spark)
    result = spark_wrapper.table('table_name')
    assert result == mock_df
    mock_spark.table.assert_called_once_with('table_name')


def test_create_data_frame(spark_wrapper, mock_spark):
    mock_df = MagicMock()
    mock_spark.createDataFrame.return_value = mock_df
    spark_wrapper.set_spark(mock_spark)
    data = [('a', 1), ('b', 2)]
    schema = 'col1 STRING, col2 INT'
    result = spark_wrapper.create_data_frame(data, schema)
    assert result == mock_df
    mock_spark.createDataFrame.assert_called_once_with(data, schema)


def test_sql(spark_wrapper, mock_spark):
    mock_df = MagicMock()
    mock_spark.sql.return_value = mock_df
    spark_wrapper.set_spark(mock_spark)
    sql_query = 'SELECT * FROM table_name'
    result = spark_wrapper.sql(sql_query)
    assert result == mock_df
    mock_spark.sql.assert_called_once_with(sql_query)


def test_start_transaction(spark_wrapper, mock_spark):
    spark_wrapper.set_spark(mock_spark)
    spark_wrapper.start_transaction()
    mock_spark.sql.assert_called_once_with("START TRANSACTION")


def test_commit_transaction(spark_wrapper, mock_spark):
    spark_wrapper.set_spark(mock_spark)
    spark_wrapper.commit_transaction()
    mock_spark.sql.assert_called_once_with("COMMIT")


def test_rollback_transaction(spark_wrapper, mock_spark):
    spark_wrapper.set_spark(mock_spark)
    spark_wrapper.rollback_transaction()
    mock_spark.sql.assert_called_once_with("ROLLBACK")


@patch("cdp_pycomm_lib.common.spark_wrapper.DeltaTable")
def test_retrieves_delta_table_by_name(mock_delta_table):
    mock_delta_instance = MagicMock()
    mock_delta_table.forName.return_value = mock_delta_instance

    spark_wrapper = SparkWrapper()
    mock_spark_session = MagicMock(spec=SparkSession)
    spark_wrapper.set_spark(mock_spark_session)

    result = spark_wrapper.delta_table("test_table")
    assert result == mock_delta_instance
    mock_delta_table.forName.assert_called_once_with(mock_spark_session, "test_table")


@patch("cdp_pycomm_lib.common.spark_wrapper.DeltaTable")
def test_raises_error_when_delta_table_not_found(mock_delta_table):
    mock_delta_table.forName.side_effect = Exception("Table not found")

    spark_wrapper = SparkWrapper()
    mock_spark_session = MagicMock(spec=SparkSession)
    spark_wrapper.set_spark(mock_spark_session)

    with pytest.raises(Exception, match="Table not found"):
        spark_wrapper.delta_table("non_existent_table")
    mock_delta_table.forName.assert_called_once_with(mock_spark_session, "non_existent_table")
