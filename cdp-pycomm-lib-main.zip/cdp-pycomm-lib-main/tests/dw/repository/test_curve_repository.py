import pytest
from pyspark import Row

from cdp_pycomm_lib.dw.repository.curve_repositories import CurveRepository
from tests.util import spark_fixture, create_spark_wrapper_mock


@pytest.fixture(scope='class')
def curve_repository(spark_fixture):
    data = [
        Row(ID=1, NAME='Curve A'),
        Row(ID=2, NAME='Curve B'),
        Row(ID=3, NAME='Curve C'),
        Row(ID=4, NAME='Duplicate Name'),
        Row(ID=5, NAME='Duplicate Name'),
    ]
    spark_wrapper_mock = create_spark_wrapper_mock(spark_fixture, data)
    yield CurveRepository(spark_wrapper_mock, 'cdb')


def test_returns_id_and_name_for_valid_ids(curve_repository):
    act_result = curve_repository.get_by_ids([1, 2]).collect()
    assert len(act_result) == 2
    assert act_result[0]['NAME'] == 'Curve A'
    assert act_result[1]['NAME'] == 'Curve B'


def test_returns_empty_for_nonexistent_ids(curve_repository):
    act_result = curve_repository.get_by_ids([999]).collect()
    assert len(act_result) == 0


def test_returns_curves_matching_partial_names(curve_repository):
    act_result = curve_repository.get_by_partial_names(['Curve', 'Name']).collect()
    act_result_ids = [row['ID'] for row in act_result]
    assert len(act_result_ids) == 5
    assert sorted(act_result_ids) == [1, 2, 3, 4, 5]


def test_returns_empty_when_no_partial_name_matches(curve_repository):
    act_result = curve_repository.get_by_partial_names(['Nonexistent']).collect()
    assert len(act_result) == 0


def test_handles_whitespace_and_case_in_partial_names(curve_repository):
    act_result = curve_repository.get_by_partial_names(['  curve a  ', 'NAME']).collect()
    assert len(act_result) > 0
    assert any(row['NAME'] == 'Curve A' for row in act_result)
    assert any(row['NAME'] == 'Duplicate Name' for row in act_result)


def test_returns_curves_matching_exact_names(curve_repository):
    act_result = curve_repository.get_by_names(['Curve A', 'Curve B']).collect()
    expected_result = [Row(ID=1, NAME='Curve A'), Row(ID=2, NAME='Curve B')]
    assert sorted(act_result, key=lambda x: x['ID']) == sorted(expected_result, key=lambda x: x['ID'])


def test_returns_empty_when_no_name_matches(curve_repository):
    act_result = curve_repository.get_by_names(['Nonexistent Curve']).collect()
    assert act_result == []


def test_handles_whitespace_in_curve_names(curve_repository):
    act_result = curve_repository.get_by_names(['  Curve A  ', 'Curve B']).collect()
    expected_result = [Row(ID=1, NAME='Curve A'), Row(ID=2, NAME='Curve B')]
    assert sorted(act_result, key=lambda x: x['ID']) == sorted(expected_result, key=lambda x: x['ID'])


def test_handles_case_insensitivity_in_curve_names(curve_repository):
    act_result = curve_repository.get_by_names(['curve a', 'CURVE B']).collect()
    assert act_result == []
