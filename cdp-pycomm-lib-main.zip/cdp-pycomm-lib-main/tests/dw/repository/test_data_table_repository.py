import pytest
from pyspark import Row

from cdp_pycomm_lib.dw.repository.curve_repositories import DataTableRepository
from tests.util import spark_fixture, create_spark_wrapper_mock


@pytest.fixture(scope='class')
def data_table_repository(spark_fixture):
    data = [
        Row(ID=1, TABLE_NAME='Table A'),
        Row(ID=2, TABLE_NAME='Table B'),
        Row(ID=3, TABLE_NAME='Table C'),
        Row(ID=4, TABLE_NAME='Duplicate Table'),
        Row(ID=5, TABLE_NAME='Duplicate Table'),
    ]
    spark_wrapper_mock = create_spark_wrapper_mock(spark_fixture, data)
    yield DataTableRepository(spark_wrapper_mock, 'cdb')


def test_returns_table_names_for_valid_ids(data_table_repository):
    act_result = data_table_repository.get_table_names([1, 2])
    assert act_result == ['Table A', 'Table B']


def test_returns_empty_for_nonexistent_ids(data_table_repository):
    act_result = data_table_repository.get_table_names([999])
    assert act_result == []


def test_handles_empty_id_list(data_table_repository):
    act_result = data_table_repository.get_table_names([])
    assert act_result == []


def test_returns_distinct_table_names(data_table_repository):
    act_result = data_table_repository.get_table_names([4, 5])
    assert act_result == ['Duplicate Table']
