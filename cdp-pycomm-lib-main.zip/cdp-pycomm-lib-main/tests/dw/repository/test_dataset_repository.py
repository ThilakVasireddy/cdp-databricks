import pytest
from pyspark import Row

from cdp_pycomm_lib.dw.repository.dataset_repository import DatasetRepository
from tests.util import spark_fixture, create_spark_wrapper_mock


@pytest.fixture(scope='class')
def dataset_repository(spark_fixture):
    data = [
        Row(ID=1, SET_TYPE_ID=1, NAME='Dataset A'),
        Row(ID=2, SET_TYPE_ID=2, NAME='Dataset B'),
        Row(ID=3, SET_TYPE_ID=1, NAME='Dataset C'),
    ]
    spark_wrapper_mock = create_spark_wrapper_mock(spark_fixture, data)
    yield DatasetRepository(spark_wrapper_mock, 'cdb')


def test_returns_filtered_datasets_for_set_type(dataset_repository):
    act_result = dataset_repository.get_df_for_load_set().collect()
    assert len(act_result) == 2
    assert act_result[0]['NAME'] == 'Dataset A'
    assert act_result[1]['NAME'] == 'Dataset C'
