import pytest
from pyspark.sql import Row

from cdp_pycomm_lib.dw.repository.curve_repositories import LoadSet2CurveRepository
from tests.util import spark_fixture, create_spark_wrapper_mock


@pytest.fixture(scope='class')
def loadset2curve_repository(spark_fixture):
    data = [
        Row(LOAD_SET_ID=101, CURVE_ID=1),
        Row(LOAD_SET_ID=102, CURVE_ID=2),
        Row(LOAD_SET_ID=103, CURVE_ID=3),
    ]
    spark_wrapper_mock = create_spark_wrapper_mock(spark_fixture, data)
    yield LoadSet2CurveRepository(spark_wrapper_mock, 'cdb')


def test_returns_loadset_for_valid_curve_ids(loadset2curve_repository):
    act_result = loadset2curve_repository.get_by_curve_ids([1, 2]).collect()
    assert len(act_result) == 2
    assert act_result[0]['LOAD_SET_ID'] == 101
    assert act_result[1]['LOAD_SET_ID'] == 102


def test_returns_empty_for_nonexistent_curve_ids(loadset2curve_repository):
    act_result = loadset2curve_repository.get_by_curve_ids([999]).collect()
    assert len(act_result) == 0
