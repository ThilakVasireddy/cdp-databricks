from unittest.mock import patch, MagicMock

from pyspark.sql import Row, DataFrame

from cdp_pycomm_lib.dw import curve_services
from tests.util import spark_fixture


@patch("cdp_pycomm_lib.dw.curve_services.curve_repository.get_by_ids")
def test_get_curve_returns_correct_data(mock_get_by_ids):
    mock_df = MagicMock(spec=DataFrame)
    mock_get_by_ids.return_value = mock_df
    result = curve_services.get_curve([1, 2])
    assert result == mock_df
    mock_get_by_ids.assert_called_once_with([1, 2])


@patch("cdp_pycomm_lib.dw.curve_services.load_set2_curve_repository.get_by_curve_ids")
@patch("cdp_pycomm_lib.dw.curve_services.dataset_repository.get_df_for_load_set")
def test_get_loadset_for_curve_by_id_returns_correct_data(
        mock_get_df_for_load_set, mock_get_by_curve_ids, spark_fixture
):
    mock_get_by_curve_ids.return_value = spark_fixture.createDataFrame(
        [Row(CURVE_ID=1, LOAD_SET_ID=10), Row(CURVE_ID=2, LOAD_SET_ID=20)]
    )
    mock_get_df_for_load_set.return_value = spark_fixture.createDataFrame([
        Row(ID=10, NAME="LoadSet A"),
        Row(ID=10, NAME="LoadSet A"),
        Row(ID=20, NAME="LoadSet B"),
        Row(ID=30, NAME="LoadSet C")
    ])
    result = curve_services.get_loadset_for_curve_by_id([1, 2]).collect()
    expected = [Row(ID=10, NAME="LoadSet A"), Row(ID=20, NAME="LoadSet B")]
    assert sorted(result, key=lambda x: x.ID) == sorted(expected, key=lambda x: x.ID)
    mock_get_by_curve_ids.assert_called_once_with([1, 2])


@patch("cdp_pycomm_lib.dw.curve_services.load_set2_curve_repository.get")
@patch("cdp_pycomm_lib.dw.curve_services.dataset_repository.get_df_for_load_set")
@patch("cdp_pycomm_lib.dw.curve_services.curve_repository.get")
@patch("cdp_pycomm_lib.dw.curve_services.CDP_SPARK.create_data_frame")
def test_get_loadset_for_curve_by_nm_returns_correct_data(
        mock_create_data_frame, mock_curve_repository, mock_dataset_repository, mock_load_set2_curve_repository,
        spark_fixture
):
    mock_load_set2_curve_repository.return_value = spark_fixture.createDataFrame(
        [Row(CURVE_ID=1, LOAD_SET_ID=10), Row(CURVE_ID=2, LOAD_SET_ID=20)]
    )
    mock_dataset_repository.return_value = spark_fixture.createDataFrame(
        [Row(ID=10, NAME="LoadSet A"), Row(ID=20, NAME="LoadSet B")]
    )
    mock_curve_repository.return_value = spark_fixture.createDataFrame(
        [Row(ID=1, NAME="Curve A"), Row(ID=2, NAME="Curve B"), Row(ID=2, NAME="Not B")]
    )
    mock_create_data_frame.return_value = spark_fixture.createDataFrame(
        [Row(c_name="%curve%")]
    )

    result = curve_services.get_loadset_for_curve_by_curve_name(["Curve"]).collect()
    expected = [Row(ID=10, NAME="LoadSet A"), Row(ID=20, NAME="LoadSet B")]
    assert sorted(result, key=lambda x: x.ID) == sorted(expected, key=lambda x: x.ID)
    mock_create_data_frame.assert_called_once_with([('%curve%',)], ['c_name'])


@patch("cdp_pycomm_lib.dw.curve_services.load_set2_curve_repository.get")
@patch("cdp_pycomm_lib.dw.curve_services.dataset_repository.get_df_for_load_set")
def test_get_curve_ids_by_load_set_names_returns_correct_data(
        mock_dataset_repository, mock_load_set2_curve_repository, spark_fixture
):
    mock_load_set2_curve_repository.return_value = spark_fixture.createDataFrame(
        [Row(ID=1, CURVE_ID=1, LOAD_SET_ID=10), Row(ID=2, CURVE_ID=2, LOAD_SET_ID=20),
         Row(ID=3, CURVE_ID=3, LOAD_SET_ID=50)]
    )
    mock_dataset_repository.return_value = spark_fixture.createDataFrame([
        Row(ID=10, NAME="LoadSet A"),
        Row(ID=20, NAME="LoadSet B"),
        Row(ID=30, NAME="LoadSet C"),
        Row(ID=40, NAME="LoadSet B")
    ])

    result = curve_services.get_curve_ids_by_load_set_names(["LoadSet A", "LoadSet B"]).collect()
    expected = [Row(OBJECT_ID=1), Row(OBJECT_ID=2)]
    assert sorted(result, key=lambda x: x.OBJECT_ID) == sorted(expected, key=lambda x: x.OBJECT_ID)
