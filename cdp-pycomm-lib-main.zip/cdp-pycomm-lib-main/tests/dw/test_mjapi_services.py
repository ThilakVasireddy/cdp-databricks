from datetime import datetime
from unittest.mock import patch, MagicMock

import pytest
from pyspark.sql import Row
from pyspark.sql.functions import col, lit
from pyspark.sql.types import StructType

from cdp_pycomm_lib.dw.mjapi_services import (
    get_curve_info,
    get_dates,
    z2z_udf,
    get_curve_data_from_one_table,
    get_data
)
from tests.util import spark_fixture


@patch("cdp_pycomm_lib.dw.mjapi_services.curve_repository.get_by_partial_names")
@patch("cdp_pycomm_lib.dw.mjapi_services.curve_repository.get_by_names")
def test_returns_curve_info_for_exact_match(mock_get_by_names, mock_get_by_partial_names, spark_fixture):
    mock_get_by_names.return_value = spark_fixture.createDataFrame(
        [Row(ID=1, DATA_TABLE_ID=10, NAME="Curve A"), Row(ID=2, DATA_TABLE_ID=20, NAME="Curve B")]
    )
    curve_ids, data_table_ids, curve_id_name_map = get_curve_info(["Curve A", "Curve B"], partial_match=False)
    assert sorted(curve_ids) == [1, 2]
    assert sorted(data_table_ids) == [10, 20]
    assert curve_id_name_map == {1: "Curve A", 2: "Curve B"}
    mock_get_by_partial_names.assert_not_called()


@patch("cdp_pycomm_lib.dw.mjapi_services.curve_repository.get_by_partial_names")
@patch("cdp_pycomm_lib.dw.mjapi_services.curve_repository.get_by_names")
def test_returns_curve_info_for_partial_match(mock_get_by_names, mock_get_by_partial_names, spark_fixture):
    mock_get_by_partial_names.return_value = spark_fixture.createDataFrame(
        [Row(ID=3, DATA_TABLE_ID=30, NAME="Curve C"), Row(ID=4, DATA_TABLE_ID=40, NAME="Curve D")]
    )
    curve_ids, data_table_ids, curve_id_name_map = get_curve_info(["Curve"], partial_match=True)
    assert sorted(curve_ids) == [3, 4]
    assert sorted(data_table_ids) == [30, 40]
    assert curve_id_name_map == {3: "Curve C", 4: "Curve D"}
    mock_get_by_names.assert_not_called()


@patch("cdp_pycomm_lib.dw.mjapi_services.curve_repository.get_by_names")
def test_handles_no_matching_curves(mock_get_by_names, spark_fixture):
    mock_get_by_names.return_value = spark_fixture.createDataFrame([], StructType([]))
    curve_ids, data_table_ids, curve_id_name_map = get_curve_info(["Nonexistent Curve"], partial_match=False)
    assert curve_ids == []
    assert data_table_ids == []
    assert curve_id_name_map == {}


@pytest.mark.parametrize(
    "timezone, expected_f_date_from, expected_f_date_to, expected_v_date_from, expected_v_date_to",
    [
        ("UTC", "2023-01-01 00:00:00", "2023-12-31 00:00:00", "2023-01-01 00:00:00", "2023-12-31 00:00:00"),
        ("America/New_York", "2023-01-01 05:00:00", "2023-12-31 05:00:00", "2023-01-01 05:00:00",
         "2023-12-31 05:00:00"),
        (None, "2023-01-01 00:00:00", "2023-12-31 00:00:00", "2023-01-01 00:00:00", "2023-12-31 00:00:00"),
    ])
@patch("cdp_pycomm_lib.dw.mjapi_services.timezone_services.change_timezone")
def test_returns_correct_dates_with_timezone(
        mock_change_timezone,
        timezone, expected_f_date_from, expected_f_date_to, expected_v_date_from, expected_v_date_to
):
    mock_change_timezone.side_effect = lambda date, tz_in, tz_out: date.replace(
        hour=date.hour + 5) if tz_in != tz_out else date
    f_date_from, f_date_to, v_date_from, v_date_to = get_dates(
        datetime(2023, 1, 1), datetime(2023, 12, 31), datetime(2023, 1, 1), datetime(2023, 12, 31), timezone
    )
    assert f_date_from == expected_f_date_from
    assert f_date_to == expected_f_date_to
    assert v_date_from == expected_v_date_from
    assert v_date_to == expected_v_date_to


def test_handles_null_dates():
    f_date_from, f_date_to, v_date_from, v_date_to = get_dates(
        None, None, None, None, None
    )
    assert "1-01-01 00:00:00" in f_date_from
    assert f_date_to == "4444-12-31 00:00:00"
    assert "1-01-01 00:00:00" in v_date_from
    assert v_date_to == "4444-12-31 00:00:00"


@patch("cdp_pycomm_lib.dw.mjapi_services.timezone_services")
def test_converts_timezone_correctly(mock_timezone_services, spark_fixture):
    mock_timezone_services.change_timezone.side_effect = lambda date, tz_in, tz_out: date.replace(
        hour=date.hour + 5) if tz_in != tz_out else date
    df = spark_fixture.createDataFrame([Row(FORECAST_DATE=datetime(2023, 1, 1, 0, 0))])
    result_df = df.withColumn(
        'FORECAST_DATE', z2z_udf(col('FORECAST_DATE'), lit("UTC"), lit("America/New_York"))
    )
    assert result_df.first().FORECAST_DATE.hour == 5


@patch("cdp_pycomm_lib.dw.mjapi_services.create_curve_data_repository")
def test_filters_data_by_date_and_curve_ids(mock_create_curve_data_repository, spark_fixture):
    mock_repository = MagicMock()
    mock_create_curve_data_repository.return_value = mock_repository
    mock_repository.get.return_value = spark_fixture.createDataFrame([
        create_curve_data_row(1, "2023-01-01 12:00:00", "2023-01-02 12:00:00", 100, "2023-01-03 11:00:00"),
        create_curve_data_row(1, "2022-01-01 12:00:00", "2023-01-02 12:00:00", 200, "2023-01-03 11:00:00"),
        create_curve_data_row(1, "2024-01-01 12:00:00", "2023-01-02 12:00:00", 300, "2023-01-03 11:00:00"),
        create_curve_data_row(1, "2023-01-01 12:00:00", "2022-01-02 12:00:00", 400, "2023-01-03 11:00:00"),
        create_curve_data_row(1, "2023-01-01 12:00:00", "2024-01-02 12:00:00", 500, "2023-01-03 11:00:00"),
        create_curve_data_row(2, "2023-01-01 12:00:00", "2023-01-02 12:00:00", 600, "2023-01-03 11:00:00"),
    ])
    result_df = get_curve_data_from_one_table(
        "test_table", [1], "2023-01-01 00:00:00", "2023-01-01 23:59:59", "2023-01-02 00:00:00", "2023-01-02 23:59:59",
        "UTC"
    )
    assert result_df.count() == 1
    assert result_df.first().CURVE_ID == 1


def create_curve_data_row(curve_id, forecast_date, value_date, value, changed_date):
    return Row(
        CURVE_ID=curve_id,
        FORECAST_DATE=str_to_date(forecast_date),
        VALUE_DATE=str_to_date(value_date),
        VALUE=value,
        CHANGED_DATE=str_to_date(changed_date)
    )


def str_to_date(date_str):
    return datetime.strptime(date_str, '%Y-%m-%d %H:%M:%S')


@patch("cdp_pycomm_lib.dw.mjapi_services.create_curve_data_repository")
@patch("cdp_pycomm_lib.dw.mjapi_services.timezone_services")
def test_applies_timezone_conversion(mock_timezone_services, mock_create_curve_data_repository, spark_fixture):
    mock_timezone_services.change_timezone.side_effect = lambda date, tz_in, tz_out: date.replace(
        hour=date.hour + 5)
    mock_repository = MagicMock()
    mock_create_curve_data_repository.return_value = mock_repository
    mock_repository.get.return_value = spark_fixture.createDataFrame([
        create_curve_data_row(1, "2023-01-01 12:00:00", "2023-01-02 12:00:00", 100, "2023-01-03 12:00:00")
    ])
    result_df = get_curve_data_from_one_table(
        "test_table", [1], "2023-01-01 00:00:00", "2023-01-01 23:59:59", "2023-01-02 00:00:00", "2023-01-02 23:59:59",
        "America/New_York"
    )
    assert result_df.first().FORECAST_DATE is not None


@patch("cdp_pycomm_lib.dw.mjapi_services.create_curve_data_repository")
def test_handles_no_matching_data(mock_create_curve_data_repository, spark_fixture):
    mock_repository = MagicMock()
    mock_create_curve_data_repository.return_value = mock_repository
    mock_repository.get.return_value = spark_fixture.createDataFrame([
        create_curve_data_row(1, "2023-01-01 12:00:00", "2023-01-02 12:00:00", 100, "2023-01-03 12:00:00")
    ])
    result_df = get_curve_data_from_one_table(
        "test_table", [2], "2023-01-01 00:00:00", "2023-01-01 23:59:59", "2023-01-02 00:00:00", "2023-01-02 23:59:59",
        "UTC"
    )
    assert result_df.count() == 0


@patch("cdp_pycomm_lib.dw.mjapi_services.data_table_repository.get_table_names")
@patch("cdp_pycomm_lib.dw.mjapi_services.get_curve_info")
@patch("cdp_pycomm_lib.dw.mjapi_services.get_curve_data_from_one_table")
def test_returns_combined_dataframe(
        mock_get_curve_data, mock_get_curve_info, mock_get_table_names, spark_fixture
):
    mock_get_curve_info.return_value = ([1, 2], [10, 20], {1: "Curve1", 2: "Curve2"})
    mock_df1 = spark_fixture.createDataFrame([
        create_curve_data_row(1, "2023-01-04 12:00:00", "2023-01-04 12:00:00", 100, "2023-01-01 12:00:00")
    ])
    mock_df2 = spark_fixture.createDataFrame([
        create_curve_data_row(2, "2023-01-02 12:00:00", "2023-01-02 12:00:00", 200, "2023-01-02 12:00:00")
    ])
    mock_get_curve_data.side_effect = [mock_df1, mock_df2]
    mock_get_table_names.return_value = ["table1", "table2"]

    result_df = get_data(
        ["Curve1", "Curve2"],
        datetime(2023, 1, 1),
        datetime(2023, 12, 31),
        datetime(2023, 1, 1),
        datetime(2023, 12, 31),
        "UTC",
        "UTC",
        False
    )
    assert result_df.count() == 2
    assert result_df.columns == ["CURVE_ID", "FORECAST_DATE", "VALUE_DATE", "VALUE", "CHANGED_DATE", "CURVE_NAME"]
    assert set(row.CURVE_ID for row in result_df.collect()) == {1, 2}


@patch("cdp_pycomm_lib.dw.mjapi_services.data_table_repository.get_table_names")
@patch("cdp_pycomm_lib.dw.mjapi_services.get_curve_info")
def test_returns_none_when_table_names_not_found(
        mock_get_curve_info, mock_get_table_names, spark_fixture
):
    mock_get_curve_info.return_value = ([1, 2], [10, 20], {1: "Curve1", 2: "Curve2"})
    mock_get_table_names.return_value = []

    result_df = get_data(
        ["Curve1", "Curve2"],
        datetime(2023, 1, 1),
        datetime(2023, 12, 31),
        datetime(2023, 1, 1),
        datetime(2023, 12, 31),
        "UTC",
        "UTC",
        False
    )
    assert result_df is None
