from datetime import datetime

import pytest

from cdp_pycomm_lib.dw.timezone_services import change_timezone


def test_change_timezone_returns_correct_new_timezone():
    old_date = datetime(2023, 10, 31, 12, 0, 0)
    old_timezone = 'America/New_York'
    new_timezone = 'Europe/London'
    result = change_timezone(old_date, old_timezone, new_timezone)
    expected = datetime(2023, 10, 31, 16, 0, 0)
    assert result == expected


def test_change_timezone_returns_same_date_for_same_timezone():
    old_date = datetime(2023, 10, 31, 12, 0, 0)
    old_timezone = 'America/New_York'
    new_timezone = 'America/New_York'
    result = change_timezone(old_date, old_timezone, new_timezone)
    expected = old_date
    assert result == expected


def test_change_timezone_raises_error_for_invalid_timezone():
    old_date = datetime(2023, 10, 31, 12, 0, 0)
    old_timezone = 'Invalid/Timezone'
    new_timezone = 'Europe/London'
    with pytest.raises(ValueError):
        change_timezone(old_date, old_timezone, new_timezone)
