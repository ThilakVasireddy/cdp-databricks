import pytest

from cdp_pycomm_lib.dw_writer.chain.chain_configs import CDP_CHAIN_CONFIGS
from cdp_pycomm_lib.dw_writer.dw_objects import ChainConfig


def test_initializes_chain_configs():
    assert len(CDP_CHAIN_CONFIGS.chain_id_map) > 0
    assert len(CDP_CHAIN_CONFIGS.chain_type_map) > 0


def test_return_chain_successfully():
    chain = CDP_CHAIN_CONFIGS.get_chain(1)
    assert isinstance(chain, ChainConfig)
    assert chain.id == 1
    assert len(chain.steps) > 0
    assert CDP_CHAIN_CONFIGS.get_chain(None) is None


def test_raises_error_for_invalid_chain_id():
    with pytest.raises(ValueError) as exc_info:
        CDP_CHAIN_CONFIGS.get_chain(100)
    assert str(exc_info.value) == "Chain ID 100 not found in configuration."


def test_return_chain_list_successfully():
    assert len(CDP_CHAIN_CONFIGS.get_chain_name_list('main')) > 0
    assert len(CDP_CHAIN_CONFIGS.get_chain_name_list('post')) > 0
    assert CDP_CHAIN_CONFIGS.get_chain_name_list('pre') == []


def test_returns_empty_list_for_unknown_chain_type():
    assert CDP_CHAIN_CONFIGS.get_chain_name_list('UNKNOWN_TYPE') == []
