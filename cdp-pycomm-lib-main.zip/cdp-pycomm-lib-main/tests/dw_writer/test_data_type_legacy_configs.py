from cdp_pycomm_lib.dw_writer.data_type_legacy.data_type_legacy_configs import CDP_DATA_TYPE_LEGACY_CONFIGS


def test_loads_data_type_legacy_config_correctly():
    assert CDP_DATA_TYPE_LEGACY_CONFIGS.get_data_type_id(1) == 1
    assert CDP_DATA_TYPE_LEGACY_CONFIGS.get_data_type_id(7) == 5
    assert CDP_DATA_TYPE_LEGACY_CONFIGS.get_data_type_id(3) == 3
    assert CDP_DATA_TYPE_LEGACY_CONFIGS.get_data_type_id(77) is None
    assert CDP_DATA_TYPE_LEGACY_CONFIGS.get_data_type_id(None) is None


def test_returns_data_type_id_correctly():
    assert CDP_DATA_TYPE_LEGACY_CONFIGS.get_curve_type_id(1) == 1
    assert CDP_DATA_TYPE_LEGACY_CONFIGS.get_curve_type_id(1000) is None
    assert CDP_DATA_TYPE_LEGACY_CONFIGS.get_curve_type_id(None) is None
