import pytest

from cdp_pycomm_lib.dw_writer.run_date_filter.run_date_filter_configs import CDP_RUN_DATE_FILTER_CONFIGS


def test_loads_all_run_date_filter_configs_correctly():
    assert len(CDP_RUN_DATE_FILTER_CONFIGS.id_map) == 19
    assert CDP_RUN_DATE_FILTER_CONFIGS.id_map[9].name == "Trunc run_date z2z -6h (using ls timezone settings)"
    assert CDP_RUN_DATE_FILTER_CONFIGS.id_map[9].timezone_enabled == True
    assert CDP_RUN_DATE_FILTER_CONFIGS.id_map[2].name == "Truncate run_date use sysdate if null"
    assert CDP_RUN_DATE_FILTER_CONFIGS.get_run_date_filter_config(1) is not None


def test_raises_error_when_accessing_nonexistent_config():
    with pytest.raises(ValueError, match="ID 999 not found in configuration."):
        CDP_RUN_DATE_FILTER_CONFIGS.get_run_date_filter_config(999)
