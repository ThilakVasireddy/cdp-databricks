import pytest
from pyspark.sql import Row

from cdp_pycomm_lib.common.cdp_error import CdpPkgError
from cdp_pycomm_lib.meta.repository.meta_repositories import AttributeRepository
from tests.util import spark_fixture, create_spark_wrapper_mock


@pytest.fixture(scope='class')
def attribute_repository(spark_fixture):
    data = [
        Row(ID=1, DIMENSION_ID=10, NAME='Attribute A', SHORT_NAME='AttrA'),
        Row(ID=2, DIMENSION_ID=20, NAME='Attribute B', SHORT_NAME='AttrB'),
        Row(ID=3, DIMENSION_ID=30, NAME='Attribute C', SHORT_NAME='AttrC'),
        Row(ID=4, DIMENSION_ID=40, NAME='Duplicate Name', SHORT_NAME='DupName'),
        Row(ID=5, DIMENSION_ID=50, NAME='Duplicate Name', SHORT_NAME='DupName'),
    ]
    spark_wrapper_mock = create_spark_wrapper_mock(spark_fixture, data)
    yield AttributeRepository(spark_wrapper_mock, 'cdb')


def test_returns_id_and_dimension_id_for_exact_name(attribute_repository):
    act_result = attribute_repository.get_id_and_dimension_id('Attribute A')
    assert act_result == (1, 10)


def test_returns_id_and_dimension_id_for_short_name(attribute_repository):
    act_result = attribute_repository.get_id_and_dimension_id('AttrB')
    assert act_result == (2, 20)


def test_returns_none_for_nonexistent_name(attribute_repository):
    act_result = attribute_repository.get_id_and_dimension_id('Nonexistent Name')
    assert act_result == (None, None)


def test_raises_error_for_multiple_matching_rows(attribute_repository):
    with pytest.raises(CdpPkgError) as exc_info:
        attribute_repository.get_id_and_dimension_id('Duplicate Name')
    assert exc_info.value.error_code == -20002
    err_msg = "More than one attribute-ID or dimension-ID returned from attribute 'Duplicate Name'"
    assert exc_info.value.message == err_msg
