from unittest.mock import MagicMock

from cdp_pycomm_lib.meta.repository.meta_repositories import DimensionDataRepository


def test_retrieves__table_name():
    spark_wrapper_mock = MagicMock()
    repository = DimensionDataRepository(spark_wrapper_mock, "test_schema")
    assert repository.table_name == "test_schema.DIMENSION_DATA"
