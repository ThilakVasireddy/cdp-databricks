import pytest
from pyspark.sql import Row

from cdp_pycomm_lib.meta.repository.entity_repositories import EntityNameGroupRepository
from tests.util import spark_fixture, create_spark_wrapper_mock


@pytest.fixture(scope="class")
def entity_name_group_repository(spark_fixture):
    data = [
        Row(ID=1, NAME="Group A")
    ]
    spark_wrapper_mock = create_spark_wrapper_mock(spark_fixture, data)
    yield EntityNameGroupRepository(spark_wrapper_mock, "cdb")


def test_get_id_valid(entity_name_group_repository):
    act_result = entity_name_group_repository.get_id("Group A")
    assert act_result == 1


def test_get_id_invalid(entity_name_group_repository):
    act_result = entity_name_group_repository.get_id("Nonexistent Group")
    assert act_result is None
