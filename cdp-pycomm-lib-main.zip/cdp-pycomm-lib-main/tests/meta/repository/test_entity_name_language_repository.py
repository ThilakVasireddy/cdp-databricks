import pytest
from pyspark.sql import Row

from cdp_pycomm_lib.meta.repository.entity_repositories import EntityNameLanguageRepository
from tests.util import spark_fixture, create_spark_wrapper_mock


@pytest.fixture(scope="class")
def entity_name_language_repository(spark_fixture):
    data = [
        Row(ID=1, CODE="en", STANDARD_REFERENCE="ISO 639-1"),
        Row(ID=2, CODE="fr", STANDARD_REFERENCE="ISO-639-1"),
        Row(ID=3, CODE="de", STANDARD_REFERENCE="ISO-639-2"),
    ]
    spark_wrapper_mock = create_spark_wrapper_mock(spark_fixture, data)
    yield EntityNameLanguageRepository(spark_wrapper_mock, "cdb")


def test_get_id_valid(entity_name_language_repository):
    act_result = entity_name_language_repository.get_id("en")
    assert act_result == 1


def test_get_id_invalid(entity_name_language_repository):
    act_result_1 = entity_name_language_repository.get_id("Nonexistent")
    assert act_result_1 is None

    act_result_2 = entity_name_language_repository.get_id("de")
    assert act_result_2 is None
