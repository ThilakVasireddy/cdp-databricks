import pytest
from pyspark.sql import Row
from pyspark.sql.types import StructType, StructField, IntegerType, StringType, TimestampType

from cdp_pycomm_lib.common.cdp_error import CdpPkgError
from cdp_pycomm_lib.meta.repository.entity_repositories import EntityNameRepository
from tests.util import spark_fixture, create_spark_wrapper_mock


@pytest.fixture(scope='class')
def entity_name_repository(spark_fixture):
    data = [
        Row(ID=1, ENTITY_ID=1, ENTITY_TYPE_ID=1, GROUP_ID=1, TYPE_ID=1, VALUE='Name A', REPLACED_BY=None,
            VALID_FROM_DATE=None, SORT_ORDER=1),
        Row(ID=2, ENTITY_ID=1, ENTITY_TYPE_ID=1, GROUP_ID=1, TYPE_ID=2, VALUE='Name B', REPLACED_BY=None,
            VALID_FROM_DATE=None, SORT_ORDER=2),
        Row(ID=3, ENTITY_ID=2, ENTITY_TYPE_ID=2, GROUP_ID=2, TYPE_ID=1, VALUE='Name C', REPLACED_BY=None,
            VALID_FROM_DATE=None, SORT_ORDER=1),
        Row(ID=7, ENTITY_ID=3, ENTITY_TYPE_ID=3, GROUP_ID=3, TYPE_ID=3, VALUE='Name D', REPLACED_BY=4,
            VALID_FROM_DATE=None, SORT_ORDER=1),
        Row(ID=5, ENTITY_ID=4, ENTITY_TYPE_ID=1, GROUP_ID=4, TYPE_ID=4, VALUE='Name A', REPLACED_BY=4,
            VALID_FROM_DATE=None, SORT_ORDER=1)
    ]
    schema = StructType(
        [
            StructField('ID', IntegerType(), False),
            StructField('ENTITY_ID', IntegerType(), True),
            StructField('ENTITY_TYPE_ID', IntegerType(), True),
            StructField('GROUP_ID', IntegerType(), True),
            StructField('TYPE_ID', IntegerType(), True),
            StructField('VALUE', StringType(), False),
            StructField('REPLACED_BY', IntegerType(), True),
            StructField('VALID_FROM_DATE', TimestampType(), True),
            StructField('SORT_ORDER', IntegerType(), True)
        ]
    )
    spark_wrapper_mock = create_spark_wrapper_mock(spark_fixture, data, schema)
    yield EntityNameRepository(spark_wrapper_mock, 'cdb')


def test_get_entity_ids_valid(entity_name_repository):
    act_result = entity_name_repository.get_entity_ids('Name A', '=', 1)
    assert act_result == [1, 4]


def test_get_entity_ids_invalid(entity_name_repository):
    act_result_1 = entity_name_repository.get_entity_ids('Nonexistent Name', '=', 1)
    assert act_result_1 == []

    act_result_2 = entity_name_repository.get_entity_ids('Name C', '=', 4)
    assert act_result_2 == []


def test_get_entity_ids_with_other_operator(entity_name_repository):
    act_result = entity_name_repository.get_entity_ids('%D', 'like', 3)
    assert act_result == [3]


def test_get_entity_id_valid(entity_name_repository):
    act_result = entity_name_repository.get_entity_id('Name B', 1)
    assert act_result == 1


def test_get_entity_id_no_exist(entity_name_repository):
    act_result = entity_name_repository.get_entity_id('Nonexistent Name', 1)
    assert act_result is None


def test_get_entity_id_return_multiple_rows(entity_name_repository):
    with pytest.raises(CdpPkgError) as exc_info:
        entity_name_repository.get_entity_id('Name A', 1)
    err_msg = "More than one element-ID (meta-ID) returned from element 'Name A' with dimension-ID 1"
    assert exc_info.value.message == err_msg
    assert exc_info.value.error_code == -20003


def test_get_value_for_exact_match(entity_name_repository):
    act_result = entity_name_repository.get_value(1, 1, 1, 1)
    assert act_result == 'Name A'


def test_get_value_return_none_for_no_match(entity_name_repository):
    act_result = entity_name_repository.get_value(999, 1, 1, 1)
    assert act_result is None


def test_get_value_returns_first_value_for_multiple_matches(entity_name_repository):
    act_result = entity_name_repository.get_value(1, 1, 1, None)
    assert act_result == 'Name A'


def test_get_value_ignores_replaced_rows(entity_name_repository):
    act_result = entity_name_repository.get_value(3, 3, 3, 3)
    assert act_result is None


def test_get_value_handles_null_parameters(entity_name_repository):
    act_result = entity_name_repository.get_value(2, None, None, 1)
    assert act_result == 'Name C'


def test_returns_entity_ids_for_valid_values(entity_name_repository):
    act_result = entity_name_repository.get_entity_ids_by_values(["Name B", "Name C"], 1)
    assert act_result == [1]


def test_returns_empty_list_for_nonexistent_values(entity_name_repository):
    act_result = entity_name_repository.get_entity_ids_by_values(["Nonexistent Value"], 1)
    assert act_result == []


def test_handles_empty_values_list(entity_name_repository):
    act_result = entity_name_repository.get_entity_ids_by_values([], 1)
    assert act_result == []


def test_raises_error_for_duplicate_values(entity_name_repository):
    with pytest.raises(CdpPkgError) as exc_info:
        entity_name_repository.get_entity_ids_by_values(["Name A"], 1)
    assert exc_info.value.error_code == -20003
