import pytest
from pyspark.sql import Row

from cdp_pycomm_lib.meta.repository.entity_repositories import EntityNameTypeRepository
from tests.util import spark_fixture, create_spark_wrapper_mock


@pytest.fixture(scope="class")
def entity_name_type_repository(spark_fixture):
    data = [
        Row(ID=1, NAME="Type A")
    ]
    spark_wrapper_mock = create_spark_wrapper_mock(spark_fixture, data)
    yield EntityNameTypeRepository(spark_wrapper_mock, "cdb")


def test_get_id_valid(entity_name_type_repository):
    act_result = entity_name_type_repository.get_id("Type A")
    assert act_result == 1


def test_get_id_invalid(entity_name_type_repository):
    act_result = entity_name_type_repository.get_id("Nonexistent Type")
    assert act_result is None
