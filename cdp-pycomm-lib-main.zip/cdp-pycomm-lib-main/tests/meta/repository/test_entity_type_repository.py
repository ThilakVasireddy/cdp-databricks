import pytest
from pyspark.sql import Row

from cdp_pycomm_lib.meta.repository.entity_repositories import EntityTypeRepository
from tests.util import spark_fixture, create_spark_wrapper_mock


@pytest.fixture(scope="class")
def entity_type_repository(spark_fixture):
    data = [
        Row(ID=1, NAME="Person")
    ]
    spark_wrapper_mock = create_spark_wrapper_mock(spark_fixture, data)
    yield EntityTypeRepository(spark_wrapper_mock, "cdb")


def test_get_id_valid(entity_type_repository):
    act_result = entity_type_repository.get_id("Person")
    expected_result = 1
    assert act_result == expected_result


def test_get_id_invalid(entity_type_repository):
    act_result = entity_type_repository.get_id("Nonexistent Type")
    expected_result = None
    assert act_result == expected_result
