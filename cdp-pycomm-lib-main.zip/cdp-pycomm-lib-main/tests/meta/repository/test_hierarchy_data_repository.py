import pytest
from pyspark.sql import Row

from cdp_pycomm_lib.meta.repository.meta_repositories import HierarchyDataRepository
from tests.util import spark_fixture, create_spark_wrapper_mock


@pytest.fixture(scope="class")
def hierarchy_data_repository(spark_fixture):
    data = [
        Row(NODE_ID=10, PARENT_ID=-1, CHILD_ID=100, DIMENSION_ID=1),
        Row(NODE_ID=20, PARENT_ID=10, CHILD_ID=101, DIMENSION_ID=1),
        Row(NODE_ID=30, PARENT_ID=20, CHILD_ID=102, DIMENSION_ID=1),
        Row(NODE_ID=40, PARENT_ID=20, CHILD_ID=103, DIMENSION_ID=1),
        Row(NODE_ID=50, PARENT_ID=20, CHILD_ID=104, DIMENSION_ID=2),
    ]
    spark_wrapper_mock = create_spark_wrapper_mock(spark_fixture, data)
    yield HierarchyDataRepository(spark_wrapper_mock, "cdb")


def test_returns_node_ids_for_valid_hierarchy_and_child(hierarchy_data_repository):
    act_result = hierarchy_data_repository.get_node_ids([100], 1)
    assert act_result == [10]


def test_returns_empty_for_invalid_child_id(hierarchy_data_repository):
    act_result = hierarchy_data_repository.get_node_ids([999], 1)
    assert act_result == []


def test_returns_empty_for_invalid_dimension_id(hierarchy_data_repository):
    act_result = hierarchy_data_repository.get_node_ids([100], 999)
    assert act_result == []


def test_handles_multiple_child_ids(hierarchy_data_repository):
    act_result = hierarchy_data_repository.get_node_ids([100, 101], 1)
    assert act_result == [10, 20]


def test_return_child_ids_direct(hierarchy_data_repository):
    act_result = hierarchy_data_repository.get_child_ids_direct([20], 1)
    assert act_result == [102, 103]


def test_return_child_ids_all(hierarchy_data_repository):
    act_result = hierarchy_data_repository.get_child_ids_all([10], 1)
    assert act_result == [101, 102, 103]
