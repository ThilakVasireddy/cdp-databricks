import pytest
from pyspark.sql import Row

from cdp_pycomm_lib.meta.repository.meta_repositories import LevelsRepository
from tests.util import spark_fixture, create_spark_wrapper_mock


@pytest.fixture(scope="class")
def levels_repository(spark_fixture):
    data = [
        Row(ID=1, NAME="Level A", SHORT_NAME="LA", DIMENSION_ID=1),
        Row(ID=2, NAME="Level B", SHORT_NAME="LB", DIMENSION_ID=1),
        Row(ID=3, NAME="Level C", SHORT_NAME="LC", DIMENSION_ID=2),
    ]
    spark_wrapper_mock = create_spark_wrapper_mock(spark_fixture, data)
    yield LevelsRepository(spark_wrapper_mock, "cdb")


def test_returns_id_for_exact_name_and_dimension(levels_repository):
    act_result = levels_repository.get_id("Level A", 1)
    assert act_result == 1


def test_returns_id_for_short_name_and_dimension(levels_repository):
    act_result = levels_repository.get_id("LB", 1)
    assert act_result == 2


def test_returns_none_for_nonexistent_name(levels_repository):
    act_result = levels_repository.get_id("Nonexistent Level", 1)
    assert act_result is None


def test_returns_none_for_invalid_dimension(levels_repository):
    act_result = levels_repository.get_id("Level A", 999)
    assert act_result is None


def test_handles_case_insensitive_name(levels_repository):
    act_result = levels_repository.get_id("level b", 1)
    assert act_result == 2


def test_handles_case_insensitive_short_name(levels_repository):
    act_result = levels_repository.get_id("lb", 1)
    assert act_result == 2


def test_returns_ids_for_valid_names_and_dimension(levels_repository):
    act_result = levels_repository.get_ids_by_names(["Level A", "Level B"], 1)
    assert act_result == [1, 2]


def test_returns_empty_list(levels_repository):
    act_result = levels_repository.get_ids_by_names(["Nonexistent Level"], 1)
    assert act_result == []


def test_handles_mixed_valid_and_invalid_names(levels_repository):
    act_result = levels_repository.get_ids_by_names(["Level A", "Nonexistent Level"], 1)
    assert act_result == [1]
