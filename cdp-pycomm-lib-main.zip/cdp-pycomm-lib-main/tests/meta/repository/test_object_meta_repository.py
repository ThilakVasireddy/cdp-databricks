import pytest
from pyspark.sql import Row

from cdp_pycomm_lib.meta.repository.meta_repositories import ObjectMetaRepository
from tests.util import spark_fixture, create_spark_wrapper_mock


@pytest.fixture(scope="class")
def object_meta_repository(spark_fixture):
    data = [
        Row(OBJECT_ID=1, OBJECT_TYPE_ID=10, ATTRIBUTE_ID=100, DIMENSION_ID=1000, VERB_ID=10000,
            META_ID=100000,
            OBJECT_NAME="Object A",
            UPDATED_DATE="2023-01-01"),
        Row(OBJECT_ID=1, OBJECT_TYPE_ID=60, ATTRIBUTE_ID=600, DIMENSION_ID=6000, VERB_ID=60000,
            META_ID=600000,
            OBJECT_NAME="Object A Updated",
            UPDATED_DATE="2023-02-01"),
        Row(OBJECT_ID=2, OBJECT_TYPE_ID=20, ATTRIBUTE_ID=200, DIMENSION_ID=2000, VERB_ID=20000,
            META_ID=200000,
            OBJECT_NAME="Object B",
            UPDATED_DATE="2023-02-01"),
        Row(OBJECT_ID=3, OBJECT_TYPE_ID=10, ATTRIBUTE_ID=100, DIMENSION_ID=1000, VERB_ID=10000,
            META_ID=300000,
            OBJECT_NAME="Object C",
            UPDATED_DATE="2023-01-01"),
        Row(OBJECT_ID=3, OBJECT_TYPE_ID=50, ATTRIBUTE_ID=500, DIMENSION_ID=5000, VERB_ID=50000,
            META_ID=100000,
            OBJECT_NAME="Object C Updated",
            UPDATED_DATE="2023-01-01"),
    ]
    spark_wrapper_mock = create_spark_wrapper_mock(spark_fixture, data)
    yield ObjectMetaRepository(spark_wrapper_mock, "cdb")


def test_returns_object_id_dataframe_for_valid_filters(object_meta_repository):
    act_result = object_meta_repository.get_object_id_dataframe(
        object_type_id=10,
        attribute_id=100,
        dimension_id=1000,
        verb_ids=[10000],
        meta_ids=[100000]
    )
    assert act_result.count() == 1
    assert act_result.collect()[0].OBJECT_ID == 1


def test_returns_empty_dataframe_for_invalid_object_type_id(object_meta_repository):
    act_result = object_meta_repository.get_object_id_dataframe(
        object_type_id=999,
        attribute_id=100,
        dimension_id=1000,
        verb_ids=[10000],
        meta_ids=[100000]
    )
    assert act_result.count() == 0


def test_returns_empty_dataframe_for_invalid_attribute_id(object_meta_repository):
    act_result = object_meta_repository.get_object_id_dataframe(
        object_type_id=10,
        attribute_id=999,
        dimension_id=1000,
        verb_ids=[10000],
        meta_ids=[100000]
    )
    assert act_result.count() == 0


def test_returns_empty_dataframe_for_invalid_dimension_id(object_meta_repository):
    act_result = object_meta_repository.get_object_id_dataframe(
        object_type_id=10,
        attribute_id=100,
        dimension_id=999,
        verb_ids=[10000],
        meta_ids=[100000]
    )
    assert act_result.count() == 0


def test_returns_empty_dataframe_for_invalid_verb_ids(object_meta_repository):
    act_result = object_meta_repository.get_object_id_dataframe(
        object_type_id=10,
        attribute_id=100,
        dimension_id=1000,
        verb_ids=[99999],
        meta_ids=[100000]
    )
    assert act_result.count() == 0


def test_returns_empty_dataframe_for_invalid_element_names(object_meta_repository):
    act_result = object_meta_repository.get_object_id_dataframe(
        object_type_id=10,
        attribute_id=100,
        dimension_id=1000,
        verb_ids=[10000],
        meta_ids=[900000]
    )
    assert act_result.count() == 0


def test_handles_multiple_matching_rows(object_meta_repository):
    act_result = object_meta_repository.get_object_id_dataframe(
        object_type_id=10,
        attribute_id=100,
        dimension_id=1000,
        verb_ids=[10000],
        meta_ids=[100000, 300000]
    )
    assert act_result.count() == 2
    object_ids = [row.OBJECT_ID for row in act_result.collect()]
    assert 1 in object_ids
    assert 3 in object_ids


def test_returns_latest_object_name_for_each_object_id(object_meta_repository):
    result_df = object_meta_repository.group_by_object_ids()
    result = result_df.collect()

    assert len(result) == 3
    assert any(row.OBJECT_ID == 1 and row.OBJECT_NAME == "Object A Updated" for row in result)
    assert any(row.OBJECT_ID == 2 and row.OBJECT_NAME == "Object B" for row in result)
    assert any(row.OBJECT_ID == 3 and row.OBJECT_NAME == "Object C" for row in result)
