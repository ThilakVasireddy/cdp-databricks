import pytest
from pyspark.sql import Row

from cdp_pycomm_lib.meta.repository.meta_repositories import ObjectTypeRepository
from tests.util import spark_fixture, create_spark_wrapper_mock


@pytest.fixture(scope="class")
def object_type_repository(spark_fixture):
    data = [
        Row(ID=1, NAME="Object Type A"),
        Row(ID=2, NAME="Object Type B"),
        Row(ID=3, NAME="Object Type C"),
    ]
    spark_wrapper_mock = create_spark_wrapper_mock(spark_fixture, data)
    yield ObjectTypeRepository(spark_wrapper_mock, "cdb")


def test_returns_id_for_exact_name(object_type_repository):
    act_result = object_type_repository.get_id("Object Type A")
    assert act_result == 1


def test_returns_none_for_nonexistent_name(object_type_repository):
    act_result = object_type_repository.get_id("Nonexistent Object Type")
    assert act_result is None


def test_handles_whitespace_in_name(object_type_repository):
    act_result = object_type_repository.get_id("  Object Type B  ")
    assert act_result == 2
