import pytest
from pyspark.sql import Row

from cdp_pycomm_lib.meta.repository.meta_repositories import VerbRepository
from tests.util import spark_fixture, create_spark_wrapper_mock


@pytest.fixture(scope='class')
def verb_repository(spark_fixture):
    data = [
        Row(ID=1, NAME='Verb A'),
        Row(ID=2, NAME='Verb B'),
        Row(ID=3, NAME='Verb C'),
    ]
    spark_wrapper_mock = create_spark_wrapper_mock(spark_fixture, data)
    yield VerbRepository(spark_wrapper_mock, 'cdb')


def test_returns_id_for_exact_name(verb_repository):
    act_result = verb_repository.get_id('Verb A')
    assert act_result == 1


def test_returns_none_for_nonexistent_name(verb_repository):
    act_result = verb_repository.get_id('Nonexistent Verb')
    assert act_result is None


def test_handles_whitespace_in_name(verb_repository):
    act_result = verb_repository.get_id('  Verb B  ')
    assert act_result == 2


def test_returns_ids_for_valid_names_and_dimension(verb_repository):
    act_result = verb_repository.get_ids_by_names(["Verb A", "Verb B"])
    assert act_result == [1, 2]


def test_returns_empty_list_for_nonexistent_names(verb_repository):
    act_result = verb_repository.get_ids_by_names(["Nonexistent Level"])
    assert act_result == []


def test_handles_mixed_valid_and_invalid_names(verb_repository):
    act_result = verb_repository.get_ids_by_names(["Verb A", "Nonexistent Level"])
    assert act_result == [1]


def test_handles_empty_names_list(verb_repository):
    act_result = verb_repository.get_ids_by_names([])
    assert act_result == []
