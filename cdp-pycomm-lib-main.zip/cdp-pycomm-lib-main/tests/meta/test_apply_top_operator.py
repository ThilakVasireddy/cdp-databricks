from pyspark.sql import Row

from cdp_pycomm_lib.common.cdp_constants import OP_UNION, OP_MINUS
from cdp_pycomm_lib.meta.meta_services import apply_top_operator
from tests.util import spark_fixture


def test_applies_operator_correctly(spark_fixture):
    df1 = spark_fixture.createDataFrame([Row(OBJECT_ID=1)])
    df2 = spark_fixture.createDataFrame([Row(OBJECT_ID=2)])
    df3 = spark_fixture.createDataFrame([Row(OBJECT_ID=1)])
    df4 = spark_fixture.createDataFrame([Row(OBJECT_ID=1)])
    df_stack = [df1, df2, df3, df4]
    op_stack = [OP_UNION, OP_MINUS, OP_MINUS]

    expected = df1.union(df2).subtract(df3).subtract(df4).collect()
    apply_top_operator(df_stack, op_stack)

    result = df_stack.pop()
    assert result.collect() == expected


def test_applies_operator_correctly_with_brackets(spark_fixture):
    df1 = spark_fixture.createDataFrame([Row(OBJECT_ID=1)])
    df2 = spark_fixture.createDataFrame([Row(OBJECT_ID=2)])
    df3 = spark_fixture.createDataFrame([Row(OBJECT_ID=1)])
    df4 = spark_fixture.createDataFrame([Row(OBJECT_ID=1)])
    df_stack = [df1, df2, df3, df4]
    op_stack = ['(', OP_UNION, OP_MINUS, OP_MINUS]

    expected = df1.union(df2).subtract(df3).subtract(df4).collect()
    apply_top_operator(df_stack, op_stack)

    result = df_stack.pop()
    assert result.collect() == expected
