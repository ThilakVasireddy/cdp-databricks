import pytest
from pyspark.sql import Row

from cdp_pycomm_lib.meta.meta_services import combine_dataframes
from tests.util import spark_fixture


@pytest.fixture
def df1(spark_fixture):
    return spark_fixture.createDataFrame(
        [Row(OBJECT=1)]
    )


@pytest.fixture
def df2(spark_fixture):
    return spark_fixture.createDataFrame(
        [Row(OBJECT=1), Row(OBJECT=2)]
    )


def test_union(df1, df2):
    result = combine_dataframes(df1, df2, "UNION")
    assert result.collect() == [Row(OBJECT=1), Row(OBJECT=1), Row(OBJECT=2)]


def test_intersect(df1, df2):
    result = combine_dataframes(df1, df2, "INTERSECT")
    assert result.collect() == [Row(OBJECT=1)]


def test_minus(df1, df2):
    result = combine_dataframes(df1, df2, "MINUS")
    assert result.collect() == []


def test_invalid_operator(df1, df2):
    result = combine_dataframes(df1, df2, "INVALID")
    assert result.collect() == [Row(OBJECT=1)]


def test_none_first_dataframe(df2):
    result = combine_dataframes(None, df2, "UNION")
    assert result == df2


def test_none_second_dataframe(df1):
    result = combine_dataframes(df1, None, "UNION")
    assert result == df1
