from unittest.mock import patch

from pyspark.sql import Row

from cdp_pycomm_lib.common.cdp_constants import OP_UNION, OP_MINUS
from cdp_pycomm_lib.common.cdp_object import MjApiArguments
from cdp_pycomm_lib.meta.meta_services import compute_dataframes_with_operators
from tests.util import spark_fixture


@patch('cdp_pycomm_lib.meta.meta_services.get_object_ids')
def test_computes_single_dataframe_without_operators(mock_get_object_ids, spark_fixture):
    expected = spark_fixture.createDataFrame([
        Row(OBJECT_ID=1)
    ])
    mock_get_object_ids.return_value = expected

    p_args = [MjApiArguments('', 'attr1', ['verb1'], ['value1'])]
    result = compute_dataframes_with_operators(1, p_args)
    assert result.collect() == expected.collect()


@patch('cdp_pycomm_lib.meta.meta_services.get_object_ids')
def test_handles_multiple_operators(mock_get_object_ids, spark_fixture):
    df1 = spark_fixture.createDataFrame([Row(OBJECT_ID=1)])
    df2 = spark_fixture.createDataFrame([Row(OBJECT_ID=2)])
    df3 = spark_fixture.createDataFrame([Row(OBJECT_ID=1)])
    df4 = spark_fixture.createDataFrame([Row(OBJECT_ID=1)])
    mock_get_object_ids.side_effect = [df1, df2, df3, df4]

    p_args = [
        MjApiArguments('', 'attr1', ['verb1'], ['value1']),
        MjApiArguments(OP_UNION, 'attr2', ['verb2'], ['value2']),
        MjApiArguments(OP_MINUS, 'attr3', ['verb3'], ['value3']),
        MjApiArguments(OP_MINUS, 'attr4', ['verb4'], ['value4'])
    ]
    result = compute_dataframes_with_operators(1, p_args)

    assert result.collect() == [Row(OBJECT_ID=2)]


@patch('cdp_pycomm_lib.meta.meta_services.get_object_ids')
def test_handles_multiple_operators_with_brackets(mock_get_object_ids, spark_fixture):
    df1 = spark_fixture.createDataFrame([Row(OBJECT_ID=1)])
    df2 = spark_fixture.createDataFrame([Row(OBJECT_ID=2)])
    df3 = spark_fixture.createDataFrame([Row(OBJECT_ID=1)])
    df4 = spark_fixture.createDataFrame([Row(OBJECT_ID=1)])
    mock_get_object_ids.side_effect = [df1, df2, df3, df4]

    p_args = [
        MjApiArguments('(', 'attr1', ['verb1'], ['value1']),
        MjApiArguments(OP_UNION, 'attr2', ['verb2'], ['value2']),
        MjApiArguments(f'){OP_MINUS}(', 'attr3', ['verb3'], ['value3']),
        MjApiArguments(OP_MINUS, 'attr4', ['verb4'], ['value4']),
        MjApiArguments(')', '', [], [])
    ]
    result = compute_dataframes_with_operators(1, p_args)

    assert result.collect() == [Row(OBJECT_ID=1), Row(OBJECT_ID=2)]


def test_returns_none_for_empty_arguments():
    result = compute_dataframes_with_operators(1, [])
    assert result is None
