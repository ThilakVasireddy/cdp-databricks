from unittest.mock import patch

from cdp_pycomm_lib.meta import entity_services


@patch("cdp_pycomm_lib.meta.entity_services.entity_name_group_repository.get_id", return_value=10)
@patch("cdp_pycomm_lib.meta.entity_services.entity_name_type_repository.get_id", return_value=20)
def test_returns_correct_ids_for_valid_group_and_type_names(mock_get_type_id, mock_get_group_id):
    result = entity_services.prepare_parameters("Group A", "Type A")
    assert result == {"group_id": 10, "type_id": 20}
    mock_get_group_id.assert_called_once_with("Group A")
    mock_get_type_id.assert_called_once_with("Type A")


@patch("cdp_pycomm_lib.meta.entity_services.entity_name_group_repository.get_id", return_value=None)
@patch("cdp_pycomm_lib.meta.entity_services.entity_name_type_repository.get_id", return_value=None)
def test_returns_none_for_missing_group_and_type_names(mock_get_type_id, mock_get_group_id):
    result = entity_services.prepare_parameters(None, None)
    assert result == {"group_id": None, "type_id": None}
    mock_get_group_id.assert_not_called()
    mock_get_type_id.assert_not_called()


@patch("cdp_pycomm_lib.meta.entity_services.entity_name_group_repository.get_id", return_value=None)
@patch("cdp_pycomm_lib.meta.entity_services.entity_name_type_repository.get_id", return_value=None)
def test_returns_correct_type_id_and_none_group_id(mock_get_type_id, mock_get_group_id):
    result = entity_services.prepare_parameters('Group A', "Type A")
    assert result == {"group_id": None, "type_id": None}
    mock_get_group_id.assert_called_once_with('Group A')
    mock_get_type_id.assert_called_once_with("Type A")


@patch("cdp_pycomm_lib.meta.entity_services.entity_name_repository.get_value", return_value="Entity Name A")
@patch("cdp_pycomm_lib.meta.entity_services.prepare_parameters", return_value={"group_id": 10, "type_id": 20})
def test_returns_entity_name_for_valid_parameters(mock_prepare_parameters, mock_get_value):
    result = entity_services.get_name(1, 2, "Group A", "Type A")
    assert result == "Entity Name A"
    mock_prepare_parameters.assert_called_once_with("Group A", "Type A")
    mock_get_value.assert_called_once_with(1, 2, 10, 20)


@patch("cdp_pycomm_lib.meta.entity_services.entity_name_repository.get_value", return_value=None)
@patch("cdp_pycomm_lib.meta.entity_services.prepare_parameters", return_value={"group_id": None, "type_id": None})
def test_returns_none_for_nonexistent_entity(mock_prepare_parameters, mock_get_value):
    result = entity_services.get_name(999, 999, "Nonexistent Group", "Nonexistent Type")
    assert result is None
    mock_prepare_parameters.assert_called_once_with("Nonexistent Group", "Nonexistent Type")
    mock_get_value.assert_called_once_with(999, 999, None, None)
