from unittest.mock import patch

from pyspark.sql import Row

from cdp_pycomm_lib.common.cdp_object import MjApiArguments
from cdp_pycomm_lib.meta.meta_services import get_by_meta_query
from tests.util import spark_fixture


@patch('cdp_pycomm_lib.meta.meta_services.compute_dataframes_with_operators')
def test_returns_none(mock_compute_dataframes_with_operators):
    mock_compute_dataframes_with_operators.return_value = None
    args = [MjApiArguments('', 'attr1', ['is'], ['value1'])]
    result = get_by_meta_query(1, args, True)
    assert result is None


@patch('cdp_pycomm_lib.meta.meta_services.compute_dataframes_with_operators')
@patch('cdp_pycomm_lib.meta.meta_services.object_meta_repository.group_by_object_ids')
def test_returns_name(mock_group_by_object_ids, mock_compute_dataframes_with_operators, spark_fixture):
    mock_compute_dataframes_with_operators.return_value = spark_fixture.createDataFrame(
        [Row(OBJECT_ID=1), Row(OBJECT_ID=2)]
    )
    mock_group_by_object_ids.return_value = spark_fixture.createDataFrame(
        [Row(OBJECT_ID=1, OBJECT_NAME='name1'), Row(OBJECT_ID=2, OBJECT_NAME='name2')]
    )

    args = [
        MjApiArguments('', 'attr1', ['is'], ['value1']),
        MjApiArguments('UNION', 'attr2', ['is'], ['value2'])
    ]
    result = get_by_meta_query(1, args, True)
    assert result.collect() == [Row(OBJECT_ID=1, NAME='name1'), Row(OBJECT_ID=2, NAME='name2')]


@patch('cdp_pycomm_lib.meta.meta_services.compute_dataframes_with_operators')
def test_no_returns_name(mock_compute_dataframes_with_operators, spark_fixture):
    mock_compute_dataframes_with_operators.return_value = spark_fixture.createDataFrame(
        [Row(OBJECT_ID=1), Row(OBJECT_ID=1)]
    )

    args = [MjApiArguments('', 'attr1', ['is'], ['value1'])]
    result = get_by_meta_query(1, args, False)
    assert result.collect() == [Row(OBJECT_ID=1)]
