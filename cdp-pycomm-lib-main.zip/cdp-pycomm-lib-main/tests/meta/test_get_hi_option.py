from cdp_pycomm_lib.common.cdp_constants import HQ_ALL, HQ_LEVEL, HQ_DIRECT, HQ_DIRECT_P, HQ_ALL_P
from cdp_pycomm_lib.meta.meta_services import get_hi_option


def test_empty_args():
    result = get_hi_option([])
    assert result == HQ_ALL


def test_multiple_args():
    result = get_hi_option(['level1', 'level2'])
    assert result == HQ_LEVEL


def test_direct():
    result = get_hi_option(['direct'])
    assert result == HQ_DIRECT


def test_directp():
    result = get_hi_option(['directp'])
    assert result == HQ_DIRECT_P


def test_all():
    result = get_hi_option(['all'])
    assert result == HQ_ALL


def test_allp():
    result = get_hi_option(['allp'])
    assert result == HQ_ALL_P


def test_invalid():
    result = get_hi_option(['invalid'])
    assert result == HQ_LEVEL
