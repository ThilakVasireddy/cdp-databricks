from unittest.mock import patch, MagicMock

from pyspark.sql import DataFrame
from pyspark.sql.functions import col
from pyspark.sql.types import Row

from cdp_pycomm_lib.meta import meta_services
from tests.util import spark_fixture


@patch('cdp_pycomm_lib.meta.meta_services.get_meta_common')
def test_returns_correct_dataframe_for_char_array_input(mock_get_meta_common):
    mock_result_df = MagicMock(spec=DataFrame)
    mock_get_meta_common.return_value = mock_result_df
    mock_input_df = MagicMock(spec=DataFrame)
    act_result = meta_services.get_meta_char_array_dataframe(1, mock_input_df)

    assert act_result == mock_result_df
    mock_get_meta_common.assert_called_once_with(1, mock_input_df)


@patch('cdp_pycomm_lib.meta.meta_services.get_meta_common')
@patch('cdp_pycomm_lib.meta.meta_services.CDP_SPARK.create_data_frame')
def test_returns_correct_dataframe_for_number_array_input(mock_create_data_frame, mock_get_meta_common):
    mock_result_df = MagicMock(spec=DataFrame)
    mock_get_meta_common.return_value = mock_result_df

    mock_input_df = MagicMock(spec=DataFrame)
    mock_create_data_frame.return_value = mock_input_df

    act_result = meta_services.get_meta_num_array_dataframe(1, [1, 2])
    assert act_result == mock_result_df
    mock_get_meta_common.assert_called_once_with(1, mock_input_df)


@patch("cdp_pycomm_lib.meta.meta_services.object_meta_repository.get")
@patch("cdp_pycomm_lib.meta.meta_services.attribute_repository.get")
@patch("cdp_pycomm_lib.meta.meta_services.verb_repository.get")
@patch("cdp_pycomm_lib.meta.meta_services.dimension_data_repository.get")
@patch("cdp_pycomm_lib.meta.meta_services.entity_services.get_name")
def test_returns_dataframe_with_correct_object_ids(
        mock_get_name,
        mock_dimension_data_repository,
        mock_verb_repository,
        mock_attribute_repository,
        mock_object_meta_repository,
        spark_fixture
):
    mock_object_meta_repository.return_value = spark_fixture.createDataFrame(
        [
            Row(OBJECT_ID=1, ATTRIBUTE_ID=10, VERB_ID=100, META_ID=1000, DIMENSION_ID=10000, OBJECT_TYPE_ID=1),
            Row(OBJECT_ID=2, ATTRIBUTE_ID=20, VERB_ID=200, META_ID=2000, DIMENSION_ID=20000, OBJECT_TYPE_ID=2)
        ]
    )
    mock_attribute_repository.return_value = spark_fixture.createDataFrame(
        [Row(ID=10, SHORT_NAME="attr1")]
    )
    mock_verb_repository.return_value = spark_fixture.createDataFrame(
        [Row(ID=100, NAME="verb2")]
    )
    mock_dimension_data_repository.return_value = spark_fixture.createDataFrame(
        [
            Row(NAME='name 1', ELEMENT_ID=1000, DIMENSION_ID=10000),
            Row(NAME='name 2', ELEMENT_ID=2000, DIMENSION_ID=10000),
            Row(NAME='name 3', ELEMENT_ID=1000, DIMENSION_ID=20000)
        ]
    )

    mock_get_name.side_effect = lambda e_id, d_id, _, name_type: f"{name_type}_{e_id}_{d_id}"
    object_id_df = spark_fixture.createDataFrame([Row(OBJECT_ID=1), Row(OBJECT_ID=2)])
    result = meta_services.get_meta_common(1, object_id_df)
    row = result.first()
    assert row['object_id'] == 1
    assert row['attr'] == 'attr1'
    assert row['verb'] == 'verb2'
    assert row['alias'] == 'Abbreviation_1000_10000'

    assert result.columns == ['object_id', 'attr', 'verb', 'alias']


@patch("cdp_pycomm_lib.meta.meta_services.entity_services.get_name")
def test_returns_name_maps(mock_get_name, spark_fixture):
    mock_result_df = spark_fixture.createDataFrame(
        [
            Row(META_ID=1, DIMENSION_ID=10, ATTRIBUTE_ID=10, NAME='1'),
            Row(META_ID=2, DIMENSION_ID=20, ATTRIBUTE_ID=20, NAME='2'),
            Row(META_ID=3, DIMENSION_ID=30, ATTRIBUTE_ID=20, NAME='3'),
            Row(META_ID=4, DIMENSION_ID=40, ATTRIBUTE_ID=20, NAME='4'),
            Row(META_ID=5, DIMENSION_ID=50, ATTRIBUTE_ID=22, NAME='5'),
            Row(META_ID=6, DIMENSION_ID=60, ATTRIBUTE_ID=169, NAME='6'),
        ]
    )
    mock_dimension_df = spark_fixture.createDataFrame(
        [
            Row(ELEMENT_ID=1, NAME='name 100'),
            Row(ELEMENT_ID=2, NAME='name 200'),
            Row(ELEMENT_ID=3, NAME='name 300'),
            Row(ELEMENT_ID=4, NAME='name 400'),
            Row(ELEMENT_ID=5, NAME='name 500'),
            Row(ELEMENT_ID=6, NAME=None),
        ]
    )
    mock_result_df = (
        mock_result_df.alias('om')
        .join(mock_dimension_df.alias('d'), col('om.META_ID') == col('d.ELEMENT_ID'))
    )
    mock_get_name.side_effect = lambda e_id, d_id, _, name_type: get_name(e_id, d_id, name_type)
    name_maps = meta_services.get_name_maps(mock_result_df)
    assert name_maps == {
        '1_10': 'Abbreviation_1_10',
        '2_20': 'Shortname_2_20',
        '3_30': 'Fullname_3_30',
        '4_40': None,
        '5_50': 'name 500',
        '6_60': None,
    }


def get_name(element_id, dimension_id, name_type):
    if ((element_id == 1 and name_type == 'Abbreviation')
            or (element_id == 2 and name_type == 'Shortname')
            or (element_id in [3, 5, 6] and name_type == 'Fullname')):
        return f"{name_type}_{element_id}_{dimension_id}"
    return None
