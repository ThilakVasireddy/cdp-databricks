from unittest.mock import patch, MagicMock

from cdp_pycomm_lib.common.cdp_constants import LOAD_SET, FUNC_GETCHILDREN
from cdp_pycomm_lib.common.cdp_object import MjApiArguments
from cdp_pycomm_lib.meta.meta_services import get_object_ids


@patch('cdp_pycomm_lib.meta.meta_services.get_object_ids_from_om')
def test_without_function(mock_get_object_ids_from_om):
    p_arg = MjApiArguments('', 'attribute', ['is'], ['value1'])
    mock_df = MagicMock()
    mock_get_object_ids_from_om.return_value = mock_df

    result = get_object_ids(1, p_arg)
    assert result == mock_df
    mock_get_object_ids_from_om.assert_called_once_with(1, 'attribute', ['is'], ['value1'])


@patch('cdp_pycomm_lib.meta.meta_services.get_object_ids_from_om')
def test_without_function_1(mock_get_object_ids_from_om):
    p_arg = MjApiArguments('', LOAD_SET, ['is'], ['value1'])
    mock_df = MagicMock()
    mock_get_object_ids_from_om.return_value = mock_df

    result = get_object_ids(2, p_arg)
    assert result == mock_df
    mock_get_object_ids_from_om.assert_called_once_with(2, LOAD_SET, ['is'], ['value1'])


@patch('cdp_pycomm_lib.meta.meta_services.curve_services.get_curve_ids_by_load_set_names')
def test_load_set(mock_get_curve_ids_by_load_set_names):
    p_arg = MjApiArguments('', LOAD_SET, ['is'], ['value1'])
    mock_df = MagicMock()
    mock_get_curve_ids_by_load_set_names.return_value = mock_df

    result = get_object_ids(1, p_arg)
    assert result == mock_df
    mock_get_curve_ids_by_load_set_names.assert_called_once_with(['value1'])


@patch('cdp_pycomm_lib.meta.meta_services.get_object_ids_from_getchildren')
def test_with_function_getchildren(mock_get_object_ids_from_getchildren):
    p_arg = MjApiArguments('', 'attribute', ['is'], ['value1'], FUNC_GETCHILDREN, ['all'])
    mock_df = MagicMock()
    mock_get_object_ids_from_getchildren.return_value = mock_df

    result = get_object_ids(1, p_arg)
    assert result == mock_df
    mock_get_object_ids_from_getchildren.assert_called_once_with('attribute', ['value1'], ['all'])


def test_get_object_ids_invalid_function():
    p_arg = MjApiArguments('', 'attribute', ['is'], ['value1'], 'INVALID')
    result = get_object_ids(1, p_arg)
    assert result is None
