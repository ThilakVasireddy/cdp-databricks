from unittest.mock import patch, MagicMock

from pyspark.sql import DataFrame

from cdp_pycomm_lib.meta.meta_services import get_object_ids_from_getchildren


@patch("cdp_pycomm_lib.meta.meta_services.hierarchy_data_repository.get_child_ids_direct")
@patch("cdp_pycomm_lib.meta.meta_services.object_meta_repository.get")
@patch("cdp_pycomm_lib.meta.meta_services.dimension_data_repository.get")
@patch('cdp_pycomm_lib.meta.meta_services.hierarchy_data_repository.get_node_ids')
@patch('cdp_pycomm_lib.meta.meta_services.entity_name_repository.get_entity_ids_by_values')
@patch('cdp_pycomm_lib.meta.meta_services.attribute_repository.get_id_and_dimension_id')
def test_direct(
        mock_get_id_and_dimension_id,
        mock_get_entity_ids_by_values,
        mock_get_node_ids,
        mock_dimension_data_repository,
        mock_object_meta_repository,
        mock_get_child_ids_direct
):
    mock_get_id_and_dimension_id.return_value = (1, 2)
    mock_get_entity_ids_by_values.return_value = [100]
    mock_get_node_ids.return_value = [4]

    mock_get_child_ids_direct.return_value = [1, 2, 3]
    mock_object_meta_repository.return_value = MagicMock(spec=DataFrame)
    mock_df = MagicMock(spec=DataFrame)
    mock_dimension_data_repository.return_value.filter.return_value.join.return_value.select.return_value.distinct.return_value = mock_df

    result = get_object_ids_from_getchildren("attribute", ["value"], ["direct"])
    assert result == mock_df
    mock_get_id_and_dimension_id.assert_called_once_with("attribute")
    mock_get_entity_ids_by_values.assert_called_once_with(["value"], 2)
    mock_get_node_ids.assert_called_once_with([100], 2)
    mock_get_child_ids_direct.assert_called_once_with([4], 2)
    mock_object_meta_repository.assert_called_once()
    mock_dimension_data_repository.assert_called_once()


@patch("cdp_pycomm_lib.meta.meta_services.hierarchy_data_repository.get_child_ids_direct")
@patch("cdp_pycomm_lib.meta.meta_services.object_meta_repository.get")
@patch("cdp_pycomm_lib.meta.meta_services.dimension_data_repository.get")
@patch('cdp_pycomm_lib.meta.meta_services.hierarchy_data_repository.get_node_ids')
@patch('cdp_pycomm_lib.meta.meta_services.entity_name_repository.get_entity_ids_by_values')
@patch('cdp_pycomm_lib.meta.meta_services.attribute_repository.get_id_and_dimension_id')
def test_direct_p(
        mock_get_id_and_dimension_id,
        mock_get_entity_ids_by_values,
        mock_get_node_ids,
        mock_dimension_data_repository,
        mock_object_meta_repository,
        mock_get_child_ids_direct
):
    mock_get_id_and_dimension_id.return_value = (1, 2)
    mock_get_entity_ids_by_values.return_value = [100]
    mock_get_node_ids.return_value = [4]

    mock_get_child_ids_direct.return_value = [1, 2, 3]
    mock_object_meta_repository.return_value = MagicMock(spec=DataFrame)
    mock_df = MagicMock(spec=DataFrame)
    mock_dimension_data_repository.return_value.filter.return_value.join.return_value.select.return_value.distinct.return_value = mock_df

    result = get_object_ids_from_getchildren("attribute", ["value"], ["directp"])
    assert result == mock_df


@patch("cdp_pycomm_lib.meta.meta_services.hierarchy_data_repository.get_child_ids_all")
@patch("cdp_pycomm_lib.meta.meta_services.object_meta_repository.get")
@patch("cdp_pycomm_lib.meta.meta_services.dimension_data_repository.get")
@patch('cdp_pycomm_lib.meta.meta_services.hierarchy_data_repository.get_node_ids')
@patch('cdp_pycomm_lib.meta.meta_services.entity_name_repository.get_entity_ids_by_values')
@patch('cdp_pycomm_lib.meta.meta_services.attribute_repository.get_id_and_dimension_id')
def test_all(
        mock_get_id_and_dimension_id,
        mock_get_entity_ids_by_values,
        mock_get_node_ids,
        mock_dimension_data_repository,
        mock_object_meta_repository,
        mock_get_child_ids_all
):
    mock_get_id_and_dimension_id.return_value = (1, 2)
    mock_get_entity_ids_by_values.return_value = [100]
    mock_get_node_ids.return_value = [4]

    mock_get_child_ids_all.return_value = [1, 2, 3]
    mock_object_meta_repository.return_value = MagicMock(spec=DataFrame)
    mock_df = MagicMock(spec=DataFrame)
    mock_dimension_data_repository.return_value.filter.return_value.join.return_value.select.return_value.distinct.return_value = mock_df

    result = get_object_ids_from_getchildren("attribute", ["value"], ["all"])
    assert result == mock_df


@patch("cdp_pycomm_lib.meta.meta_services.hierarchy_data_repository.get_child_ids_all")
@patch("cdp_pycomm_lib.meta.meta_services.object_meta_repository.get")
@patch("cdp_pycomm_lib.meta.meta_services.dimension_data_repository.get")
@patch('cdp_pycomm_lib.meta.meta_services.hierarchy_data_repository.get_node_ids')
@patch('cdp_pycomm_lib.meta.meta_services.entity_name_repository.get_entity_ids_by_values')
@patch('cdp_pycomm_lib.meta.meta_services.attribute_repository.get_id_and_dimension_id')
def test_all_p(
        mock_get_id_and_dimension_id,
        mock_get_entity_ids_by_values,
        mock_get_node_ids,
        mock_dimension_data_repository,
        mock_object_meta_repository,
        mock_get_child_ids_all
):
    mock_get_id_and_dimension_id.return_value = (1, 2)
    mock_get_entity_ids_by_values.return_value = [100]
    mock_get_node_ids.return_value = [4]

    mock_get_child_ids_all.return_value = [1, 2, 3]
    mock_object_meta_repository.return_value = MagicMock(spec=DataFrame)
    mock_df = MagicMock(spec=DataFrame)
    mock_dimension_data_repository.return_value.filter.return_value.join.return_value.select.return_value.distinct.return_value = mock_df

    result = get_object_ids_from_getchildren("attribute", ["value"], ["allp"])
    assert result == mock_df


@patch('cdp_pycomm_lib.meta.meta_services.get_hi_option')
@patch("cdp_pycomm_lib.meta.meta_services.object_meta_repository.get")
@patch("cdp_pycomm_lib.meta.meta_services.dimension_data_repository.get")
@patch('cdp_pycomm_lib.meta.meta_services.hierarchy_data_repository.get_node_ids')
@patch('cdp_pycomm_lib.meta.meta_services.entity_name_repository.get_entity_ids_by_values')
@patch('cdp_pycomm_lib.meta.meta_services.attribute_repository.get_id_and_dimension_id')
def test_returns_none_for_invalid_option(
        mock_get_id_and_dimension_id,
        mock_get_entity_ids_by_values,
        mock_get_node_ids,
        mock_dimension_data_repository,
        mock_object_meta_repository,
        mock_get_hi_option
):
    mock_get_id_and_dimension_id.return_value = (1, 2)
    mock_get_entity_ids_by_values.return_value = [100]
    mock_get_node_ids.return_value = [4]
    mock_dimension_data_repository.return_value = MagicMock(spec=DataFrame)
    mock_object_meta_repository.return_value = MagicMock(spec=DataFrame)
    mock_get_hi_option.return_value = "invalid_option"
    result = get_object_ids_from_getchildren("attribute", ["value"], ["invalid"])
    assert result is None


@patch("cdp_pycomm_lib.meta.meta_services.levels_repository.get_ids_by_names")
@patch("cdp_pycomm_lib.meta.meta_services.hierarchy_data_repository.get_child_ids_all")
@patch("cdp_pycomm_lib.meta.meta_services.object_meta_repository.get")
@patch("cdp_pycomm_lib.meta.meta_services.dimension_data_repository.get")
@patch('cdp_pycomm_lib.meta.meta_services.hierarchy_data_repository.get_node_ids')
@patch('cdp_pycomm_lib.meta.meta_services.entity_name_repository.get_entity_ids_by_values')
@patch('cdp_pycomm_lib.meta.meta_services.attribute_repository.get_id_and_dimension_id')
def test_level(
        mock_get_id_and_dimension_id,
        mock_get_entity_ids_by_values,
        mock_get_node_ids,
        mock_dimension_data_repository,
        mock_object_meta_repository,
        mock_get_child_ids_all,
        mock_get_ids_by_names
):
    mock_get_id_and_dimension_id.return_value = (1, 2)
    mock_get_entity_ids_by_values.return_value = [100]
    mock_get_node_ids.return_value = [4]
    mock_get_child_ids_all.return_value = [1, 2, 3]
    mock_get_ids_by_names.return_value = [9]

    mock_object_meta_repository.return_value = MagicMock(spec=DataFrame)
    mock_df = MagicMock(spec=DataFrame)
    (
        mock_dimension_data_repository.return_value
        .filter.return_value
        .filter.return_value
        .join.return_value
        .select.return_value
        .distinct
    ).return_value = mock_df

    result = get_object_ids_from_getchildren("attribute", ["value"], ['level1', 'level2'])
    assert result == mock_df
    mock_get_ids_by_names.assert_called_once_with(['level1', 'level2'], 2)
