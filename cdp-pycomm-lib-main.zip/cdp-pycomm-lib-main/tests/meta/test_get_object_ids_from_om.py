from unittest.mock import patch, MagicMock

from pyspark.sql import DataFrame

from cdp_pycomm_lib.meta.meta_services import get_object_ids_from_om


@patch("cdp_pycomm_lib.meta.meta_services.attribute_repository.get_id_and_dimension_id")
@patch("cdp_pycomm_lib.meta.meta_services.verb_repository.get_ids_by_names")
@patch("cdp_pycomm_lib.meta.meta_services.entity_name_repository.get_entity_ids_by_values")
@patch("cdp_pycomm_lib.meta.meta_services.object_meta_repository.get_object_id_dataframe")
def test_returns_object_ids_for_valid_inputs(
        mock_get_object_id_dataframe,
        mock_get_entity_ids_by_values,
        mock_get_verb_ids,
        mock_get_attribute_id_and_dimension_id
):
    mock_get_attribute_id_and_dimension_id.return_value = 1, 2
    mock_get_verb_ids.return_value = [10, 20]
    mock_get_entity_ids_by_values.return_value = [100, 200]
    df = MagicMock(spec=DataFrame)
    mock_get_object_id_dataframe.return_value = df

    result = get_object_ids_from_om(1, "attribute_name", ["verb1", "verb2"], ["value1", "value2"])
    assert result == df
    mock_get_attribute_id_and_dimension_id.assert_called_once_with("attribute_name")
    mock_get_verb_ids.assert_called_once_with(["verb1", "verb2"])
    mock_get_entity_ids_by_values.assert_called_once_with(["value1", "value2"], 2)
    mock_get_object_id_dataframe.assert_called_once_with(1, 1, 2, [10, 20], [100, 200])
