from unittest.mock import patch, MagicMock

from pyspark.sql import DataFrame

from cdp_pycomm_lib.common.cdp_object import MjApiArguments
from cdp_pycomm_lib.meta import mjapi_services


@patch('cdp_pycomm_lib.meta.mjapi_services.object_type_repository.get_id')
@patch('cdp_pycomm_lib.meta.mjapi_services.meta_services.get_by_meta_query')
def test_get_by_meta_invalid_object_type(mock_get_by_meta_query, mock_get_id):
    mock_get_id.return_value = None
    result = mjapi_services.get_by_meta('invalid_type', [], False)
    assert result is None
    mock_get_id.assert_called_once_with('invalid_type')
    mock_get_by_meta_query.assert_not_called()


@patch('cdp_pycomm_lib.meta.mjapi_services.object_type_repository.get_id')
@patch('cdp_pycomm_lib.meta.mjapi_services.meta_services.get_by_meta_query')
def test_get_by_meta_return_validate(mock_get_by_meta_query, mock_get_id):
    mock_get_id.return_value = 1
    mock_df = MagicMock(spec=DataFrame)
    mock_get_by_meta_query.return_value = mock_df
    args = [MjApiArguments(attribute="attr1", value=["val1"], verb=["verb1"], operator="UNION")]
    result = mjapi_services.get_by_meta('valid_type', args, True)
    assert result == mock_df
    mock_get_id.assert_called_once_with('valid_type')
    mock_get_by_meta_query.assert_called_once_with(1, args, True)


@patch('cdp_pycomm_lib.meta.mjapi_services.object_type_repository.get_id')
@patch('cdp_pycomm_lib.meta.mjapi_services.meta_services.get_meta_num_array_dataframe')
def test_get_meta_by_id_invalid_object_type(mock_get_meta_num_array_dataframe, mock_get_id):
    mock_get_id.return_value = None
    result = mjapi_services.get_meta_by_id('invalid_type', [1, 2])
    assert result is None
    mock_get_id.assert_called_once_with('invalid_type')
    mock_get_meta_num_array_dataframe.assert_not_called()


@patch('cdp_pycomm_lib.meta.mjapi_services.object_type_repository.get_id')
@patch('cdp_pycomm_lib.meta.mjapi_services.meta_services.get_meta_num_array_dataframe')
def test_get_meta_by_id_return_validate(mock_get_meta_num_array_dataframe, mock_get_id):
    mock_get_id.return_value = 1
    mock_df = MagicMock(spec=DataFrame)
    mock_get_meta_num_array_dataframe.return_value = mock_df
    result = mjapi_services.get_meta_by_id('valid_type', [1, 2])
    assert result == mock_df
    mock_get_id.assert_called_once_with('valid_type')
    mock_get_meta_num_array_dataframe.assert_called_once_with(1, [1, 2])


@patch('cdp_pycomm_lib.meta.mjapi_services.meta_services.get_meta_char_array_dataframe')
@patch('cdp_pycomm_lib.meta.mjapi_services.get_by_meta')
@patch('cdp_pycomm_lib.meta.mjapi_services.object_type_repository.get_id')
def test_get_meta_by_meta_return_empty_invalid_object_type(
        mock_get_id, mock_get_by_meta, mock_get_meta_char_array_dataframe
):
    mock_get_id.return_value = None
    result = mjapi_services.get_meta_by_meta('invalid_type', [MagicMock(spec=MjApiArguments)])

    assert result is None
    mock_get_id.assert_called_once_with('invalid_type')
    mock_get_by_meta.assert_not_called()
    mock_get_meta_char_array_dataframe.assert_not_called()


@patch('cdp_pycomm_lib.meta.mjapi_services.meta_services.get_meta_char_array_dataframe')
@patch('cdp_pycomm_lib.meta.mjapi_services.get_by_meta')
@patch('cdp_pycomm_lib.meta.mjapi_services.object_type_repository.get_id')
def test_get_meta_by_meta_return_empty_with_get_meta_return_none(
        mock_get_id, mock_get_by_meta, mock_get_meta_char_array_dataframe
):
    mock_get_id.return_value = 1
    mock_get_by_meta.return_value = None

    result = mjapi_services.get_meta_by_meta('invalid_type', [MagicMock(spec=MjApiArguments)])
    assert result is None
    mock_get_id.assert_called_once_with('invalid_type')
    mock_get_meta_char_array_dataframe.assert_not_called()


@patch('cdp_pycomm_lib.meta.mjapi_services.meta_services.get_meta_char_array_dataframe')
@patch('cdp_pycomm_lib.meta.mjapi_services.get_by_meta')
@patch('cdp_pycomm_lib.meta.mjapi_services.object_type_repository.get_id')
def test_get_meta_by_meta_return_validate(
        mock_get_id, mock_get_by_meta, mock_get_meta_char_array_dataframe
):
    mock_get_id.return_value = 1
    mock_object_ids_df = MagicMock(spec=DataFrame)
    mock_get_by_meta.return_value = mock_object_ids_df
    mock_df = MagicMock(spec=DataFrame)
    mock_get_meta_char_array_dataframe.return_value = mock_df
    result = mjapi_services.get_meta_by_meta('valid_type', [MagicMock(spec=MjApiArguments)])
    assert result == mock_df
    mock_get_id.assert_called_once_with('valid_type')
    mock_get_meta_char_array_dataframe.assert_called_once()
