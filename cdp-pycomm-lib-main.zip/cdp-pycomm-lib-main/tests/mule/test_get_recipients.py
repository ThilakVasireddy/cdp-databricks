from unittest.mock import patch

from pyspark.sql import Row

from cdp_pycomm_lib.mule.mule_services import get_recipients
from tests.util import spark_fixture


@patch("cdp_pycomm_lib.mule.mule_services.safe_user_repository.get")
@patch("cdp_pycomm_lib.mule.mule_services.safe_user_groups_repository.get")
@patch("cdp_pycomm_lib.mule.mule_services.safe_groups_repository.get")
@patch("cdp_pycomm_lib.mule.mule_services.matlab_model_repository.get")
def test_get_recipients_returns_correct_emails(
        mock_matlab_model_repository,
        mock_safe_groups_repository,
        mock_safe_user_groups_repository,
        mock_safe_user_repository,
        spark_fixture
):
    mock_safe_user_repository.return_value = spark_fixture.createDataFrame(
        [Row(ID=1, EMAIL="user1@example.com"), Row(ID=2, EMAIL="user2@example.com")]
    )
    mock_safe_user_groups_repository.return_value = spark_fixture.createDataFrame(
        [Row(ID=1, SAFE_GROUPS_ID=10), Row(ID=2, SAFE_GROUPS_ID=20)]
    )
    mock_safe_groups_repository.return_value = spark_fixture.createDataFrame(
        [Row(ID=10, NAME="Group1"), Row(ID=20, NAME="Group2")]
    )
    mock_matlab_model_repository.return_value = spark_fixture.createDataFrame(
        [
            Row(MODEL_NAME="TestModel", MODEL_RUN="Run1", NOTIFY_GROUP_ID=10),
            Row(MODEL_NAME="TestModel", MODEL_RUN="Run1", NOTIFY_GROUP_ID=20)
        ]
    )

    result = get_recipients("TestModel", "Run1")
    assert sorted(result) == ["user1@example.com", "user2@example.com"]

    result_emtpy = get_recipients("Model", "Run")
    assert result_emtpy == []
