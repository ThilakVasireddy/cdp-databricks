from unittest.mock import MagicMock

from cdp_pycomm_lib.mule.repository.mule_repositories import (
    SafeUserRepository,
    SafeUserGroupsRepository,
    SafeGroupsRepository,
    MatlabModelRepository
)


def test_retrieves_safe_user_repository_table_name():
    spark_wrapper_mock = MagicMock()
    repository = SafeUserRepository(spark_wrapper_mock, "test_schema")
    assert repository.table_name == "test_schema.SAFE_USER"


def test_retrieves_safe_user_groups_repository_table_name():
    spark_wrapper_mock = MagicMock()
    repository = SafeUserGroupsRepository(spark_wrapper_mock, "test_schema")
    assert repository.table_name == "test_schema.SAFE_USER_GROUPS"


def test_retrieves_safe_groups_repository_table_name():
    spark_wrapper_mock = MagicMock()
    repository = SafeGroupsRepository(spark_wrapper_mock, "test_schema")
    assert repository.table_name == "test_schema.SAFE_GROUPS"


def test_retrieves_matlab_model_repository_table_name():
    spark_wrapper_mock = MagicMock()
    repository = MatlabModelRepository(spark_wrapper_mock, "test_schema")
    assert repository.table_name == "test_schema.MATLAB_MODEL"
