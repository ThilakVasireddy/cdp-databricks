import logging
from unittest.mock import patch, ANY, mock_open

from cdp_pycomm_lib.mule.mule_services import send_mail


@patch('cdp_pycomm_lib.mule.mule_services.smtplib.SMTP')
def test_send_mail_success(mock_smtp):
    mock_server = mock_smtp.return_value
    send_mail(
        ['user@example.com'],
        'Test message',
        'Test subject',
        'sender@example.com',
        None,
        'text/plain'
    )
    mock_server.sendmail.assert_called_once_with(
        'sender@example.com',
        ['user@example.com'],
        ANY
    )
    mock_server.quit.assert_called_once()


@patch('cdp_pycomm_lib.mule.mule_services.smtplib.SMTP')
@patch('builtins.open', new_callable=mock_open, read_data=b'file content')
def test_send_mail_with_attachments(mock_open_method, mock_smtp):
    mock_server = mock_smtp.return_value
    send_mail(
        ['user@example.com'],
        'Test message',
        'Test subject',
        'sender@example.com',
        ['/path/to/file.txt'],
        'text/plain'
    )

    mock_server.sendmail.assert_called_once_with(
        'sender@example.com',
        ['user@example.com'],
        ANY
    )
    mock_open_method.assert_called_once_with('/path/to/file.txt', 'rb')
    mock_server.quit.assert_called_once()


@patch('cdp_pycomm_lib.mule.mule_services.smtplib.SMTP')
def test_send_mail_failure(mock_smtp, caplog):
    mock_smtp.side_effect = Exception('SMTP connection failed')
    with caplog.at_level(logging.ERROR, logger='mule.mule_services'):
        send_mail(
            ['user@example.com'],
            'Test message',
            'Test subject',
            'sender@example.com',
            None,
            'text/plain'
        )
    assert 'Failed to send email: SMTP connection failed' in caplog.text
