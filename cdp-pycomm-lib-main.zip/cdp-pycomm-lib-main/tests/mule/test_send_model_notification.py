from unittest.mock import patch

import pytest

from cdp_pycomm_lib.mule.mule_services import send_model_notification


@patch('cdp_pycomm_lib.mule.mule_services.get_recipients')
@patch('cdp_pycomm_lib.mule.mule_services.send_mail')
def test_when_recipients_found(mock_send_mail, mock_get_recipients):
    mock_get_recipients.return_value = ['receiver_0@example.com', 'receiver_2@example.com']
    result = send_model_notification(
        'model_test',
        'run_test',
        'message',
        'subject',
        'test@lseg.com',
        'attachment.txt',
        'text/html'
    )

    assert result == {"status": 1, "description": "Message sent"}
    mock_get_recipients.assert_called_once_with('model_test', 'run_test')
    mock_send_mail.assert_called_once_with(
        ['receiver_0@example.com', 'receiver_2@example.com'],
        'message',
        'subject',
        'test@lseg.com',
        'attachment.txt',
        'text/html'
    )


@patch('cdp_pycomm_lib.mule.mule_services.get_recipients')
@patch('cdp_pycomm_lib.mule.mule_services.send_mail')
def test_does_not_send_notification_when_no_recipients_found(mock_send_mail, mock_get_recipients):
    mock_get_recipients.return_value = []
    result = send_model_notification('model_test', 'run_test', 'message', 'subject')
    assert result == {"status": -1, "description": "Failed to get the list of recipients"}
    mock_send_mail.assert_not_called()


@patch('cdp_pycomm_lib.mule.mule_services.get_recipients')
@patch('cdp_pycomm_lib.mule.mule_services.send_mail')
def test_handles_exception_during_spark_query(mock_send_mail, mock_get_recipients):
    mock_get_recipients.side_effect = Exception("Spark error")
    with pytest.raises(Exception):
        send_model_notification('model_test', 'run_test', 'message', 'subject')
