from datetime import datetime
from unittest.mock import patch, MagicMock

from pyspark.sql import SparkSession

from cdp_pycomm_lib.cdp_utils import reset_app_config, add_app_config, set_model_run_config, set_spark
from cdp_pycomm_lib.common.cdp_config import CDP_CONFIG, CDP_MODEL


@patch.object(CDP_CONFIG, 'reset_config')
def test_reset_app_config_calls_reset_config(mock_reset_config):
    reset_app_config("test_config_path")
    mock_reset_config.assert_called_once_with("test_config_path")


@patch.object(CDP_CONFIG, 'add_config')
def test_add_app_config_calls_add_config(mock_add_config):
    add_app_config("test_name", "test_value")
    mock_add_config.assert_called_once_with("test_name", "test_value")


def test_set_model_run_config_updates():
    original_model_run = CDP_MODEL.model_run
    original_caller_guid = CDP_MODEL.caller_guid
    original_run_datetime = CDP_MODEL.run_datetime

    test_datetime = datetime(2023, 1, 1)
    test_guid = "test-guid"
    test_model_run = "test_model_run"
    set_model_run_config(test_datetime, test_guid, test_model_run)
    assert CDP_MODEL.model_run == test_model_run
    assert CDP_MODEL.run_datetime == test_datetime
    assert CDP_MODEL.caller_guid == test_guid

    CDP_MODEL.model_run = original_model_run
    CDP_MODEL.run_datetime = original_run_datetime
    CDP_MODEL.caller_guid = original_caller_guid


@patch("cdp_pycomm_lib.cdp_utils.CDP_SPARK")
def test_set_spark_updates_spark_local(mock_cdp_spark):
    mock_spark_session = MagicMock(spec=SparkSession)
    set_spark(mock_spark_session)
    assert mock_cdp_spark.spark_local == mock_spark_session
