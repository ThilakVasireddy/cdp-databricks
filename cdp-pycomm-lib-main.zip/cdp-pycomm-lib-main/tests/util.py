from typing import Optional
from unittest.mock import MagicMock

import pytest
from pyspark.sql import Row
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType

from cdp_pycomm_lib.common.spark_wrapper import SparkWrapper
from cdp_pycomm_lib.common.spark_wrapper import CDP_SPARK


@pytest.fixture(scope="package")
def spark_fixture():
    spark = SparkSession.Builder().master("local[1]").getOrCreate()
    CDP_SPARK.set_spark(spark)
    yield spark
    spark.stop()


def create_spark_wrapper_mock(spark: SparkSession, data: list[Row], schema: Optional[StructType] = None):
    df = spark.createDataFrame(data, schema)
    spark_wrapper_mock = MagicMock(spec=SparkWrapper)
    spark_wrapper_mock.create_data_frame.side_effect = lambda p_data, p_schema: spark.createDataFrame(p_data, p_schema)
    spark_wrapper_mock.table.return_value = df
    return spark_wrapper_mock
