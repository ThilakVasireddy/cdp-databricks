"""
setup.py configuration script describing how to build and package this project.

This file is primarily used by the setuptools library and typically should not
be executed directly. See README.md for how to deploy, test, and run
the ship_position_cleaning project.
"""

from setuptools import setup, find_packages

import sys

sys.path.append("./src/shipping_data_onboarding_package")

import datetime

setup(
    name="shipping_data_onboarding_package",
    # We use timestamp as Local version identifier (https://peps.python.org/pep-0440/#local-version-identifiers.)
    # to ensure that changes to wheel package are picked up when used on all-purpose clusters
    version="0.1.0+" + datetime.datetime.now().strftime("%Y%m%d.%H%M%S"),
    url="https://databricks.com",
    author="auc509204@dvrft.refinitiv.com",
    description="wheel file based on shipping_data_onboarding_bundle/src/shipping_data_onboarding_package",
    packages=find_packages(where="./src/shipping_data_onboarding_package"),
    package_dir={"": "src/shipping_data_onboarding_package"},
    entry_points={"packages": ["main=shipping_data_onboarding_package.main:main"]},
    install_requires=[
        # Dependencies in case the output wheel file is used as a library dependency.
        # For defining dependencies, when this package is used in Databricks, see:
        # https://docs.databricks.com/dev-tools/bundles/library-dependencies.html
        "setuptools"
    ],
)
