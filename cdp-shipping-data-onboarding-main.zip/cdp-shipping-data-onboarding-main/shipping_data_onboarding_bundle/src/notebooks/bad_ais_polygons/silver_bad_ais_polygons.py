# Databricks notebook source
# MAGIC %md
# MAGIC ### [CMDP-3034] Create a table and pipeline to read KML files into delta table
# MAGIC
# MAGIC KML file path is set in config.json file under /Volume
# MAGIC [/shipping_bronze/bronze/config/shipping/kml_files/positions_cleaning/BadPositionZones.kml]
# MAGIC
# MAGIC After tesselation save it into delta table

# COMMAND ----------

import sys
import os
import re

if (config_path := re.split(r"notebooks", os.getcwd())[0] + "config") not in sys.path:
    sys.path.append(config_path)

if (
    package_path := re.split(r"notebooks", os.getcwd())[0] + "shipping_data_onboarding_package"
) not in sys.path:
    sys.path.append(package_path)

# COMMAND ----------

pip install fastkml

# COMMAND ----------

from datetime import datetime
from fastkml.utils import find, find_all
from fastkml import KML
from fastkml import Placemark, Point, StyleUrl, Style, ExtendedData, Data
from typing import Dict, Any, Optional, Iterable

import pyspark.sql.functions as F
import pandas as pd

from bad_ais_polygons.merge_bad_ais_polygons import merge_bad_ais_polygons
from config import Config

# COMMAND ----------

config = Config()

system_catalog_name = config["shared"]["system_catalog_name"]
bronze_schema_name = config["shipping"]["bronze_schema_name"]
silver_schema_name = config["shipping"]["silver_schema_name"]
silver_kml_table_name = config["shipping"]["kml_bad_positions"]["silver_kml_table_name"]
bronze_kml_path = config["shipping"]["kml_bad_positions"]["bronze_kml_path"]

kml_bad_polygons_path = (
    f"/Volumes/{system_catalog_name}/{bronze_schema_name}/{bronze_kml_path}"
)
cdp_file_path = kml_bad_polygons_path
current_datetime = datetime.now()

print(f"{system_catalog_name=}")
print(f"{bronze_schema_name=}")
print(f"{silver_schema_name=}")
print(f"{bronze_kml_path=}")
print(f"{silver_kml_table_name=}")
print(f"{kml_bad_polygons_path=}")
print(f"{cdp_file_path=}")
print(f"{current_datetime=}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Load bad positions zone polygons and assign H3 indices
# MAGIC
# MAGIC https://docs.databricks.com/aws/en/sql/language-manual/functions/h3_tessellateaswkb

# COMMAND ----------

def extract_kml_data():

    k = KML.parse(kml_bad_polygons_path)
    placemarks = list(find_all(k, of_type=Placemark))
    data = list(find_all(k, of_type=Data))
    
    records = []
    for p, d in zip(placemarks, data):
        df_record = pd.DataFrame({
            'perm_id': [d.value],
            'name': [p.name],
            'geometry': [str(p.geometry)]
        })
        records.append(df_record)
    return records


def process_kml_bad_polygons():
    list_of_bad_position_records = extract_kml_data()

    df = spark.createDataFrame(pd.concat(list_of_bad_position_records , ignore_index=True))

    geo_expr = 'geometry'
    res_expr = '6'

    df = (df.withColumn("h3", F.expr(f"explode(h3_tessellateAsWKB({geo_expr},{res_expr}))"))
          .withColumn("cdp_created", F.lit(current_datetime))
          .withColumn("cdp_updated", F.lit(current_datetime))          
          .withColumn("cdp_file_path", F.lit(cdp_file_path)))

    # # Rename columns to match the schema of the silver table
    df = (df.select("perm_id", "name", "h3.*", "cdp_created", "cdp_updated", "cdp_file_path")
          .withColumnRenamed("core", "h3_core")
          .withColumnRenamed("cellid", "h3_cellid")
          .withColumnRenamed("chip", "h3_chip"))    
    
    # Merge logic
    target_table_name = f"{system_catalog_name}.{silver_schema_name}.{silver_kml_table_name}"
    merge_bad_ais_polygons(df, target_table_name)

process_kml_bad_polygons()
