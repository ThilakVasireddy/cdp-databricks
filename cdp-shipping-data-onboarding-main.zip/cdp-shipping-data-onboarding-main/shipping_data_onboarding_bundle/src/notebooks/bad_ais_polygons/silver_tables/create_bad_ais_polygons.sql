-- Databricks notebook source
CREATE WIDGET TEXT catalog_name DEFAULT 'hive_metastore';
CREATE WIDGET TEXT schema_name DEFAULT 'shipping_system';
CREATE WIDGET TEXT table_name DEFAULT 'bad_ais_polygons';

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS IDENTIFIER(:catalog_name || '.' || :schema_name || '.' || :table_name)
(
  perm_id                   BIGINT,
  name                      STRING,
  h3_cellid                 STRING,
  h3_core                   BOOLEAN,
  h3_chip                   BINARY,
  cdp_created               TIMESTAMP,
  cdp_updated               TIMESTAMP,
  cdp_file_path             STRING
)
USING DELTA
CLUSTER BY (perm_id, h3_cellid)
