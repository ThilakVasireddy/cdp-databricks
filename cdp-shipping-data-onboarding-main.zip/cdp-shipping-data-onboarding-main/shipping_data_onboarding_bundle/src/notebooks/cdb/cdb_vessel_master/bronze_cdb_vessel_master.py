# Databricks notebook source
# MAGIC %md
# MAGIC # Oracle SQL query
# MAGIC ```sql
# MAGIC   (select /*+ cardinality(p_lst 1) */
# MAGIC      p_lst.perm_id perm_id,
# MAGIC      ves.imo imo,
# MAGIC      ves.mmsi mmsi,
# MAGIC      ves.deadeadwight dwt,
# MAGIC      ves.loa loa,
# MAGIC      ves.cubic_capacity cubic_capacity,
# MAGIC      ves.beam beam,
# MAGIC      ves.draft draft,
# MAGIC      ves.teu teu,
# MAGIC      case
# MAGIC        when lower (ves.hull_style) like '%double%' then 'Double Hull'
# MAGIC        when lower (ves.hull_style) like '%single%' then 'Single Hull'
# MAGIC        else null
# MAGIC      end
# MAGIC        hull_style,
# MAGIC      ves.bottom_style bottom_style,
# MAGIC      ves.side_style side_style,
# MAGIC      decode (ves.coated,  'Y', 'Y',  'N', 'N',  null) coated,
# MAGIC      decode (ves.is_deactived,  'Y', 'Y',  'N', 'N',  null) is_deactived,
# MAGIC      (select   decode (cde.status,  'C', 'Y',  'D', 'N',  null)
# MAGIC         from   cef_cnr.vessel_clean_dirty_factor cde
# MAGIC        where   cde.ves_id = ves.id and cde.against_vcd_id is null
# MAGIC             and cde.effective_to is null and rownum <= 1)
# MAGIC        product,
# MAGIC      ves.tpc tpc,
# MAGIC      ves.built built,
# MAGIC      ves.built_initial built_initial,
# MAGIC      ves.built_demolition built_demolition,
# MAGIC      relation_object_id_type (gun.gun_perm_id,
# MAGIC           404007,
# MAGIC           'Geography',
# MAGIC           cef_cnr.pas_distribution_pkg.get_pas_rship_type_perm_id_fn ('SailsUnderFlagOf'),
# MAGIC           'SailsUnderFlagOf',
# MAGIC           pas.perm_id,
# MAGIC           404088,
# MAGIC           'CommodityPhysicalAsset',
# MAGIC           pas.entity_created_date)
# MAGIC        flag_id,
# MAGIC      --flag.id              flag_id,
# MAGIC      flag.flag_name flag_name,
# MAGIC      flag.flag_abrevation flag_iso,
# MAGIC      gud.rcs_code flag_rcs
# MAGIC      --Add fields to SDI CDB-2473 Edited by Jeff 2020-05-11
# MAGIC      --,(select vvd.vt_value from cef_cnr.vt_vessel_detail vvd where vvd.ves_id = ves.id
# MAGIC      --   and vvd.vt_name = 'SPEED CONSUMPT') SPEED_CONSUMPT --removed
# MAGIC      (select vvd.vt_value from cef_cnr.vt_vessel_detail vvd where vvd.ves_id = ves.id
# MAGIC         and vvd.vt_name = 'BENEFICIAL OWNER') BENEFICIAL_OWNER
# MAGIC      (select vvd.vt_value from cef_cnr.vt_vessel_detail vvd where vvd.ves_id = ves.id
# MAGIC         and vvd.vt_name = 'GROSS TONNAGE') GROSS_TONNAGE
# MAGIC      (select vvd.vt_value from cef_cnr.vt_vessel_detail vvd where vvd.ves_id = ves.id
# MAGIC         and vvd.vt_name = 'FUEL TYPE') FUEL_TYPE
# MAGIC      to_char(ves.built,'yyyy') YEAR_OF_BUILD
# MAGIC      (select vvd.vt_value from cef_cnr.vt_vessel_detail vvd where vvd.ves_id = ves.id
# MAGIC         and vvd.vt_name = 'BUILDER') BUILDER
# MAGIC      (select vvd.vt_value from cef_cnr.vt_vessel_detail vvd where vvd.ves_id = ves.id
# MAGIC         and vvd.vt_name = 'BUILDER COUNTRY') BUILDER_COUNTRY
# MAGIC      (select vvd.vt_value from cef_cnr.vt_vessel_detail vvd where vvd.ves_id = ves.id
# MAGIC         and vvd.vt_name = 'SCRUBBER FITTED') SCRUBBER_FITTED
# MAGIC      (select vvd.vt_value from cef_cnr.vt_vessel_detail vvd where vvd.ves_id = ves.id
# MAGIC         and vvd.vt_name = 'SCRUBBER READY') SCRUBBER_READY
# MAGIC      (select vvd.vt_value from cef_cnr.vt_vessel_detail vvd where vvd.ves_id = ves.id
# MAGIC         and vvd.vt_name = 'SCRUBBER PLANNED') SCRUBBER_PLANNED
# MAGIC      (select vvd.vt_value from cef_cnr.vt_vessel_detail vvd where vvd.ves_id = ves.id
# MAGIC         and vvd.vt_name = 'SCRUBBER TYPE') SCRUBBER_TYPE
# MAGIC      --End Add fields to SDI CDB-2473 Edited by Jeff 2020-05-11
# MAGIC      --Add fields to SDI CDB-6811 Edited by jingjingdong 2024-01-24
# MAGIC      (select vvd.vt_value from cef_cnr.vt_vessel_detail vvd where vvd.ves_id = ves.id
# MAGIC         and vvd.vt_name = 'JONES ACT FLAG' and VT_SECTION = 'GENERAL') JONES_ACT_FLAG
# MAGIC      (select vvd.vt_value from cef_cnr.vt_vessel_detail vvd where vvd.ves_id = ves.id
# MAGIC         and vvd.vt_name = 'ICE CLASS' and VT_SECTION = 'CLASSIFICATION') ICE_CLASS
# MAGIC      (select vvd.vt_value from cef_cnr.vt_vessel_detail vvd where vvd.ves_id = ves.id
# MAGIC         and vvd.vt_name = 'MAIN ENGINE' and VT_SECTION = 'ENGINE' ) MAIN_ENGINE
# MAGIC      (select vvd.vt_value from cef_cnr.vt_vessel_detail vvd where vvd.ves_id = ves.id
# MAGIC         and vvd.vt_name = 'MAIN ENGINE MODEL' and VT_SECTION = 'ENGINE') Main_Engine_Model
# MAGIC      --Add fields to SDI CDB-6811  Edited by jingjingdong 2024-01-24
# MAGIC      from   cef_cnr.vessel ves,
# MAGIC        cef_cnr.physical_asset pas,
# MAGIC        cef_cnr.vessel_flag flag,
# MAGIC        (select   perm_id
# MAGIC           from   sdi_asset_list
# MAGIC          where   indicator = 'F') p_lst,
# MAGIC        mpd2_cnr.geographic_unit gun,
# MAGIC        (select   *
# MAGIC           from   mpd2_cnr.geographic_unit_detail
# MAGIC          where   effective_to is null) gud
# MAGIC      where       ves.id = pas.ves_id
# MAGIC        and pas.perm_id = p_lst.perm_id
# MAGIC        and ves.vfl_id = flag.id(+)
# MAGIC        and flag.gun_id = gun.geographic_unit_id(+)
# MAGIC        and flag.gun_id = gud.gun_id(+)
# MAGIC   order by   perm_id
# MAGIC   unused_table_alias
# MAGIC ```
# MAGIC ## Notes on query
# MAGIC - oracle SQL dialect
# MAGIC - `ves.deadeadwight` is the actual name
# MAGIC - The original query was provided with some variables. Platform team helped me
# MAGIC - in addition to the JDBC driver, the above query requires xdb or xdb6 to run c.f.
# MAGIC https://stackoverflow.com/questions/33790239/oracle-jdbc-xmltype-noclassdeffounderror.
# MAGIC  **However** in this case `flag_id` is identified as a string
# MAGIC and all returned values are `null` which is wrong.
# MAGIC The issue is that `relation_object_id_type` is a custom type like a struct
# MAGIC  that doesn't get read correctly.
# MAGIC   - Our workaround below modifies the query to flatten out the struct,
# MAGIC  by pulling out each of the attributes of the type.
# MAGIC This final query does not need xdb. From inspecting the database,
# MAGIC  the flag_id has the following fields/attributes:
# MAGIC   ```sql
# MAGIC   object_id               number,
# MAGIC   relation_object_type_id number,
# MAGIC   relation_object_type    varchar2(100),
# MAGIC   relationship_id         number,
# MAGIC   relationship_type_id    number,
# MAGIC   related_object_id       number,
# MAGIC   related_object_type_id  number,
# MAGIC   related_object_type     varchar2(100),
# MAGIC   relation_role           number,
# MAGIC   relationship_type       varchar2(100),
# MAGIC   relationship_confidence float,
# MAGIC   relation_object_na_code varchar2(100),
# MAGIC   related_object_order    number,
# MAGIC   relation_object_order   number,
# MAGIC   effective_from          date,
# MAGIC   effective_to            date,
# MAGIC   ```
# MAGIC
# MAGIC

# COMMAND ----------

# DBTITLE 1,Imports
from datetime import datetime
import pyspark.sql.functions as F

# COMMAND ----------

# DBTITLE 1,add to sys path

def append_to_sys_path(folder: str) -> str:
    import re
    import os
    import sys

    if (path := re.split("notebooks", os.getcwd())[0] + folder) not in sys.path:
        sys.path.append(path)
    return path


append_to_sys_path("config")

# COMMAND ----------

# DBTITLE 1,Variables
from config import Config

config = Config()
shipping = config["shipping"]

server = shipping["cdb"]["server_name"]
service = shipping["cdb"]["service_name"]
jdbc_url = f"jdbc:oracle:thin:@//{server}:1521/{service}"

user_name = config["shipping"]["cdb_vessel_master_credentials"]["user_name"]
password = dbutils.secrets.get(
    config["shipping"]["secret_scope"],
    key=config["shipping"]["cdb_vessel_master_credentials"]["secret_scope_key"],
)


connection_properties = {
    "user": user_name,
    "password": password,
    "driver": "oracle.jdbc.driver.OracleDriver",
}
now = datetime.now()

shipping_catalog = shipping["catalog_name"]
bronze_schema = shipping["bronze_schema_name"]
table_name = "cdb_vessel_master"
full_table_name = f"{shipping_catalog}.{bronze_schema}.{table_name}"
print(
    f"""
{server=}
{service=}
{jdbc_url=}
{user_name=}
{shipping_catalog=}
{bronze_schema=}
{table_name=}
{full_table_name=}
""".strip()
)

# COMMAND ----------

# DBTITLE 1,JDBC query
fields = [  # manually created list by inspecting cdb
    "object_id",
    "relation_object_type_id",
    "relation_object_type",
    "relationship_id",
    "relationship_type_id",
    "related_object_id",
    "related_object_type_id",
    "related_object_type",
    "relation_role",
    "relationship_type",
    "relationship_confidence",
    "relation_object_na_code",
    "related_object_order",
    "relation_object_order",
    "effective_from",
    "effective_to",
]


def extract_field(expr, field, prefix, comma=True):
    return f"{expr}.{field} {prefix}_{field}{',' if comma else ''}"


def extract_fields(expr, fields, prefix, comma=True):
    return "\n".join([extract_field(expr, field, prefix, comma) for field in fields])


relation_object_id_type = """
    relation_object_id_type (gun.gun_perm_id,
         404007,
         'Geography',
         cef_cnr.pas_distribution_pkg.get_pas_rship_type_perm_id_fn ('SailsUnderFlagOf'),
         'SailsUnderFlagOf',
         pas.perm_id,
         404088,
         'CommodityPhysicalAsset',
         pas.entity_created_date)
"""
field_name = "relation_role"
prefix = "flag"

query_part = extract_field(relation_object_id_type, field_name, prefix)
query = f"""
        (
    select /*+ cardinality(p_lst 1) */
       p_lst.perm_id perm_id,
       ves.imo imo,
       ves.mmsi mmsi,
       ves.deadeadwight dwt,
       ves.loa loa,
       ves.cubic_capacity cubic_capacity,
       ves.beam beam,
       ves.draft draft,
       ves.teu teu,
       case
         when lower (ves.hull_style) like '%double%' then 'Double Hull'
         when lower (ves.hull_style) like '%single%' then 'Single Hull'
         else null
       end
         hull_style,
       ves.bottom_style bottom_style,
       ves.side_style side_style,
       decode (ves.coated,  'Y', 'Y',  'N', 'N',  null) coated,
       decode (ves.is_deactived,  'Y', 'Y',  'N', 'N',  null) is_deactived,
       (select   decode (cde.status,  'C', 'Y',  'D', 'N',  null)
          from   cef_cnr.vessel_clean_dirty_factor cde
         where   cde.ves_id = ves.id and cde.against_vcd_id is null
            and cde.effective_to is null and rownum <= 1)
         product,
       ves.tpc tpc,
       ves.built built,
       ves.built_initial built_initial,
       ves.built_demolition built_demolition,
       {extract_fields(relation_object_id_type, fields, "flag_id")}
       --flag.id              flag_id,
       flag.flag_name flag_name,
       flag.flag_abrevation flag_iso,
       gud.rcs_code flag_rcs
       --Add fields to SDI CDB-2473 Edited by Jeff 2020-05-11
      --,(select vvd.vt_value from cef_cnr.vt_vessel_detail vvd where vvd.ves_id = ves.id
      --      and vvd.vt_name = 'SPEED CONSUMPT') SPEED_CONSUMPT --removed
      ,(select vvd.vt_value from cef_cnr.vt_vessel_detail vvd where vvd.ves_id = ves.id
            and vvd.vt_name = 'BENEFICIAL OWNER') BENEFICIAL_OWNER
      ,(select vvd.vt_value from cef_cnr.vt_vessel_detail vvd where vvd.ves_id = ves.id
            and vvd.vt_name = 'GROSS TONNAGE') GROSS_TONNAGE
      ,(select vvd.vt_value from cef_cnr.vt_vessel_detail vvd where vvd.ves_id = ves.id
            and vvd.vt_name = 'FUEL TYPE') FUEL_TYPE
      ,to_char(ves.built,'yyyy') YEAR_OF_BUILD
      ,(select vvd.vt_value from cef_cnr.vt_vessel_detail vvd where vvd.ves_id = ves.id
            and vvd.vt_name = 'BUILDER') BUILDER
      ,(select vvd.vt_value from cef_cnr.vt_vessel_detail vvd where vvd.ves_id = ves.id
            and vvd.vt_name = 'BUILDER COUNTRY') BUILDER_COUNTRY
      ,(select vvd.vt_value from cef_cnr.vt_vessel_detail vvd where vvd.ves_id = ves.id
            and vvd.vt_name = 'SCRUBBER FITTED') SCRUBBER_FITTED
      ,(select vvd.vt_value from cef_cnr.vt_vessel_detail vvd where vvd.ves_id = ves.id
            and vvd.vt_name = 'SCRUBBER READY') SCRUBBER_READY
      ,(select vvd.vt_value from cef_cnr.vt_vessel_detail vvd where vvd.ves_id = ves.id
            and vvd.vt_name = 'SCRUBBER PLANNED') SCRUBBER_PLANNED
      ,(select vvd.vt_value from cef_cnr.vt_vessel_detail vvd where vvd.ves_id = ves.id
            and vvd.vt_name = 'SCRUBBER TYPE') SCRUBBER_TYPE
       --End Add fields to SDI CDB-2473 Edited by Jeff 2020-05-11
       --Add fields to SDI CDB-6811 Edited by jingjingdong 2024-01-24
      ,(select vvd.vt_value from cef_cnr.vt_vessel_detail vvd where vvd.ves_id = ves.id
            and vvd.vt_name = 'JONES ACT FLAG' and VT_SECTION = 'GENERAL') JONES_ACT_FLAG
      ,(select vvd.vt_value from cef_cnr.vt_vessel_detail vvd where vvd.ves_id = ves.id
            and vvd.vt_name = 'ICE CLASS' and VT_SECTION = 'CLASSIFICATION') ICE_CLASS
      ,(select vvd.vt_value from cef_cnr.vt_vessel_detail vvd where vvd.ves_id = ves.id
            and vvd.vt_name = 'MAIN ENGINE' and VT_SECTION = 'ENGINE' ) MAIN_ENGINE
      ,(select vvd.vt_value from cef_cnr.vt_vessel_detail vvd where vvd.ves_id = ves.id
            and vvd.vt_name = 'MAIN ENGINE MODEL' and  VT_SECTION = 'ENGINE' ) Main_Engine_Model
       --Add fields to SDI CDB-6811  Edited by jingjingdong 2024-01-24
    from   cef_cnr.vessel ves,
        cef_cnr.physical_asset pas,
        cef_cnr.vessel_flag flag,
        (select   perm_id
           from   sdi_asset_list
          where   indicator = 'F') p_lst,
        mpd2_cnr.geographic_unit gun,
        (select   *
           from   mpd2_cnr.geographic_unit_detail
          where   effective_to is null) gud
    where       ves.id = pas.ves_id
        and pas.perm_id = p_lst.perm_id
        and ves.vfl_id = flag.id(+)
        and flag.gun_id = gun.geographic_unit_id(+)
        and flag.gun_id = gud.gun_id(+)
    order by   perm_id
    ) unused_table_alias
    """

df_oracle = spark.read.jdbc(
    url=jdbc_url,
    properties=connection_properties,
    table=query,  # some table name is required for correct SQL syntax
)
print(query)

# COMMAND ----------

# DBTITLE 1,Add column and sanity check

df_oracle = df_oracle.withColumn("cdp_created", F.lit(now))

# sanity check
small_df = df_oracle.limit(3)
display(small_df)

# COMMAND ----------

print(small_df.schema)

# COMMAND ----------

# DBTITLE 1,Write to databricks
df_oracle.write.mode("overwrite").saveAsTable(full_table_name)
