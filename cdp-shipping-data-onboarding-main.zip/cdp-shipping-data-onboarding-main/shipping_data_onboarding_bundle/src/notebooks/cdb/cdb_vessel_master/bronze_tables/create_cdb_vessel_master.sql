-- Databricks notebook source
CREATE WIDGET TEXT catalog_name DEFAULT "";
CREATE WIDGET TEXT schema_name DEFAULT "";
CREATE WIDGET TEXT table_name DEFAULT "cdb_vessel_master";

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS IDENTIFIER(:catalog_name || '.' || :schema_name || '.' || :table_name) (
    PERM_ID                             DECIMAL(38,0),
    IMO                                 STRING,
    MMSI                                DECIMAL(15,0),
    DWT                                 DECIMAL(38,10),
    LOA                                 DECIMAL(38,10),
    CUBIC_CAPACITY                      DECIMAL(38,10),
    BEAM                                DECIMAL(38,10),
    DRAFT                               DECIMAL(38,10),
    TEU                                 DECIMAL(38,10),
    HULL_STYLE                          STRING,
    BOTTOM_STYLE                        STRING,
    SIDE_STYLE                          STRING,
    COATED                              STRING,
    IS_DEACTIVED                        STRING,
    PRODUCT                             STRING,
    TPC                                 DECIMAL(38,10),
    BUILT                               TIMESTAMP,
    BUILT_INITIAL                       TIMESTAMP,
    BUILT_DEMOLITION                    TIMESTAMP,
    FLAG_ID_OBJECT_ID                   DECIMAL(38,10),
    FLAG_ID_RELATION_OBJECT_TYPE_ID     DECIMAL(38,10),
    FLAG_ID_RELATION_OBJECT_TYPE        STRING,
    FLAG_ID_RELATIONSHIP_ID             DECIMAL(38,10),
    FLAG_ID_RELATIONSHIP_TYPE_ID        DECIMAL(38,10),
    FLAG_ID_RELATED_OBJECT_ID           DECIMAL(38,10),
    FLAG_ID_RELATED_OBJECT_TYPE_ID      DECIMAL(38,10),
    FLAG_ID_RELATED_OBJECT_TYPE         STRING,
    FLAG_ID_RELATION_ROLE               DECIMAL(38,10),
    FLAG_ID_RELATIONSHIP_TYPE           STRING,
    FLAG_ID_RELATIONSHIP_CONFIDENCE     DECIMAL(38,10),
    FLAG_ID_RELATION_OBJECT_NA_CODE     STRING,
    FLAG_ID_RELATED_OBJECT_ORDER        DECIMAL(38,10),
    FLAG_ID_RELATION_OBJECT_ORDER       DECIMAL(38,10),
    FLAG_ID_EFFECTIVE_FROM              TIMESTAMP,
    FLAG_ID_EFFECTIVE_TO                TIMESTAMP,
    FLAG_NAME                           STRING,
    FLAG_ISO                            STRING,
    FLAG_RCS                            STRING,
    BENEFICIAL_OWNER                    STRING,
    GROSS_TONNAGE                       STRING,
    FUEL_TYPE                           STRING,
    YEAR_OF_BUILD                       STRING,
    BUILDER                             STRING,
    BUILDER_COUNTRY                     STRING,
    SCRUBBER_FITTED                     STRING,
    SCRUBBER_READY                      STRING,
    SCRUBBER_PLANNED                    STRING,
    SCRUBBER_TYPE                       STRING,
    JONES_ACT_FLAG                      STRING,
    ICE_CLASS                           STRING,
    MAIN_ENGINE                         STRING,
    MAIN_ENGINE_MODEL                   STRING,
    cdp_created                         TIMESTAMP NOT NULL
)
CLUSTER BY (IMO, PERM_ID)

-- COMMAND ----------

