# Databricks notebook source
# MAGIC %md
# MAGIC # Bronze -> Silver
# MAGIC (https://jira.refinitiv.com/browse/CMDP-872)
# MAGIC - very minor cleaning of data
# MAGIC - lowercasing of field names

# COMMAND ----------

from datetime import datetime

# COMMAND ----------


def append_to_sys_path(folder: str) -> str:
    import re
    import os
    import sys

    if (path := re.split("notebooks", os.getcwd())[0] + folder) not in sys.path:
        sys.path.append(path)
    return path


append_to_sys_path("config")

# COMMAND ----------

from config import Config

config = Config()
shipping = config["shipping"]

now = datetime.now()

shipping_catalog = shipping["catalog_name"]
bronze_schema = shipping["bronze_schema_name"]
silver_schema = shipping["silver_schema_name"]
table_name = "cdb_vessel_master"
bronze_table_name = f"{shipping_catalog}.{bronze_schema}.{table_name}"
silver_table_name = f"{shipping_catalog}.{silver_schema}.{table_name}"
print(
    f"""
{shipping_catalog=}
{bronze_schema=}
{silver_schema=}
{table_name=}
{bronze_table_name=}
{silver_table_name=}
""".strip()
)

# COMMAND ----------

dbutils.notebook.run(
    "silver_tables/merge_cdb_vessel_master",
    1600,
    {
        "bronze_table_name": bronze_table_name,
        "silver_table_name": silver_table_name,
    },
)
