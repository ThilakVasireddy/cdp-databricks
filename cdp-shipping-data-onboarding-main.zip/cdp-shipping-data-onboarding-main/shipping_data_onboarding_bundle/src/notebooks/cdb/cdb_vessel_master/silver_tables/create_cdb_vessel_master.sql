-- Databricks notebook source
CREATE WIDGET TEXT catalog_name DEFAULT "";
CREATE WIDGET TEXT schema_name DEFAULT "";
CREATE WIDGET TEXT table_name DEFAULT "cdb_vessel_master";

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS IDENTIFIER(:catalog_name || '.' || :schema_name || '.' || :table_name) (
    perm_id                          DECIMAL(38,0),
    imo                              STRING,
    mmsi                             DECIMAL(15,0),
    dwt                              DECIMAL(38,10),
    loa                              DECIMAL(38,10),
    cubic_capacity                   DECIMAL(38,10),
    beam                             DECIMAL(38,10),
    draft                            DECIMAL(38,10),
    teu                              DECIMAL(38,10),
    hull_style                       STRING,
    bottom_style                     STRING,
    side_style                       STRING,
    coated                           BOOLEAN, -- Y or null in bronze
    is_deactived                     BOOLEAN, -- Y/N in bronze
    product                          BOOLEAN, -- Y/N in bronze
    tpc                              DECIMAL(38,10),
    built                            TIMESTAMP, 
    built_initial                    TIMESTAMP,
    built_demolition                 TIMESTAMP,
    flag_id_object_id                DECIMAL(38,0), -- changed from DECIMAL(38,10) in bronze 
    flag_id_relation_object_type_id  DECIMAL(38,0), -- changed from DECIMAL(38,10) in bronze 
    flag_id_relation_object_type     STRING,
    flag_id_relationship_id          DECIMAL(38,0), -- changed from DECIMAL(38,10) in bronze 
    flag_id_relationship_type_id     DECIMAL(38,0), -- changed from DECIMAL(38,10) in bronze 
    flag_id_related_object_id        DECIMAL(38,0), -- changed from DECIMAL(38,10) in bronze 
    flag_id_related_object_type_id   DECIMAL(38,0), -- changed from DECIMAL(38,10) in bronze 
    flag_id_related_object_type      STRING,
    flag_id_relation_role            DECIMAL(38,10),
    flag_id_relationship_type        STRING,
    flag_id_relationship_confidence  DECIMAL(38,10),
    flag_id_relation_object_na_code  STRING,
    flag_id_related_object_order     DECIMAL(38,10),
    flag_id_relation_object_order    DECIMAL(38,10),
    flag_id_effective_from           TIMESTAMP,
    flag_id_effective_to             TIMESTAMP,
    flag_name                        STRING,
    flag_iso                         STRING,
    flag_rcs                         STRING,
    beneficial_owner                 STRING,
    gross_tonnage                    DECIMAL(38,10), -- changed from string in bronze
    fuel_type                        STRING,
    year_of_build                    INT,
    builder                          STRING,
    builder_country                  STRING,
    scrubber_fitted                  BOOLEAN, -- Yes/No in bronze
    scrubber_ready                   BOOLEAN, -- Yes/null in bronze
    scrubber_planned                 BOOLEAN, -- Yes/No in bronze
    scrubber_type                    STRING,
    jones_act_flag                   BOOLEAN, -- Y/N in bronze
    ice_class                        STRING,
    main_engine                      STRING,
    main_engine_model                STRING,
    cdp_created                      TIMESTAMP
)
CLUSTER BY (imo, perm_id)