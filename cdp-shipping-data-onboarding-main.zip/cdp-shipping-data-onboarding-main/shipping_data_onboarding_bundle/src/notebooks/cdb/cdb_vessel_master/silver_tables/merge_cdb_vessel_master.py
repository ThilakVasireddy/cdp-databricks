# Databricks notebook source
import pyspark.sql.functions as F
from pyspark.sql import Column

# COMMAND ----------

dbutils.widgets.text(
    "bronze_table_name", "cdp_dev_sandbox_catalog_01.shipping_bronze.cdb_vessel_master"
)
dbutils.widgets.text(
    "silver_table_name", "cdp_dev_sandbox_catalog_01.shipping_silver.cdb_vessel_master"
)

# COMMAND ----------

bronze_table_name = dbutils.widgets.get("bronze_table_name")
silver_table_name = dbutils.widgets.get("silver_table_name")


print(f"""
{bronze_table_name=}
{silver_table_name=}
""")

# COMMAND ----------

# MAGIC %md
# MAGIC Validate basic assumptions:
# MAGIC - GROSS_TONNAGE should be convertible to `DECIMAL(38,10)`
# MAGIC - YEAR_OF_BUILD should be convertible to `INT`
# MAGIC - FLAG_ID_*_ID fields should be convertible to `DECIMAL(38,0)`
# MAGIC - various boolean-ish cols can be converted to `BOOLEAN`

# COMMAND ----------

# DBTITLE 1,Validate GROSS_TONNAGE
# Check if the GROSS_TONNAGE column can be converted

bronze_df = spark.read.table(bronze_table_name)

convertible_df = spark.sql(f"""
    SELECT *,
           CASE
               WHEN GROSS_TONNAGE IS NULL THEN TRUE
               WHEN CAST(GROSS_TONNAGE AS DECIMAL(38,10)) IS NOT NULL THEN True
               ELSE False
           END AS is_convertible
    FROM {bronze_table_name}
""")
convertible_count = (
    convertible_df.filter(F.col("is_convertible"))
    .select(F.count("is_convertible"))
    .collect()[0][0]
)
remaining_count = convertible_df.count() - convertible_count
if remaining_count != 0:
    print(remaining_count)
    dbutils.notebook.exit(
        f"Error: {remaining_count} rows in {bronze_table_name} have non-convertible "
        f"GROSS_TONNAGE values to DECIMAL(38,10)."
    )

# COMMAND ----------

# DBTITLE 1,Validate YEAR_OF_BUILD column conversion
# Check if the YEAR_OF_BUILD column can be converted

convertible_df = bronze_df.withColumn(
    "is_convertible",
    F.when(F.col("YEAR_OF_BUILD").isNull(), True)
    .when(F.col("YEAR_OF_BUILD").cast("INT").isNotNull(), True)
    .otherwise(False),
)

convertible_count = convertible_df.filter(F.col("is_convertible")).count()
remaining_count = convertible_df.count() - convertible_count

if remaining_count != 0:
    display(convertible_df.filter(not F.col("is_convertible")))
    dbutils.notebook.exit(
        f"Error: {remaining_count} rows in {bronze_table_name} have non-convertible "
        f"YEAR_OF_BUILD values to INT."
    )

# COMMAND ----------

# DBTITLE 1,Validate flag_id_*_id
flag_id_id_cols = [
    col.lower() for col in bronze_df.columns if col.startswith("FLAG_ID") and col.endswith("ID")
]
for col_name in flag_id_id_cols:
    print(col_name, bronze_df.schema[col_name.upper()].dataType)

assert len(flag_id_id_cols) == 6

filtered_df = bronze_df.na.drop(subset=flag_id_id_cols)
casted_df = filtered_df

for col_name in flag_id_id_cols:
    casted_df = casted_df.withColumn(
        col_name + "_can_cast", F.col(col_name).cast("DECIMAL(38,0)").isNotNull()
    )
    casted_df = casted_df.filter(~F.col(col_name + "_can_cast"))
    if casted_df.count() > 0:
        display(casted_df)
        dbutils.notebook.exit(
            f"Error: {col_name} contains non-convertible values to DECIMAL(38,0)."
        )

# COMMAND ----------

# DBTITLE 1,Validate boolean cols
boolean_cols = [
    "coated",
    "is_deactived",
    "product",
    "jones_act_flag",
    "scrubber_fitted",
    "scrubber_ready",
    "scrubber_planned",
]

for col_name in boolean_cols:
    invalid_values_df = bronze_df.filter(
        ~(F.lower(F.col(col_name)).isin("y", "yes", "n", "no") | F.col(col_name).isNull())
    )
    if invalid_values_df.count() > 0:
        display(invalid_values_df)
        dbutils.notebook.exit(
            f"Error: {col_name} contains invalid values, cannot convert to bool."
        )

# COMMAND ----------


class UnknownDataTypeException(Exception):
    pass


columns_dict = {
    "boolean": boolean_cols,
    "decimal_38_0": flag_id_id_cols,
    "decimal_38_10": ["gross_tonnage"],
    "int": ["year_of_build"],
}


def cast_expr(dtype: str, col_name: str) -> Column:
    match dtype:
        case "boolean":
            return F.expr(
                f"CASE WHEN lower({col_name}) = 'y' OR lower({col_name}) = 'yes' THEN true "
                f"WHEN lower({col_name}) = 'n' OR lower({col_name}) = 'no' THEN false "
                "ELSE NULL END"
            )
        case "decimal_38_10":
            return F.col(col_name).cast("decimal(38, 10)")
        case "decimal_38_0":
            return F.col(col_name).cast("decimal(38, 0)")
        case "int":
            return F.col(col_name).cast("int")
        case _:
            raise UnknownDataTypeException("Found unknown data type")


# COMMAND ----------

silver_df = bronze_df.toDF(*[col.lower() for col in bronze_df.columns])
display(silver_df.limit(10))

# COMMAND ----------

for dtype, cols in columns_dict.items():
    for col_name in cols:
        silver_df = silver_df.withColumn(col_name, cast_expr(dtype, col_name))

display(silver_df.limit(10))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Minor cleanup:
# MAGIC - there is a data warehousing row with IMO 9999999 with meaningless -1 entries
# MAGIC - IDs with the exact value of 0 should instead be nulls. Similarly for other measurements
# MAGIC
# MAGIC Note that the data is still **not** properly cleaned after this.
# MAGIC There are other invalid IMOs

# COMMAND ----------

silver_df = silver_df.filter((F.col("imo") != 9_999_999) | F.col("imo").isNull())
for nonzero_col in [
    "perm_id",
    "imo",  # International Maritime Organization number
    "mmsi",  # Maritime Mobile Service Identity
    "dwt",  # Deadweight tonnage
    "loa",  # Length overall
    "cubic_capacity",  # Volume capacity
    "beam",  # Width of the ship
    "draft",  # Vertical distance between the waterline and the bottom of the hull
    "teu",  # Twenty-foot Equivalent Unit
    "tpc",  # Tonnes per Centimetre immersion
    "gross_tonnage",  # Internal volume of the ship
    "year_of_build",  # Year the ship was built
] + flag_id_id_cols:
    silver_df = silver_df.withColumn(
        nonzero_col, F.when(F.col(nonzero_col) == 0, None).otherwise(F.col(nonzero_col))
    )

display(silver_df.limit(500))

# COMMAND ----------

silver_df.write.mode("overwrite").saveAsTable(silver_table_name)

dbutils.notebook.exit(
    {
        "silver_full_name": silver_table_name,
        "silver_row_count": silver_df.count(),
        "silver_column_count": len(silver_df.columns),
        "bronze_full_name": bronze_table_name,
        "bronze_row_count": bronze_df.count(),
        "bronze_column_count": len(bronze_df.columns),
    }
)
