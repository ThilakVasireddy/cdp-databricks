# Databricks notebook source
# MAGIC %md
# MAGIC Original query:
# MAGIC ```sql
# MAGIC select vv.imo, n.*
# MAGIC from physical_asset_name n
# MAGIC join physical_asset pa
# MAGIC on pa.perm_id = n.pas_perm_id
# MAGIC inner join vt_vessel_m_v vv
# MAGIC on vv.ves_id = pa.ves_id
# MAGIC order by vv.imo, n.effective_from;
# MAGIC ```
# MAGIC we have modified:
# MAGIC - renamed some fields
# MAGIC - removed the order by as spark partitions the data in a distributed and unordered manner
# MAGIC - added `cdp_created` audit column which is the start time of this notebook.

# COMMAND ----------

# DBTITLE 1,Imports
from datetime import datetime
import pyspark.sql.functions as F

# COMMAND ----------

# DBTITLE 1,add to sys path

def append_to_sys_path(folder: str) -> str:
    import re
    import os
    import sys

    if (path := re.split("notebooks", os.getcwd())[0] + folder) not in sys.path:
        sys.path.append(path)
    return path


append_to_sys_path("config")

# COMMAND ----------

# DBTITLE 1,Variables
from config import Config

config = Config()
shipping = config["shipping"]

server = shipping["cdb"]["server_name"]
service = shipping["cdb"]["service_name"]
jdbc_url = f"jdbc:oracle:thin:@//{server}:1521/{service}"

user_name = config["shipping"]["cdb_vessel_name_credentials"]["user_name"]
password = dbutils.secrets.get(
    config["shipping"]["secret_scope"],
    key=config["shipping"]["cdb_vessel_name_credentials"]["secret_scope_key"],
)

connection_properties = {
    "user": user_name,
    "password": password,
    "driver": "oracle.jdbc.driver.OracleDriver",
}
now = datetime.now()

shipping_catalog = shipping["catalog_name"]
silver_schema = shipping["silver_schema_name"]
table_name = "cdb_vessel_name_history"
full_table_name = f"{shipping_catalog}.{silver_schema}.{table_name}"
print(
    f"""
{server=}
{service=}
{jdbc_url=}
{user_name=}
{shipping_catalog=}
{silver_schema=}
{table_name=}
{full_table_name=}
""".strip()
)

# COMMAND ----------

# DBTITLE 1,JDBC query
df_oracle = spark.read.jdbc(
    url=jdbc_url,
    properties=connection_properties,
    table="""
        (
            SELECT
                vv.imo,
                n.id,
                n.pas_perm_id AS physical_asset_perm_id,
                n.value AS vessel_name,
                n.effective_from,
                n.effective_to
            FROM
                physical_asset_name n
            JOIN
                physical_asset pa
            ON
                pa.perm_id = n.pas_perm_id
            INNER JOIN
                vt_vessel_m_v vv
            ON
                vv.ves_id = pa.ves_id
        ) unused_table_alias
        """,  # some table name is required for correct SQL syntax
)


# COMMAND ----------

# DBTITLE 1,Add column and sanity check

df_oracle = df_oracle.toDF(*[col.lower() for col in df_oracle.columns]).withColumn(
    "cdp_created", F.lit(now)
)

# sanity check
small_df = df_oracle.limit(3)
display(small_df)

# COMMAND ----------

# DBTITLE 1,Write to databricks
df_oracle.write.mode("overwrite").saveAsTable(full_table_name)

# COMMAND ----------

# DBTITLE 1,Exit
dbutils.notebook.exit(full_table_name)
