-- Databricks notebook source
CREATE WIDGET TEXT catalog_name DEFAULT "hive_metastore";
CREATE WIDGET TEXT schema_name DEFAULT "silver";
CREATE WIDGET TEXT table_name DEFAULT "cdb_vessel_name_history";

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS IDENTIFIER(:catalog_name || '.' || :schema_name || '.' || :table_name) (
  imo STRING,
  id DECIMAL(38, 0),
  physical_asset_perm_id DECIMAL(38, 0),
  vessel_name STRING,
  effective_from TIMESTAMP,
  effective_to TIMESTAMP,
  cdp_created TIMESTAMP NOT NULL
)
CLUSTER BY (imo, effective_from);

-- COMMAND ----------

