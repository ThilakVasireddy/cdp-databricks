# Databricks notebook source
# MAGIC %md
# MAGIC # Create 29 initial tables for shipping
# MAGIC - shipping_system.process
# MAGIC - shipping_bronze.shipdb_master_data_source_json
# MAGIC - shipping_bronze.shipdb_new_building_source_json
# MAGIC - shipping_bronze.spire_source_json
# MAGIC - shipping_bronze.vt_source_json
# MAGIC - shipping_silver.shipdb_master_data_ships
# MAGIC - shipping_silver.shipdb_master_data_ships_history
# MAGIC - shipping_silver.shipdb_new_building_ships
# MAGIC - shipping_silver.shipdb_new_building_ships_history
# MAGIC - shipping_silver.spire_vessel_characteristics
# MAGIC - shipping_silver.spire_vessel_characteristics_history
# MAGIC - shipping_silver.spire_vessel_id
# MAGIC - shipping_silver.spire_vessel_position
# MAGIC - shipping_silver.spire_vessel_static_data
# MAGIC - shipping_silver.spire_vessel_static_data_history
# MAGIC - shipping_silver.spire_vessel_voyage
# MAGIC - shipping_silver.vt_ais_position
# MAGIC - shipping_silver.vt_ais_static
# MAGIC - shipping_silver.vt_ais_static_history
# MAGIC - shipping_silver.vt_ais_voyage
# MAGIC - shipping_silver.vt_ais_voyage_history
# MAGIC - shipping_silver.vt_geo_details
# MAGIC - shipping_silver.vt_geo_details_history
# MAGIC - shipping_silver.vt_msg27
# MAGIC - shipping_silver.vt_vessel_details
# MAGIC - shipping_silver.vt_vessel_details_history
# MAGIC - shipping_silver.vt_vessel_id
# MAGIC - shipping_silver.vt_voyage_details
# MAGIC - shipping_silver.vt_voyage_details_history

# COMMAND ----------

# DBTITLE 1,Add Sys Path
import sys
import os
import re


if (config_path := re.split(r"notebooks", os.getcwd())[0] + "config") not in sys.path:
    sys.path.append(config_path)

if (
    package_path := re.split(r"notebooks", os.getcwd())[0] + "shipping_data_onboarding_package"
) not in sys.path:
    sys.path.append(package_path)

# COMMAND ----------

# DBTITLE 1,Imports
from config import Config

# COMMAND ----------

# DBTITLE 1,Variables from Config
config = Config()

system_catalog_name = config["shared"]["system_catalog_name"]
system_schema_name = config["shared"]["system_schema_name"]

catalog_name = config["shipping"]["catalog_name"]
bronze_schema_name = config["shipping"]["bronze_schema_name"]
silver_schema_name = config["shipping"]["silver_schema_name"]

# COMMAND ----------

# DBTITLE 1,Create tables

dbutils.notebook.run(
    "../../shipping_system/create_process",
    600,
    {"catalog_name": system_catalog_name, "schema_name": system_schema_name},
)


dbutils.notebook.run(
    "../../../shipdb/bronze_tables/create_shipdb_master_data_source_json",
    60,
    {"catalog_name": catalog_name, "schema_name": bronze_schema_name},
)
dbutils.notebook.run(
    "../../../shipdb/bronze_tables/create_shipdb_new_building_source_json",
    60,
    {"catalog_name": catalog_name, "schema_name": bronze_schema_name},
)

dbutils.notebook.run("../../../shipdb/silver_tables/main_create_tables", 600)


dbutils.notebook.run(
    "../../../spire/bronze_tables/create_spire_source_json",
    60,
    {"catalog_name": catalog_name, "schema_name": bronze_schema_name},
)

dbutils.notebook.run("../../../spire/silver_tables/main_create_tables", 600)


dbutils.notebook.run(
    "../../../vesseltracker/bronze_tables/create_vt_source_json",
    60,
    {"catalog_name": catalog_name, "schema_name": bronze_schema_name},
)

dbutils.notebook.run("../../../vesseltracker/silver_tables/main_create_tables", 600)
