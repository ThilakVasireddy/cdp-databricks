# Databricks notebook source
# MAGIC %md
# MAGIC # Create 4 initial tables for shipping data manually imported from CDB
# MAGIC - `shipping_bronze.cdb_master_data_ships`
# MAGIC - `shipping_silver.cdb_master_data_ships`
# MAGIC - `shipping_bronze.cdb_vessel_master`
# MAGIC - `shipping_silver.cdb_vessel_master`

# COMMAND ----------

# DBTITLE 1,Add Sys Path
def append_to_sys_path(folder: str) -> str:
    import re
    import os
    import sys

    if (path := re.split("notebooks", os.getcwd())[0] + folder) not in sys.path:
        sys.path.append(path)
    return path


append_to_sys_path("config")
append_to_sys_path("shipping_data_onboarding_package")

# COMMAND ----------

# DBTITLE 1,Imports
from config import Config

# COMMAND ----------

# DBTITLE 1,Variables from Config
config = Config()

catalog_name = config["shipping"]["catalog_name"]
bronze = config["shipping"]["bronze_schema_name"]
silver = config["shipping"]["silver_schema_name"]

# COMMAND ----------

# DBTITLE 1,Create tables


def params(schema_name: str, table_name: str) -> dict[str, str]:
    return {
        "catalog_name": catalog_name,
        "schema_name": schema_name,
        "table_name": table_name,
    }


dbutils.notebook.run(
    "../../../cdb/cdb_vessel_name_history/silver_tables/create_cdb_vessel_name_history",
    600,
    params(silver, "cdb_vessel_name_history"),
)
