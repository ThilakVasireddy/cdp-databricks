# Databricks notebook source
# MAGIC %md
# MAGIC # Create 2 initial tables for shipping vesseltracker position history data
# MAGIC - `shipping_bronze.vt_source_history_csv`
# MAGIC - `shipping_silver.vt_position_history`

# COMMAND ----------

# DBTITLE 1,Add Sys Path
def append_to_sys_path(folder: str) -> str:
    import re
    import os
    import sys

    if (path := re.split("notebooks", os.getcwd())[0] + folder) not in sys.path:
        sys.path.append(path)
    return path


append_to_sys_path("config")
append_to_sys_path("shipping_data_onboarding_package")

# COMMAND ----------

# DBTITLE 1,Imports
from config import Config

# COMMAND ----------

# DBTITLE 1,Variables from Config
config = Config()

catalog_name = config["shipping"]["catalog_name"]
bronze_schema_name = config["shipping"]["bronze_schema_name"]
silver_schema_name = config["shipping"]["silver_schema_name"]

# COMMAND ----------

# DBTITLE 1,Create tables

dbutils.notebook.run(
    "../../../vesseltracker/historical_load_from_csv/bronze_tables/create_vt_source_history_csv",
    60,
    {"catalog_name": catalog_name, "schema_name": bronze_schema_name},
)

dbutils.notebook.run(
    "../../../vesseltracker/historical_load_from_csv/silver_tables/create_vt_position_history",
    60,
    {"catalog_name": catalog_name, "schema_name": silver_schema_name},
)
