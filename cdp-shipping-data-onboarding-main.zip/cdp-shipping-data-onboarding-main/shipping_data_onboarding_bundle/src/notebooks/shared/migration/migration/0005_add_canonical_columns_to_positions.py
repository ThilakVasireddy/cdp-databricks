# Databricks notebook source
# MAGIC %md
# MAGIC # Add columns to positions in spire and vesseltracker

# COMMAND ----------

# DBTITLE 1,Add Sys Path
def append_to_sys_path(folder: str) -> str:
    import re
    import os
    import sys

    if (path := re.split("notebooks", os.getcwd())[0] + folder) not in sys.path:
        sys.path.append(path)
    return path


append_to_sys_path("config")
append_to_sys_path("shipping_data_onboarding_package")

# COMMAND ----------

# DBTITLE 1,Imports
from config import Config

# COMMAND ----------

# DBTITLE 1,Variables from Config
config = Config()

catalog_name = config["shipping"]["catalog_name"]
silver_schema_name = config["shipping"]["silver_schema_name"]

# COMMAND ----------

# DBTITLE 1,Add columns to spire


spire_table_name = f"{catalog_name}.{silver_schema_name}.spire_vessel_position"
df_spire = spark.table(spire_table_name)

spire_cols_to_add = [
    ("canonical_collection_type", "STRING", "h3_cellid"),
    ("canonical_navigational_status", "STRING", "canonical_collection_type"),
    ("rot_ais", "INT", "canonical_navigational_status"),
]

for col in spire_cols_to_add:
    if col[0] not in df_spire.columns:
        spark.sql(f"""
    ALTER TABLE {spire_table_name}
    ADD COLUMN {col[0]} {col[1]} AFTER {col[2]}
    """)

# COMMAND ----------

# DBTITLE 1,Add columns to vesseltracker

vesseltracker_table_name = f"{catalog_name}.{silver_schema_name}.vt_ais_position"
df_vesseltracker = spark.table(vesseltracker_table_name)

vesseltracker_cols_to_add = [
    ("canonical_collection_type", "STRING", "h3_cellid"),
    ("canonical_navigational_status", "STRING", "canonical_collection_type"),
]

for col in vesseltracker_cols_to_add:
    if col[0] not in df_vesseltracker.columns:
        spark.sql(f"""
    ALTER TABLE {vesseltracker_table_name}
    ADD COLUMN {col[0]} {col[1]} AFTER {col[2]}
    """)
