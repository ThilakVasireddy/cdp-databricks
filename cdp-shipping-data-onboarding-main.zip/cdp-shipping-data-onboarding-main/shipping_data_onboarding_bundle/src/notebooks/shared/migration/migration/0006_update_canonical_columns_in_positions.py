# Databricks notebook source
# MAGIC %md
# MAGIC # Update rot_ais, and canonical columns in positions in spire and vesseltracker

# COMMAND ----------

# DBTITLE 1,Add Sys Path
def append_to_sys_path(folder: str) -> str:
    import re
    import os
    import sys

    if (path := re.split("notebooks", os.getcwd())[0] + folder) not in sys.path:
        sys.path.append(path)
    return path


append_to_sys_path("config")
append_to_sys_path("shipping_data_onboarding_package")

# COMMAND ----------

# DBTITLE 1,Imports
from config import Config

# COMMAND ----------

# DBTITLE 1,Variables from Config
config = Config()

catalog_name = config["shipping"]["catalog_name"]
silver_schema_name = config["shipping"]["silver_schema_name"]

# COMMAND ----------

# DBTITLE 1,Update columns in spire
spark.sql(f"""
WITH src AS(
    SELECT
          s.vessel_id
        , s.create_timestamp
        , CAST(ROUND(4.733 *
        CASE
          WHEN s.rot < 0 THEN -1 * SQRT(ABS(s.rot))
          ELSE SQRT(s.rot)
        END
       ,0) AS INT)          AS rot_ais
        , ns.canonical_name AS canonical_navigational_status
        , ct.canonical_name AS canonical_collection_type
    FROM
       {catalog_name}.{silver_schema_name}.spire_vessel_position AS s
    LEFT JOIN
      {catalog_name}.{silver_schema_name}.spire_mapping_navigational_status AS ns
      ON ns.source_name = s.navigational_status
    LEFT JOIN
      {catalog_name}.{silver_schema_name}.spire_mapping_collection_type AS ct
      ON ct.source_name = s.collection_type
    WHERE
        (s.canonical_navigational_status IS NULL AND ns.canonical_name IS NOT NULL)
        OR (s.canonical_collection_type IS NULL AND ct.canonical_name IS NOT NULL)
        OR (s.rot_ais IS NULL AND s.rot IS NOT NULL)
)
MERGE INTO {catalog_name}.{silver_schema_name}.spire_vessel_position AS trg
USING src
ON src.vessel_id = trg.vessel_id
    AND (
        src.create_timestamp = trg.create_timestamp
        OR
        (src.create_timestamp IS NULL AND trg.create_timestamp IS NULL)
    )
WHEN MATCHED THEN
UPDATE
    SET
        trg.canonical_navigational_status = src.canonical_navigational_status
        , trg.canonical_collection_type   = src.canonical_collection_type
        , trg.rot_ais                     = src.rot_ais
""")

# COMMAND ----------

# DBTITLE 1,Update columns in vesseltracker
spark.sql(f"""
WITH src AS(
    SELECT
          s.vessel_id
        , s.time_received
        , ns.canonical_name AS canonical_navigational_status
        , ct.canonical_name AS canonical_collection_type
    FROM
       {catalog_name}.{silver_schema_name}.vt_ais_position AS s
    LEFT JOIN
      {catalog_name}.{silver_schema_name}.vt_mapping_navigational_status AS ns
      ON ns.source_name = s.navigational_status
    LEFT JOIN
      {catalog_name}.{silver_schema_name}.vt_mapping_collection_type AS ct
      ON ct.source_name = s.collection_type
    WHERE
        (s.canonical_navigational_status IS NULL AND ns.canonical_name IS NOT NULL)
        OR (s.canonical_collection_type IS NULL AND ct.canonical_name IS NOT NULL)
)
MERGE INTO {catalog_name}.{silver_schema_name}.vt_ais_position AS trg
USING src
ON src.vessel_id          = trg.vessel_id
   AND src.time_received  = trg.time_received
WHEN MATCHED THEN
UPDATE
    SET
        trg.canonical_navigational_status = src.canonical_navigational_status
        , trg.canonical_collection_type   = src.canonical_collection_type
""")
