# Databricks notebook source
# MAGIC %md
# MAGIC # Rename vt_mapping_navigational_status to config_ais_mapping_navigational_status

# COMMAND ----------

# DBTITLE 1,Add Sys Path
def append_to_sys_path(folder: str) -> str:
    import re
    import os
    import sys

    if (path := re.split("notebooks", os.getcwd())[0] + folder) not in sys.path:
        sys.path.append(path)
    return path


append_to_sys_path("config")
append_to_sys_path("shipping_data_onboarding_package")

# COMMAND ----------

# DBTITLE 1,Imports
from config import Config

# COMMAND ----------

# DBTITLE 1,Variables from Config
config = Config()

catalog_name = config["shipping"]["catalog_name"]
silver_schema_name = config["shipping"]["silver_schema_name"]

# COMMAND ----------

# DBTITLE 1,Rename table

old_table_name = f"{catalog_name}.{silver_schema_name}.vt_mapping_navigational_status"
new_table_name = f"{catalog_name}.{silver_schema_name}.config_ais_mapping_navigational_status"

table_exists = spark.catalog.tableExists(old_table_name)

if table_exists:
    spark.sql(f"ALTER TABLE {old_table_name} RENAME TO {new_table_name};")
