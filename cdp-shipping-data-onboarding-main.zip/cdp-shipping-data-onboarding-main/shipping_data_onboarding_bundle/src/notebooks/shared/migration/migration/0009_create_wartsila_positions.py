# Databricks notebook source
# MAGIC %md
# MAGIC # Creaate wartsila positions

# COMMAND ----------

# DBTITLE 1,Create Wartsila positions

dbutils.notebook.run("../../../wartsila/silver_tables/main_create_tables", 600)
