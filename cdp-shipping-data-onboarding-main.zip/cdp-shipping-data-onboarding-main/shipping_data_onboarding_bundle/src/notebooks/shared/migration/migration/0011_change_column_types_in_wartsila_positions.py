# Databricks notebook source
# MAGIC %md
# MAGIC # Change floats to decimals in wartsila positions

# COMMAND ----------

# DBTITLE 1,Add Sys Path
def append_to_sys_path(folder: str) -> str:
    import re
    import os
    import sys

    if (path := re.split("notebooks", os.getcwd())[0] + folder) not in sys.path:
        sys.path.append(path)
    return path


append_to_sys_path("config")
append_to_sys_path("shipping_data_onboarding_package")

# COMMAND ----------

# DBTITLE 1,Imports
from config import Config

# COMMAND ----------

# DBTITLE 1,Variables from Config
config = Config()

catalog_name = config["shipping"]["catalog_name"]
silver_schema_name = config["shipping"]["silver_schema_name"]

# COMMAND ----------

# DBTITLE 1,Change properties to allow dropping columns

spark.sql(f"""
ALTER TABLE {catalog_name}.{silver_schema_name}.wartsila_positions
SET TBLPROPERTIES (
    'delta.minReaderVersion' = '2',
    'delta.minWriterVersion' = '5',
    'delta.columnMapping.mode' = 'name'
)
""")

# COMMAND ----------

# DBTITLE 1,Add columns to spire

df = spark.table(f"{catalog_name}.{silver_schema_name}.wartsila_positions")

columns_to_change = {
    "latitude": "DECIMAL(8,6)",
    "longitude": "DECIMAL(9,6)",
    "cog": "DECIMAL(4,1)",
    "sog": "DECIMAL(4,1)",
    "draught": "DECIMAL(3,1)",
}

for column_name, column_type in df.dtypes:
    if column_type == "float":
        new_column_type = columns_to_change[column_name]
        spark.sql(f"""ALTER TABLE {catalog_name}.{silver_schema_name}.wartsila_positions
                  ADD COLUMN {column_name}_new {new_column_type} AFTER {column_name}""")
        spark.sql(f"""ALTER TABLE {catalog_name}.{silver_schema_name}.wartsila_positions
                  DROP COLUMN {column_name}""")
        spark.sql(f"""ALTER TABLE {catalog_name}.{silver_schema_name}.wartsila_positions
                  RENAME COLUMN {column_name}_new TO {column_name}""")
        print(f"Column: {column_name}, new Column Type: {new_column_type}")
