# Databricks notebook source
# MAGIC %md
# MAGIC # Create an initial table for shipping data
# MAGIC - `shipping_silver.bad_ais_polygons`

# COMMAND ----------

# DBTITLE 1,Add Sys Path
def append_to_sys_path(folder: str) -> str:
    import re
    import os
    import sys

    if (path := re.split("notebooks", os.getcwd())[0] + folder) not in sys.path:
        sys.path.append(path)
    return path


append_to_sys_path("config")
append_to_sys_path("shipping_data_onboarding_package")

# COMMAND ----------

# DBTITLE 1,Imports
from config import Config

# COMMAND ----------

# DBTITLE 1,Variables from Config
config = Config()

catalog_name = config["shipping"]["catalog_name"]
silver_schema_name = config["shipping"]["silver_schema_name"]
silver_table_name = config["shipping"]["kml_bad_positions"]["silver_kml_table_name"]

# COMMAND ----------

# DBTITLE 1, Delete bad ais polygons table if table doesn't have perm_id column
# Check if the table exists
table_exists_query = f"""
SELECT 1
FROM information_schema.tables
WHERE table_catalog = '{catalog_name}'
  AND table_schema = '{silver_schema_name}'
  AND table_name = '{silver_table_name}'
"""
table_exists = spark.sql(table_exists_query).count() > 0

# Check if the column 'perm_id_test' exists
column_exists_query = f"""
SELECT 1
FROM information_schema.columns
WHERE table_catalog = '{catalog_name}'
  AND table_schema = '{silver_schema_name}'
  AND table_name = '{silver_table_name}'
  AND column_name = 'perm_id'
"""
column_exists = spark.sql(column_exists_query).count() > 0

# Drop the table if it exists and the column does not exist
if table_exists and not column_exists:
    drop_table_query = f"DROP TABLE {catalog_name}.{silver_schema_name}.{silver_table_name}"
    spark.sql(drop_table_query)

# COMMAND ----------


# DBTITLE 1,Create tables
def params(schema_name: str, table_name: str) -> dict[str, str]:
    return {
        "catalog_name": catalog_name,
        "schema_name": schema_name,
        "table_name": table_name,
    }


dbutils.notebook.run(
    "../../../bad_ais_polygons/silver_tables/main_create_tables",
    600,
    params(silver_schema_name, silver_table_name),
)
