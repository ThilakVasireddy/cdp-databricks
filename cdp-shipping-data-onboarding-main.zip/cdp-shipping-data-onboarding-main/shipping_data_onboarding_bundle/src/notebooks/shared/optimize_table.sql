-- Databricks notebook source
CREATE WIDGET TEXT catalog_name DEFAULT '';
CREATE WIDGET TEXT schema_name DEFAULT '';
CREATE WIDGET TEXT table_name DEFAULT '';

-- COMMAND ----------

OPTIMIZE IDENTIFIER(:catalog_name || '.' || :schema_name || '.' || :table_name)

