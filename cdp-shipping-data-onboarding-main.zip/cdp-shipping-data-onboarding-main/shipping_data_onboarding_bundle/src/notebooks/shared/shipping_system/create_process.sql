-- Databricks notebook source
CREATE WIDGET TEXT catalog_name DEFAULT 'hive_metastore';
CREATE WIDGET TEXT schema_name DEFAULT 'shipping_system';
CREATE WIDGET TEXT table_name DEFAULT 'process';

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS IDENTIFIER(:catalog_name || '.' || :schema_name || '.' || :table_name)
(
  process_name              STRING,
  last_api_call_timestamp   TIMESTAMP,
  cdp_updated               TIMESTAMP
)
USING DELTA
CLUSTER BY (process_name)


