# Databricks notebook source
# MAGIC %md
# MAGIC # Download shipdb data and save to bronze
# MAGIC
# MAGIC Downloads vessels from the www.shipdb.com API endpoint at https://www.shipdb.com/api/v1/ships/master_data.json
# MAGIC
# MAGIC Confluence Documentation: https://confluence.refinitiv.com/display/CDB2/Vessel+Characteristics+Data+Dictionary#VesselCharacteristicsDataDictionary-APIParameters
# MAGIC Api Documentation: https://newapi.vesseltracker.com/static/shipdb-api/index.html#/ships/get_ships_master_data
# MAGIC
# MAGIC Example url: https://www.shipdb.com/api/v1/ships/master_data.json?api_token=jagHTctPOw19GoF8wWmeYa2gERwQCDLDp&limit=500&updated_after=1712996736000
# MAGIC
# MAGIC Args (widgets):
# MAGIC * api_endpoint - URL json files location [master_data, new_building]

# COMMAND ----------

dbutils.widgets.text("api_endpoint", "master_data")

# COMMAND ----------

import sys
import os
import itertools


def append_config_path_to_sys_path():
    def get_config_path(current_notebook_absolute_path: str = os.getcwd()) -> str:
        path_components = current_notebook_absolute_path.split("/")
        config_components = list(
            itertools.takewhile(lambda x: x != "notebooks", path_components)
        ) + ["config"]
        return "/".join(config_components)

    config_path = get_config_path()

    if config_path not in sys.path:
        sys.path.append(config_path)


append_config_path_to_sys_path()

# COMMAND ----------

from datetime import datetime, timezone
import json
import requests
from pyspark.sql.types import (
    StructType,
    StructField,
    StringType,
    ArrayType,
    TimestampType,
    LongType,
)
from pyspark.sql.functions import to_timestamp, lit

from config import Config

# COMMAND ----------

config = Config()

API_ENDPOINT = dbutils.widgets.get("api_endpoint")

API_BASE_URL = config["shipping"]["shipdb"]["api_base_url"]

SYSTEM_CATALOG_NAME = config["shared"]["system_catalog_name"]
SYSTEM_SCHEMA_NAME = config["shared"]["system_schema_name"]

CATALOG_NAME = config["shipping"]["catalog_name"]
BRONZE_SCHEMA_NAME = config["shipping"]["bronze_schema_name"]
TABLE_NAME = f"shipdb_{API_ENDPOINT}_source_json"
FULL_TABLE_NAME = f"{CATALOG_NAME}.{BRONZE_SCHEMA_NAME}.shipdb_{API_ENDPOINT}_source_json"

CDP_CREATED = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")

print(f"{API_BASE_URL=}")
print(f"{API_ENDPOINT=}")

# COMMAND ----------


def save_batch_to_table(
    api_responses_json: list, full_table_name: str, cdp_created: datetime
) -> None:
    """
    Saves a batch of API response data to the specified bronze table.

    Parameters:
        api_responses_json (list): A list of dictionaries containing API response data.
        full_table_name (str): Full table name in format CATALOG_NAME.SCHEMA_NAME.TABLE_NAME
        cdp_created (datetime): The timestamp of the job run
    """
    # Define the schema for the 'ships' field
    ships_schema = ArrayType(
        StructType(
            [
                StructField(
                    "fields",
                    ArrayType(
                        StructType(
                            [
                                StructField("name", StringType(), True),
                                StructField("section", StringType(), True),
                                StructField("value", StringType(), True),
                            ]
                        )
                    ),
                    True,
                )
            ]
        )
    )

    # Define the complete schema for the DataFrame
    schema = StructType(
        [
            StructField("max_updated_at", LongType(), True),
            StructField("ships", ships_schema, True),
            StructField("cdp_created", TimestampType(), True),
        ]
    )

    # Assuming 'api_responses_json' is a list of dictionaries
    response_df = spark.createDataFrame(api_responses_json, schema=schema)
    response_df = response_df.withColumn(
        "cdp_created",
        to_timestamp(
            lit(cdp_created),
            format="yyyy-MM-dd'T'HH:mm:ss",
        ),
    )

    response_df.write.mode("append").format("delta").saveAsTable(full_table_name)


# COMMAND ----------


def get_updated_after_from_metadata_process() -> int:
    """
    Retrieves the timestamp of the last API call from the metadata process table.

    Returns:
        int: The unix timestamp in miliseconds of the last API call.
    """
    df = spark.sql(
        f"""SELECT last_api_call_timestamp
            FROM
                {SYSTEM_CATALOG_NAME}.{SYSTEM_SCHEMA_NAME}.process
            WHERE
                process_name = 'shipdb_{API_ENDPOINT}'"""
    )

    updated_after = 0

    if df.count() > 0:
        last_api_call_timestamp = df.select("last_api_call_timestamp").first()[0]
        updated_after = last_api_call_timestamp.timestamp() * 1000

    return updated_after


def fetch_api_data(
    base_url: str, endpoint: str, api_token: str, limit: int, updated_after: int
) -> list:
    """
    Fetches data from the API based on the given parameters.

    Returns:
        list: A list of dictionaries containing the fetched data.
    """
    api_url = f"{base_url}/{endpoint}.json"
    params = {"api_token": api_token, "limit": limit, "updated_after": updated_after}

    while True:
        print(f"Fetching {api_url} with params: {params}")

        response = requests.get(url=api_url, params=params)

        if response.status_code != 200:
            exit_message = (
                f"{{ 'error_code': '{response.status_code}',"
                f"'response_content': '{response.content}' }}"
            )
            dbutils.notebook.exit(exit_message)

        response_json = response.json()
        yield response_json

        if len(response_json["ships"]) < limit:
            break

        params["updated_after"] = response_json["max_updated_at"]


UPDATED_AFTER = get_updated_after_from_metadata_process()
API_TOKEN = dbutils.secrets.get(config["shipping"]["secret_scope"], "shipdb-api-token")
LIMIT = 500

api_responses_json = []
max_updated_at = 0
num_saved_batches = 0


for api_response_json in fetch_api_data(
    API_BASE_URL, API_ENDPOINT, API_TOKEN, LIMIT, UPDATED_AFTER
):
    # Process each batch of data
    max_updated_at = api_response_json["max_updated_at"]
    api_responses_json.append(api_response_json)
    # We are saving when there are 50 batches (25.000 records).
    # It is because in case of initial run of master data there are 200.000 records.
    # Trying to save it in one batch was crashing the cluster
    if len(api_responses_json) >= 50:
        print(
            f"Saving batch of {len(api_responses_json)} records. max_updated_at = {max_updated_at}"
        )
        save_batch_to_table(api_responses_json, FULL_TABLE_NAME, CDP_CREATED)
        num_saved_batches = num_saved_batches + len(api_responses_json)
        api_responses_json = []

# COMMAND ----------

# If there are remaining records, save them
if len(api_responses_json) > 0:
    print(f"Saving batch of {len(api_responses_json)} records. max_updated_at = {max_updated_at}")
    save_batch_to_table(api_responses_json, FULL_TABLE_NAME, CDP_CREATED)
    num_saved_batches = num_saved_batches + len(api_responses_json)

print(f"{num_saved_batches=}")

timestamp_string = datetime.fromtimestamp(int(max_updated_at) / 1000, tz=timezone.utc)
print(f"Data downloaded up to '{timestamp_string}' timestamp")

# COMMAND ----------

MAX_UPDATED_AT = str(max_updated_at)

dbutils.jobs.taskValues.set(key="cdp_created", value=CDP_CREATED)
dbutils.jobs.taskValues.set(key="max_updated_at", value=MAX_UPDATED_AT)

exit_message = {
    "cdp_created": CDP_CREATED,
    "max_updated_at": MAX_UPDATED_AT,
}

dbutils.notebook.exit(json.dumps(exit_message))
