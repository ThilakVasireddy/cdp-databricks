-- Databricks notebook source
CREATE WIDGET TEXT catalog_name DEFAULT 'hive_metastore';
CREATE WIDGET TEXT schema_name DEFAULT 'shipping_bronze';
CREATE WIDGET TEXT table_name DEFAULT 'shipdb_master_data_source_json';

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS IDENTIFIER(:catalog_name || '.' || :schema_name || '.' || :table_name)
(
  max_updated_at BIGINT,
  ships ARRAY<STRUCT<
    fields: ARRAY<STRUCT<
      name: STRING,
      section: STRING,
      value: STRING
    >>
  >>,
  cdp_created TIMESTAMP NOT NULL
)
USING DELTA
CLUSTER BY (cdp_created);
