-- Databricks notebook source
CREATE WIDGET TEXT catalog_name DEFAULT 'hive_metastore';
CREATE WIDGET TEXT schema_name DEFAULT 'silver';
CREATE WIDGET TEXT table_name DEFAULT 'shipdb_master_data_ships_history';

-- COMMAND ----------

-- This is initial table with key columns, all the other columns are added automatically as withSchemaEvolution is set in merge statement
CREATE TABLE IF NOT EXISTS IDENTIFIER(:catalog_name || '.' || :schema_name || '.' || :table_name)
(
  imo                          INT,
  mmsi                         INT,
  max_updated_at               BIGINT,
  cdp_created                  TIMESTAMP
)
USING DELTA
CLUSTER BY (imo, mmsi, max_updated_at)