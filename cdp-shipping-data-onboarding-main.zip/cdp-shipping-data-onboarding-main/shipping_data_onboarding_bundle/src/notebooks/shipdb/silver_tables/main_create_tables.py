# Databricks notebook source

import sys
import os
import itertools


def append_config_path_to_sys_path():
    def get_config_path(current_notebook_absolute_path: str = os.getcwd()) -> str:
        path_components = current_notebook_absolute_path.split("/")
        config_components = list(
            itertools.takewhile(lambda x: x != "notebooks", path_components)
        ) + ["config"]
        return "/".join(config_components)

    config_path = get_config_path()

    if config_path not in sys.path:
        sys.path.append(config_path)


append_config_path_to_sys_path()

# COMMAND ----------

from config import Config

# COMMAND ----------

config = Config()

catalog_name = config["shipping"]["catalog_name"]
schema_name = config["shipping"]["silver_schema_name"]

# COMMAND ----------

current_dir = os.getcwd()
notebooks = os.listdir(current_dir)
for notebook in notebooks:
    if notebook.startswith("create_shipdb"):
        dbutils.notebook.run(
            f"{notebook}", 60, {"catalog_name": catalog_name, "schema_name": schema_name}
        )
