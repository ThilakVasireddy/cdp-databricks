# Databricks notebook source
dbutils.widgets.text("catalog_name", "hive_metastore")
dbutils.widgets.text("silver_schema_name", "silver")
dbutils.widgets.text("bronze_schema_name", "bronze")
dbutils.widgets.text("target_table_name", "shipdb_new_building_ships")
dbutils.widgets.text("source_table_name", "shipdb_new_building_source_json")
dbutils.widgets.text("cdp_created", "")

# COMMAND ----------

from pyspark.sql import Window
from datetime import datetime
from delta.tables import DeltaTable
from pyspark.sql import functions as F
from pyspark.sql.types import DateType, IntegerType, FloatType

# COMMAND ----------

catalog_name = dbutils.widgets.get("catalog_name")
silver_schema_name = dbutils.widgets.get("silver_schema_name")
bronze_schema_name = dbutils.widgets.get("bronze_schema_name")
target_table_name = dbutils.widgets.get("target_table_name")
source_table_name = dbutils.widgets.get("source_table_name")
cdp_created = dbutils.widgets.get("cdp_created")

# COMMAND ----------

DATE_NAMES = [
    "multi_level_status_of_ship_date",
    "survey_1_date",
    "survey_1_next_date",
    "scrubber_date",
    "launch_date",
]


INT_NAMES = [
    "imo",
    "mmsi",
    "bulkheads",
    "decks_number",
    "bale",
    "ballast",
    "crude_capacity",
    "deadweight",
    "deck_teu",
    "feu",
    "grain",
    "gross_tonnage",
    "liquid_cap",
    "net_tonnage",
    "panama_canal_net_tonnage",
    "reefer_teu",
    "suez_canal_net_tonnage",
    "teu",
    "main_engine_power",
    "year_of_built",
]

FLOAT_NAMES = [
    "service_speed",
    "fuel",
    "lane_meters",
    "beam_extreme",
    "breadth_moulded",
    "depth_moulded",
    "draught",
    "draught_tropical",
    "draught_winter",
    "length_bp",
    "length_overall",
    "bollard_pull",
]


def parse_date(date_str):
    if date_str is None:
        return None
    formats = ["%d/%m/%Y", "%Y-%m-%d"]
    for fmt in formats:
        try:
            return datetime.strptime(date_str, fmt).date()
        except ValueError:
            continue
    print("Invalid date format: %s.", date_str)
    return None


def parse_int(int_str):
    if int_str is None:
        return None
    if not isinstance(int_str, IntegerType):
        print("Invalid int format: %s.", int_str)
    try:
        return int(int_str)
    except ValueError:
        try:
            return int(float(int_str))
        except ValueError:
            return None


def parse_float(float_str):
    if float_str is None:
        return None
    if not isinstance(float_str, FloatType):
        print("Invalid float format: %s.", float_str)
    try:
        return float(float_str)
    except ValueError:
        return None


parse_date_udf = F.udf(parse_date, DateType())
parse_int_udf = F.udf(parse_int, IntegerType())
parse_float_udf = F.udf(parse_float, FloatType())


def convert_data_types(df):
    for column in DATE_NAMES:
        if column in df.columns:
            df = df.withColumn(column, parse_date_udf(df[column]))
    for column in INT_NAMES:
        if column in df.columns:
            df = df.withColumn(column, parse_int_udf(df[column]))
    for column in FLOAT_NAMES:
        if column in df.columns:
            df = df.withColumn(column, parse_float_udf(df[column]))
    return df


# COMMAND ----------

df = spark.read.table(f"{catalog_name}.{bronze_schema_name}.{source_table_name}")

df_filtered = df.filter(F.col("cdp_created") == cdp_created)

# Check if any row has a non-empty 'ships' array
non_empty_ships_count = (
    df_filtered.select(F.size(F.col("ships")).alias("ships_size"))
    .filter(F.col("ships_size") > 0)
    .limit(1)
    .count()
)

if non_empty_ships_count == 0:
    dbutils.notebook.exit(
        f"The 'ships' column in table '{catalog_name}.{bronze_schema_name}.{source_table_name}' "
        f"for cdp_created == {cdp_created} is empty. Skipping merge operation..."
    )

df_with_exploded_fields = (
    df_filtered.withColumn("field", F.explode("ships.fields"))
    .withColumn("row_Id", F.monotonically_increasing_id())
    .withColumn("field_exploded", F.explode("field"))
    .withColumn("name", F.regexp_replace(F.lower("field_exploded.name"), " ", "_"))
    .withColumn("value", F.lower("field_exploded.value"))
    .select("max_updated_at", "row_Id", "name", "value", "cdp_created")
)

df_pivoted = (
    df_with_exploded_fields.groupBy("row_Id", "max_updated_at", "cdp_created")
    .pivot("name")
    .agg(F.first("value"))
)

windowSpec = Window.partitionBy("brl_ship_id").orderBy(F.col("max_updated_at").desc())

df_with_row_number = df_pivoted.withColumn("row_num", F.row_number().over(windowSpec))

df_most_recent = df_with_row_number.filter(F.col("row_num") == 1).drop(
    "row_num", "row_Id", "field", "field_exploded"
)

df_datatype_conversion = convert_data_types(df_most_recent)

# COMMAND ----------

targetTable = DeltaTable.forName(spark, f"{catalog_name}.{silver_schema_name}.{target_table_name}")

targetTable.alias("target").merge(
    df_datatype_conversion.alias("source"),
    """target.brl_ship_id = source.brl_ship_id""",
).withSchemaEvolution().whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()
