-- Databricks notebook source

SELECT DISTINCT COUNT(max_updated_at)
FROM IDENTIFIER('hive_metastore.bronze.shipdb_master_data_source_json')

-- COMMAND ----------

SELECT DISTINCT MAX(max_updated_at), COUNT(max_updated_at), COUNT(*), cdp_created
FROM IDENTIFIER('hive_metastore.bronze.shipdb_master_data_source_json')
GROUP BY cdp_created
ORDER BY cdp_created DESC

-- COMMAND ----------

SELECT DISTINCT COUNT(max_updated_at)
FROM IDENTIFIER('hive_metastore.bronze.shipdb_new_building_source_json')

-- COMMAND ----------

SELECT DISTINCT MAX(max_updated_at), COUNT(max_updated_at), COUNT(*), cdp_created
FROM IDENTIFIER('hive_metastore.bronze.shipdb_new_building_source_json')
GROUP BY cdp_created
ORDER BY cdp_created DESC

-- COMMAND ----------

SELECT DISTINCT COUNT(max_updated_at)
FROM IDENTIFIER('hive_metastore.silver.shipdb_master_data_ships')

-- COMMAND ----------

SELECT DISTINCT MAX(max_updated_at), COUNT(max_updated_at), COUNT(*), cdp_created
FROM IDENTIFIER('hive_metastore.silver.shipdb_master_data_ships')
GROUP BY cdp_created
ORDER BY cdp_created DESC

-- COMMAND ----------

SELECT DISTINCT COUNT(max_updated_at)
FROM IDENTIFIER('hive_metastore.silver.shipdb_master_data_ships_history')

-- COMMAND ----------

SELECT DISTINCT MAX(max_updated_at), COUNT(max_updated_at), COUNT(*), cdp_created
FROM IDENTIFIER('hive_metastore.silver.shipdb_master_data_ships_history')
GROUP BY cdp_created
ORDER BY cdp_created DESC

-- COMMAND ----------

SELECT DISTINCT COUNT(max_updated_at)
FROM IDENTIFIER('hive_metastore.silver.shipdb_new_building_ships')

-- COMMAND ----------

SELECT DISTINCT MAX(max_updated_at), COUNT(max_updated_at), COUNT(*), cdp_created
FROM IDENTIFIER('hive_metastore.silver.shipdb_new_building_ships')
GROUP BY cdp_created
ORDER BY cdp_created DESC

-- COMMAND ----------

SELECT DISTINCT COUNT(max_updated_at)
FROM IDENTIFIER('hive_metastore.silver.shipdb_new_building_ships_history')

-- COMMAND ----------

SELECT DISTINCT MAX(max_updated_at), COUNT(max_updated_at), COUNT(*), cdp_created
FROM IDENTIFIER('hive_metastore.silver.shipdb_new_building_ships_history')
GROUP BY cdp_created
ORDER BY cdp_created DESC