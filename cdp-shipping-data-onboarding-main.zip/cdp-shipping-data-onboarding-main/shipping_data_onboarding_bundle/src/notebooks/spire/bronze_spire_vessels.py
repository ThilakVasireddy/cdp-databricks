# Databricks notebook source
# MAGIC %md
# MAGIC # Ingest Spire vessel data
# MAGIC
# MAGIC Make requests to the Spire GraphQL API for pages until there are no more.
# MAGIC
# MAGIC Load raw JSON data into bronze table.

# COMMAND ----------

# DBTITLE 1,Add Sys Path
import sys
import os
import re

if (config_path := re.split(r"notebooks", os.getcwd())[0] + "config") not in sys.path:
    sys.path.append(config_path)

if (
    package_path := re.split(r"notebooks", os.getcwd())[0] + "shipping_data_onboarding_package"
) not in sys.path:
    sys.path.append(package_path)

# COMMAND ----------

# DBTITLE 1,Imports
from config import Config
from string import Template
from datetime import datetime, timedelta
import requests
import concurrent.futures
from urllib3.util.retry import Retry
from pyspark.sql.functions import lit, to_timestamp
from pyspark.sql.types import (
    StructType,
    StructField,
    ArrayType,
    StringType,
    IntegerType,
    FloatType,
    BooleanType,
)
from rate_limiter import RateLimiter
from rate_limit_http_adapter import RateLimitHTTPAdapter


# COMMAND ----------

# DBTITLE 1,Variables from Config
config = Config()

STORAGE_ACCOUNT = config["shared"]["storage_account"]
SPIRE_ENDPOINT_URI_ARG = config["shipping"]["spire"]["api_base_url"]
CATALOG_NAME = config["shipping"]["catalog_name"]
BRONZE_SCHEMA_NAME = config["shipping"]["bronze_schema_name"]

SYSTEM_CATALOG_NAME = config["shared"]["system_catalog_name"]
SYSTEM_SCHEMA_NAME = config["shared"]["system_schema_name"]
request_rate_limit_per_minute = config["shipping"]["spire"]["request_rate_limit_per_minute"]

print(f"{STORAGE_ACCOUNT=}")
print(f"{SPIRE_ENDPOINT_URI_ARG=}")
print(f"{request_rate_limit_per_minute=}")

# COMMAND ----------

# DBTITLE 1,Other variables
max_retries = 3
rate_limiter = RateLimiter(max_calls=request_rate_limit_per_minute, period=60)
date_format = "%Y-%m-%dT%H:%M:%S"
print(f"{rate_limiter=}")

# COMMAND ----------


def get_last_api_call_timestamp_from_metadata_process() -> datetime:
    """
    Retrieves the timestamp of the last API call from the metadata process table.

    Returns:
        datetime: The timestamp in miliseconds of the last API call.
    """
    df = spark.sql(
        f"""SELECT last_api_call_timestamp
            FROM {SYSTEM_CATALOG_NAME}.{SYSTEM_SCHEMA_NAME}.process
            WHERE process_name = 'spire_vessels'"""
    )

    now = datetime.now()
    last_api_call_timestamp = datetime(now.year, now.month, now.day, 0, 0, 0, 0)

    if df.count() > 0:
        # API can get no more than 1 day of data changes
        last_api_call_from_metadata_process = df.select("last_api_call_timestamp").first()[0]
        difference = abs(now - last_api_call_from_metadata_process)
        if difference < timedelta(days=1):
            last_api_call_timestamp = last_api_call_from_metadata_process

    return last_api_call_timestamp


SPIRE_ENDPOINT_URI = SPIRE_ENDPOINT_URI_ARG
SPIRE_API_TOKEN = dbutils.secrets.get(config["shipping"]["secret_scope"], "spire-api-token")
SPIRE_REQUEST_HEADERS = {"Authorization": f"Bearer {SPIRE_API_TOKEN}"}

CURRENT_API_CALL_TIMESTAMP = datetime.now()
SINCE = get_last_api_call_timestamp_from_metadata_process()
TARGET_TABLE = f"{CATALOG_NAME}.{BRONZE_SCHEMA_NAME}.spire_source_json"
PAGE_SIZE = 1000
SHIP_TYPES = [
    "GENERAL_CARGO",
    "OTHER",
    "GENERAL_TANKER",
    "VEHICLE_PASSENGER",
    "DRY_BULK",
    "CAR_CARRIER",
    "LNG_CARRIER",
    "REEFER",
    "COMBINATION_CARRIER",
    "GAS_CARRIER",
    "FISHING",
    "TUG",
    "LIVESTOCK",
    "TANKER_CHEMICALS",
    "TANKER_CRUDE",
    "ROLL_ON_ROLL_OFF",
    "OFFSHORE",
    "TANKER_PRODUCT",
    "CONTAINER",
]

print(f"{CURRENT_API_CALL_TIMESTAMP=}")
print(f"{SINCE=}")
print(f"{SHIP_TYPES=}")
print(f"{SINCE=}")
print(f"{TARGET_TABLE=}")

# COMMAND ----------

# DBTITLE 1,Function create_session

def create_session() -> requests.Session:
    retry_strategy = Retry(
        total=max_retries, backoff_factor=1, status_forcelist=list(range(300, 600))
    )
    adapter = RateLimitHTTPAdapter(
        rate_limiter=rate_limiter,
        max_retries=retry_strategy,
        pool_connections=len(SHIP_TYPES),
        pool_maxsize=len(SHIP_TYPES),
    )
    session = requests.Session()
    session.mount("https://", adapter)
    return session


# COMMAND ----------

# DBTITLE 1,Spire query template
spire_query_template = Template(
    """
{
    vessels (
        $query_filters
    ) {
        nodes {
            id,
            timestamp,
            updateTimestamp,
            staticData {
                timestamp,
                updateTimestamp,
                mmsi,
                imo,
                name,
                callsign,
                shipType,
                shipSubType,
                aisClass,
                flag,
                dimensions {
                    length, width, a, b, c, d
                },
                validated {
                    imo,
                    name,
                    callsign,
                    shipType,
                    dimensions { length, width },
                    nameTimestamp,
                    callsignTimestamp
                }
            },
            lastPositionUpdate {
                timestamp,
                updateTimestamp,
                latitude,
                longitude,
                heading,
                speed,
                rot,
                accuracy,
                maneuver,
                course,
                navigationalStatus,
                collectionType
            },
            currentVoyage {
                timestamp,
                updateTimestamp,
                draught,
                eta,
                destination,
                matchedPort {
                    matchScore,
                    port {
                        name,
                        unlocode,
                        centerPoint { longitude, latitude }
                    }
                }
            },
            characteristics {
                basic {
                    capacity {
                        deadweight,
                        grossTonnage
                    },
                    history { builtYear },
                    vesselTypeAndTrading { vesselSubtype }
                }
            }
        },
        pageInfo {endCursor, hasNextPage},
        totalCount {value,relation}
    }
}
""".strip()
)
print(f"{spire_query_template.template=!r}")  # !r means use the repr

# COMMAND ----------

spire_characteristics_field = StructField(
    "characteristics",
    StructType(
        [
            StructField(
                "basic",
                StructType(
                    [
                        StructField(
                            "capacity",
                            StructType(
                                [
                                    StructField(
                                        "deadweight",
                                        IntegerType(),
                                        True,
                                    ),
                                    StructField(
                                        "grossTonnage",
                                        IntegerType(),
                                        True,
                                    ),
                                ]
                            ),
                            True,
                        ),
                        StructField(
                            "history",
                            StructType(
                                [
                                    StructField(
                                        "builtYear",
                                        IntegerType(),
                                        True,
                                    )
                                ]
                            ),
                            True,
                        ),
                        StructField(
                            "vesselTypeAndTrading",
                            StructType(
                                [
                                    StructField(
                                        "vesselSubtype",
                                        StringType(),
                                        True,
                                    )
                                ]
                            ),
                            True,
                        ),
                    ]
                ),
                True,
            )
        ]
    ),
    True,
)

spire_current_voyage_field = StructField(
    "currentVoyage",
    StructType(
        [
            StructField("destination", StringType(), True),
            StructField("draught", FloatType(), True),
            StructField("eta", StringType(), True),
            StructField(
                "matchedPort",
                StructType(
                    [
                        StructField(
                            "matchScore",
                            FloatType(),
                            True,
                        ),
                        StructField(
                            "port",
                            StructType(
                                [
                                    StructField(
                                        "centerPoint",
                                        StructType(
                                            [
                                                StructField(
                                                    "latitude",
                                                    FloatType(),
                                                    True,
                                                ),
                                                StructField(
                                                    "longitude",
                                                    FloatType(),
                                                    True,
                                                ),
                                            ]
                                        ),
                                        True,
                                    ),
                                    StructField(
                                        "name",
                                        StringType(),
                                        True,
                                    ),
                                    StructField(
                                        "unlocode",
                                        StringType(),
                                        True,
                                    ),
                                ]
                            ),
                            True,
                        ),
                    ]
                ),
                True,
            ),
            StructField("timestamp", StringType(), True),
            StructField(
                "updateTimestamp",
                StringType(),
                True,
            ),
        ]
    ),
    True,
)

spire_last_position_field = StructField(
    "lastPositionUpdate",
    StructType(
        [
            StructField("accuracy", StringType(), True),
            StructField(
                "collectionType",
                StringType(),
                True,
            ),
            StructField("course", FloatType(), True),
            StructField("heading", FloatType(), True),
            StructField("latitude", FloatType(), True),
            StructField("longitude", FloatType(), True),
            StructField("maneuver", StringType(), True),
            StructField(
                "navigationalStatus",
                StringType(),
                True,
            ),
            StructField("rot", FloatType(), True),
            StructField("speed", FloatType(), True),
            StructField("timestamp", StringType(), True),
            StructField(
                "updateTimestamp",
                StringType(),
                True,
            ),
        ]
    ),
    True,
)

spire_static_data_field = StructField(
    "staticData",
    StructType(
        [
            StructField("aisClass", StringType(), True),
            StructField("callsign", StringType(), True),
            StructField(
                "dimensions",
                StructType(
                    [
                        StructField(
                            "a",
                            IntegerType(),
                            True,
                        ),
                        StructField(
                            "b",
                            IntegerType(),
                            True,
                        ),
                        StructField(
                            "c",
                            IntegerType(),
                            True,
                        ),
                        StructField(
                            "d",
                            IntegerType(),
                            True,
                        ),
                        StructField(
                            "length",
                            IntegerType(),
                            True,
                        ),
                        StructField(
                            "width",
                            IntegerType(),
                            True,
                        ),
                    ]
                ),
                True,
            ),
            StructField("flag", StringType(), True),
            StructField("imo", IntegerType(), True),
            StructField("mmsi", IntegerType(), True),
            StructField("name", StringType(), True),
            StructField("shipSubType", StringType(), True),
            StructField("shipType", StringType(), True),
            StructField("timestamp", StringType(), True),
            StructField(
                "updateTimestamp",
                StringType(),
                True,
            ),
            StructField(
                "validated",
                StructType(
                    [
                        StructField(
                            "callsign",
                            StringType(),
                            True,
                        ),
                        StructField(
                            "callsignTimestamp",
                            StringType(),
                            True,
                        ),
                        StructField(
                            "dimensions",
                            StructType(
                                [
                                    StructField(
                                        "length",
                                        IntegerType(),
                                        True,
                                    ),
                                    StructField(
                                        "width",
                                        IntegerType(),
                                        True,
                                    ),
                                ]
                            ),
                            True,
                        ),
                        StructField(
                            "imo",
                            IntegerType(),
                            True,
                        ),
                        StructField(
                            "name",
                            StringType(),
                            True,
                        ),
                        StructField(
                            "nameTimestamp",
                            StringType(),
                            True,
                        ),
                        StructField(
                            "shipType",
                            StringType(),
                            True,
                        ),
                    ]
                ),
                True,
            ),
        ]
    ),
    True,
)

spire_schema = StructType(
    [
        StructField(
            "data",
            StructType(
                [
                    StructField(
                        "vessels",
                        StructType(
                            [
                                StructField(
                                    "nodes",
                                    ArrayType(
                                        StructType(
                                            [
                                                spire_characteristics_field,
                                                spire_current_voyage_field,
                                                StructField("id", StringType(), True),
                                                spire_last_position_field,
                                                spire_static_data_field,
                                                StructField("timestamp", StringType(), True),
                                                StructField("updateTimestamp", StringType(), True),
                                            ]
                                        )
                                    ),
                                    True,
                                ),
                                StructField(
                                    "pageInfo",
                                    StructType(
                                        [
                                            StructField("endCursor", StringType(), True),
                                            StructField("hasNextPage", BooleanType(), True),
                                        ]
                                    ),
                                    True,
                                ),
                                StructField(
                                    "totalCount",
                                    StructType(
                                        [
                                            StructField("relation", StringType(), True),
                                            StructField("value", IntegerType(), True),
                                        ]
                                    ),
                                    True,
                                ),
                            ]
                        ),
                        True,
                    )
                ]
            ),
        ),
        StructField(
            "extensions",
            StructType(
                [
                    StructField("requestId", StringType(), True),
                    StructField(
                        "requestQuota",
                        StructType(
                            [
                                StructField("limit", StringType(), True),
                                StructField("remaining", IntegerType(), True),
                            ]
                        ),
                        True,
                    ),
                ]
            ),
            True,
        ),
        StructField(
            "errors",
            ArrayType(
                StructType(
                    [
                        StructField(
                            "extensions",
                            StructType([StructField("code", StringType(), True)]),
                            True,
                        ),
                        StructField("message", StringType(), True),
                        StructField("path", ArrayType(StringType()), True),
                    ]
                )
            ),
            True,
        ),
    ]
)

# COMMAND ----------

# This notebook is executed for multiple concurrent groups of vessel types.
# To avoid the risk of concurrent writes to create the same folder,
# the target file path is unique per time and per vessel type.


def get_spire_query(since: str, page_size: int, ship_type: str, after: str) -> str:
    time_updated = since.strftime("%Y-%m-%dT%H:%M:%SZ")
    filters = f"""
        lastUpdate: {{ startTime: "{time_updated}" }},
        shipType: [{ship_type}],
        first: {page_size}
        {f', after: "{after}"' if after else ""}
    """
    return spire_query_template.substitute(query_filters=filters)


def send_spire_vessels_request(spire_query: str, session: requests.Session) -> dict:
    spire_response = session.post(
        url=SPIRE_ENDPOINT_URI,
        json={"query": spire_query},
        headers=SPIRE_REQUEST_HEADERS,
        timeout=(60, 60),
    )
    if spire_response.status_code != 200:
        exit_message = "{{ 'error_code': '{}', 'response_content': '{}' }}".format(
            spire_response.status_code, spire_response.content
        )
        print(exit_message)

    spire_response_json = spire_response.json()

    try:
        vessels = spire_response_json.get("data").get("vessels")
        page_info = vessels.get("pageInfo")
        end_cursor = page_info.get("endCursor")
        has_next_page = page_info.get("hasNextPage")
        total_count = vessels.get("totalCount").get("value")
    except AttributeError:
        print(f"Incorrect data in spire api response: {spire_response_json=}")
        raise

    result = {
        "end_cursor": end_cursor,
        "has_next_page": has_next_page,
        "total_count": total_count,
        "spire_response_json": spire_response_json,
    }
    return result


# Persist raw response to storage.
def save_response(ship_type: str, vessel_type_records: list):
    print(f"{ship_type} saving to: {TARGET_TABLE}")
    spire_response_df = spark.createDataFrame(vessel_type_records, schema=spire_schema)

    # change col name cdp_file_path to ship_type
    spire_response_df = spire_response_df.withColumn("cdp_ship_type", lit(ship_type))
    spire_response_df = spire_response_df.withColumn(
        "cdp_created",
        to_timestamp(
            lit(CURRENT_API_CALL_TIMESTAMP.strftime(date_format)),
            "yyyy-MM-dd'T'HH:mm:ss",
        ),
    )
    spire_response_df.write.mode("append").format("delta").saveAsTable(TARGET_TABLE)


def download_files(
    since: str,
    page_size: int,
    ship_type: str,
    session: requests.Session,
    print_initial_query: bool = False,
):
    def handle_error(ship_type, attempt, exception):
        print(f"{ship_type} error on attempt {attempt + 1}: {exception}")
        if attempt < max_retries:
            print(f"{ship_type} retrying... Attempt {attempt + 2}")
        else:
            print(f"{ship_type} all retries failed")
            raise

    page = 1
    vessel_type_records = []
    attempt = 0
    end_cursor = ""

    while attempt <= max_retries:
        try:
            # Make page request
            query = get_spire_query(
                since=since, page_size=page_size, ship_type=ship_type, after=end_cursor
            )
            if page == 1 and print_initial_query:
                print(f"{query=!r}")
            spire_response = send_spire_vessels_request(query, session)
            records = spire_response["spire_response_json"]
            vessel_type_records.append(records)
            print(f"{ship_type} appended page {page}")
            has_next_page = spire_response.get("has_next_page")
            if not has_next_page:
                print(f"{ship_type} all data fetched")
                break
            end_cursor = spire_response.get("end_cursor")
            page += 1
            attempt = 0  # Reset attempt counter after successful fetch
        except requests.exceptions.ConnectionError as conn_err:
            print(f"{ship_type} ConnectionError")
            session.close()
            session = create_session()
            handle_error(ship_type, attempt, conn_err)
            attempt += 1
        except AttributeError as attr_err:
            print(f"{ship_type} AttributeError")
            handle_error(ship_type, attempt, attr_err)
            attempt += 1

    save_response(ship_type, vessel_type_records)


# COMMAND ----------

# MAGIC %md
# MAGIC ## Concurrent requests
# MAGIC
# MAGIC If we request all data types we want, we receive a single paging reaponse,
# MAGIC which can take a very long time to page through.
# MAGIC By creating request threads for each ship type,
# MAGIC we can be paging through multiple datasets simultaneously,
# MAGIC and overall take just a few minutes.
# MAGIC For storage, we store JSON-based datasets for each ship type in the landing zone.

# COMMAND ----------


class DownloadFailedException(Exception):
    pass


exceptions = {}  # keep track of exceptions raised

with (
    concurrent.futures.ThreadPoolExecutor(max_workers=len(SHIP_TYPES)) as executor,
    create_session() as session,
):
    downloads: dict[concurrent.futures.Future, str] = {
        executor.submit(download_files, SINCE, PAGE_SIZE, ship_type, session): ship_type
        for ship_type in SHIP_TYPES
    }

    for future in concurrent.futures.as_completed(downloads):
        download_results = downloads[future]
        try:
            data = future.result()
        except Exception as exc:
            print(f"{download_results} generated an exception: {exc}")
            exceptions[download_results] = exc
        else:
            print(f"{download_results!r} done")

# if at least one ship type raised an exception, fail the pipeline
if len(exceptions):
    raise DownloadFailedException(f"{len(exceptions)} downloads failed:\n{exceptions}")

# COMMAND ----------

dbutils.jobs.taskValues.set(key="target_table", value=TARGET_TABLE)
dbutils.jobs.taskValues.set(
    key="last_api_call_timestamp",
    value=CURRENT_API_CALL_TIMESTAMP.strftime(date_format),
)

exit_message = {
    "target_table": TARGET_TABLE,
    "last_api_call_timestamp": CURRENT_API_CALL_TIMESTAMP.strftime(date_format),
}
dbutils.notebook.exit(exit_message)
