-- Databricks notebook source
CREATE WIDGET TEXT catalog_name DEFAULT 'hive_metastore';
CREATE WIDGET TEXT schema_name DEFAULT 'shipping_bronze';
CREATE WIDGET TEXT table_name DEFAULT 'spire_source_json';

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS IDENTIFIER(:catalog_name || '.' || :schema_name || '.' || :table_name)
(
    data            STRUCT<
                vessels: STRUCT<
                    nodes: ARRAY<STRUCT<
                       characteristics: STRUCT<
                            basic: STRUCT<
                                capacity: STRUCT<
                                    deadweight: INT,
                                    grossTonnage: INT
                                >,
                                history: STRUCT<
                                    builtYear: INT
                                >,
                                vesselTypeAndTrading: STRUCT<
                                    vesselSubtype: STRING
                                >
                            >
                        >,
                        currentVoyage: STRUCT<
                            destination: STRING,
                            draught: FLOAT,
                            eta: STRING,
                            matchedPort: STRUCT<
                                matchScore: FLOAT,
                                port: STRUCT<
                                    centerPoint: STRUCT<
                                        latitude: FLOAT,
                                        longitude: FLOAT
                                    >,
                                    name: STRING,
                                    unlocode: STRING
                                >
                            >,
                            timestamp: STRING,
                            updateTimestamp: STRING
                        >,
                        id: STRING, 
                        lastPositionUpdate: STRUCT<
                            accuracy: STRING,
                            collectionType: STRING,
                            course: FLOAT,
                            heading: FLOAT,
                            latitude: FLOAT,
                            longitude: FLOAT,
                            maneuver: STRING,
                            navigationalStatus: STRING,
                            rot: FLOAT,
                            speed: FLOAT,
                            timestamp: STRING,
                            updateTimestamp: STRING
                        >,
                        staticData: STRUCT<
                            aisClass: STRING,
                            callsign: STRING,
                            dimensions: STRUCT<
                                a: INT,
                                b: INT,
                                c: INT,
                                d: INT,
                                length: INT,
                                width: INT
                            >,
                            flag: STRING,
                            imo: INT,
                            mmsi: INT,
                            name: STRING,
                            shipSubType: STRING,
                            shipType: STRING,
                            timestamp: STRING,
                            updateTimestamp: STRING,
                            validated: STRUCT<
                                callsign: STRING,
                                callsignTimestamp: STRING,
                                dimensions: STRUCT<
                                    length: INT,
                                    width: INT
                                >,
                                imo: INT,
                                name: STRING,
                                nameTimestamp: STRING,
                                shipType: STRING
                            >
                        >,
                        timestamp: STRING,
                        updateTimestamp: STRING
                    >>,
                pageInfo: STRUCT<
                    endCursor: STRING,
                    hasNextPage: BOOLEAN
                >,
                totalCount: STRUCT<
                    relation: STRING,
                    value: INT
                >
                >

            >, 
    extensions      STRUCT<
                        requestId: STRING, 
                        requestQuota: STRUCT<
                            limit: STRING, 
                            remaining: INT
                    >>,   
    errors           ARRAY<STRUCT<extensions: 
                        STRUCT<
                        code: STRING
                        >,
                        message: STRING, 
                        path: ARRAY<STRING>
                    >>,  
    cdp_ship_type   STRING,
    cdp_created     TIMESTAMP NOT NULL
)
USING DELTA
CLUSTER BY (cdp_created);