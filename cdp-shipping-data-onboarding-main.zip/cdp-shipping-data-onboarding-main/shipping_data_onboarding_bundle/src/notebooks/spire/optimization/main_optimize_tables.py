# Databricks notebook source

import sys
import os
import itertools


def append_config_path_to_sys_path():
    def get_config_path(current_notebook_absolute_path: str = os.getcwd()) -> str:
        path_components = current_notebook_absolute_path.split("/")
        config_components = list(
            itertools.takewhile(lambda x: x != "notebooks", path_components)
        ) + ["config"]
        return "/".join(config_components)

    config_path = get_config_path()

    if config_path not in sys.path:
        sys.path.append(config_path)


append_config_path_to_sys_path()

# COMMAND ----------

from config import Config

# COMMAND ----------

config = Config()

catalog_name = config["shipping"]["catalog_name"]
schema_name = config["shipping"]["silver_schema_name"]

# COMMAND ----------

table_names = [
    "spire_vessel_position",
    "spire_vessel_static_data",
    "spire_vessel_static_data_history",
    "spire_vessel_voyage",
    "spire_vessel_characteristics",
    "spire_vessel_characteristics_history",
    "spire_vessel_id",
]

for table_name in table_names:
    dbutils.notebook.run(
        "../../shared/optimize_table",
        3600,
        {"catalog_name": catalog_name, "schema_name": schema_name, "table_name": table_name},
    )
