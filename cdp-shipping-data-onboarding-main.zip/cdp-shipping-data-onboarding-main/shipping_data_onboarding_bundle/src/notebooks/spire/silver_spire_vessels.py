# Databricks notebook source
# MAGIC %md
# MAGIC # Apply latest Spire changes
# MAGIC
# MAGIC Take all the files that are available in bronze spire_source_json
# MAGIC and merge it into the spire data silver tables:
# MAGIC
# MAGIC * spire_vessel_position
# MAGIC * spire_vessel_static_data
# MAGIC * spire_vessel_voyage
# MAGIC * spire_vessel_characteristics
# MAGIC * spire_vessel_id

# COMMAND ----------
dbutils.widgets.text("last_api_call_timestamp", "")

# COMMAND ----------

import sys
import os
import re

if (config_path := re.split(r"notebooks", os.getcwd())[0] + "config") not in sys.path:
    sys.path.append(config_path)

if (
    package_path := re.split(r"notebooks", os.getcwd())[0] + "shipping_data_onboarding_package"
) not in sys.path:
    sys.path.append(package_path)

# COMMAND ----------
from concurrent.futures import ThreadPoolExecutor, as_completed
from config import Config
from shared.shipping_system.merge_process import merge_process
from spire.silver_tables import spire_silver_merge_functions

# COMMAND ----------

config = Config()

last_api_call_timestamp = dbutils.widgets.get("last_api_call_timestamp")

catalog_name = config["shipping"]["catalog_name"]
bronze_schema_name = config["shipping"]["bronze_schema_name"]
silver_schema_name = config["shipping"]["silver_schema_name"]

system_catalog_name = config["shared"]["system_catalog_name"]
system_schema_name = config["shared"]["system_schema_name"]


# COMMAND ----------
spark.conf.set("spark.databricks.geo.st.enabled", "true")

# COMMAND ----------

source_table_name = "spire_source_json"

with ThreadPoolExecutor(max_workers=len(spire_silver_merge_functions)) as executor:
    notebook_futures = [
        executor.submit(
            merge_function,
            spark,
            catalog_name,
            silver_schema_name,
            bronze_schema_name,
            merge_function.__name__.replace("merge_", ""),
            source_table_name,
            last_api_call_timestamp,
        )
        for merge_function in spire_silver_merge_functions
    ]
    for future in as_completed(notebook_futures):
        print(future.result())
        # Wait for all futures to complete
        # Mark this notebook as failed if any of subnotebooks fails


# COMMAND ----------

merge_process(
    spark,
    catalog_name=system_catalog_name,
    schema_name=system_schema_name,
    table_name="process",
    process_name="spire_vessels",
    last_api_call_timestamp=last_api_call_timestamp,
)
