-- Databricks notebook source
CREATE WIDGET TEXT catalog_name DEFAULT 'hive_metastore';
CREATE WIDGET TEXT schema_name DEFAULT 'silver';
CREATE WIDGET TEXT table_name DEFAULT 'spire_vessel_characteristics';

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS IDENTIFIER(:catalog_name || '.' || :schema_name || '.' || :table_name)
(
  vessel_id               STRING,
  update_timestamp        TIMESTAMP,
  deadweight              INT,
  gross_tonnage           INT,
  built_year              INT,
  vessel_subtype          STRING,
  cdp_ship_type           STRING,
  cdp_created             TIMESTAMP
)
USING DELTA
CLUSTER BY (vessel_id)