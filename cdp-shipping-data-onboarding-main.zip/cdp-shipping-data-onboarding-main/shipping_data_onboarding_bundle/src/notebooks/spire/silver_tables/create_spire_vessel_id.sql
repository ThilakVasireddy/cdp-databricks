-- Databricks notebook source
CREATE WIDGET TEXT catalog_name DEFAULT 'hive_metastore';
CREATE WIDGET TEXT schema_name DEFAULT 'silver';
CREATE WIDGET TEXT table_name DEFAULT 'spire_vessel_id';

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS IDENTIFIER(:catalog_name || '.' || :schema_name || '.' || :table_name)
(
  vessel_id       STRING,
  cdp_ship_type   STRING,
  cdp_created     TIMESTAMP
)
USING DELTA
CLUSTER BY (vessel_id)
