-- Databricks notebook source
CREATE WIDGET TEXT catalog_name DEFAULT 'hive_metastore';
CREATE WIDGET TEXT schema_name DEFAULT 'silver';
CREATE WIDGET TEXT table_name DEFAULT 'spire_vessel_static_data_history';

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS IDENTIFIER(:catalog_name || '.' || :schema_name || '.' || :table_name)
(
  vessel_id                    STRING,
  ais_class                    STRING,
  callsign                     STRING,
  dim_a                        INT,
  dim_b                        INT,
  dim_c                        INT,
  dim_d                        INT,
  dim_length                   INT,
  dim_width                    INT,
  flag                         STRING,
  imo                          INT,
  mmsi                         INT,
  name                         STRING,
  ship_subtype                 STRING,
  ship_type                    STRING,
  create_timestamp             TIMESTAMP,
  update_timestamp             TIMESTAMP,
  validated_callsign           STRING,
  validated_callsign_timestamp TIMESTAMP,
  validated_dim_length         INT,
  validated_dim_width          INT,
  validated_imo                INT,
  validated_name               STRING,
  validated_name_timestamp     TIMESTAMP,
  validated_ship_type          STRING,
  cdp_ship_type                STRING,
  cdp_created                  TIMESTAMP
)
USING DELTA
CLUSTER BY (vessel_id, create_timestamp)