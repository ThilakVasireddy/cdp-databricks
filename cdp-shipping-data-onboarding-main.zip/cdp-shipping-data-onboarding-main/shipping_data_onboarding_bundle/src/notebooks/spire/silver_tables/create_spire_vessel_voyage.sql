-- Databricks notebook source
CREATE WIDGET TEXT catalog_name DEFAULT 'hive_metastore';
CREATE WIDGET TEXT schema_name DEFAULT 'silver';
CREATE WIDGET TEXT table_name DEFAULT 'spire_vessel_voyage';

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS IDENTIFIER(:catalog_name || '.' || :schema_name || '.' || :table_name)
(
  vessel_id                          STRING,
  destination                        STRING,
  draught                            FLOAT,
  eta                                TIMESTAMP,
  matched_port_match_score           FLOAT,
  matched_port_name                  STRING,
  matched_port_centerpoint_latitude  FLOAT,
  matched_port_centerpoint_longitude FLOAT,
  matched_port_unlocode              STRING,
  create_timestamp                   TIMESTAMP,
  update_timestamp                   TIMESTAMP,
  cdp_ship_type                      STRING,
  cdp_created                        TIMESTAMP
)
USING DELTA
CLUSTER BY (vessel_id, create_timestamp)