-- Databricks notebook source
SELECT COUNT(*), cdp_ship_type
FROM IDENTIFIER('hive_metastore.bronze.spire_source_json')
GROUP BY cdp_ship_type

-- COMMAND

SELECT COUNT(*), cdp_created
FROM IDENTIFIER('hive_metastore.bronze.spire_source_json')
GROUP BY cdp_created
ORDER BY cdp_created DESC

-- COMMAND

SELECT COUNT(*), cdp_created
FROM IDENTIFIER('hive_metastore.silver.spire_vessel_characteristics')
GROUP BY cdp_created
ORDER BY cdp_created DESC

-- COMMAND

SELECT COUNT(*), cdp_created
FROM IDENTIFIER('hive_metastore.silver.spire_vessel_id')
GROUP BY cdp_created
ORDER BY cdp_created DESC

-- COMMAND

SELECT COUNT(*), cdp_created
FROM IDENTIFIER('hive_metastore.silver.spire_vessel_position')
GROUP BY cdp_created
ORDER BY cdp_created DESC

-- COMMAND

SELECT COUNT(*), cdp_created
FROM IDENTIFIER('hive_metastore.silver.spire_vessel_characteristics_history')
GROUP BY cdp_created
ORDER BY cdp_created DESC

-- COMMAND

SELECT COUNT(*), cdp_created
FROM IDENTIFIER('hive_metastore.silver.spire_vessel_static_data')
GROUP BY cdp_created
ORDER BY cdp_created DESC

-- COMMAND

SELECT COUNT(*), cdp_created
FROM IDENTIFIER('hive_metastore.silver.spire_vessel_static_data_history')
GROUP BY cdp_created
ORDER BY cdp_created DESC

-- COMMAND

SELECT COUNT(*), cdp_created
FROM IDENTIFIER('hive_metastore.silver.spire_vessel_voyage')
GROUP BY cdp_created
ORDER BY cdp_created DESC