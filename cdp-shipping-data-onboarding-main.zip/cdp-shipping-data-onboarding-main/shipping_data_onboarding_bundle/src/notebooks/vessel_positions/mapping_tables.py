# Databricks notebook source
# MAGIC %md
# MAGIC ### [CMDP-3389] Mapping attributes in Positions - pipelines to create mapping tables in silver from csv files
# MAGIC
# MAGIC The file path is set in config.json and selected based on notebook parameters

# COMMAND ----------

dbutils.widgets.text("config_name", "")

# COMMAND ----------

import sys
import os
import re

if (config_path := re.split(r"notebooks", os.getcwd())[0] + "config") not in sys.path:
    sys.path.append(config_path)

if (
    package_path := re.split(r"notebooks", os.getcwd())[0] + "shipping_data_onboarding_package"
) not in sys.path:
    sys.path.append(package_path)

# COMMAND ----------

from datetime import datetime
import pyspark.sql.functions as F

from config import Config

# COMMAND ----------

config = Config()

config_name = dbutils.widgets.get("config_name")

system_catalog_name = config["shared"]["system_catalog_name"]
bronze_schema_name = config["shipping"]["bronze_schema_name"]
silver_schema_name = config["shipping"]["silver_schema_name"]
mappings_config = config["shipping"][config_name]
cdp_created = datetime.now()

print(f"{system_catalog_name=}")
print(f"{bronze_schema_name=}")
print(f"{silver_schema_name=}")
print(f"{mappings_config=}")
print(f"{cdp_created=}")

# COMMAND ----------


def process_mapping_config(
    system_catalog_name, silver_schema_name, silver_table_name, cdp_file_path, cdp_created
):
    df = spark.read.csv(cdp_file_path, header=True, inferSchema=True, sep=";")
    df = (
        df.withColumn("cdp_created", F.lit(cdp_created))
        .withColumn("cdp_file_path", F.lit(cdp_file_path))
        .write.mode("overwrite")
        .saveAsTable(f"{system_catalog_name}.{silver_schema_name}.{silver_table_name}")
    )


# COMMAND ----------

for mapping in mappings_config:
    file_path = mappings_config[mapping]["file_path"]
    silver_table_name = mappings_config[mapping]["silver_table_name"]
    cdp_file_path = f"/Volumes/{system_catalog_name}/{bronze_schema_name}/{file_path}"

    print(f"{file_path=}")
    print(f"{cdp_file_path=}")
    print(f"{silver_table_name=}")

    process_mapping_config(
        system_catalog_name, silver_schema_name, silver_table_name, cdp_file_path, cdp_created
    )
