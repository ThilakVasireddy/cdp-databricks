# Databricks notebook source
dbutils.widgets.text("catalog_name", "hive_metastore")
dbutils.widgets.text("schema_name", "shipping_silver")
dbutils.widgets.text("view_name", "vessel_positions_combined_vw")
dbutils.widgets.text("vt_positions_table_name", "vt_ais_position")
dbutils.widgets.text("spire_positions_table_name", "spire_vessel_position")

# COMMAND ----------

catalog_name = dbutils.widgets.get("catalog_name")
schema_name = dbutils.widgets.get("schema_name")
view_name = dbutils.widgets.get("view_name")
vt_positions_table_name = dbutils.widgets.get("vt_positions_table_name")
spire_positions_table_name = dbutils.widgets.get("spire_positions_table_name")

# COMMAND ----------

query = f"""
CREATE OR REPLACE VIEW {catalog_name}.{schema_name}.{view_name}
AS
SELECT
    vessel_id                       AS source_vessel_id,
    canonical_collection_type,
    cog,
    heading,
    latitude,
    longitude,
    canonical_navigational_status,
    rot_ais,
    sog,
    imo,
    destination,
    draught,
    eta,
    geom,
    h3_cellid,
    cdp_created,
    create_timestamp                AS time_received,
    'spire'                         AS source_name
FROM
    {catalog_name}.{schema_name}.{spire_positions_table_name}

UNION ALL

SELECT
    CAST(vessel_id AS STRING)       AS source_vessel_id,
    canonical_collection_type,
    cog,
    heading,
    latitude,
    longitude,
    canonical_navigational_status,
    rot                             AS rot_ais,
    sog,
    imo,
    destination,
    draught,
    eta,
    geom,
    h3_cellid,
    cdp_created,
    time_received,
    'vesseltracker'                 AS source_name
FROM
    {catalog_name}.{schema_name}.{vt_positions_table_name}
"""

spark.sql(query)
