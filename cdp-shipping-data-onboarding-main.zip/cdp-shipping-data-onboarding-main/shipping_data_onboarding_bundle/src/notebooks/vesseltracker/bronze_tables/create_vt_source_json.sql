-- Databricks notebook source
CREATE WIDGET TEXT catalog_name DEFAULT 'hive_metastore';
CREATE WIDGET TEXT schema_name DEFAULT 'shipping_bronze';
CREATE WIDGET TEXT table_name DEFAULT 'vt_source_json';

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS IDENTIFIER(:catalog_name || '.' || :schema_name || '.' || :table_name)
(
    message         STRING,
    numVessels      INT,
    numberOfResults INT,
    returnCode      INT,
    timeCreated     STRING,
    vessels         ARRAY<
        STRUCT<
            aisPosition:STRUCT<
                cog:FLOAT,
                hdg:FLOAT,
                lat:FLOAT,
                lon:FLOAT,
                navStatus:INT,
                rot:INT,
                sog:FLOAT,
                src:STRING,
                timeReceived:STRING>,
                aisStatic:STRUCT<
                    aisClass:STRING,
                    aisShiptype:STRING,
                    callsign:STRING,
                    dimA:INT,
                    dimB:INT,
                    dimC:INT,
                    dimD:INT,
                    eni:STRING,
                    flag:STRING,
                    imo:INT,
                    length:FLOAT,
                    mmsi:INT,
                    name:STRING,
                    typeOfShipAndCargo:INT,
                    updateTime:STRING,
                    width:FLOAT
                >,
                aisVoyage:STRUCT<
                    cargotype:INT,
                    dest:STRING,
                    draught:FLOAT,
                    eta:STRING,
                    source:STRING,
                    updateTime:STRING
                >,
                geoDetails:STRUCT<
                    currentAnchorage:STRING,
                    currentBerth:STRING,
                    currentPort:STRING,
                    currentPortLocode:STRING,
                    portCountry:STRING,
                    status:STRING,
                    timeOfATChange:STRING
                >,
                msg27:STRUCT<
                    cog:FLOAT,
                    hdg:FLOAT,
                    lat:FLOAT,
                    lon:FLOAT,
                    navStatus:INT,
                    rot:INT,
                    sog:FLOAT,
                    src:STRING,
                    timeReceived:STRING
                >,
                shipId:INT,
                vesselDetails:STRUCT<
                    deadWeight:INT,
                    grossTonnage:INT,
                    shipDBName:STRING,
                    shipType:STRING,
                    sizeClass:STRING,
                    teu:INT
                >,
                voyageDetails:STRUCT<
                    calculatedEta:STRING,
                    destination:STRING,
                    locode:STRING,
                    portCountry:STRING
                >
            >
        >,
    cdp_created   TIMESTAMP
)
USING DELTA
CLUSTER BY (cdp_created);
