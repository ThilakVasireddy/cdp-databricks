# Databricks notebook source
# MAGIC %md
# MAGIC # Download Vesseltracker vessels
# MAGIC
# MAGIC Downloads vessels from the Vesseltracker `userpolygon` API endpoint at
# MAGIC https://api.vesseltracker.com/api/v1/vessels/userpolygon
# MAGIC
# MAGIC This includes vessel characteristics, static data, voyage details,
# MAGIC and positions (AIS and Msg27).
# MAGIC
# MAGIC Subsequently save data to brozne table.
# MAGIC
# MAGIC Args (widgets):
# MAGIC
# MAGIC * api_base_url - The URI of the `userpolygon` endpoint.
# MAGIC * since - API requests are based on asking for the most
# MAGIC recent updates since a specific date/time.

# COMMAND ----------

import sys
import os
import itertools


def append_config_path_to_sys_path():
    def get_config_path(current_notebook_absolute_path: str = os.getcwd()) -> str:
        path_components = current_notebook_absolute_path.split("/")
        config_components = list(
            itertools.takewhile(lambda x: x != "notebooks", path_components)
        ) + ["config"]
        return "/".join(config_components)

    config_path = get_config_path()

    if config_path not in sys.path:
        sys.path.append(config_path)


append_config_path_to_sys_path()

# COMMAND ----------

import requests
from datetime import datetime, timedelta
from pyspark.sql.functions import lit, to_timestamp
from pyspark.sql.types import (
    StructType,
    StructField,
    ArrayType,
    StringType,
    FloatType,
    IntegerType,
)
from config import Config

# COMMAND ----------

config = Config()

API_BASE_URL_ARG = config["shipping"]["vessel_tracker"]["api_base_url"]

SYSTEM_CATALOG_NAME = config["shared"]["system_catalog_name"]
SYSTEM_SCHEMA_NAME = config["shared"]["system_schema_name"]

print(f"{API_BASE_URL_ARG=}")


# COMMAND ----------


def get_last_api_call_timestamp_from_metadata_process() -> datetime:
    """
    Retrieves the timestamp of the last API call from the metadata process table.

    Returns:
        datetime: The timestamp in miliseconds of the last API call.
    """
    df = spark.sql(
        f"""SELECT last_api_call_timestamp
            FROM {SYSTEM_CATALOG_NAME}.{SYSTEM_SCHEMA_NAME}.process
            WHERE process_name = 'vesseltracker_vessels'"""
    )

    now = datetime.now()
    last_api_call_timestamp = datetime(now.year, now.month, now.day, 0, 0, 0, 0)

    if df.count() > 0:
        # API can get no more than 1 day of data changes
        last_api_call_from_metadata_process = df.select("last_api_call_timestamp").first()[0]
        difference = abs(now - last_api_call_from_metadata_process)
        if difference < timedelta(days=1):
            last_api_call_timestamp = last_api_call_from_metadata_process

    return last_api_call_timestamp


CURRENT_API_CALL_TIMESTAMP = datetime.now()

SINCE = get_last_api_call_timestamp_from_metadata_process()
DATE_FORMAT = "%Y-%m-%dT%H:%M:%S"

QUERY_TIME_UPDATED = SINCE.strftime("%Y-%m-%dT%H:%M:%SZ")
QUERY_TOKEN = dbutils.secrets.get(config["shipping"]["secret_scope"], "vesseltracker-api-token")
QUERY_HEADERS = {"Authorization": QUERY_TOKEN}
API_URL = "{}?timeUpdated={}".format(API_BASE_URL_ARG, QUERY_TIME_UPDATED)

print(f"{CURRENT_API_CALL_TIMESTAMP=}")
print(f"{SINCE=}")
print(f"{API_URL=}")

# COMMAND ----------

# Call HTTP endpoint

api_response = requests.get(url=API_URL, headers=QUERY_HEADERS)
if api_response.status_code != 200:
    exit_message = "{{ 'error_code': '{}', 'response_content': '{}' }}".format(
        api_response.status_code, api_response.content
    )
    dbutils.notebook.exit(exit_message)

api_response_json = api_response.json()

# COMMAND ----------

CATALOG_NAME = config["shipping"]["catalog_name"]
BRONZE_SCHEMA_NAME = config["shipping"]["bronze_schema_name"]

# COMMAND ----------

vessels_schema = StructType(
    [
        StructField("numberOfResults", IntegerType(), True),
        StructField("timeCreated", StringType(), True),
        StructField("returnCode", IntegerType(), True),
        StructField("message", StringType(), True),
        StructField("numVessels", IntegerType(), True),
        StructField(
            "vessels",
            ArrayType(
                StructType(
                    [
                        StructField(
                            "aisPosition",
                            StructType(
                                [
                                    StructField("cog", FloatType(), True),
                                    StructField("hdg", FloatType(), True),
                                    StructField("lat", FloatType(), True),
                                    StructField("lon", FloatType(), True),
                                    StructField("navStatus", IntegerType(), True),
                                    StructField("rot", IntegerType(), True),
                                    StructField("sog", FloatType(), True),
                                    StructField("src", StringType(), True),
                                    StructField("timeReceived", StringType(), True),
                                ]
                            ),
                            True,
                        ),
                        StructField(
                            "aisStatic",
                            StructType(
                                [
                                    StructField("aisClass", StringType(), True),
                                    StructField("aisShiptype", StringType(), True),
                                    StructField("callsign", StringType(), True),
                                    StructField("dimA", IntegerType(), True),
                                    StructField("dimB", IntegerType(), True),
                                    StructField("dimC", IntegerType(), True),
                                    StructField("dimD", IntegerType(), True),
                                    StructField("eni", StringType(), True),
                                    StructField("flag", StringType(), True),
                                    StructField("imo", IntegerType(), True),
                                    StructField("length", FloatType(), True),
                                    StructField("mmsi", IntegerType(), True),
                                    StructField("name", StringType(), True),
                                    StructField("typeOfShipAndCargo", IntegerType(), True),
                                    StructField("updateTime", StringType(), True),
                                    StructField("width", FloatType(), True),
                                ]
                            ),
                            True,
                        ),
                        StructField(
                            "aisVoyage",
                            StructType(
                                [
                                    StructField("cargotype", IntegerType(), True),
                                    StructField("dest", StringType(), True),
                                    StructField("draught", FloatType(), True),
                                    StructField("eta", StringType(), True),
                                    StructField("source", StringType(), True),
                                    StructField("updateTime", StringType(), True),
                                ]
                            ),
                            True,
                        ),
                        StructField(
                            "geoDetails",
                            StructType(
                                [
                                    StructField("currentAnchorage", StringType(), True),
                                    StructField("currentBerth", StringType(), True),
                                    StructField("currentPort", StringType(), True),
                                    StructField("currentPortLocode", StringType(), True),
                                    StructField("portCountry", StringType(), True),
                                    StructField("status", StringType(), True),
                                    StructField("timeOfATChange", StringType(), True),
                                ]
                            ),
                            True,
                        ),
                        StructField(
                            "msg27",
                            StructType(
                                [
                                    StructField("cog", FloatType(), True),
                                    StructField("hdg", FloatType(), True),
                                    StructField("lat", FloatType(), True),
                                    StructField("lon", FloatType(), True),
                                    StructField("navStatus", IntegerType(), True),
                                    StructField("rot", IntegerType(), True),
                                    StructField("sog", FloatType(), True),
                                    StructField("src", StringType(), True),
                                    StructField("timeReceived", StringType(), True),
                                ]
                            ),
                            True,
                        ),
                        StructField("shipId", IntegerType(), True),
                        StructField(
                            "vesselDetails",
                            StructType(
                                [
                                    StructField("deadWeight", IntegerType(), True),
                                    StructField("grossTonnage", IntegerType(), True),
                                    StructField("shipDBName", StringType(), True),
                                    StructField("shipType", StringType(), True),
                                    StructField("sizeClass", StringType(), True),
                                    StructField("teu", IntegerType(), True),
                                ]
                            ),
                            True,
                        ),
                        StructField(
                            "voyageDetails",
                            StructType(
                                [
                                    StructField("calculatedEta", StringType(), True),
                                    StructField("destination", StringType(), True),
                                    StructField("locode", StringType(), True),
                                    StructField("portCountry", StringType(), True),
                                ]
                            ),
                            True,
                        ),
                    ]
                )
            ),
            True,
        ),
    ]
)

# COMMAND ----------

response_df = spark.createDataFrame([api_response_json], schema=vessels_schema)

# COMMAND ----------

response_df = response_df.withColumn(
    "cdp_created",
    to_timestamp(lit(CURRENT_API_CALL_TIMESTAMP.strftime(DATE_FORMAT)), "yyyy-MM-dd'T'HH:mm:ss"),
)

response_df.write.mode("append").format("delta").saveAsTable(
    f"{CATALOG_NAME}.{BRONZE_SCHEMA_NAME}.vt_source_json"
)

# COMMAND ----------

dbutils.jobs.taskValues.set(
    key="last_api_call_timestamp",
    value=CURRENT_API_CALL_TIMESTAMP.strftime(DATE_FORMAT),
)

exit_message = {"last_api_call_timestamp": CURRENT_API_CALL_TIMESTAMP.strftime(DATE_FORMAT)}
dbutils.notebook.exit(exit_message)
