-- Databricks notebook source
CREATE WIDGET TEXT catalog_name DEFAULT 'hive_metastore';
CREATE WIDGET TEXT schema_name DEFAULT 'bronze';
CREATE WIDGET TEXT table_name DEFAULT 'vt_source_history_csv';
-- COMMAND ----------
CREATE TABLE IF NOT EXISTS IDENTIFIER(
    :catalog_name || '.' || :schema_name || '.' || :table_name
  ) (
    ship_id STRING,
    name STRING,
    imo STRING,
    mmsi STRING,
    callsign STRING,
    length STRING,
    width STRING,
    timestamp_position STRING,
    source_position STRING,
    lon STRING,
    lat STRING,
    speed STRING,
    course STRING,
    heading STRING,
    rot STRING,
    nav_status STRING,
    timestamp_voyage STRING,
    source_voyage STRING,
    draught STRING,
    destination STRING,
    destination_portname STRING,
    destination_locode STRING,
    eta STRING,
    shiptype STRING,
    d_my_vessel_type STRING,
    dimA STRING,
    dimB STRING,
    dimC STRING,
    dimD STRING,
    msgid STRING,
    cdp_created TIMESTAMP,
    cdp_filepath STRING
  ) 
  USING DELTA
  CLUSTER BY (ship_id, timestamp_position, cdp_filepath)