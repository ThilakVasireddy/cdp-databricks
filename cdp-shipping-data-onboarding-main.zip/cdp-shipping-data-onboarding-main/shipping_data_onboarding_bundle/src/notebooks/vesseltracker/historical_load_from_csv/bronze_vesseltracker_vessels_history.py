# Databricks notebook source
# MAGIC %md
# MAGIC # Load vesseltracker history data from landing to bronze

# COMMAND ----------

import sys
import os
import itertools


def append_config_path_to_sys_path():
    def get_config_path(current_notebook_absolute_path: str = os.getcwd()) -> str:
        path_components = current_notebook_absolute_path.split("/")
        config_components = list(
            itertools.takewhile(lambda x: x != "notebooks", path_components)
        ) + ["config"]
        return "/".join(config_components)

    config_path = get_config_path()

    if config_path not in sys.path:
        sys.path.append(config_path)


append_config_path_to_sys_path()

# COMMAND ----------

from config import Config
from datetime import datetime
from pyspark.sql.functions import to_timestamp, lit, col


# COMMAND ----------

config = Config()
CATALOG_NAME = config["shipping"]["catalog_name"]
BRONZE_SCHEMA_NAME = config["shipping"]["bronze_schema_name"]
LANDING_GZ_FOLDER = config["shipping"]["vessel_tracker_history"]["landing_path_gz"]

# COMMAND ----------

BRONZE_TABLE_NAME = "vt_source_history_csv"
CURRENT_API_CALL_TIMESTAMP = datetime.now()

# COMMAND ----------


def process_all_files_autoloader(source_folder):
    bronze_schema = """
    ship_id STRING,
    name STRING,
    imo STRING,
    mmsi STRING,
    callsign STRING,
    length STRING,
    width STRING,
    timestamp_position STRING,
    source_position STRING,
    lon STRING,
    lat STRING,
    speed STRING,
    course STRING,
    heading STRING,
    rot STRING,
    nav_status STRING,
    timestamp_voyage STRING,
    source_voyage STRING,
    draught STRING,
    destination STRING,
    destination_portname STRING,
    destination_locode STRING,
    eta STRING,
    shiptype STRING,
    d_my_vessel_type STRING,
    dimA STRING,
    dimB STRING,
    dimC STRING,
    dimD STRING,
    msgid STRING,
    cdp_created TIMESTAMP,
    cdp_filepath STRING
    """
    # Read data using Auto Loader
    df = (
        spark.readStream.format("cloudFiles")
        .option("cloudFiles.format", "csv")
        .option("cloudFiles.maxFilesPerTrigger", 60)
        .option("header", "true")
        .option("cloudFiles.schemaLocation", f"{source_folder}/_schema")
        .schema(bronze_schema)
        .load(source_folder)
        .withColumn(
            "cdp_created",
            to_timestamp(
                lit(CURRENT_API_CALL_TIMESTAMP.strftime("%Y-%m-%dT%H:%M:%S")),
                "yyyy-MM-dd'T'HH:mm:ss",
            ),
        )
        .withColumn("cdp_filepath", col("_metadata.file_path"))
    )

    # Write data to Delta table
    (
        df.writeStream.outputMode("append")
        .trigger(availableNow=True)
        .option("checkpointLocation", f"{source_folder}/_checkpoint")
        .table(f"{CATALOG_NAME}.{BRONZE_SCHEMA_NAME}.{BRONZE_TABLE_NAME}")
        .awaitTermination()
    )


process_all_files_autoloader(LANDING_GZ_FOLDER)
