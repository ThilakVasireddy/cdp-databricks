# Databricks notebook source
# MAGIC %md
# MAGIC # Cleanup vesseltracker history folder

# COMMAND ----------

import sys
import os
import itertools


def append_config_path_to_sys_path():
    def get_config_path(current_notebook_absolute_path: str = os.getcwd()) -> str:
        path_components = current_notebook_absolute_path.split("/")
        config_components = list(
            itertools.takewhile(lambda x: x != "notebooks", path_components)
        ) + ["config"]
        return "/".join(config_components)

    config_path = get_config_path()

    if config_path not in sys.path:
        sys.path.append(config_path)


append_config_path_to_sys_path()

# COMMAND ----------

from config import Config

# COMMAND ----------

config = Config()

catalog_name = config["shipping"]["catalog_name"]
bronze_schema_name = config["shipping"]["bronze_schema_name"]
silver_schema_name = config["shipping"]["silver_schema_name"]
landing_folder = config["shipping"]["vessel_tracker_history"]["landing_path"]

# COMMAND ----------

# DBTITLE 1,Remove landing folder
dbutils.fs.rm(landing_folder, recurse=True)

# COMMAND ----------

# DBTITLE 1,Enable VACUUM RETAIN 0 HOURS
spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", False)

# COMMAND ----------

# DBTITLE 1,Delete and VACUUM
env = os.environ["ENV"]
stage = os.environ["STAGE"]

# make sure not to delete data in prod live by accident
if env != "prd" or stage != "live":
    spark.sql(f"DELETE FROM {catalog_name}.{bronze_schema_name}.vt_source_history_csv;")
    spark.sql(f"VACUUM {catalog_name}.{bronze_schema_name}.vt_source_history_csv RETAIN 0 HOURS;")

    spark.sql(f"DELETE FROM {catalog_name}.{silver_schema_name}.vt_position_history;")
    spark.sql(f"VACUUM {catalog_name}.{silver_schema_name}.vt_position_history RETAIN 0 HOURS;")
