# Databricks notebook source
# MAGIC %md
# MAGIC # Download vesseltracker history data from dataexport to landing

# COMMAND ----------

import sys
import os
import itertools


def append_config_path_to_sys_path():
    def get_config_path(current_notebook_absolute_path: str = os.getcwd()) -> str:
        path_components = current_notebook_absolute_path.split("/")
        config_components = list(
            itertools.takewhile(lambda x: x != "notebooks", path_components)
        ) + ["config"]
        return "/".join(config_components)

    config_path = get_config_path()

    if config_path not in sys.path:
        sys.path.append(config_path)


append_config_path_to_sys_path()

# COMMAND ----------

import requests
from concurrent.futures import ThreadPoolExecutor
from datetime import date, timedelta
from config import Config
import gzip
import shutil
import zipfile

# COMMAND ----------

dbutils.widgets.text("start_date", "")  # 2014-11-14
dbutils.widgets.text("end_date", "")  # 2025-05-16


# COMMAND ----------

config = Config()
LANDING_FOLDER = config["shipping"]["vessel_tracker_history"]["landing_path"]
BASE_API_URL = config["shipping"]["vessel_tracker_history"]["api_base_history_url"]

TARGET_CSV_FOLDER = LANDING_FOLDER
TARGET_GZ_GOLDER = f"{LANDING_FOLDER}/gz"

START_DATE = date.fromisoformat(dbutils.widgets.get("start_date"))
END_DATE = date.fromisoformat(dbutils.widgets.get("end_date"))

CURRENT_DATE = START_DATE
DELTA = timedelta(days=1)

# COMMAND ----------


def compress_csv_to_gz(csv_file_path, target_gz_path):
    with open(csv_file_path, "rb") as f_in:
        with gzip.open(target_gz_path, "wb") as f_out:
            shutil.copyfileobj(f_in, f_out)
    print(f"Compressed {csv_file_path} to {target_gz_path}")
    os.remove(csv_file_path)
    print(f"Removed original file: {csv_file_path}")


def compress_zip_to_gz(zip_file_path, gzip_file_path):
    with zipfile.ZipFile(zip_file_path, "r") as zip_ref:
        # Assuming there is only one file in the ZIP, get the extracted file name
        extracted_file_name = zip_ref.namelist()[0]

        # Read the extracted file directly from the ZIP and write to GZIP
        with zip_ref.open(extracted_file_name) as f_in:
            with gzip.open(gzip_file_path, "wb") as f_out:
                shutil.copyfileobj(f_in, f_out)

        print(f"Converted {zip_file_path} to {gzip_file_path}")
        os.remove(zip_file_path)
        print(f"Removed original file: {zip_file_path}")


# COMMAND ----------


class FileDownloadFailedException(Exception):
    pass


def construct_url(current_date: date):
    date_string = current_date.strftime("%Y-%m-%d")
    return f"{BASE_API_URL}/tr_{date_string}.csv.zip"


def download_and_save_to_landing(api_url, file_name):
    target_gz_file_path = f"{TARGET_GZ_GOLDER}/{file_name}.gz".replace(".zip", "")

    # Check if the file already exists and is non-empty
    if os.path.exists(target_gz_file_path) and os.path.getsize(target_gz_file_path) > 0:
        print(f"Skipping the file {file_name} as it exists")
        return

    print("Downloading from url: {}".format(api_url))
    response = requests.get(api_url)

    if response.status_code == 200:
        target_raw_file_path = f"{TARGET_CSV_FOLDER}/{file_name}"

        print(f"Downloading file: {file_name} to {target_raw_file_path}")
        with open(target_raw_file_path, "wb") as file:
            file.write(response.content)
        print(f"Downloaded {file_name}")

        if file_name.endswith(".csv"):
            compress_csv_to_gz(target_raw_file_path, target_gz_file_path)
        if file_name.endswith(".zip"):
            compress_zip_to_gz(target_raw_file_path, target_gz_file_path)

    else:
        raise FileDownloadFailedException(f"Failed to download file: {response.status_code}")


dbutils.fs.mkdirs(TARGET_GZ_GOLDER)

date_list = [START_DATE + timedelta(days=x) for x in range((END_DATE - START_DATE).days + 1)]

# Use ThreadPoolExecutor to parallelize the download process
with ThreadPoolExecutor(max_workers=32) as executor:
    futures = [
        executor.submit(
            download_and_save_to_landing,
            construct_url(current_date),
            f"tr_{current_date.strftime('%Y-%m-%d')}.csv.zip",
        )
        for current_date in date_list
    ]

# Wait for all futures to complete
for future in futures:
    future.result()
