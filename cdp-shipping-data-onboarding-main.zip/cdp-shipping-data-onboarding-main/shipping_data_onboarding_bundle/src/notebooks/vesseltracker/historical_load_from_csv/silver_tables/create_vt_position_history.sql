-- Databricks notebook source
CREATE WIDGET TEXT catalog_name DEFAULT 'hive_metastore';
CREATE WIDGET TEXT schema_name DEFAULT 'silver';
CREATE WIDGET TEXT table_name DEFAULT 'vt_position_history';
-- COMMAND ----------
CREATE TABLE IF NOT EXISTS IDENTIFIER(
    :catalog_name || '.' || :schema_name || '.' || :table_name
  ) (
    ship_id BIGINT,
    name STRING,
    imo BIGINT,
    mmsi BIGINT,
    callsign STRING,
    length DOUBLE,
    width DOUBLE,
    timestamp_position TIMESTAMP,
    source_position STRING,
    lon DOUBLE,
    lat DOUBLE,
    speed DOUBLE,
    course DOUBLE,
    heading DOUBLE,
    rot BIGINT,
    nav_status BIGINT,
    timestamp_voyage TIMESTAMP,
    source_voyage STRING,
    draught DOUBLE,
    destination STRING,
    destination_portname STRING,
    destination_locode STRING,
    eta TIMESTAMP,
    shiptype STRING,
    d_my_vessel_type STRING,
    dimA BIGINT,
    dimB BIGINT,
    dimC BIGINT,
    dimD BIGINT,
    msgid STRING,
    cdp_created TIMESTAMP,
    cdp_filepath STRING
  ) 
  USING DELTA
  CLUSTER BY (ship_id, timestamp_position, cdp_filepath)