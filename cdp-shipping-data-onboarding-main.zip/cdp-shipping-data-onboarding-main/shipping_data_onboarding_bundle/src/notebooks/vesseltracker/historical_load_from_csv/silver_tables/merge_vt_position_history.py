# Databricks notebook source
# DBTITLE 1,Widgets
dbutils.widgets.text("catalog_name", "hive_metastore")
dbutils.widgets.text("bronze_schema_name", "shipping_bronze")
dbutils.widgets.text("silver_schema_name", "shipping_silver")
dbutils.widgets.text("source_table_name", "vt_source_history_csv")
dbutils.widgets.text("target_table_name", "vt_position_history")
dbutils.widgets.text("start_date", "")
dbutils.widgets.text("end_date", "")

catalog_name = dbutils.widgets.get("catalog_name")
silver_schema_name = dbutils.widgets.get("silver_schema_name")
bronze_schema_name = dbutils.widgets.get("bronze_schema_name")
target_table_name = dbutils.widgets.get("target_table_name")
source_table_name = dbutils.widgets.get("source_table_name")
start_date = dbutils.widgets.get("start_date")
end_date = dbutils.widgets.get("end_date")

# COMMAND ----------

# DBTITLE 1,Query
result = spark.sql(f"""
INSERT INTO {catalog_name}.{silver_schema_name}.{target_table_name}
SELECT
  CAST(bronze_src.ship_id AS BIGINT) AS ship_id,
  CAST(bronze_src.name AS STRING) AS name,
  CAST(bronze_src.imo AS BIGINT) AS imo,
  CAST(bronze_src.mmsi AS BIGINT) AS mmsi,
  CAST(bronze_src.callsign AS STRING) AS callsign,
  CAST(bronze_src.length AS DOUBLE) AS length,
  CAST(bronze_src.width AS DOUBLE) AS width,
  CAST(bronze_src.timestamp_position AS TIMESTAMP) AS timestamp_position,
  CAST(bronze_src.source_position AS STRING) AS source_position,
  CAST(bronze_src.lon AS DOUBLE) AS lon,
  CAST(bronze_src.lat AS DOUBLE) AS lat,
  CAST(bronze_src.speed AS DOUBLE) AS speed,
  CAST(bronze_src.course AS DOUBLE) AS course,
  CAST(bronze_src.heading AS DOUBLE) AS heading,
  CAST(bronze_src.rot AS BIGINT) AS rot,
  CAST(bronze_src.nav_status AS BIGINT) AS nav_status,
  CAST(bronze_src.timestamp_voyage AS TIMESTAMP) AS timestamp_voyage,
  CAST(bronze_src.source_voyage AS STRING) AS source_voyage,
  CAST(bronze_src.draught AS DOUBLE) AS draught,
  CAST(bronze_src.destination AS STRING) AS destination,
  CAST(bronze_src.destination_portname AS STRING) AS destination_portname,
  CAST(bronze_src.destination_locode AS STRING) AS destination_locode,
  CAST(bronze_src.eta AS TIMESTAMP) AS eta,
  CAST(bronze_src.shiptype AS STRING) AS shiptype,
  CAST(bronze_src.d_my_vessel_type AS STRING) AS d_my_vessel_type,
  CAST(bronze_src.dimA AS BIGINT) AS dimA,
  CAST(bronze_src.dimB AS BIGINT) AS dimB,
  CAST(bronze_src.dimC AS BIGINT) AS dimC,
  CAST(bronze_src.dimD AS BIGINT) AS dimD,
  CAST(bronze_src.msgid AS STRING) AS msgid,
  CAST(bronze_src.cdp_created AS TIMESTAMP) AS cdp_created,
  CAST(bronze_src.cdp_filepath AS STRING) AS cdp_filepath
FROM
   {catalog_name}.{bronze_schema_name}.{source_table_name} AS bronze_src
WHERE NOT EXISTS(
    SELECT *
    FROM
      {catalog_name}.{silver_schema_name}.{target_table_name} AS silver_trg
    WHERE
      silver_trg.cdp_filepath = bronze_src.cdp_filepath
      AND CAST(silver_trg.timestamp_position AS date) BETWEEN CAST('{start_date}' AS date)
        AND CAST('{end_date}' AS date)
) AND CAST(bronze_src.timestamp_position AS date) BETWEEN CAST('{start_date}' AS date)
        AND CAST('{end_date}' AS date)
""")
