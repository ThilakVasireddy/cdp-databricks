# Databricks notebook source
# MAGIC %md
# MAGIC # Run instert to vt_position_history

# COMMAND ----------
import sys
import os
import re

if (config_path := re.split(r"notebooks", os.getcwd())[0] + "config") not in sys.path:
    sys.path.append(config_path)

if (
    package_path := re.split(r"notebooks", os.getcwd())[0] + "shipping_data_onboarding_package"
) not in sys.path:
    sys.path.append(package_path)

# COMMAND ----------

dbutils.widgets.text("start_date", "")  # 2014-11-14
dbutils.widgets.text("end_date", "")  # 2025-05-16

# COMMAND ----------
from config import Config

# COMMAND ----------
config = Config()

catalog_name = config["shipping"]["catalog_name"]
bronze_schema_name = config["shipping"]["bronze_schema_name"]
silver_schema_name = config["shipping"]["silver_schema_name"]
start_date = dbutils.widgets.get("start_date")
end_date = dbutils.widgets.get("end_date")

# COMMAND ----------
dbutils.notebook.run(
    "silver_tables/merge_vt_position_history",
    36000,
    {
        "catalog_name": catalog_name,
        "silver_schema_name": silver_schema_name,
        "bronze_schema_name": bronze_schema_name,
        "target_table_name": "vt_position_history",
        "source_table_name": "vt_source_history_csv",
        "start_date": start_date,
        "end_date": end_date,
    },
)
