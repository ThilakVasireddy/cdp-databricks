# Databricks notebook source

import sys
import os
import itertools


def append_config_path_to_sys_path():
    def get_config_path(current_notebook_absolute_path: str = os.getcwd()) -> str:
        path_components = current_notebook_absolute_path.split("/")
        config_components = list(
            itertools.takewhile(lambda x: x != "notebooks", path_components)
        ) + ["config"]
        return "/".join(config_components)

    config_path = get_config_path()

    if config_path not in sys.path:
        sys.path.append(config_path)


append_config_path_to_sys_path()

# COMMAND ----------

from config import Config

# COMMAND ----------

config = Config()

catalog_name = config["shipping"]["catalog_name"]
schema_name = config["shipping"]["silver_schema_name"]

# COMMAND ----------

table_names = [
    "vt_ais_position",
    "vt_ais_static",
    "vt_ais_voyage",
    "vt_geo_details",
    "vt_msg27",
    "vt_vessel_details",
    "vt_vessel_id",
    "vt_voyage_details",
    "vt_voyage_details_history",
    "vt_vessel_details_history",
    "vt_ais_static_history",
    "vt_geo_details_history",
    "vt_ais_voyage_history",
]

for table_name in table_names:
    dbutils.notebook.run(
        "../../shared/optimize_table",
        3600,
        {"catalog_name": catalog_name, "schema_name": schema_name, "table_name": table_name},
    )
