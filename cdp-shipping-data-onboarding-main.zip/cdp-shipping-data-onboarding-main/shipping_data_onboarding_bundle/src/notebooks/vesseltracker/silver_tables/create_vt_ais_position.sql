-- Databricks notebook source
CREATE WIDGET TEXT catalog_name DEFAULT 'hive_metastore';
CREATE WIDGET TEXT schema_name DEFAULT 'silver';
CREATE WIDGET TEXT table_name DEFAULT 'vt_ais_position';

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS IDENTIFIER(:catalog_name || '.' || :schema_name || '.' || :table_name)
(
  vessel_id                     INT,
  time_received                 TIMESTAMP,
  collection_type               STRING,
  longitude                     FLOAT,
  latitude                      FLOAT,
  sog                           FLOAT,
  cog                           FLOAT,
  heading                       FLOAT,
  rot                           INT,
  navigational_status           INT,

  imo                           INT,

  destination                   STRING,
  eta                           TIMESTAMP,
  draught                       FLOAT,

  geom                          STRING,

  h3_cellid                     LONG,

  canonical_collection_type     STRING,
  canonical_navigational_status STRING,

  cdp_created                   TIMESTAMP
  )
USING DELTA
CLUSTER BY (vessel_id, time_received)
