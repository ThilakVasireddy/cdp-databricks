-- Databricks notebook source
CREATE WIDGET TEXT catalog_name DEFAULT 'hive_metastore';
CREATE WIDGET TEXT schema_name DEFAULT 'silver';
CREATE WIDGET TEXT table_name DEFAULT 'vt_ais_static';

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS IDENTIFIER(:catalog_name || '.' || :schema_name || '.' || :table_name)
(
  vessel_id              INT,
  name                   STRING,
  mmsi                   INT,
  imo                    INT,
  callsign               STRING,
  flag                   STRING,
  dim_a                  INT,
  dim_b                  INT,
  dim_c                  INT,
  dim_d                  INT,
  length                 FLOAT,
  width                  FLOAT,
  type_of_ship_and_cargo INT,
  ais_shiptype           STRING,
  update_time            TIMESTAMP,
  cdp_created            TIMESTAMP
)
USING DELTA
CLUSTER BY (vessel_id, update_time)
