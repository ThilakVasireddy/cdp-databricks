-- Databricks notebook source
CREATE WIDGET TEXT catalog_name DEFAULT 'hive_metastore';
CREATE WIDGET TEXT schema_name DEFAULT 'silver';
CREATE WIDGET TEXT table_name DEFAULT 'vt_geo_details_history';

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS IDENTIFIER(:catalog_name || '.' || :schema_name || '.' || :table_name)
(
  vessel_id           INT,
  current_port        STRING,
  current_port_locode STRING,
  port_country        STRING,
  current_berth       STRING,
  current_anchorage   STRING,
  time_of_at_change   TIMESTAMP,
  status              STRING,
  area                STRING,
  cdp_created         TIMESTAMP
)
USING DELTA
CLUSTER BY (vessel_id, time_of_at_change)
