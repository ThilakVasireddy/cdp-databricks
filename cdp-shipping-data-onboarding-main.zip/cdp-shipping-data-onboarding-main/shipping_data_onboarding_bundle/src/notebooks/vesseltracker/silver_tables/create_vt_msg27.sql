-- Databricks notebook source
CREATE WIDGET TEXT catalog_name DEFAULT 'hive_metastore';
CREATE WIDGET TEXT schema_name DEFAULT 'silver';
CREATE WIDGET TEXT table_name DEFAULT 'vt_msg27';

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS IDENTIFIER(:catalog_name || '.' || :schema_name || '.' || :table_name)
(
  vessel_id           INT,
  time_received       TIMESTAMP,
  src                 STRING,
  lon                 FLOAT,
  lat                 FLOAT,
  sog                 FLOAT,
  cog                 FLOAT,
  hdg                 FLOAT,
  rot                 INT,
  navigational_status INT,
  cdp_created         TIMESTAMP
)
USING DELTA
CLUSTER BY (vessel_id, time_received)
