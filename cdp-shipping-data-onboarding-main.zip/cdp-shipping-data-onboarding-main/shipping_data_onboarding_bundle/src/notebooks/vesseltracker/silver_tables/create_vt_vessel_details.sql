-- Databricks notebook source
CREATE WIDGET TEXT catalog_name DEFAULT 'hive_metastore';
CREATE WIDGET TEXT schema_name DEFAULT 'silver';
CREATE WIDGET TEXT table_name DEFAULT 'vt_vessel_details';

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS IDENTIFIER(:catalog_name || '.' || :schema_name || '.' || :table_name)
(
  vessel_id       INT,
  ship_type       STRING,
  size_class      STRING,
  gross_tonnage   INT,
  dead_weight     INT,
  teu             INT,
  cdp_created     TIMESTAMP
)
USING DELTA
CLUSTER BY (vessel_id)
