-- Databricks notebook source
CREATE WIDGET TEXT catalog_name DEFAULT 'hive_metastore';
CREATE WIDGET TEXT schema_name DEFAULT 'silver';
CREATE WIDGET TEXT table_name DEFAULT 'vt_voyage_details';

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS IDENTIFIER(:catalog_name || '.' || :schema_name || '.' || :table_name)
(
  vessel_id        INT,
  destination      STRING,
  locode           STRING,
  port_country     STRING,
  calculated_eta   TIMESTAMP,
  cdp_created      TIMESTAMP
)
USING DELTA
CLUSTER BY (vessel_id)