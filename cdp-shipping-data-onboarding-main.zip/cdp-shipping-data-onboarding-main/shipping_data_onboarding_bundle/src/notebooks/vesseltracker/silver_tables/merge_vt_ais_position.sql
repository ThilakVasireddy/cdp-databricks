-- Databricks notebook source

CREATE WIDGET TEXT catalog_name DEFAULT 'hive_metastore';
CREATE WIDGET TEXT silver_schema_name DEFAULT 'silver';
CREATE WIDGET TEXT bronze_schema_name DEFAULT 'bronze';
CREATE WIDGET TEXT target_table_name DEFAULT 'vt_ais_position';
CREATE WIDGET TEXT source_table_name DEFAULT 'vt_source_json';
CREATE WIDGET TEXT mapping_navigational_status DEFAULT 'config_ais_mapping_navigational_status';
CREATE WIDGET TEXT mapping_collection_type DEFAULT 'config_vt_mapping_collection_type';
CREATE WIDGET TEXT last_api_call_timestamp DEFAULT '';

-- COMMAND ----------

SET spark.databricks.geo.st.enabled = true;

-- COMMAND ----------

WITH src AS (
  SELECT
    cdp_created,
    EXPLODE(vessels)               AS vessel
  FROM
    IDENTIFIER(:catalog_name || '.' || :bronze_schema_name || '.' || :source_table_name)
  WHERE
    cdp_created = :last_api_call_timestamp
), ordered AS (
  SELECT
    vessel.shipId,
    vessel.aisPosition.timeReceived             AS time_received,
    vessel.aisPosition.src                      AS collection_type,
    vessel.aisPosition.lon                      AS longitude,
    vessel.aisPosition.lat                      AS latitude,
    vessel.aisPosition.sog,
    vessel.aisPosition.cog,
    vessel.aisPosition.hdg                      AS heading,
    vessel.aisPosition.rot,
    vessel.aisPosition.navStatus                AS navigational_status,

    vessel.aisStatic.imo                        AS imo,

    vessel.aisVoyage.dest                       AS destination,
    vessel.aisVoyage.eta                        AS eta,
    vessel.aisVoyage.draught                    AS draught,

    ST_astext(
        ST_Point(
          vessel.aisPosition.lon,
          vessel.aisPosition.lat))  AS geom,

    cdp_created,
    ROW_NUMBER() OVER (PARTITION BY vessel.shipId, vessel.aisPosition.timeReceived ORDER BY cdp_created DESC) AS rn
  FROM src
), filtered AS (
  SELECT o.*,
    h3_pointash3(o.geom, 11) AS h3_cellid,
    ns.canonical_name        AS canonical_navigational_status,
    ct.canonical_name        AS canonical_collection_type
  FROM
    ordered AS o
  LEFT JOIN
    IDENTIFIER(:catalog_name || '.' || :silver_schema_name || '.' || :mapping_navigational_status) AS ns
    ON ns.source_name = o.navigational_status
  LEFT JOIN
    IDENTIFIER(:catalog_name || '.' || :silver_schema_name || '.' || :mapping_collection_type) AS ct
    ON ct.source_name = o.collection_type
  WHERE
    o.rn = 1
    AND o.latitude IS NOT NULL
    AND o.longitude IS NOT NULL
)
MERGE INTO IDENTIFIER(:catalog_name || '.' || :silver_schema_name || '.' || :target_table_name) AS trg
USING filtered
    ON filtered.shipId = trg.vessel_id
    AND filtered.time_received = trg.time_received
WHEN MATCHED THEN
UPDATE
  SET
    vessel_id                     = filtered.shipId,
    time_received                 = filtered.time_received,
    collection_type               = filtered.collection_type,
    longitude                     = filtered.longitude,
    latitude                      = filtered.latitude,
    sog                           = filtered.sog,
    cog                           = filtered.cog,
    heading                       = filtered.heading,
    rot                           = filtered.rot,
    navigational_status           = filtered.navigational_status,

    imo                           = filtered.imo,

    destination                   = filtered.destination,
    draught                       = filtered.draught,
    eta                           = filtered.eta,

    geom                          = filtered.geom,

    h3_cellid                     = filtered.h3_cellid,

    canonical_collection_type     = filtered.canonical_collection_type,
    canonical_navigational_status = filtered.canonical_navigational_status,

    cdp_created                   = filtered.cdp_created
WHEN NOT MATCHED THEN
INSERT
(
    vessel_id,
    time_received,
    collection_type,
    longitude,
    latitude,
    sog,
    cog,
    heading,
    rot,
    navigational_status,

    imo,

    destination,
    draught,
    eta,

    geom,

    h3_cellid,

    canonical_collection_type,
    canonical_navigational_status,

    cdp_created
)
VALUES
(
    shipId,
    time_received,
    collection_type,
    longitude,
    latitude,
    sog,
    cog,
    heading,
    rot,
    navigational_status,

    imo,

    destination,
    draught,
    eta,

    geom,

    h3_cellid,

    canonical_collection_type,
    canonical_navigational_status,

    cdp_created
);

