-- Databricks notebook source

CREATE WIDGET TEXT catalog_name DEFAULT 'hive_metastore';
CREATE WIDGET TEXT silver_schema_name DEFAULT 'silver';
CREATE WIDGET TEXT bronze_schema_name DEFAULT 'bronze';
CREATE WIDGET TEXT target_table_name DEFAULT 'vt_ais_static';
CREATE WIDGET TEXT source_table_name DEFAULT 'vt_source_json';
CREATE WIDGET TEXT last_api_call_timestamp DEFAULT '';

-- COMMAND ----------

WITH src AS (
  SELECT 
    cdp_created,
    EXPLODE(vessels)               AS vessel                  
  FROM 
    IDENTIFIER(:catalog_name || '.' || :bronze_schema_name || '.' || :source_table_name)
  WHERE 
    cdp_created = :last_api_call_timestamp
), ordered AS (
  SELECT
    vessel.shipId                       AS ship_id, 
    vessel.aisStatic.name               AS name,
    vessel.aisStatic.mmsi               AS mmsi,
    vessel.aisStatic.imo                AS imo,
    vessel.aisStatic.callsign           AS callsign,
    vessel.aisStatic.flag               AS flag,
    vessel.aisStatic.dimA               AS dim_a,
    vessel.aisStatic.dimB               AS dim_b,
    vessel.aisStatic.dimC               AS dim_c,
    vessel.aisStatic.dimD               AS dim_d,
    vessel.aisStatic.length             AS length,
    vessel.aisStatic.width              AS width,
    vessel.aisStatic.typeOfShipAndCargo AS type_of_ship_and_cargo,
    vessel.aisStatic.aisShiptype        AS ais_shiptype,
    vessel.aisStatic.updateTime         AS update_time,
    cdp_created,
    ROW_NUMBER() OVER (PARTITION BY vessel.shipId ORDER BY cdp_created DESC) AS rn
  FROM src
), filtered AS (
  SELECT *
  FROM
    ordered
  WHERE
    rn = 1
)
MERGE INTO IDENTIFIER(:catalog_name || '.' || :silver_schema_name || '.' || :target_table_name) AS trg
USING filtered
    ON filtered.ship_id = trg.vessel_id
WHEN MATCHED THEN
UPDATE 
  SET
    vessel_id              = filtered.ship_id,
    name                   = filtered.name,
    mmsi                   = filtered.mmsi,
    imo                    = filtered.imo,
    callsign               = filtered.callsign,
    flag                   = filtered.flag,
    dim_a                  = filtered.dim_a,
    dim_b                  = filtered.dim_b,
    dim_c                  = filtered.dim_c,
    dim_d                  = filtered.dim_d,
    length                 = filtered.length,
    width                  = filtered.width,
    type_of_ship_and_cargo = filtered.type_of_ship_and_cargo,
    ais_shiptype           = filtered.ais_shiptype,
    update_time            = filtered.update_time,
    cdp_created            = filtered.cdp_created
WHEN NOT MATCHED THEN
INSERT
(
    vessel_id,
    name,
    mmsi,
    imo,
    callsign,
    flag,
    dim_a,
    dim_b,
    dim_c,
    dim_d,
    length,
    width,
    type_of_ship_and_cargo,
    ais_shiptype,
    update_time,
    cdp_created
)
VALUES
(
    ship_id,
    name,
    mmsi,
    imo,
    callsign,
    flag,
    dim_a,
    dim_b,
    dim_c,
    dim_d,
    length,
    width,
    type_of_ship_and_cargo,
    ais_shiptype,
    update_time,
    cdp_created
);