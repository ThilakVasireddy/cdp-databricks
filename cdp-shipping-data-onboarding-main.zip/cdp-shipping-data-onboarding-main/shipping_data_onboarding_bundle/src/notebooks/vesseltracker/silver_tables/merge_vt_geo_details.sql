-- Databricks notebook source

CREATE WIDGET TEXT catalog_name DEFAULT 'hive_metastore';
CREATE WIDGET TEXT silver_schema_name DEFAULT 'silver';
CREATE WIDGET TEXT bronze_schema_name DEFAULT 'bronze';
CREATE WIDGET TEXT target_table_name DEFAULT 'vt_geo_details';
CREATE WIDGET TEXT source_table_name DEFAULT 'vt_source_json';
CREATE WIDGET TEXT last_api_call_timestamp DEFAULT '';

-- COMMAND ----------

WITH src AS (
  SELECT 
    cdp_created,
    EXPLODE(vessels) AS vessel                  
  FROM 
    IDENTIFIER(:catalog_name || '.' || :bronze_schema_name || '.' || :source_table_name)
  WHERE 
    cdp_created = :last_api_call_timestamp
), ordered AS (
  SELECT
    vessel.shipId                       AS ship_id, 
    vessel.geoDetails.currentPort       AS current_port,
    vessel.geoDetails.currentPortLocode AS current_port_locode,
    vessel.geoDetails.portCountry       AS port_country,
    vessel.geoDetails.currentBerth      AS current_berth,
    vessel.geoDetails.currentAnchorage  AS current_anchorage,
    vessel.geoDetails.timeOfATChange    AS time_of_at_change,
    vessel.geoDetails.status            AS status,
    NULL AS area,
    cdp_created,
    ROW_NUMBER() OVER (PARTITION BY vessel.shipId ORDER BY cdp_created DESC) AS rn
  FROM src
), filtered AS (
  SELECT *
  FROM
    ordered
  WHERE
    rn = 1
)
MERGE INTO IDENTIFIER(:catalog_name || '.' || :silver_schema_name || '.' || :target_table_name) AS trg
USING filtered
    ON filtered.ship_id = trg.vessel_id
WHEN MATCHED THEN
UPDATE 
  SET
    vessel_id           = filtered.ship_id,
    current_port        = filtered.current_port,
    current_port_locode = filtered.current_port_locode,
    port_country        = filtered.port_country,
    current_berth       = filtered.current_berth,
    current_anchorage   = filtered.current_anchorage,
    time_of_at_change   = filtered.time_of_at_change,
    status              = filtered.status,
    area                = filtered.area,
    cdp_created         = filtered.cdp_created
WHEN NOT MATCHED THEN
INSERT
(
    vessel_id,
    current_port,
    current_port_locode,
    port_country,
    current_berth,
    current_anchorage,
    time_of_at_change,
    status,
    area,
    cdp_created
)
VALUES
(
    ship_id,
    current_port,
    current_port_locode,
    port_country,
    current_berth,
    current_anchorage,
    time_of_at_change,
    status,
    area,
    cdp_created
);