-- Databricks notebook source

CREATE WIDGET TEXT catalog_name DEFAULT 'hive_metastore';
CREATE WIDGET TEXT silver_schema_name DEFAULT 'silver';
CREATE WIDGET TEXT bronze_schema_name DEFAULT 'bronze';
CREATE WIDGET TEXT target_table_name DEFAULT 'vt_msg27';
CREATE WIDGET TEXT source_table_name DEFAULT 'vt_source_json';
CREATE WIDGET TEXT last_api_call_timestamp DEFAULT '';

-- COMMAND ----------

WITH src AS (
  SELECT 
    cdp_created,
    EXPLODE(vessels)               AS vessel                  
  FROM 
    IDENTIFIER(:catalog_name || '.' || :bronze_schema_name || '.' || :source_table_name)
  WHERE 
    cdp_created = :last_api_call_timestamp
), ordered AS (
  SELECT
    vessel.shipId, 
    vessel.msg27.timeReceived AS time_received,
    vessel.msg27.src,
    vessel.msg27.lon,
    vessel.msg27.lat,
    vessel.msg27.sog,
    vessel.msg27.cog,
    vessel.msg27.hdg,
    vessel.msg27.rot,
    vessel.msg27.navStatus    AS navigational_status,
    cdp_created,
    ROW_NUMBER() OVER (PARTITION BY vessel.shipId, vessel.msg27.timeReceived ORDER BY cdp_created DESC) AS rn
  FROM src
), filtered AS (
  SELECT *
  FROM
    ordered
  WHERE
    rn = 1
)
MERGE INTO IDENTIFIER(:catalog_name || '.' || :silver_schema_name || '.' || :target_table_name) AS trg
USING filtered
    ON filtered.shipId = trg.vessel_id
    AND ( (filtered.time_received IS NULL AND trg.time_received IS NULL) 
            OR filtered.time_received = trg.time_received)
WHEN MATCHED THEN
UPDATE 
  SET
    vessel_id           = filtered.shipId,
    time_received       = filtered.time_received,
    src                 = filtered.src,
    lon                 = filtered.lon,
    lat                 = filtered.lat,
    sog                 = filtered.sog,
    cog                 = filtered.cog,
    hdg                 = filtered.hdg,
    rot                 = filtered.rot,
    navigational_status = filtered.navigational_status,
    cdp_created         = filtered.cdp_created
WHEN NOT MATCHED THEN
INSERT
(
    vessel_id,
    time_received,
    src,
    lon,
    lat,
    sog,
    cog,
    hdg,
    rot,
    navigational_status,
    cdp_created
)
VALUES
(
    shipId, 
    time_received,
    src,
    lon,
    lat,
    sog,
    cog,
    hdg,
    rot,
    navigational_status,
    cdp_created
);
