# Databricks notebook source
dbutils.widgets.text("catalog_name", "hive_metastore")
dbutils.widgets.text("silver_schema_name", "silver")
dbutils.widgets.text("bronze_schema_name", "bronze")
dbutils.widgets.text("target_table_name", "vt_vessel_details_history")
dbutils.widgets.text("source_table_name", "vt_source_json")
dbutils.widgets.text("last_api_call_timestamp", "")

catalog_name = dbutils.widgets.get("catalog_name")
silver_schema_name = dbutils.widgets.get("silver_schema_name")
bronze_schema_name = dbutils.widgets.get("bronze_schema_name")
target_table_name = dbutils.widgets.get("target_table_name")
source_table_name = dbutils.widgets.get("source_table_name")
last_api_call_timestamp = dbutils.widgets.get("last_api_call_timestamp")

# COMMAND ----------

sql_query = f"""WITH source AS (
  SELECT
    cdp_created,
    EXPLODE(vessels) AS vessel
  FROM {catalog_name}.{bronze_schema_name}.{source_table_name}
  WHERE
    cdp_created = '{last_api_call_timestamp}'
),
latest_target AS (
    -- Get the latest record from the target for each vessel_id
    SELECT
        t.vessel_id,
        t.ship_type,
        t.size_class,
        t.gross_tonnage,
        t.dead_weight,
        t.teu,
        t.cdp_created
    FROM (
        SELECT
            t.*,
            ROW_NUMBER() OVER (PARTITION BY t.vessel_id ORDER BY t.cdp_created DESC) AS rn
        FROM {catalog_name}.{silver_schema_name}.{target_table_name} t
    ) t
    WHERE t.rn = 1
)

INSERT INTO {catalog_name}.{silver_schema_name}.{target_table_name}
  (
    vessel_id,
    ship_type,
    size_class,
    gross_tonnage,
    dead_weight,
    teu,
    cdp_created
  )
SELECT
    sc.vessel.shipId                     AS vessel_id,
    sc.vessel.vesselDetails.shipType     AS ship_type,
    sc.vessel.vesselDetails.sizeClass    AS size_class,
    sc.vessel.vesselDetails.grossTonnage AS gross_tonnage,
    sc.vessel.vesselDetails.deadWeight   AS dead_weight,
    sc.vessel.vesselDetails.teu          AS teu,
    sc.cdp_created
FROM source sc
LEFT JOIN latest_target lt ON sc.vessel.shipId = lt.vessel_id
WHERE
    (
        -- Insert if attributes differ or target record doesn't exist
        (
            lt.vessel_id IS NULL
            OR COALESCE(sc.vessel.vesselDetails.shipType,'')     != COALESCE(lt.ship_type,'')
            OR COALESCE(sc.vessel.vesselDetails.sizeClass,'')    != COALESCE(lt.size_class,'')
            OR COALESCE(sc.vessel.vesselDetails.grossTonnage,'') != COALESCE(lt.gross_tonnage,'')
            OR COALESCE(sc.vessel.vesselDetails.deadWeight,'')   != COALESCE(lt.dead_weight,'')
            OR COALESCE(sc.vessel.vesselDetails.teu,'')          != COALESCE(lt.teu,'')
        )
    );
    """

spark.sql(sql_query)
