-- Databricks notebook source

CREATE WIDGET TEXT catalog_name DEFAULT 'hive_metastore';
CREATE WIDGET TEXT silver_schema_name DEFAULT 'silver';
CREATE WIDGET TEXT bronze_schema_name DEFAULT 'bronze';
CREATE WIDGET TEXT target_table_name DEFAULT 'vt_vessel_id';
CREATE WIDGET TEXT source_table_name DEFAULT 'vt_source_json';
CREATE WIDGET TEXT last_api_call_timestamp DEFAULT '';

-- COMMAND ----------

WITH src AS (
  SELECT 
    cdp_created,
    EXPLODE(vessels)               AS vessel
  FROM
    IDENTIFIER(:catalog_name || '.' || :bronze_schema_name || '.' || :source_table_name)
  WHERE 
    cdp_created = :last_api_call_timestamp
), grouped AS (
  SELECT 
    MIN(cdp_created)   AS cdp_created,
    vessel.shipId      AS vessel_id
  FROM
    src
  GROUP BY
    vessel.shipId
) 
MERGE INTO IDENTIFIER(:catalog_name || '.' || :silver_schema_name || '.' || :target_table_name) AS trg
USING grouped
    ON grouped.vessel_id = trg.vessel_id
WHEN NOT MATCHED THEN
INSERT
(
  vessel_id,
  cdp_created
)
VALUES
(
  vessel_id,
  cdp_created
);

