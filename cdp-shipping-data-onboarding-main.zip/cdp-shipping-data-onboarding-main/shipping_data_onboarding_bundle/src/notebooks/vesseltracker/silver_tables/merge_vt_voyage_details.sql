-- Databricks notebook source

CREATE WIDGET TEXT catalog_name DEFAULT 'hive_metastore';
CREATE WIDGET TEXT silver_schema_name DEFAULT 'silver';
CREATE WIDGET TEXT bronze_schema_name DEFAULT 'bronze';
CREATE WIDGET TEXT target_table_name DEFAULT 'vt_voyage_details';
CREATE WIDGET TEXT source_table_name DEFAULT 'vt_source_json';
CREATE WIDGET TEXT last_api_call_timestamp DEFAULT '';

-- COMMAND ----------

WITH src AS (
  SELECT 
    cdp_created,
    EXPLODE(vessels) AS vessel                  
  FROM 
    IDENTIFIER(:catalog_name || '.' || :bronze_schema_name || '.' || :source_table_name)
  WHERE 
    cdp_created = :last_api_call_timestamp
), ordered AS (
  SELECT   
    vessel.shipId                      AS ship_id, 
    vessel.voyageDetails.destination   AS destination,
    vessel.voyageDetails.locode        AS locode,
    vessel.voyageDetails.portCountry   AS port_country,
    vessel.voyageDetails.calculatedETA AS calculated_eta,
    cdp_created,
    ROW_NUMBER() OVER(PARTITION BY vessel.shipId ORDER BY cdp_created DESC) AS rn    
  FROM 
    src
), filtered AS (
  SELECT *
  FROM 
    ordered
  WHERE
    rn = 1
)
MERGE INTO IDENTIFIER(:catalog_name || '.' || :silver_schema_name || '.' || :target_table_name) AS trg
USING filtered
    ON filtered.ship_id = trg.vessel_id
WHEN MATCHED THEN
UPDATE
  SET 
    destination     = filtered.destination,
    locode          = filtered.locode,
    port_country    = filtered.port_country,
    calculated_eta  = filtered.calculated_eta,
    cdp_created     = filtered.cdp_created
WHEN NOT MATCHED THEN
INSERT
(
    vessel_id,
    destination,
    locode,
    port_country,
    calculated_eta,
    cdp_created
)
VALUES
(
    ship_id, 
    destination,
    locode,
    port_country,
    calculated_eta,
    cdp_created
);