# Databricks notebook source
dbutils.widgets.text("catalog_name", "hive_metastore")
dbutils.widgets.text("silver_schema_name", "silver")
dbutils.widgets.text("bronze_schema_name", "bronze")
dbutils.widgets.text("target_table_name", "vt_voyage_details_history")
dbutils.widgets.text("source_table_name", "vt_source_json")
dbutils.widgets.text("last_api_call_timestamp", "")

catalog_name = dbutils.widgets.get("catalog_name")
silver_schema_name = dbutils.widgets.get("silver_schema_name")
bronze_schema_name = dbutils.widgets.get("bronze_schema_name")
target_table_name = dbutils.widgets.get("target_table_name")
source_table_name = dbutils.widgets.get("source_table_name")
last_api_call_timestamp = dbutils.widgets.get("last_api_call_timestamp")

# COMMAND ----------

sql_query = f"""WITH source AS (
  SELECT
    cdp_created,
    EXPLODE(vessels) AS vessel
  FROM {catalog_name}.{bronze_schema_name}.{source_table_name}
  WHERE
    cdp_created = '{last_api_call_timestamp}'
),
latest_target AS (
    -- Get the latest record from the target for each vessel_id
    SELECT
        t.vessel_id,
        t.destination,
        t.locode,
        t.port_country,
        t.calculated_eta,
        t.cdp_created
    FROM (
        SELECT
            t.*,
            ROW_NUMBER() OVER (PARTITION BY t.vessel_id ORDER BY t.cdp_created DESC) AS rn
        FROM {catalog_name}.{silver_schema_name}.{target_table_name} t
    ) t
    WHERE t.rn = 1
)

INSERT INTO {catalog_name}.{silver_schema_name}.{target_table_name}
  (
    vessel_id,
    destination,
    locode,
    port_country,
    calculated_eta,
    cdp_created
  )
SELECT
    sc.vessel.shipId                      AS vessel_id,
    sc.vessel.voyageDetails.destination   AS destination,
    sc.vessel.voyageDetails.locode        AS locode,
    sc.vessel.voyageDetails.portCountry   AS port_country,
    sc.vessel.voyageDetails.calculatedEta AS calculated_eta,
    sc.cdp_created
FROM source sc
LEFT JOIN latest_target lt ON sc.vessel.shipId = lt.vessel_id
WHERE
    (
        -- Insert if attributes differ or target record doesn't exist
        (
            lt.vessel_id IS NULL
            OR COALESCE(sc.vessel.voyageDetails.destination,'')   != COALESCE(lt.destination,'')
            OR COALESCE(sc.vessel.voyageDetails.locode,'')        != COALESCE(lt.locode,'')
            OR COALESCE(sc.vessel.voyageDetails.portCountry,'')   != COALESCE(lt.port_country,'')
            OR COALESCE(sc.vessel.voyageDetails.calculatedEta,'') != COALESCE(lt.calculated_eta,'')
        )
    );
    """

spark.sql(sql_query)
