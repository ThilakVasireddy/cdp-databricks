# Databricks notebook source
# MAGIC %md
# MAGIC # Apply latest Vessel Tracker changes
# MAGIC
# MAGIC Take incremental load from bronze vt_source_json
# MAGIC and merge it into the vessel data silver tables:
# MAGIC
# MAGIC * vt_vessel_id
# MAGIC * vt_vessel_details
# MAGIC * vt_ais_position
# MAGIC * vt_ais_static
# MAGIC * vt_ais_voyage
# MAGIC * vt_geo_details
# MAGIC * vt_msg27
# MAGIC * vt_voyage_details

# COMMAND ----------
dbutils.widgets.text("last_api_call_timestamp", "")

# COMMAND ----------
import sys
import os
import re

if (config_path := re.split(r"notebooks", os.getcwd())[0] + "config") not in sys.path:
    sys.path.append(config_path)

if (
    package_path := re.split(r"notebooks", os.getcwd())[0] + "shipping_data_onboarding_package"
) not in sys.path:
    sys.path.append(package_path)

# COMMAND ----------
from concurrent.futures import ThreadPoolExecutor, as_completed
from config import Config
from shared.shipping_system.merge_process import merge_process

# COMMAND ----------
config = Config()

last_api_call_timestamp = dbutils.widgets.get("last_api_call_timestamp")

catalog_name = config["shipping"]["catalog_name"]
bronze_schema_name = config["shipping"]["bronze_schema_name"]
silver_schema_name = config["shipping"]["silver_schema_name"]

system_catalog_name = config["shared"]["system_catalog_name"]
system_schema_name = config["shared"]["system_schema_name"]


# COMMAND ----------
def run_notebook(target_table_name):
    dbutils.notebook.run(
        f"silver_tables/merge_{target_table_name}",
        3600,
        {
            "catalog_name": catalog_name,
            "silver_schema_name": silver_schema_name,
            "bronze_schema_name": bronze_schema_name,
            "target_table_name": target_table_name,
            "source_table_name": source_table_name,
            "last_api_call_timestamp": last_api_call_timestamp,
        },
    )


target_table_names = [
    "vt_vessel_id",
    "vt_ais_static",
    "vt_vessel_details",
    "vt_voyage_details",
    "vt_ais_position",
    "vt_msg27",
    "vt_geo_details",
    "vt_ais_voyage",
    "vt_voyage_details_history",
    "vt_vessel_details_history",
    "vt_ais_static_history",
    "vt_geo_details_history",
    "vt_ais_voyage_history",
]

source_table_name = "vt_source_json"

with ThreadPoolExecutor() as executor:
    notebook_futures = [
        executor.submit(run_notebook, target_table_name)
        for target_table_name in target_table_names
    ]
    for future in as_completed(notebook_futures):
        future.result()
        # Wait for all futures to complete
        # Mark this notebook as failed if any of subnotebooks fails

# COMMAND ----------

merge_process(
    spark,
    catalog_name=system_catalog_name,
    schema_name=system_schema_name,
    table_name="process",
    process_name="vesseltracker_vessels",
    last_api_call_timestamp=last_api_call_timestamp,
)
