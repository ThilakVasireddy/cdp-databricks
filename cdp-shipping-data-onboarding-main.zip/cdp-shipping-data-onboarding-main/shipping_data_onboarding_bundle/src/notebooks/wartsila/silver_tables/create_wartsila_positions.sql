-- Databricks notebook source
CREATE WIDGET TEXT catalog_name DEFAULT 'hive_metastore';
CREATE WIDGET TEXT schema_name DEFAULT 'silver';
CREATE WIDGET TEXT table_name DEFAULT 'wartsila_positions';

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS IDENTIFIER(:catalog_name || '.' || :schema_name || '.' || :table_name)
(
  create_timestamp              TIMESTAMP,
  mmsi                          INTEGER,
  latitude                      DECIMAL(8,6),
  longitude                     DECIMAL(9,6),
  cog                           DECIMAL(4,1),
  sog                           DECIMAL(4,1),
  navigational_status           INTEGER,
  imo                           INTEGER,
  name                          STRING,
  destination                   STRING,
  length                        INTEGER,
  width                         INTEGER,
  draught                       DECIMAL(3,1),
  ais_type                      INTEGER,
  canonical_navigational_status STRING,
  cdp_created                   TIMESTAMP,
  cdp_file_path                 STRING
)
USING DELTA
CLUSTER BY (imo, create_timestamp, cdp_created)