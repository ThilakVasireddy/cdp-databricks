# Databricks notebook source
# MAGIC %md
# MAGIC ### Load Wartsila files to silver table, move to bronze
# MAGIC
# MAGIC This notebook:
# MAGIC 1. Reads csv files from a landing path using autoloader
# MAGIC 2. Joins it with a navigational status table
# MAGIC 3. Writes the processed data to a Delta table.
# MAGIC 4. It also moves the processed files to a bronze folder.

# COMMAND ----------

# DBTITLE 1,Add Sys Path
import sys
import os
import re

if (config_path := re.split(r"notebooks", os.getcwd())[0] + "config") not in sys.path:
    sys.path.append(config_path)

if (
    package_path := re.split(r"notebooks", os.getcwd())[0] + "shipping_data_onboarding_package"
) not in sys.path:
    sys.path.append(package_path)

# COMMAND ----------

# DBTITLE 1,Imports
from pyspark.sql.types import (
    StructType,
    StructField,
    StringType,
    IntegerType,
    TimestampType,
    DecimalType,
)
import pyspark.sql.functions as F
from pyspark.sql import DataFrame
from config import Config
from wartsila.process_and_move_batch import process_and_move_batch

# COMMAND ----------

# DBTITLE 1,Variables and Config

config = Config()

catalog_name = config["shipping"]["catalog_name"]
bronze_schema_name = config["shipping"]["bronze_schema_name"]
silver_schema_name = config["shipping"]["silver_schema_name"]

landing_path = config["shipping"]["wartsila"]["landing_path"]
bronze_path = config["shipping"]["wartsila"]["bronze_path"]
checkpoint_path = config["shipping"]["wartsila"]["checkpoint_path"]

full_landing_path = f"/Volumes/{catalog_name}/{bronze_schema_name}/{landing_path}/*/*/*/"
base_bronze_path = f"/Volumes/{catalog_name}/{bronze_schema_name}/{bronze_path}"
full_checkpoint_path = f"/Volumes/{catalog_name}/{bronze_schema_name}/{checkpoint_path}"

print(f"{full_landing_path=}")
print(f"{base_bronze_path=}")
print(f"{full_checkpoint_path=}")


# COMMAND ----------

# DBTITLE 1,Define schema
schema = StructType(
    [
        StructField("timestamp", TimestampType(), True),
        StructField("mmsi", IntegerType(), True),
        StructField("lat", DecimalType(8, 6), True),
        StructField("lon", DecimalType(9, 6), True),
        StructField("cog", DecimalType(4, 1), True),
        StructField("sog", DecimalType(4, 1), True),
        StructField("status", IntegerType(), True),
        StructField("imo", IntegerType(), True),
        StructField("name", StringType(), True),
        StructField("destination", StringType(), True),
        StructField("length", IntegerType(), True),
        StructField("width", IntegerType(), True),
        StructField("draught", DecimalType(3, 1), True),
        StructField("ais_type", IntegerType(), True),
    ]
)

# COMMAND ----------

# DBTITLE 1,Auto Loader
spark.conf.set("spark.sql.files.ignoreMissingFiles", "true")


def read_stream_data(full_landing_path: str, schema: StructType) -> DataFrame:
    """Read stream data from the landing path with the given schema."""
    return (
        spark.readStream.format("cloudFiles")
        .option("cloudFiles.format", "csv")
        .option("header", "true")
        .option("delimiter", ",")
        .option("quote", '"')
        .option("escape", '"')
        .schema(schema)
        .load(full_landing_path)
        .withColumn("cdp_created", F.current_timestamp())
        .withColumn("cdp_file_path", F.col("_metadata.file_path"))
    )


def read_nav_status_table(catalog_name: str, silver_schema_name: str) -> DataFrame:
    """Read the navigational status table."""
    return spark.read.table(
        f"{catalog_name}.{silver_schema_name}.config_ais_mapping_navigational_status"
    ).alias("nav_status")


def join_stream_with_nav_status(stream: DataFrame, nav_status: DataFrame) -> DataFrame:
    """Join stream data with navigational status table."""
    return (
        stream.alias("stream")
        .join(F.broadcast(nav_status), stream["status"] == nav_status["source_name"], "left")
        .select(
            "stream.*",  # All columns from main dataframe
            F.col("nav_status.canonical_name").alias("canonical_navigational_status"),
        )
        .withColumnRenamed("timestamp", "create_timestamp")
        .withColumnRenamed("status", "navigational_status")
        .withColumnRenamed("lat", "latitude")
        .withColumnRenamed("lon", "longitude")
    )


# Read stream data
stream = read_stream_data(full_landing_path, schema)

# Read navigational status table
nav_status = read_nav_status_table(catalog_name, silver_schema_name)

# Join stream data with navigational status table
joined_stream = join_stream_with_nav_status(stream, nav_status)

query = (
    joined_stream.writeStream.trigger(processingTime="5 seconds")
    .foreachBatch(
        lambda batch_df, batch_id: process_and_move_batch(
            batch_df, batch_id, catalog_name, silver_schema_name, base_bronze_path
        )
    )
    .option("checkpointLocation", full_checkpoint_path)
    .start()
)

query.awaitTermination()
