def merge_bad_ais_polygons(source_df, target_table_name: str):
    """
    Merge KML data into the silver table using Delta Lake merge operations.
    Args:
        source_df (pyspark.sql.DataFrame): Source DataFrame containing KML data
        target_table_name (str): Fully qualified name of the target Delta table
    Returns:
        None
    """

    from delta.tables import DeltaTable
    from pyspark.sql import SparkSession

    # Ensure the spark session is defined
    spark = SparkSession.builder.appName("KMLProcessing").getOrCreate()

    # Get the target Delta table
    target_table = DeltaTable.forName(spark, target_table_name)

    # Perform the merge operation
    target_table.alias("target").merge(
        source=source_df.alias("source"),
        condition="target.perm_id = source.perm_id AND target.h3_cellid = source.h3_cellid",
    ).whenMatchedUpdate(
        condition=(
            "target.name != source.name OR "
            "target.h3_core != source.h3_core OR "
            "target.h3_chip != source.h3_chip"
        ),
        set={
            "name": "source.name",
            "h3_cellid": "source.h3_cellid",
            "h3_core": "source.h3_core",
            "h3_chip": "source.h3_chip",
            "cdp_updated": "source.cdp_updated",
        },
    ).whenNotMatchedInsert(
        values={
            "perm_id": "source.perm_id",
            "name": "source.name",
            "h3_cellid": "source.h3_cellid",
            "h3_core": "source.h3_core",
            "h3_chip": "source.h3_chip",
            "cdp_created": "source.cdp_created",
            "cdp_updated": "source.cdp_updated",
            "cdp_file_path": "source.cdp_file_path",
        }
    ).whenNotMatchedBySourceDelete().execute()
