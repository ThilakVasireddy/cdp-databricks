from requests.adapters import HTTPAdapter


class RateLimitHTTPAdapter(HTTPAdapter):
    def __init__(self, rate_limiter, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.rate_limiter = rate_limiter

    def send(self, request, **kwargs):
        self.rate_limiter.acquire()

        response = super().send(request, **kwargs)
        return response
