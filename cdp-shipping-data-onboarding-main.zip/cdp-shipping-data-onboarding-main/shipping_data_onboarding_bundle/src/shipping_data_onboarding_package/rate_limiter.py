import time
from threading import Lock, current_thread
from collections import deque


class RateLimiter:
    def __init__(self, max_calls: int, period: float):
        self.max_calls = max_calls
        self.period = period  # in seconds
        self.call_times = deque()
        self.lock = Lock()

    def acquire(self):
        with self.lock:
            current_time = time.monotonic()
            # Remove timestamps older than the period
            while self.call_times and self.call_times[0] <= current_time - self.period:
                self.call_times.popleft()

            if len(self.call_times) < self.max_calls:
                # We can make a request immediately
                self.call_times.append(current_time)
            else:
                # Need to wait before making the next request
                earliest_call = self.call_times[0]
                sleep_time = self.period - (current_time - earliest_call)
                print(
                    f"Thread {current_thread().name} - Rate limit reached. "
                    f"Sleeping for {sleep_time:.2f} seconds."
                )
                time.sleep(sleep_time)
                # After sleeping, remove outdated timestamps
                while self.call_times and self.call_times[0] <= time.monotonic() - self.period:
                    self.call_times.popleft()
                # Record the current time
                self.call_times.append(time.monotonic())
