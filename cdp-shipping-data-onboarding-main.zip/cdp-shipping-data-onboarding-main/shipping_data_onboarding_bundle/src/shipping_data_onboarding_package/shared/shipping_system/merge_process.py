from pyspark.sql import SparkSession


def merge_process(
    spark: SparkSession,
    catalog_name: str,
    schema_name: str,
    table_name: str,
    process_name: str,
    last_api_call_timestamp: str,
) -> None:
    sql_query = f"""
    MERGE INTO {catalog_name}.{schema_name}.{table_name} AS target
    USING (
        SELECT
            '{process_name}'                               AS process_name,
            CAST('{last_api_call_timestamp}' AS TIMESTAMP) AS last_api_call_timestamp,
            current_timestamp()                            AS cdp_updated
    ) AS source
    ON target.process_name = source.process_name
    WHEN MATCHED THEN
        UPDATE SET
            target.last_api_call_timestamp = source.last_api_call_timestamp,
            target.cdp_updated             = source.cdp_updated
    WHEN NOT MATCHED THEN
        INSERT
        (
            process_name,
            last_api_call_timestamp,
            cdp_updated
        )
        VALUES
        (
            source.process_name,
            source.last_api_call_timestamp,
            source.cdp_updated
        );
    """

    # Execute the SQL query
    spark.sql(sql_query)
