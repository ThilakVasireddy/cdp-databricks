from .merge_spire_vessel_characteristics_history import merge_spire_vessel_characteristics_history
from .merge_spire_vessel_characteristics import merge_spire_vessel_characteristics
from .merge_spire_vessel_id import merge_spire_vessel_id
from .merge_spire_vessel_position import merge_spire_vessel_position
from .merge_spire_vessel_static_data import merge_spire_vessel_static_data
from .merge_spire_vessel_static_data_history import merge_spire_vessel_static_data_history
from .merge_spire_vessel_voyage import merge_spire_vessel_voyage

spire_silver_merge_functions = [
    merge_spire_vessel_characteristics_history,
    merge_spire_vessel_characteristics,
    merge_spire_vessel_id,
    merge_spire_vessel_position,
    merge_spire_vessel_static_data,
    merge_spire_vessel_static_data_history,
    merge_spire_vessel_voyage,
]
