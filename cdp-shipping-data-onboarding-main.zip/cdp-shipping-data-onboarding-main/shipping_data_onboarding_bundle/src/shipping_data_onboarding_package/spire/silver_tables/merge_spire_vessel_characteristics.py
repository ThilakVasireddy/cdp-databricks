from pyspark.sql import SparkSession


def merge_spire_vessel_characteristics(
    spark: SparkSession,
    catalog_name: str,
    silver_schema_name: str,
    bronze_schema_name: str,
    target_table_name: str,
    source_table_name: str,
    last_api_call_timestamp: str,
) -> str:
    spark.sql(f"""
    WITH src AS (
      SELECT
        cdp_created                    AS cdp_created,
        cdp_ship_type                  AS cdp_ship_type,
        EXPLODE(data.vessels.nodes)    AS vessel
      FROM
        {catalog_name}.{bronze_schema_name}.{source_table_name}
      WHERE
        cdp_created = '{last_api_call_timestamp}'
    ), ordered AS (
    SELECT
      vessel.id                                                            AS vessel_id,
      to_timestamp(vessel.updateTimestamp)                                 AS update_timestamp,
      vessel.characteristics.basic.capacity.deadweight                     AS deadweight,
      vessel.characteristics.basic.capacity.grosstonnage                   AS gross_tonnage,
      vessel.characteristics.basic.history.builtYear                       AS built_year,
      vessel.characteristics.basic.vesselTypeAndTrading.vesselSubtype      AS vessel_subtype,
      cdp_ship_type                                                        AS cdp_ship_type,
      cdp_created                                                          AS cdp_created,
      ROW_NUMBER() OVER(PARTITION BY vessel.id ORDER BY cdp_created DESC)  AS rn
    FROM
      src
    ), filtered AS (
     SELECT *
     FROM
      ordered
     WHERE
       rn = 1
    )
    MERGE INTO {catalog_name}.{silver_schema_name}.{target_table_name} AS trg
    USING filtered
        ON filtered.vessel_id = trg.vessel_id
    WHEN MATCHED THEN
    UPDATE
      SET
        update_timestamp        = filtered.update_timestamp,
        deadweight              = filtered.deadweight,
        gross_tonnage           = filtered.gross_tonnage,
        built_year              = filtered.built_year,
        vessel_subtype          = filtered.vessel_subtype,
        cdp_ship_type           = filtered.cdp_ship_type,
        cdp_created             = filtered.cdp_created
    WHEN NOT MATCHED THEN
    INSERT
    (
        vessel_id,
        update_timestamp,
        deadweight,
        gross_tonnage,
        built_year,
        vessel_subtype,
        cdp_ship_type,
        cdp_created
    )
    VALUES
    (
        vessel_id,
        update_timestamp,
        deadweight,
        gross_tonnage,
        built_year,
        vessel_subtype,
        cdp_ship_type,
        cdp_created
    );""")
    return f"merge succeeded for table {target_table_name}"
