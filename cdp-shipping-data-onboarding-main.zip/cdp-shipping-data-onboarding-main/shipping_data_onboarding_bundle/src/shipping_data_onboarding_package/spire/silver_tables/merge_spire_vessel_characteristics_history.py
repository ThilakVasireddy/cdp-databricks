from pyspark.sql import SparkSession


def merge_spire_vessel_characteristics_history(
    spark: SparkSession,
    catalog_name: str,
    silver_schema_name: str,
    bronze_schema_name: str,
    target_table_name: str,
    source_table_name: str,
    last_api_call_timestamp: str,
) -> str:
    spark.sql(f"""
    WITH source AS (
      SELECT
        cdp_created                    AS cdp_created,
        cdp_ship_type                  AS cdp_ship_type,
        EXPLODE(data.vessels.nodes)    AS vessel
      FROM {catalog_name}.{bronze_schema_name}.{source_table_name}
      WHERE
        cdp_created = '{last_api_call_timestamp}'
    ),
    latest_target AS (
        -- Get the latest record from the target for each ObjectId
        SELECT
            t.vessel_id,
            t.update_timestamp,
            t.deadweight,
            t.gross_tonnage,
            t.built_year,
            t.vessel_subtype,
            t.cdp_ship_type,
            t.cdp_created
        FROM (
            SELECT
                t.*,
                ROW_NUMBER() OVER (PARTITION BY t.vessel_id ORDER BY t.cdp_created DESC) AS rn
            FROM {catalog_name}.{silver_schema_name}.{target_table_name} t
        ) t
        WHERE t.rn = 1
    )

    INSERT INTO {catalog_name}.{silver_schema_name}.{target_table_name}
      (
        vessel_id,
        update_timestamp,
        deadweight,
        gross_tonnage,
        built_year,
        vessel_subtype,
        cdp_ship_type,
        cdp_created
      )
    SELECT
      sc.vessel.id                                                            AS vessel_id,
      to_timestamp(sc.vessel.updateTimestamp)                                 AS update_timestamp,
      sc.vessel.characteristics.basic.capacity.deadweight                     AS deadweight,
      sc.vessel.characteristics.basic.capacity.grosstonnage                   AS gross_tonnage,
      sc.vessel.characteristics.basic.history.builtYear                       AS built_year,
      sc.vessel.characteristics.basic.vesselTypeAndTrading.vesselSubtype      AS vessel_subtype,
      sc.cdp_ship_type                                                        AS cdp_ship_type,
      sc.cdp_created                                                          AS cdp_created
    FROM source sc
    LEFT JOIN latest_target lt ON sc.vessel.id = lt.vessel_id
    WHERE
        (
            -- Insert if attributes differ or target record doesn't exist
            (
                lt.vessel_id IS NULL
                OR COALESCE(sc.vessel.characteristics.basic.capacity.deadweight,'')
                  != COALESCE(lt.deadweight,'')
                OR COALESCE(sc.vessel.characteristics.basic.capacity.grosstonnage,'')
                  != COALESCE(lt.gross_tonnage,'')
                OR COALESCE(sc.vessel.characteristics.basic.history.builtYear,'')
                  != COALESCE(lt.built_year,'')
                OR COALESCE(sc.vessel.characteristics.basic.vesselTypeAndTrading.vesselSubtype,'')
                  != COALESCE(lt.vessel_subtype,'')
            )
        );
        """)

    return f"merge succeeded for table {target_table_name}"
