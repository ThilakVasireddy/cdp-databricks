from pyspark.sql import SparkSession


def merge_spire_vessel_id(
    spark: SparkSession,
    catalog_name: str,
    silver_schema_name: str,
    bronze_schema_name: str,
    target_table_name: str,
    source_table_name: str,
    last_api_call_timestamp: str,
) -> str:
    spark.sql(f"""
    WITH src AS (
      SELECT
        cdp_created                    AS cdp_created,
        cdp_ship_type                  AS cdp_ship_type,
        EXPLODE(data.vessels.nodes)    AS vessel
      FROM
        {catalog_name}.{bronze_schema_name}.{source_table_name}
      WHERE
        cdp_created = '{last_api_call_timestamp}'
    ), grouped AS (
      SELECT
        MIN(cdp_created)   AS cdp_created,
        MIN(cdp_ship_type) AS cdp_ship_type,
        vessel.id          AS vessel_id
      FROM
        src
      GROUP BY
        vessel.id
    )
    MERGE INTO {catalog_name}.{silver_schema_name}.{target_table_name} AS trg
    USING grouped
        ON grouped.vessel_id = trg.vessel_id
    WHEN NOT MATCHED THEN
    INSERT
    (
      vessel_id,
      cdp_ship_type,
      cdp_created
    )
    VALUES
    (
      vessel_id,
      cdp_ship_type,
      cdp_created
    );
    """)
    return f"merge succeeded for table {target_table_name}"
