from pyspark.sql import SparkSession


def merge_spire_vessel_position(
    spark: SparkSession,
    catalog_name: str,
    silver_schema_name: str,
    bronze_schema_name: str,
    target_table_name: str,
    source_table_name: str,
    last_api_call_timestamp: str,
    mapping_navigational_status: str = "config_spire_mapping_navigational_status",
    mapping_collection_type: str = "config_spire_mapping_collection_type",
) -> str:
    spark.sql(f"""
    WITH src AS (
      SELECT
        cdp_created                    AS cdp_created,
        cdp_ship_type                  AS cdp_ship_type,
        EXPLODE(data.vessels.nodes)    AS vessel
      FROM
        {catalog_name}.{bronze_schema_name}.{source_table_name}
      WHERE
        cdp_created = '{last_api_call_timestamp}'
    ), ordered AS (
    SELECT
      vessel.id                                                          AS vessel_id,
      vessel.lastPositionUpdate.accuracy                                 AS accuracy,
      vessel.lastPositionUpdate.collectionType                           AS collection_type,
      vessel.lastPositionUpdate.course                                   AS cog,
      vessel.lastPositionUpdate.heading                                  AS heading,
      vessel.lastPositionUpdate.latitude                                 AS latitude,
      vessel.lastPositionUpdate.longitude                                AS longitude,
      vessel.lastPositionUpdate.maneuver                                 AS maneuver,
      vessel.lastPositionUpdate.navigationalStatus                       AS navigational_status,
      vessel.lastPositionUpdate.rot                                      AS rot,
      vessel.lastPositionUpdate.speed                                    AS sog,
      to_timestamp(vessel.lastPositionUpdate.timestamp)                  AS create_timestamp,
      to_timestamp(vessel.lastPositionUpdate.updateTimestamp)            AS update_timestamp,

      vessel.staticData.imo                                              AS imo,

      vessel.currentVoyage.destination                                   AS destination,
      vessel.currentVoyage.draught                                       AS draught,
      vessel.currentVoyage.eta                                           AS eta,
      vessel.currentVoyage.matchedPort.matchScore                        AS matched_port_match_score,
      vessel.currentVoyage.matchedPort.port.name                         AS matched_port_name,
      vessel.currentVoyage.matchedPort.port.centerPoint.latitude         AS matched_port_centerpoint_latitude,
      vessel.currentVoyage.matchedPort.port.centerPoint.longitude        AS matched_port_centerpoint_longitude,
      vessel.currentVoyage.matchedPort.port.unlocode                     AS matched_port_unlocode,

      ST_astext(
        ST_Point(
          vessel.lastPositionUpdate.longitude,
          vessel.lastPositionUpdate.latitude))                           AS geom,

      cdp_ship_type,
      cdp_created,
      ROW_NUMBER() OVER(
        PARTITION BY vessel.id, to_timestamp(vessel.lastPositionUpdate.timestamp)
        ORDER BY cdp_created DESC)                                       AS rn
    FROM
      src
    ), filtered AS (
     SELECT o.*,
      h3_pointash3(o.geom, 11)    AS h3_cellid,
      ns.canonical_name           AS canonical_navigational_status,
      ct.canonical_name           AS canonical_collection_type,
      CAST(ROUND(4.733 *
        CASE
          WHEN o.rot < 0 THEN -1 * SQRT(ABS(o.rot))
          ELSE SQRT(o.rot)
        END
       ,0) AS INT)                AS rot_ais
     FROM
      ordered AS o
    LEFT JOIN
      {catalog_name}.{silver_schema_name}.{mapping_navigational_status} AS ns
      ON ns.source_name = o.navigational_status
    LEFT JOIN
      {catalog_name}.{silver_schema_name}.{mapping_collection_type} AS ct
      ON ct.source_name = o.collection_type
     WHERE
       o.rn = 1
       AND o.latitude IS NOT NULL
       AND o.longitude IS NOT NULL
    )
    MERGE INTO {catalog_name}.{silver_schema_name}.{target_table_name} AS trg
    USING filtered
        ON filtered.vessel_id = trg.vessel_id
        AND (
            filtered.create_timestamp = trg.create_timestamp
            OR
            (filtered.create_timestamp IS NULL AND trg.create_timestamp IS NULL)
          )
    WHEN MATCHED THEN
    UPDATE
      SET
        vessel_id                          = filtered.vessel_id,
        accuracy                           = filtered.accuracy,
        collection_type                    = filtered.collection_type,
        cog                                = filtered.cog,
        heading                            = filtered.heading,
        latitude                           = filtered.latitude,
        longitude                          = filtered.longitude,
        maneuver                           = filtered.maneuver,
        navigational_status                = filtered.navigational_status,
        rot                                = filtered.rot,
        sog                                = filtered.sog,
        create_timestamp                   = filtered.create_timestamp,
        update_timestamp                   = filtered.update_timestamp,

        imo                                = filtered.imo,

        destination                        = filtered.destination,
        draught                            = filtered.draught,
        eta                                = filtered.eta,
        matched_port_match_score           = filtered.matched_port_match_score,
        matched_port_name                  = filtered.matched_port_name,
        matched_port_centerpoint_latitude  = filtered.matched_port_centerpoint_latitude,
        matched_port_centerpoint_longitude = filtered.matched_port_centerpoint_longitude,
        matched_port_unlocode              = filtered.matched_port_unlocode,

        geom                               = filtered.geom,

        h3_cellid                          = filtered.h3_cellid,

        canonical_collection_type          = filtered.canonical_collection_type,
        canonical_navigational_status      = filtered.canonical_navigational_status,
        rot_ais                            = filtered.rot_ais,

        cdp_ship_type                      = filtered.cdp_ship_type,
        cdp_created                        = filtered.cdp_created
    WHEN NOT MATCHED THEN
    INSERT
    (
        vessel_id,
        accuracy,
        collection_type,
        cog,
        heading,
        latitude,
        longitude,
        maneuver,
        navigational_status,
        rot,
        sog,
        create_timestamp,
        update_timestamp,

        imo,

        destination,
        draught,
        eta,
        matched_port_match_score,
        matched_port_name,
        matched_port_centerpoint_latitude,
        matched_port_centerpoint_longitude,
        matched_port_unlocode,

        geom,

        h3_cellid,

        canonical_collection_type,
        canonical_navigational_status,
        rot_ais,

        cdp_ship_type,
        cdp_created
    )
    VALUES
    (
        vessel_id,
        accuracy,
        collection_type,
        cog,
        heading,
        latitude,
        longitude,
        maneuver,
        navigational_status,
        rot,
        sog,
        create_timestamp,
        update_timestamp,

        imo,

        destination,
        draught,
        eta,
        matched_port_match_score,
        matched_port_name,
        matched_port_centerpoint_latitude,
        matched_port_centerpoint_longitude,
        matched_port_unlocode,

        geom,

        h3_cellid,

        canonical_collection_type,
        canonical_navigational_status,
        rot_ais,

        cdp_ship_type,
        cdp_created
    );


              """)
    return f"merge succeeded for table {target_table_name}"
