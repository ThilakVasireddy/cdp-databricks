from pyspark.sql import SparkSession


def merge_spire_vessel_static_data(
    spark: SparkSession,
    catalog_name: str,
    silver_schema_name: str,
    bronze_schema_name: str,
    target_table_name: str,
    source_table_name: str,
    last_api_call_timestamp: str,
) -> str:
    spark.sql(f"""
    WITH src AS (
      SELECT
        cdp_created                    AS cdp_created,
        cdp_ship_type                  AS cdp_ship_type,
        EXPLODE(data.vessels.nodes)    AS vessel
      FROM
        {catalog_name}.{bronze_schema_name}.{source_table_name}
      WHERE
        cdp_created = '{last_api_call_timestamp}'
    ), ordered AS (
    SELECT
      vessel.id                                                          AS vessel_id,
      vessel.staticData.aisClass                                         AS ais_class,
      vessel.staticData.callsign                                         AS callsign,
      vessel.staticData.dimensions.a                                     AS dim_a,
      vessel.staticData.dimensions.b                                     AS dim_b,
      vessel.staticData.dimensions.c                                     AS dim_c,
      vessel.staticData.dimensions.d                                     AS dim_d,
      vessel.staticData.dimensions.length                                AS dim_length,
      vessel.staticData.dimensions.width                                 AS dim_width,
      vessel.staticData.flag                                             AS flag,
      vessel.staticData.imo                                              AS imo,
      vessel.staticData.mmsi                                             AS mmsi,
      vessel.staticData.name                                             AS name,
      vessel.staticData.shipSubType                                      AS ship_subtype,
      vessel.staticData.shipType                                         AS ship_type,
      to_timestamp(vessel.staticData.timestamp)                          AS create_timestamp,
      to_timestamp(vessel.staticData.updateTimestamp)                    AS update_timestamp,
      vessel.staticData.validated.callsign                               AS validated_callsign,
      vessel.staticData.validated.callsignTimestamp                      AS validated_callsign_timestamp,
      vessel.staticData.validated.dimensions.length                      AS validated_dim_length,
      vessel.staticData.validated.dimensions.width                       AS validated_dim_width,
      vessel.staticData.validated.imo                                    AS validated_imo,
      vessel.staticData.validated.name                                   AS validated_name,
      vessel.staticData.validated.nameTimestamp                          AS validated_name_timestamp,
      vessel.staticData.validated.shipType                               AS validated_ship_type,
      cdp_ship_type,
      cdp_created,
      ROW_NUMBER() OVER(PARTITION BY vessel.id ORDER BY cdp_created DESC) AS rn
    FROM
      src
    ), filtered AS (
     SELECT *
     FROM
      ordered
     WHERE
       rn = 1
    )
    MERGE INTO {catalog_name}.{silver_schema_name}.{target_table_name} AS trg
    USING filtered
        ON filtered.vessel_id = trg.vessel_id
    WHEN MATCHED THEN
    UPDATE
      SET
        ais_class                           = filtered.ais_class,
        callsign                            = filtered.callsign,
        dim_a                               = filtered.dim_a,
        dim_b                               = filtered.dim_b,
        dim_c                               = filtered.dim_c,
        dim_d                               = filtered.dim_d,
        dim_length                          = filtered.dim_length,
        dim_width                           = filtered.dim_width,
        flag                                = filtered.flag,
        imo                                 = filtered.imo,
        mmsi                                = filtered.mmsi,
        name                                = filtered.name,
        ship_subtype                        = filtered.ship_subtype,
        ship_type                           = filtered.ship_type,
        create_timestamp                    = filtered.create_timestamp,
        update_timestamp                    = filtered.update_timestamp,
        validated_callsign                  = filtered.validated_callsign,
        validated_callsign_timestamp        = filtered.validated_callsign_timestamp,
        validated_dim_length                = filtered.validated_dim_length,
        validated_dim_width                 = filtered.validated_dim_width,
        validated_imo                       = filtered.validated_imo,
        validated_name                      = filtered.validated_name,
        validated_name_timestamp            = filtered.validated_name_timestamp,
        validated_ship_type                 = filtered.validated_ship_type,
        cdp_ship_type                       = filtered.cdp_ship_type,
        cdp_created                         = filtered.cdp_created
    WHEN NOT MATCHED THEN
    INSERT
    (
        vessel_id,
        ais_class,
        callsign,
        dim_a,
        dim_b,
        dim_c,
        dim_d,
        dim_length,
        dim_width,
        flag,
        imo,
        mmsi,
        name,
        ship_subtype,
        ship_type,
        create_timestamp,
        update_timestamp,
        validated_callsign,
        validated_callsign_timestamp,
        validated_dim_length,
        validated_dim_width,
        validated_imo,
        validated_name,
        validated_name_timestamp,
        validated_ship_type,
        cdp_ship_type,
        cdp_created
    )
    VALUES
    (
        vessel_id,
        ais_class,
        callsign,
        dim_a,
        dim_b,
        dim_c,
        dim_d,
        dim_length,
        dim_width,
        flag,
        imo,
        mmsi,
        name,
        ship_subtype,
        ship_type,
        create_timestamp,
        update_timestamp,
        validated_callsign,
        validated_callsign_timestamp,
        validated_dim_length,
        validated_dim_width,
        validated_imo,
        validated_name,
        validated_name_timestamp,
        validated_ship_type,
        cdp_ship_type,
        cdp_created
    );

""")
    return f"merge succeeded for table {target_table_name}"
