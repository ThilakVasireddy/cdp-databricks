from pyspark.sql import SparkSession


def merge_spire_vessel_static_data_history(
    spark: SparkSession,
    catalog_name: str,
    silver_schema_name: str,
    bronze_schema_name: str,
    target_table_name: str,
    source_table_name: str,
    last_api_call_timestamp: str,
) -> str:
    spark.sql(f"""
    WITH source AS (
        SELECT
          cdp_created                    AS cdp_created,
          cdp_ship_type                  AS cdp_ship_type,
          EXPLODE(data.vessels.nodes)    AS vessel
        FROM {catalog_name}.{bronze_schema_name}.{source_table_name}
        WHERE
          cdp_created = '{last_api_call_timestamp}'
    ), latest_target AS (
        -- Get the latest record from the target for each ObjectId
        SELECT
            t.vessel_id,
            t.ais_class,
            t.callsign,
            t.dim_a,
            t.dim_b,
            t.dim_c,
            t.dim_d,
            t.dim_length,
            t.dim_width,
            t.flag,
            t.imo,
            t.mmsi,
            t.name,
            t.ship_subtype,
            t.ship_type,
            t.create_timestamp,
            t.update_timestamp,
            t.validated_callsign,
            t.validated_callsign_timestamp,
            t.validated_dim_length,
            t.validated_dim_width,
            t.validated_imo,
            t.validated_name,
            t.validated_name_timestamp,
            t.validated_ship_type,
            t.cdp_ship_type,
            t.cdp_created
        FROM (
            SELECT
                t.*,
                ROW_NUMBER() OVER (PARTITION BY t.vessel_id ORDER BY t.create_timestamp DESC) AS rn
            FROM {catalog_name}.{silver_schema_name}.{target_table_name} t
        ) t
        WHERE t.rn = 1
    )

    INSERT INTO {catalog_name}.{silver_schema_name}.{target_table_name}
      (
        vessel_id,
        ais_class,
        callsign,
        dim_a,
        dim_b,
        dim_c,
        dim_d,
        dim_length,
        dim_width,
        flag,
        imo,
        mmsi,
        name,
        ship_subtype,
        ship_type,
        create_timestamp,
        update_timestamp,
        validated_callsign,
        validated_callsign_timestamp,
        validated_dim_length,
        validated_dim_width,
        validated_imo,
        validated_name,
        validated_name_timestamp,
        validated_ship_type,
        cdp_ship_type,
        cdp_created
      )
    SELECT
      sc.vessel.id                                                          AS vessel_id,
      sc.vessel.staticData.aisClass                                         AS ais_class,
      sc.vessel.staticData.callsign                                         AS callsign,
      sc.vessel.staticData.dimensions.a                                     AS dim_a,
      sc.vessel.staticData.dimensions.b                                     AS dim_b,
      sc.vessel.staticData.dimensions.c                                     AS dim_c,
      sc.vessel.staticData.dimensions.d                                     AS dim_d,
      sc.vessel.staticData.dimensions.length                                AS dim_length,
      sc.vessel.staticData.dimensions.width                                 AS dim_width,
      sc.vessel.staticData.flag                                             AS flag,
      sc.vessel.staticData.imo                                              AS imo,
      sc.vessel.staticData.mmsi                                             AS mmsi,
      sc.vessel.staticData.name                                             AS name,
      sc.vessel.staticData.shipSubType                                      AS ship_subtype,
      sc.vessel.staticData.shipType                                         AS ship_type,
      to_timestamp(sc.vessel.staticData.timestamp)                          AS create_timestamp,
      to_timestamp(sc.vessel.staticData.updateTimestamp)                    AS update_timestamp,
      sc.vessel.staticData.validated.callsign                               AS validated_callsign,
      sc.vessel.staticData.validated.callsignTimestamp                      AS validated_callsign_timestamp,
      sc.vessel.staticData.validated.dimensions.length                      AS validated_dim_length,
      sc.vessel.staticData.validated.dimensions.width                       AS validated_dim_width,
      sc.vessel.staticData.validated.imo                                    AS validated_imo,
      sc.vessel.staticData.validated.name                                   AS validated_name,
      sc.vessel.staticData.validated.nameTimestamp                          AS validated_name_timestamp,
      sc.vessel.staticData.validated.shipType                               AS validated_ship_type,
      sc.cdp_ship_type,
      sc.cdp_created
    FROM source sc
    LEFT JOIN latest_target lt ON sc.vessel.id = lt.vessel_id
    WHERE
        (
            -- Insert if attributes differ or target record doesn't exist
            (
                lt.vessel_id IS NULL
                OR COALESCE(sc.vessel.staticData.aisClass, '')                      != COALESCE(lt.ais_class, '')
                OR COALESCE(sc.vessel.staticData.callsign, '')                      != COALESCE(lt.callsign, '')
                OR COALESCE(sc.vessel.staticData.dimensions.a, '')                  != COALESCE(lt.dim_a, '')
                OR COALESCE(sc.vessel.staticData.dimensions.b, '')                  != COALESCE(lt.dim_b, '')
                OR COALESCE(sc.vessel.staticData.dimensions.c, '')                  != COALESCE(lt.dim_c, '')
                OR COALESCE(sc.vessel.staticData.dimensions.d, '')                  != COALESCE(lt.dim_d, '')
                OR COALESCE(sc.vessel.staticData.dimensions.length, '')             != COALESCE(lt.dim_length, '')
                OR COALESCE(sc.vessel.staticData.dimensions.width, '')              != COALESCE(lt.dim_width, '')
                OR COALESCE(sc.vessel.staticData.flag, '')                          != COALESCE(lt.flag, '')
                OR COALESCE(sc.vessel.staticData.imo, '')                           != COALESCE(lt.imo, '')
                OR COALESCE(sc.vessel.staticData.mmsi, '')                          != COALESCE(lt.mmsi, '')
                OR COALESCE(sc.vessel.staticData.name, '')                          != COALESCE(lt.name, '')
                OR COALESCE(sc.vessel.staticData.shipSubType, '')                   != COALESCE(lt.ship_subtype, '')
                OR COALESCE(sc.vessel.staticData.shipType, '')                      != COALESCE(lt.ship_type, '')
                OR COALESCE(sc.vessel.staticData.validated.callsign, '')            != COALESCE(lt.validated_callsign, '')
                OR COALESCE(sc.vessel.staticData.validated.callsignTimestamp, '')   != COALESCE(lt.validated_callsign_timestamp, '')
                OR COALESCE(sc.vessel.staticData.validated.dimensions.length, '')   != COALESCE(lt.validated_dim_length, '')
                OR COALESCE(sc.vessel.staticData.validated.dimensions.width, '')    != COALESCE(lt.validated_dim_width, '')
                OR COALESCE(sc.vessel.staticData.validated.imo, '')                 != COALESCE(lt.validated_imo, '')
                OR COALESCE(sc.vessel.staticData.validated.name, '')                != COALESCE(lt.validated_name, '')
                OR COALESCE(sc.vessel.staticData.validated.nameTimestamp, '')       != COALESCE(lt.validated_name_timestamp, '')
                OR COALESCE(sc.vessel.staticData.validated.shipType, '')            != COALESCE(lt.validated_ship_type, '')
            )
        );""")

    return f"merge succeeded for table {target_table_name}"
