from pyspark.sql import SparkSession


def merge_spire_vessel_voyage(
    spark: SparkSession,
    catalog_name: str,
    silver_schema_name: str,
    bronze_schema_name: str,
    target_table_name: str,
    source_table_name: str,
    last_api_call_timestamp: str,
) -> str:
    spark.sql(f"""
    WITH src AS (
        SELECT
            cdp_created                    AS cdp_created,
            cdp_ship_type                  AS cdp_ship_type,
            EXPLODE(data.vessels.nodes)    AS vessel
        FROM
            {catalog_name}.{bronze_schema_name}.{source_table_name}
        WHERE
            cdp_created = '{last_api_call_timestamp}'
    ), ordered AS (
    SELECT
        vessel.id                                                   AS vessel_id,
        vessel.currentVoyage.destination                            AS destination,
        vessel.currentVoyage.draught                                AS draught,
        vessel.currentVoyage.eta                                    AS eta,
        vessel.currentVoyage.matchedPort.matchScore                 AS matched_port_match_score,
        vessel.currentVoyage.matchedPort.port.name                  AS matched_port_name,
        vessel.currentVoyage.matchedPort.port.centerPoint.latitude  AS matched_port_centerpoint_latitude,
        vessel.currentVoyage.matchedPort.port.centerPoint.longitude AS matched_port_centerpoint_longitude,
        vessel.currentVoyage.matchedPort.port.unlocode              AS matched_port_unlocode,
        vessel.currentVoyage.timestamp                              AS create_timestamp,
        vessel.currentVoyage.updateTimestamp                        AS update_timestamp,
        cdp_ship_type,
        cdp_created,
        ROW_NUMBER() OVER(
            PARTITION BY vessel.id, to_timestamp(vessel.currentVoyage.timestamp)
            ORDER BY cdp_created DESC)                              AS rn
    FROM
        src
    ), filtered AS (
        SELECT *
        FROM
        ordered
        WHERE
        rn = 1
    )
    MERGE INTO {catalog_name}.{silver_schema_name}.{target_table_name} AS trg
    USING filtered
        ON filtered.vessel_id = trg.vessel_id
        AND (
            filtered.create_timestamp = trg.create_timestamp
            OR
            (filtered.create_timestamp IS NULL AND trg.create_timestamp IS NULL)
            )
    WHEN MATCHED THEN
    UPDATE
        SET
        vessel_id                          = filtered.vessel_id,
        destination                        = filtered.destination,
        draught                            = filtered.draught,
        eta                                = filtered.eta,
        matched_port_match_score           = filtered.matched_port_match_score,
        matched_port_name                  = filtered.matched_port_name,
        matched_port_centerpoint_latitude  = filtered.matched_port_centerpoint_latitude,
        matched_port_centerpoint_longitude = filtered.matched_port_centerpoint_longitude,
        matched_port_unlocode              = filtered.matched_port_unlocode,
        create_timestamp                   = filtered.create_timestamp,
        update_timestamp                   = filtered.update_timestamp,
        cdp_ship_type                      = filtered.cdp_ship_type,
        cdp_created                        = filtered.cdp_created
    WHEN NOT MATCHED THEN
    INSERT
    (
        vessel_id,
        destination,
        draught,
        eta,
        matched_port_match_score,
        matched_port_name,
        matched_port_centerpoint_latitude,
        matched_port_centerpoint_longitude,
        matched_port_unlocode,
        create_timestamp,
        update_timestamp,
        cdp_ship_type,
        cdp_created
    )
    VALUES
    (
        vessel_id,
        destination,
        draught,
        eta,
        matched_port_match_score,
        matched_port_name,
        matched_port_centerpoint_latitude,
        matched_port_centerpoint_longitude,
        matched_port_unlocode,
        create_timestamp,
        update_timestamp,
        cdp_ship_type,
        cdp_created
    );

    """)

    return f"merge succeeded for table {target_table_name}"
