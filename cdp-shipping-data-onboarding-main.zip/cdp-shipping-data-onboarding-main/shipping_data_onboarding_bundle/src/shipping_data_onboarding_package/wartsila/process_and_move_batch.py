from pyspark.sql import DataFrame
import os
import shutil


def get_bronze_file_path(landing_file_path: str, base_bronze_path: str) -> str:
    """Generate the bronze file path from the landing file path."""
    subfolder_path = "/".join(landing_file_path.split("/")[-4:-1])
    filename = landing_file_path.split("/")[-1]
    bronze_folder_path = f"{base_bronze_path}/{subfolder_path}"
    bronze_file_path = f"{bronze_folder_path}/{filename}"
    return bronze_file_path


def move_file_to_bronze(landing_file_path: str, bronze_file_path: str):
    """Move file from landing to bronze folder preserving subfolder structure."""
    bronze_folder_path = os.path.dirname(bronze_file_path)

    print(f"{landing_file_path=}")
    print(f"{bronze_file_path=}")

    os.makedirs(bronze_folder_path, exist_ok=True)
    shutil.move(landing_file_path, bronze_file_path)


def get_distinct_file_paths(batch_df: DataFrame) -> list:
    """Extract a list of distinct cdp_file_path values from the DataFrame."""
    return [
        row.cdp_file_path for row in batch_df.select(batch_df.cdp_file_path).distinct().collect()
    ]


def process_and_move_batch(
    batch_df: DataFrame,
    batch_id: int,
    catalog_name: str,
    silver_schema_name: str,
    base_bronze_path: str,
):
    """Process each batch and move files to the bronze folder."""
    if batch_df.count() > 0:
        batch_df.write.mode("append").format("delta").saveAsTable(
            f"{catalog_name}.{silver_schema_name}.wartsila_positions"
        )

    landing_file_paths = get_distinct_file_paths(batch_df)

    print(
        f"Batch {batch_id}: Successfully processed {batch_df.count()} records and moved {len(landing_file_paths)} files"  # noqa: E501
    )

    for landing_file_path in landing_file_paths:
        bronze_file_path = get_bronze_file_path(landing_file_path, base_bronze_path)
        move_file_to_bronze(landing_file_path, bronze_file_path)
