def append_to_sys_path(folder: str, base_folder: str = "shipping_data_onboarding_bundle") -> str:
    """
    Append the specified folder to the system path if it is not already present. Allows importing packages from the folder.
    """  # noqa: E501
    import re
    import os
    import sys

    if not (match := re.search(rf"(.*[\\/]{base_folder})", os.getcwd())):
        raise Exception(f"Could not find {base_folder} in current path: {os.getcwd()}")

    base_path = match.group(1)
    for root, dirs, _ in os.walk(base_path):
        if "src" in dirs:
            base_path = root
            break

    path = os.path.join(base_path, folder)
    if path not in sys.path:
        sys.path.append(path)
    return path


append_to_sys_path("src/config")
append_to_sys_path("src/shipping_data_onboarding_package")
append_to_sys_path("tests/unit")

import pytest
from pyspark.sql import Row
from wartsila.process_and_move_batch import get_distinct_file_paths


def test_get_distinct_file_paths(spark):
    data = [
        Row(
            cdp_file_path="/Volumes/cdp_prd_sandbox_catalog_01/shipping_bronze/landing_wartsila/2024/12/16/wartsila_ais_202412160001.csv.gz"
        ),
        Row(
            cdp_file_path="/Volumes/cdp_prd_sandbox_catalog_01/shipping_bronze/landing_wartsila/2024/12/16/wartsila_ais_202412160001.csv.gz"
        ),
        Row(
            cdp_file_path="/Volumes/cdp_prd_sandbox_catalog_01/shipping_bronze/landing_wartsila/2024/12/16/wartsila_ais_202412160002.csv.gz"
        ),
    ]
    df = spark.createDataFrame(data)

    expected_file_paths = [
        "/Volumes/cdp_prd_sandbox_catalog_01/shipping_bronze/landing_wartsila/2024/12/16/wartsila_ais_202412160001.csv.gz",
        "/Volumes/cdp_prd_sandbox_catalog_01/shipping_bronze/landing_wartsila/2024/12/16/wartsila_ais_202412160002.csv.gz",
    ]

    assert set(get_distinct_file_paths(df)) == set(expected_file_paths)


if __name__ == "__main__":
    pytest.main()
