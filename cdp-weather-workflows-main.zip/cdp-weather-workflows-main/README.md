# cdp-weather-workflows

## Databricks tasks

## Configure your Databricks environment

### Install Databricks CLI 

```shell
# Install the Databricks CLI
curl -fsSL https://raw.githubusercontent.com/databricks/setup-cli/main/install.sh | sudo sh 

# Configure the CLI to have access to the workspace.
# This requires a personal access token to be created in the workspace..
databricks configure
    # Databricks host: https://adb-3329120949392854.14.azuredatabricks.net
    # Personal access token: **** 
```

### Login to Databricks Workspace

```shell
# Brownfield Dev Sandbox - Login using 'AU' account via Pam/Beyond Trust.
databricks auth login --host adb-3329120949392854.14.azuredatabricks.net 

# Greenfield Dev Sandbox
databricks auth login --host adb-2123484989296422.2.azuredatabricks.net
```

## Databricks asset bundles

To add a new Databricks asset bundle, run the following and answer the questions 
that you will be asked.

```shell
databricks bundle init
```

The README.md in the project you create contains instructions on how to work with it.

