# Weather Bundle

This is a [Databricks Asset Bundle](https://learn.microsoft.com/en-us/azure/databricks/dev-tools/bundles/) which is deployed via a CI/CD pipeline in GitLab (DxOne).

## Getting started

The following are steps for typical working with the project once it is set up.

### Set up python / pip / BAMS

Set up a Python virtual environment.

   ```shell
   # Install virtualenv
   python3 -m pip install --user virtualenv
   # Create the virtual environment. VSCode might have done this for you already.
   python3 -m virtualenv ./.venv
   # Activate the virtual environment (assuming you're in a Powershell terminal inside VSCode).
   # Windows
   .\.venv\Scripts\Activate.ps1
   # Linux
   source ./.venv/bin/activate
   ```

Configure pip if you haven't already.

   ```shell
   python3 -m ensurepip --upgrade
   mkdir ~/pip
   touch ~/pip/pip.ini
   ```

Edit pip.ini as follows to configure BAMS as a default repository to search for artifacts.

   ```ini
   [global]
   index-url = https://USERNAME:TOKEN@bams-aws.refinitiv.com/artifactory/api/pypi/default.pypi.global/simple
   ```

Install libraries for the project.

   ```shell
   python3 -m pip install --upgrade pip
   python3 -m pip install -r .\requirements.txt
   python3 -m pip install -r .\requirements-dev.txt
   ```

## Docker

BAMS is an internal LSEG artifact repository which can be used as a proxy for getting hold of Docker images.
Create a BAMS API Token at https://bams-aws.refinitiv.com/ui/user_profile

Within the container, you can create/update your pip config as follows, but it's simpler to update the pip.conf in `local_user_config` and let the Docker build handle it.

   ```shell
   pip config --user set global.index-url https://YOUR_BAMS_USER:YOUR_BAMS_TOKEN@bams-aws.refinitiv.com/artifactory/api/pypi/default.pypi.global/simple
   ```

Build the `cdpspark` image:

   ```shell
   podman login bams-aws.refinitiv.com
   podman buildx build -t cdpspark .
   ```

Run the `cdpspark` image interactively:

   ```shell
   podman run -v ./:/opt/spark/work-dir/cdp_ops/ -it cdpspark /bin/bash
   ```

## Test

Test using pytest:

   ```shell
   # Run unit tests
   python3 -m pytest tests/unit
   ```

## Databricks configuration

1. Install the Databricks CLI from [https://docs.databricks.com/dev-tools/cli/databricks-cli.html](https://docs.databricks.com/dev-tools/cli/databricks-cli.html)

2. Authenticate to your Databricks workspace, if you have not done so already:

   ```shell
   databricks configure

   docker run -v ./:/cdp_ops --workdir=/cdp_ops ghcr.io/databricks/cli:latest configure
   ```

3. To deploy a development copy of this project, type:

    ```shell
    databricks bundle deploy --profile dev_sandbox_personal --target dev_sandbox_personal
    
    # Or using Docker
    docker run -e DATABRICKS_TOKEN=YOUR_PAT_TOKEN -v ./:/cdp_ops --workdir=/cdp_ops  ghcr.io/databricks/cli:latest bundle deploy --target dev_sandbox_personal
    ```

    This deploys everything that's defined for this project.
    For example, the default template would deploy a job called
    `[dev yourname] cdp_ops_dashboards_bundle_job` to your workspace.
    You can find that job by opening your workpace and clicking on **Workflows**.

4. Similarly, to deploy a production copy, type:

   ```shell
   databricks bundle deploy --target prod
   ```

   Note that the default job from the template has a schedule that runs every day
   (defined in resources/cdp_ops_dashboards_bundle.job.yml). The schedule
   is paused when deploying in development mode (see
   [https://docs.databricks.com/dev-tools/bundles/deployment-modes.html](https://docs.databricks.com/dev-tools/bundles/deployment-modes.html)).

5. To run a job or pipeline, use the "run" command:

   ```shell
   databricks bundle run
   ```

6. Optionally, install developer tools such as the Databricks extension for Visual Studio Code from
   [https://docs.databricks.com/dev-tools/vscode-ext.html](https://docs.databricks.com/dev-tools/vscode-ext.html). 
   Or read the "getting started" documentation for **Databricks Connect** for instructions on
   running the included Python code from a different IDE.

7. For documentation on the Databricks asset bundles format used
   for this project, and for CI/CD configuration, see
   [https://docs.databricks.com/dev-tools/vscode-ext.html](https://docs.databricks.com/dev-tools/bundles/index.html).
