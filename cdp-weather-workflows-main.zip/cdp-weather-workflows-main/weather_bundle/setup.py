"""
setup.py configuration script describing how to build and package this project.

This file is primarily used by the setuptools library and typically should not
be executed directly. See README.md for how to deploy, test, and run
"""

from setuptools import setup, find_packages

import sys

sys.path.append("./src/weather_package")


def read_requirements(file):
    with open(file) as f:
        return f.read().splitlines()


setup(
    name="weather_package",
    version="0.1.0",
    url="https://databricks.com",
    author="auc509204@dvrft.refinitiv.com",
    description="wheel file based on weather_bundle/src/weather_package",
    packages=find_packages(where="./src/weather_package"),
    package_dir={"": "src/weather_package"},
    entry_points={"packages": ["main=weather_package.main:main"]},
    # Dynamically read install_requires from requirements.txt
    install_requires=read_requirements("requirements.txt"),
    include_package_data=True,
    zip_safe=False,
)
