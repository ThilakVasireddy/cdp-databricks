import json
import os


class Config:
    def __init__(self):
        env = os.environ["ENV"]
        stage = os.environ["STAGE"]

        current_directory = os.path.dirname(os.path.abspath(__file__))
        config_file_path = os.path.join(current_directory, env, stage, "config.json")

        # Read the content of the config.json file
        with open(config_file_path, "r") as config_file:
            self._config_content = json.load(config_file)

    def __getitem__(self, key):
        return self._config_content[key]

    def __str__(self):
        return json.dumps(self._config_content, indent=4)
