# Databricks notebook source
# MAGIC %md
# MAGIC # Convert ecmwf data from grib to netcdf.
# MAGIC Source data is stored in landing. Converted data is to be saved to bronze.
# MAGIC
# MAGIC Files in bronze should be stored in proper folders.
# MAGIC The structure of the folders is derived from file name
# MAGIC
# MAGIC a file in /Volumes/cdp_dev_sandbox_catalog_01/weather_bronze/landing_ecmwf/
# MAGIC will create file(s) in /Volumes/cdp_dev_sandbox_catalog_01/weather_bronze/bronze/ecmwf/.
# MAGIC e.g. landing_ecmwf/C1D03091200030912011
# MAGIC ---> ecmwf/C1/2025/03/01/00/C1D03091200030912011
# MAGIC

# COMMAND ----------

# DBTITLE 1,Add Sys Path
import sys
import os
import re

if (config_path := re.split(r"notebooks", os.getcwd())[0] + "config") not in sys.path:
    sys.path.append(config_path)

if (package_path := re.split(r"notebooks", os.getcwd())[0] + "weather_package") not in sys.path:
    sys.path.append(package_path)

# COMMAND ----------

# DBTITLE 1,Imports
import shutil
import os
from datetime import datetime
from pathlib import Path

from pyspark.sql import Row
from pyspark.sql.functions import col

from config import Config

# COMMAND ----------

# DBTITLE 1,Constant Variables from Config
config = Config()

storage_account = config["shared"]["storage_account"]
system_catalog_name = config["shared"]["system_catalog_name"]
bronze_schema_name = config["weather"]["bronze_schema_name"]
silver_schema_name = config["weather"]["silver_schema_name"]

landing_folder_volume = config["weather"]["ecmwf"]["landing_folder_volume"]
bronze_folder_volume = config["weather"]["ecmwf"]["bronze_folder_volume"]
silver_folder_volume = config["weather"]["ecmwf"]["silver_folder_volume"]
bronze_checkpoint_folder_volume = config["weather"]["ecmwf"]["bronze_checkpoint_folder_volume"]

data_provider = config["weather"]["ecmwf"]["grib2netcdf_converter"]["data_provider"]

landing_path = f"/Volumes/{system_catalog_name}/{bronze_schema_name}/{landing_folder_volume}"
bronze_base_path = f"/Volumes/{system_catalog_name}/{bronze_schema_name}/{bronze_folder_volume}"

# Currently there are two instances of silver job (emsplit, noemsplit)
# Weather research team will decide which one stays
silver_state_path = (
    f"/Volumes/{system_catalog_name}/{silver_schema_name}/{silver_folder_volume}/conversion_state"
)
bronze_checkpoint_path = (
    f"/Volumes/{system_catalog_name}/{bronze_schema_name}/{bronze_checkpoint_folder_volume}"
)

print(f"{landing_path=}")
print(f"{bronze_base_path=}")
print(f"{silver_state_path=}")
print(f"{bronze_checkpoint_path=}")

# COMMAND ----------


# DBTITLE 1,Define main function
def move_file(row: Row) -> None:
    state_file_path = row["cdp_file_path"]

    marker_file_name = state_file_path.split("/")[-1]
    landing_file_name = marker_file_name.split("success_")[-1]
    source_file_path = f"{landing_path}/{landing_file_name}"

    if os.path.exists(source_file_path):
        creation_timestamp = os.path.getctime(source_file_path)
        creation_datetime = datetime.fromtimestamp(creation_timestamp)
        year = str(creation_datetime.year)  # Extract the year

        file_name = source_file_path.split("/")[-1]

        stream_code = file_name[:2]
        month = file_name[3:5]
        day = file_name[5:7]
        hour = file_name[7:9]

        target_bronze_path = (
            Path(bronze_base_path) / stream_code / year / month / day / hour / file_name
        )
        target_bronze_path.parent.mkdir(parents=True, exist_ok=True)

        shutil.move(source_file_path, target_bronze_path)


# COMMAND ----------

# DBTITLE 1,Auto Loader
df = (
    spark.readStream.format("cloudFiles")
    .option("cloudFiles.format", "binaryFile")
    .load(silver_state_path)
    .withColumn("cdp_file_path", col("_metadata.file_path"))
).select("cdp_file_path")

# Set up the streaming query
query = (
    df.writeStream.trigger(once=True)
    .foreach(move_file)
    .option("checkpointLocation", f"{bronze_checkpoint_path}")
    .start()
)

query.awaitTermination()
