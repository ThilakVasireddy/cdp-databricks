# Databricks notebook source
# MAGIC %md
# MAGIC # Convert ecmwf data from grib to netcdf.
# MAGIC Source data is stored in landing. Converted data is to be saved to silver.
# MAGIC
# MAGIC Files in silver should be stored in proper folders.
# MAGIC The structure of the folders is derived from file name
# MAGIC
# MAGIC Example target path:
# MAGIC /Volumes/cdp_dev_sandbox_catalog_01/weather_silver/silver/ecmwf/ECCTRLEU/2025/03/05/06/
# MAGIC Example target filename
# MAGIC ECCTRLEU_0p10_itssrd_e000_20250305T06z_20250305T06z_h000.nc
# MAGIC

# COMMAND ----------

# %sh sudo apt-get update && apt-get install -y gdal-bin libeccodes-dev libnetcdf-dev libhdf5-dev

# COMMAND ----------

# %pip install numpy==1.24.4 eccodes==1.7.1 xarray==2024.9.0 cf_xarray==0.10.0 cfgrib==0.9.14.1 \
# netcdf4==1.7.2

# COMMAND ----------

# %pip install --no-cache-dir --force-reinstall cfgrib==0.9.14.1 numpy==1.24.4


# COMMAND ----------

# DBTITLE 1,Add Sys Path
import sys
import os
import re

if (config_path := re.split(r"notebooks", os.getcwd())[0] + "config") not in sys.path:
    sys.path.append(config_path)

if (package_path := re.split(r"notebooks", os.getcwd())[0] + "weather_package") not in sys.path:
    sys.path.append(package_path)

# COMMAND ----------

# DBTITLE 1,Imports
from pyspark.sql import Row
from pyspark.sql.functions import col

# import grib2netcdf converter from weather package
from grib2netcdf.converter import Grib2NetCDFConverter
from config import Config


# COMMAND ----------

# DBTITLE 1,Variables and Config

config = Config()

storage_account = config["shared"]["storage_account"]
system_catalog_name = config["shared"]["system_catalog_name"]
bronze_schema_name = config["weather"]["bronze_schema_name"]
silver_schema_name = config["weather"]["silver_schema_name"]

bronze_folder_volume = config["weather"]["ecmwf"]["bronze_folder_volume"]
silver_folder_volume = config["weather"]["ecmwf_split_ensemble"]["silver_folder_volume"]
silver_checkpoint_folder_volume = config["weather"]["ecmwf_split_ensemble"][
    "silver_checkpoint_folder_volume"
]

data_provider = config["weather"]["ecmwf"]["grib2netcdf_converter"]["data_provider"]
product_codes = config["weather"]["ecmwf"]["grib2netcdf_converter"]["product_codes"]

bronze_base = f"/Volumes/{system_catalog_name}/{bronze_schema_name}/{bronze_folder_volume}"
silver_base_path = f"/Volumes/{system_catalog_name}/{silver_schema_name}/{silver_folder_volume}"
silver_checkpoint_path = (
    f"/Volumes/{system_catalog_name}/{silver_schema_name}/{silver_checkpoint_folder_volume}"
)

print(f"{bronze_base=}")
print(f"{silver_base_path=}")
print(f"{silver_checkpoint_path=}")

# COMMAND ----------

# %load_ext autoreload
# %autoreload 2

# COMMAND ----------

# DBTITLE 1,Define main function

converter = Grib2NetCDFConverter(
    data_provider=data_provider,
)


def convert_file(row: Row) -> None:
    # Import only once per worker node
    if "cf_xarray" not in sys.modules:
        import cf_xarray as cfxr  # Required import, though not used in code #noqa: F401

    source_file_path = row["cdp_file_path"]

    converter.convert(
        source_file_path,
        silver_base_path,
        split_by_ensemble_member=True,
    )


# COMMAND ----------

# DBTITLE 1,Auto Loader
spark.conf.set("spark.sql.files.ignoreMissingFiles", "true")

# glob pattern dopes not support exclude, so we need to specify it manually
# we need top exclude E8Y as it is not yet defined how to process it
if "E8" in product_codes:
    product_codes.remove("E8")
    product_codes.extend(["E8E", "E8X"])

glob_pattern = "{" + ",".join([f"{code}*" for code in product_codes]) + "}"

df = (
    spark.readStream.format("cloudFiles")
    .option("cloudFiles.format", "binaryFile")
    .option("pathGlobFilter", glob_pattern)
    .load(bronze_base)
    .withColumn("cdp_file_path", col("_metadata.file_path"))
).select("cdp_file_path")

# Set up the streaming query
query = (
    df.writeStream.trigger(once=True)
    .foreach(convert_file)
    .option("checkpointLocation", f"{silver_checkpoint_path}")
    .start()
)

query.awaitTermination()
