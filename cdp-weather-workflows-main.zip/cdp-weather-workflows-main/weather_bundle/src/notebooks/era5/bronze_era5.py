# Databricks notebook source
# MAGIC %md
# MAGIC # bronze_era5
# MAGIC
# MAGIC This notebook handles the retrieval, processing, and storage of meteorological data from
# MAGIC the ERA5 dataset provided by the Copernicus Climate Data Store (CDS). It performs the
# MAGIC following steps:
# MAGIC
# MAGIC 1. **Parameter Configuration**:
# MAGIC    - Sets up the configuration, parameters, and widgets for selecting the dataset, date
# MAGIC      range, and other retrieval settings.
# MAGIC
# MAGIC 2. **Data Retrieval**:
# MAGIC    - Retrieves ERA5 data using the CDS API. This involves constructing the appropriate
# MAGIC      API requests and storing the retrieved data in a designated folder structure in the
# MAGIC      Databricks file system (`/mnt/cdp/bronze/weather/era5`).
# MAGIC
# MAGIC    - **6-Day Lag for Data Availability**:
# MAGIC        - The ERA5 dataset has a lag of 6 days, meaning data for the last 6 days from the
# MAGIC          current date is unavailable for retrieval.
# MAGIC        - If the end date provided in the widget exceeds the current date minus 6 days
# MAGIC          (`current_date - lag_days`), it will be adjusted to ensure only available data is
# MAGIC          retrieved.
# MAGIC        - Similarly, the start date must also be within the valid range, or an error will
# MAGIC          be raised.
# MAGIC        - This lag ensures the dataset only includes fully processed and validated data.
# MAGIC
# MAGIC 3. **Hourly File Splitting**:
# MAGIC    - Processes the downloaded files to split them into hourly segments based on the time
# MAGIC      dimension. Supports both GRIB and NetCDF file formats.
# MAGIC
# MAGIC 4. **Parallel Execution**:
# MAGIC    - Utilizes multithreading with a `ThreadPoolExecutor` to efficiently handle multiple
# MAGIC      file downloads and splitting operations.
# MAGIC
# MAGIC 5. **Storage**:
# MAGIC    - Organizes and stores the processed files in a hierarchical folder structure based on
# MAGIC      the dataset name and query dates.
# MAGIC
# MAGIC ## Input:
# MAGIC - Dataset name (e.g., `reanalysis-era5-single-levels`)
# MAGIC - Start and end dates for data retrieval (adjusted for the 6-day lag)
# MAGIC - Parameters (variables and pressure levels) defined in the configuration
# MAGIC
# MAGIC ## Output:
# MAGIC - Raw data files stored in:
# MAGIC   `/Volumes/cdp_{env}_{stage}_catalog_01/weather_bronze/weather_bronze/era5`.
# MAGIC - Files split into hourly segments (if enabled) and stored in the same directory.
# MAGIC
# MAGIC ## Key Features:
# MAGIC - Configurable through widgets for dynamic dataset selection and date range definition.
# MAGIC - Supports GRIB and NetCDF file formats.
# MAGIC - Error handling for unsupported formats and invalid requests.
# MAGIC - Retry mechanism for robust data retrieval.
# MAGIC - Optimized parallel processing for faster execution.
# MAGIC
# MAGIC ## Required Libraries:
# MAGIC - cdsapi>=0.7.2
# MAGIC - earthkit==0.9.1
# MAGIC - pygrib==2.1.6

# COMMAND ----------

# DBTITLE 1,Add Sys Path
import sys
import os
import re

if (config_path := re.split(r"notebooks", os.getcwd())[0] + "config") not in sys.path:
    sys.path.append(config_path)

if (package_path := re.split(r"notebooks", os.getcwd())[0] + "weather_package") not in sys.path:
    sys.path.append(package_path)

# COMMAND ----------

# DBTITLE 1,Imports
import cdsapi
from pathlib import Path
from requests.adapters import HTTPAdapter
from concurrent.futures import ThreadPoolExecutor, as_completed
from requests.packages.urllib3.util.retry import Retry
import requests
from datetime import date, datetime, timedelta
from dateutil.relativedelta import relativedelta
from config import Config

# COMMAND ----------

# DBTITLE 1,Set Widgets
config = Config()


dataset_options = config["weather"]["era5"]["datasets"]
dbutils.widgets.dropdown("dataset_name", "", ["", *dataset_options])
dbutils.widgets.text("start_date", "")
dbutils.widgets.text("end_date", "")

# COMMAND ----------

# DBTITLE 1,Variables from Widgets and Config
dataset_name = dbutils.widgets.get("dataset_name")

start_date = dbutils.widgets.get("start_date")
if start_date != "":
    start_date = datetime.strptime(start_date, "%Y-%m-%d").date()
else:
    start_date = None

end_date = dbutils.widgets.get("end_date")
if end_date != "":
    end_date = datetime.strptime(end_date, "%Y-%m-%d").date()
else:
    end_date = None


catalog = config["weather"]["catalog_name"]
bronze_schema = config["weather"]["bronze_schema_name"]
bronze_folder = config["weather"]["era5"]["datasets"][dataset_name]["bronze_folder"]
bronze_folder_path = f"/Volumes/{catalog}/{bronze_schema}/{bronze_folder}"
era5_parameters = config["weather"]["era5"]["datasets"][dataset_name]["parameters"]
parallel_files = config["weather"]["era5"]["datasets"][dataset_name]["parallel_files"]
data_format = config["weather"]["era5"]["datasets"][dataset_name]["data_format"]

print(f"{dataset_name=}")
print(f"{start_date=}")
print(f"{end_date=}")
print(f"{bronze_folder_path=}")
print(f"{era5_parameters=}")
print(f"{parallel_files=}")
print(f"{data_format=}")

# COMMAND ----------

# DBTITLE 1,Other variables
API_URL = "https://cds.climate.copernicus.eu/api"
api_key = dbutils.secrets.get("weather-secretscope", "weather-cds-api-token")
max_retries = 3
lag_days = 6

# COMMAND ----------

# DBTITLE 1,Define functions


def create_session() -> requests.Session:
    """
    Creates a configured requests session with retry logic for handling transient errors.

    Returns:
        requests.Session: A configured session with retry strategy.
    """
    session = requests.Session()
    retry_strategy = Retry(
        total=max_retries,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=["HEAD", "GET", "OPTIONS", "POST"],
        backoff_factor=1,
    )

    adapter = HTTPAdapter(max_retries=retry_strategy)
    session.mount("https://", adapter)

    return session


def construct_retrieve_args(
    dataset_name: str,
    target_folder: str,
    date: date,
    variable: str | list[str],
    pressure_level: str | list[str] | None = None,
    data_format: str = "grib",
    archive: bool = False,
) -> tuple[str, dict, Path]:
    """
    Constructs the arguments needed to retrieve data from a dataset.

    Args:
        dataset_name (str): The name of the dataset to retrieve data
            from. Determines the product type and data structure.
        target_folder (str): The base folder where the retrieved data
            will be stored.
        date (date): The date for which the data should be retrieved.
        variable (str | list[str]): The variable(s) to retrieve from
            the dataset.
        pressure_level (str | list[str] | None, optional): The pressure
            level(s) to retrieve, if applicable. Defaults to None.
        data_format (str, optional): The format of the retrieved data.
            Must be one of ["grib", "netcdf"]. Defaults to "grib".
        archive (bool, optional): Whether the data should be retrieved
            in archived format. Defaults to False.

    Returns:
        tuple[str, dict, Path]: A tuple containing:
            - `dataset_name` (str): The dataset name.
            - `payload` (dict): A dictionary containing the retrieval
                payload with dataset parameters.
            - `filepath` (Path): The full file path where the retrieved
                data will be stored.

    Raises:
        ValueError: If an unsupported `data_format` is provided.

    Notes:
        - If `archive` is True, the `download_format` is set to
            "archived"; otherwise, it is set to "unarchived".
        - If the dataset name includes "monthly", the payload is
            configured for monthly averaged data.
        - Constructs a file path with the format
            `<target_folder>/<year>/<month>/<filename>`.
        - Supports "grib" and "netcdf" as valid data formats.
    """
    payload = {}
    yyyy, mm, dd = date.strftime("%Y-%m-%d").split("-")
    product_type = dataset_name.split("-")[0]

    payload["variable"] = variable
    payload["year"] = yyyy
    payload["month"] = mm
    payload["data_format"] = data_format

    if archive:
        payload["download_format"] = "archived"
    else:
        payload["download_format"] = "unarchived"

    if "monthly" in dataset_name:
        payload["time"] = "00:00"
        payload["product_type"] = f"monthly_averaged_{product_type}"

        filename = f"{yyyy}{mm}_{variable}"
        filepath = Path(target_folder) / yyyy / mm / filename
    else:
        payload["time"] = [f"{hour:02d}:00" for hour in range(0, 24)]
        payload["product_type"] = product_type
        payload["day"] = dd

        filename = f"{yyyy}{mm}{dd}_{variable}"
        filepath = Path(target_folder) / yyyy / mm / dd / filename

    if pressure_level is not None:
        payload["pressure_level"] = pressure_level

    supported_data_formats = ["grib", "netcdf"]
    if data_format not in supported_data_formats:
        raise ValueError(
            f"Unsupported data format: {data_format}. "
            f"Supported data formats: {supported_data_formats}"
        )
    if archive:
        file_ext = "zip"
    elif data_format == "netcdf":
        file_ext = "nc"
    else:
        file_ext = data_format

    if pressure_level:
        filepath = filepath.with_name(f"{filepath.stem}_{pressure_level}")

    filepath = filepath.with_suffix(f".{file_ext}")

    return dataset_name, payload, filepath


def trash_can(*args, **kwargs):
    """silence the logger of the cds client"""


def calculate_dates(
    dataset_name: str,
    start_date: date = None,
    end_date: date = None,
    lag_days: int = 6,
) -> list[date]:
    """
    Calculate dates based on the given start_date, end_date, and lag_days.

    Args:
        dataset_name (str): The name of the dataset to retrieve data
            from. Determines the product type and data structure.
        start_date (date): The start date, if provided.
        end_date (date): The end date, if provided.
        lag_days (int): The number of days to subtract from the current
            date for validation.

    Returns:
        list: A list of valid dates based on the provided inputs.

    Raises:
        ValueError: If start_date is greater than or equal to end_date
            or other invalid conditions.
    """
    current_date = datetime.now().date()
    lag_limit = current_date - timedelta(days=lag_days)
    match start_date, end_date:
        case None, None:
            valid_dates = [lag_limit]

        case None, _:
            if end_date > lag_limit:
                raise ValueError(
                    f"end_date ({end_date}) must be <= current_date - lag_days ({lag_limit})."
                )
            valid_dates = [end_date]

        case _, None:
            if start_date > lag_limit:
                raise ValueError(
                    f"start_date ({start_date}) must be <= current_date - lag_days ({lag_limit})."
                )
            valid_dates = [
                start_date + timedelta(days=i) for i in range((lag_limit - start_date).days + 1)
            ]

        case _:
            if start_date > end_date:
                raise ValueError(
                    f"start_date ({start_date}) must be less or equal to end_date ({end_date})."
                )

            if end_date > lag_limit:
                raise ValueError(
                    f"end_date ({end_date}) must be <= current_date - lag_days ({lag_limit})."
                )
            valid_dates = [
                start_date + timedelta(days=i)
                for i in range((end_date - start_date).days + 1)
                if start_date + timedelta(days=i) < lag_limit
            ]

    if "monthly-means" in dataset_name:
        # Subtract lag_days from the day of each date in filtered_dates
        valid_dates = [
            d - timedelta(days=(lag_days - 1)) - relativedelta(months=1) for d in valid_dates
        ]
        print(len(valid_dates))
        # Set the day to 1 for all dates in valid_dates
        valid_dates = sorted(list({d.replace(day=1) for d in valid_dates}))

    return valid_dates


def retrieve_data(
    dataset_name: str,
    request: dict,
    filepath: Path,
    session: requests.Session,
) -> None:
    """
    Retrieves data from a dataset and saves it to the specified file path.

    Args:
        dataset_name (str): The name of the dataset to retrieve data from.
        request (dict): The retrieval request payload.
        filepath (Path): The path to save the retrieved data.
        session (requests.Session): The session to use for making requests.

    Notes:
        - Creates parent directories for the file path if they do not exist.
        - Uses `cdsapi.Client` for data retrieval.
    """
    cds = cdsapi.Client(
        url=API_URL,
        key=api_key,
        session=session,
        info_callback=trash_can,
        warning_callback=trash_can,
        progress=False,  # turn off progress bar widget
    )

    filepath.parent.mkdir(parents=True, exist_ok=True)

    cds.retrieve(dataset_name, request, filepath)
    print(f"Downloaded: {filepath}")


def clear_directory(path: Path) -> None:
    """
    Deletes all files and directories within the specified path using
    Databricks `dbutils`.

    Args:
        path (Path): The directory path to clear. Should be a valid
        Databricks file system path e.g.
        "/mnt/cdp/bronze/weather/era5/pressure_h/2025/01/"
    """

    files = dbutils.fs.ls(path)
    # Delete each file or directory
    for file in files:
        if file.isDir():
            clear_directory(file.path)  # Recursive delete for directories
            dbutils.fs.rm(file.path)  # Delete empty directory
        else:
            dbutils.fs.rm(file.path)  # Delete individual file

    print(f"Cleared directory: {path}")
    print(f"Listing directory {path}: {dbutils.fs.ls(path)}")


# COMMAND ----------

# DBTITLE 1,main logic
query_dates = calculate_dates(dataset_name, start_date, end_date, lag_days)
query_dates_str = [d.strftime("%Y-%m-%d") for d in query_dates]
print(f"Retrieve data for dates: {query_dates_str}")

era5_args = []
for query_date in query_dates:
    for param in era5_parameters:
        if isinstance(param, list):
            var, pressure = param
        elif isinstance(param, str):
            var = param
            pressure = None
        else:
            raise TypeError(f"Unsupported parameter type - {param}")
        era5_args.append(
            construct_retrieve_args(
                dataset_name,
                bronze_folder_path,
                query_date,
                var,
                pressure_level=pressure,
                data_format=data_format,
            )
        )

print(f"Number of files to download {len(era5_args)}.")
tic = datetime.now()
with (
    ThreadPoolExecutor(max_workers=parallel_files) as executor,
    create_session() as session,
):
    futures = [
        executor.submit(
            retrieve_data,
            dataset_name,
            request,
            filepath,
            session,
        )
        for dataset_name, request, filepath in era5_args
    ]
    for future in as_completed(futures):
        future.result()  # Wait for all futures to complete

toc = datetime.now()
print("Download finished in", toc - tic)

# COMMAND ----------

if "monthly" in dataset_name:
    period = "monthly"
else:
    period = "hourly"

if "pressure" in dataset_name:
    dataset_type = "pressure"
elif "single" in dataset_name:
    dataset_type = "single"
elif dataset_name == "reanalysis-era5-land":
    dataset_type = "single"
else:
    raise ValueError(f"No known dataset type for {dataset_name=}")

dataset_category = f"{dataset_type}_{period}"

dbutils.jobs.taskValues.set(key="dataset_category", value=dataset_category)
