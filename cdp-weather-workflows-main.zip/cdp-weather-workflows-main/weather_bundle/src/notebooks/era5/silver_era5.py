# Databricks notebook source
# MAGIC %md
# MAGIC # ERA5 GRIB to NetCDF Conversion Documentation
# MAGIC This document describes the methodology for converting ERA5 GRIB data into standardized
# MAGIC NetCDF format with climate metadata, focusing on accumulated variables like total
# MAGIC precipitation (`tp`). It explains how accumulation is detected, how `cell_methods` are
# MAGIC interpreted, and how time bounds are derived.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 📦 Variable Configuration: Example `tp` (Total Precipitation)
# MAGIC Two styles of accumulated variable definitions are supported. Both describe a quantity
# MAGIC accumulated between two time points, with slightly different metadata.
# MAGIC
# MAGIC ### ✅ Sample 1: Accumulation via `cell_methods`
# MAGIC ```toml
# MAGIC [variables.tp]
# MAGIC title = "Total (accumulated) precipitation "
# MAGIC out_name = "tp"
# MAGIC modeling_realm = "atmos"
# MAGIC standard_name = "total_precipitation"
# MAGIC units = "m"
# MAGIC cell_methods = "area: mean time: sum"
# MAGIC accumulation_period_start = "forecast_reference_time"
# MAGIC accumulation_period_stop = "valid_time"
# MAGIC long_name = "Total precipitation accumulated since forecast reference time"
# MAGIC comment = "Total precipitation accumulated since forecast reference time"
# MAGIC dimensions = "longitude latitude time"
# MAGIC type = "real"
# MAGIC positive = "true"
# MAGIC valid_min = 0
# MAGIC valid_max = ""
# MAGIC ```
# MAGIC
# MAGIC ### ✅ Sample 2: Accumulation via `processing` flag
# MAGIC ```toml
# MAGIC [variables.tp]
# MAGIC title = "Total (accumulated) precipitation "
# MAGIC processing = "accumulated"
# MAGIC out_name = "tp"
# MAGIC modeling_realm = "atmos"
# MAGIC standard_name = "total_precipitation"
# MAGIC units = "m"
# MAGIC cell_methods = "area: mean time: point"
# MAGIC accumulation_period_start = "forecast_reference_time"
# MAGIC accumulation_period_stop = "valid_time"
# MAGIC long_name = "Total precipitation accumulated since forecast reference time"
# MAGIC comment = "Total precipitation accumulated since forecast reference time"
# MAGIC dimensions = "longitude latitude time"
# MAGIC type = "real"
# MAGIC positive = "true"
# MAGIC valid_min = 0
# MAGIC valid_max = ""
# MAGIC ```
# MAGIC
# MAGIC In this second case, even though `cell_methods` contains `time: point`, the presence of
# MAGIC `processing = "accumulated"` triggers accumulated handling.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## ⏱️ Accumulation Logic
# MAGIC For **accumulated variables**, the accumulation period is defined by:
# MAGIC - `accumulation_period_start`: the start of integration
# MAGIC - `accumulation_period_stop`: the end of integration
# MAGIC
# MAGIC ### Common configurations:
# MAGIC - `forecast_reference_time` → `valid_time`: accumulation starts at forecast initialization
# MAGIC   (step=0) and ends at forecast time
# MAGIC - `valid_time_minus_one_hour` → `valid_time`: for hourly accumulation as in standard ERA5
# MAGIC   hourly data
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 📐 `cell_methods` Explained
# MAGIC `cell_methods` describe how the variable is aggregated in space and time. These follow
# MAGIC CF-conventions and help clarify whether a value represents an instantaneous measurement,
# MAGIC a sum, or a statistical operation.
# MAGIC
# MAGIC | `cell_methods`                 | Meaning                                                                  |
# MAGIC |-------------------------------|---------------------------------------------------------------------------|
# MAGIC | `area: mean time: sum`        | Grid-cell mean over area, **summed** over time interval (e.g. total       |
# MAGIC |                               | precipitation)                                                            |
# MAGIC | `area: mean time: point`      | Grid-cell mean over area, **instantaneous** in time (e.g. temperature at  |
# MAGIC |                               | step)                                                                     |
# MAGIC | `area: mean time: max`        | Grid-cell mean over area, **maximum** value during the time interval      |
# MAGIC | `area: mean time: min`        | Grid-cell mean over area, **minimum** value during the time interval      |
# MAGIC
# MAGIC ### Additional notes:
# MAGIC - `area: mean` is standard for gridded datasets: each cell is interpreted as an average
# MAGIC   over its area
# MAGIC - `time: point` implies no temporal aggregation — an instantaneous value
# MAGIC - `time: sum`, `max`, or `min` imply aggregation across a time interval
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 🔎 Accumulation Detection Logic
# MAGIC The conversion tool considers a variable **accumulated** if:
# MAGIC - `processing = "accumulated"` is set in the config, or
# MAGIC - `cell_methods` contains `time:` with any value **other than `point`**
# MAGIC   (e.g. `sum`, `max`, `min`)
# MAGIC
# MAGIC In either case, the tool uses the configured `accumulation_period_start` and
# MAGIC `accumulation_period_stop` to calculate and set `time_bounds`.
# COMMAND ----------

# %sh sudo apt-get update && apt-get install -y gdal-bin libeccodes-dev libnetcdf-dev libhdf5-dev

# COMMAND ----------

# %pip install numpy==1.24.4 eccodes==1.7.1 xarray==2024.9.0 cf_xarray==0.10.0 cfgrib==0.9.14.1 \
# netcdf4==1.7.2
# %pip install --no-cache-dir --force-reinstall cfgrib==0.9.14.1 numpy==1.24.4

# COMMAND ----------

import sys
import os
import re

if (config_path := re.split(r"notebooks", os.getcwd())[0] + "config") not in sys.path:
    sys.path.append(config_path)

if (
    package_path := re.split(r"notebooks", os.getcwd())[0] + "weather_package"
) not in sys.path:
    sys.path.append(package_path)

# COMMAND ----------

# DBTITLE 1,Imports
from pyspark.sql import Row
from pyspark.sql.functions import col

from config import Config
from grib2netcdf.era5_converter import ERA5Grib2NetCDFConverter

# COMMAND ----------

# DBTITLE 1,Set Widgets
dbutils.widgets.text("dataset_category", "single_hourly")

# COMMAND ----------

# DBTITLE 1,Variables from Widgets and Config
dataset_category = dbutils.widgets.get("dataset_category")

config = Config()

system_catalog_name = config["shared"]["system_catalog_name"]
bronze_schema = config["weather"]["bronze_schema_name"]
bronze_folder = config["weather"]["era5"]["bronze_folder"]
bronze_folder_path = (
    f"/Volumes/{system_catalog_name}/{bronze_schema}/{bronze_folder}/{dataset_category}"
)

silver_schema_name = config["weather"]["silver_schema_name"]
silver_folder = config["weather"]["era5"]["silver_folder"]
silver_base_path = (
    f"/Volumes/{system_catalog_name}/{silver_schema_name}/{silver_folder}"
)

silver_checkpoint_folder = config["weather"]["era5"]["silver_checkpoint_folder"]

silver_checkpoint_folder_path = (
    f"/Volumes/{system_catalog_name}/{silver_schema_name}/{silver_checkpoint_folder}"
)

print(f"{dataset_category=}")
print(f"{bronze_folder_path=}")
print(f"{silver_base_path=}")
print(f"{silver_checkpoint_folder_path=}")

# COMMAND ----------

# %load_ext autoreload
# %autoreload 2

# COMMAND ----------

converter = ERA5Grib2NetCDFConverter()


def convert_file(row: Row) -> None:
    # Import only once per worker node
    if "cf_xarray" not in sys.modules:
        import cf_xarray as cfxr  # Required import, though not used in code #noqa: F401

    source_file_path = row["cdp_file_path"]
    converter.convert(source_file_path, silver_base_path, dataset_category)


# COMMAND ----------

df = (
    spark.readStream.format("cloudFiles")
    .option("cloudFiles.format", "binaryFile")
    .load(bronze_folder_path)
    .withColumn("cdp_file_path", col("_metadata.file_path"))
).select("cdp_file_path")

# Set up the streaming query
query = (
    df.writeStream.trigger(once=True)
    .foreach(convert_file)
    .option("checkpointLocation", f"{silver_checkpoint_folder_path}")
    .start()
)
