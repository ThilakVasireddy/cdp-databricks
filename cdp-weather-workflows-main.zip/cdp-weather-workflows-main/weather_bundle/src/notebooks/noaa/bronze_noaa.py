# Databricks notebook source
# MAGIC %md
# MAGIC # bronze_noaa
# MAGIC
# MAGIC This notebook is designed to download NOAA weather data files.
# MAGIC
# MAGIC ## Notebook code structure
# MAGIC
# MAGIC At a high level, this notebook:
# MAGIC 1. does some setup and detects what the "focus date" and "run" is based
# MAGIC    on the time this notebook runs (or the value can be manually inputted
# MAGIC    into the `run_datetime` widget e.g.
# MAGIC    `2025-03-31T09:00:00.000000`)
# MAGIC 2. waits until the download start time to start downloading
# MAGIC 3. polls the source URL to see what files are ready to download
# MAGIC 4. downloads files from the source until the expected number of files is
# MAGIC    reached.
# MAGIC - Files are downloaded concurrently
# MAGIC - Each file requires (at least) two requests to be sent: one for the
# MAGIC   .idx file and one for the actual GRIB file.
# MAGIC - The .idx file is needed to determine what byte ranges to download.
# MAGIC - Multiple byte ranges of the GRIB file are downloaded in a single
# MAGIC   request (essentially this is `curl -r` but with `requests`).
# MAGIC
# MAGIC ## Datasets
# MAGIC
# MAGIC In the `dataset` widget, we can choose to download one of the following:
# MAGIC
# MAGIC - GFS_pgrb2_0p25
# MAGIC - GFS_pgrb2_0p50
# MAGIC - GFS_pgrb2_1p00
# MAGIC - GEFS_pgrb2a_0p50
# MAGIC - GEFS_pgrb2b_0p50
# MAGIC - GEFS_extended_pgrb2a_0p50
# MAGIC - GEFS_extended_pgrb2b_0p50
# MAGIC
# MAGIC where:
# MAGIC
# MAGIC - GFS denotes operational forecast
# MAGIC - GEFS denotes the ensemble forecast
# MAGIC - GEFS_extended denotes the ensemble extended run
# MAGIC - regarding pgrb2/pgrb2a/pgrb2b: The ensemble forecast places files in two
# MAGIC   different directories depending on the variable, so we have separate
# MAGIC   instances of this notebook downloading from each source.
# MAGIC   The source URLs differ in a single letter (`noaa.gov/.../pgrb2ap5/` vs
# MAGIC   `noaa.gov/.../pgrb2bp5/`). The operational forecast files are all placed
# MAGIC   into a single folder.
# MAGIC - The variables downloaded are stored in `src/config/<env>/<stage>/config.json`
# MAGIC   (the most important env-stage being `prd-live`)
# MAGIC
# MAGIC ## Scheduling
# MAGIC
# MAGIC - The job should be scheduled to start at most 15 minutes before the first file arrives.
# MAGIC   - 15 minute leeway is to allow the Databricks cluster to be provisioned and ready.
# MAGIC   - Both the warmup time and the first run download start time
# MAGIC     are configurable in the config JSON file.
# MAGIC - GFS and GEFS data are available for download in 4 runs - "00", "06", "12", and "18".
# MAGIC - The GFS_extended only has the "00" run.
# MAGIC
# MAGIC ## Rate limits
# MAGIC
# MAGIC The NOMADS server where we download files from enforces a rate limit of
# MAGIC 120 requests/min at the IP level.

# COMMAND ----------

# MAGIC %load_ext autoreload
# MAGIC %autoreload 2

# COMMAND ----------

# DBTITLE 1,Add Sys Path

from nb_helpers import append_to_sys_path

append_to_sys_path("src/config")
append_to_sys_path("src/weather_package")

# COMMAND ----------

# DBTITLE 1,Imports
# ruff: noqa: E402
import os
import re
import datetime as dt
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
import traceback
from requests.exceptions import RetryError
import random

from config import Config
from rate_limiting import create_session  # type: ignore
from noaa_downloader import (  # type: ignore
    makedirs,
    get_source_files,
    find_files_to_download,
    get_target_files,
    process_file,
    tprint,
    get_focus_date_and_run,
    regex_list_to_regex,
    NOAAFileError,
)

from metrics.noaa_metrics_manager import (
    NOAABronzeTaskMetricsManager,
    make_metric_tmp_dir,
)

# COMMAND ----------

# DBTITLE 1,Set Widgets

dbutils.widgets.dropdown(  # noqa: F821
    "dataset",
    "",
    [
        "",
        "GFS_pgrb2_0p25",
        "GFS_pgrb2_0p50",
        "GFS_pgrb2_1p00",
        "GEFS_pgrb2a_0p50",
        "GEFS_pgrb2b_0p50",
        "GEFS_extended_pgrb2a_0p50",
        "GEFS_extended_pgrb2b_0p50",
    ],
)

dbutils.widgets.text(  # noqa: F821
    "run_datetime", "infer"
)  # e.g. 2025-04-04T09:00:00.000000

dbutils.widgets.text("requests_per_minute_override", "")

# COMMAND ----------

# DBTITLE 1,Variables from Widgets and Config
dataset = dbutils.widgets.get("dataset")  # noqa: F821
if not dataset:
    raise ValueError("Choose a dataset to download")


run_datetime = dbutils.widgets.get("run_datetime")  # noqa: F821
if run_datetime == "infer":
    run_datetime = dt.datetime.now()
else:
    run_datetime_padded = run_datetime + "2025-04-04T00:00:00.000000"[len(run_datetime) :]
    run_datetime = dt.datetime.strptime(run_datetime_padded, "%Y-%m-%dT%H:%M:%S.%f")


config = Config()
catalog = config["weather"]["catalog_name"]
bronze_schema = config["weather"]["bronze_schema_name"]

noaa: dict = config["weather"]["noaa"]
url_template = noaa[dataset]["url_template"]
file_regex = re.compile(noaa[dataset]["file_regex"])
expected_file_count = noaa[dataset]["expected_file_count"]
first_hr, last_hr = [noaa[dataset][f"{x}_forecast_hour"] for x in ["first", "last"]]
forecast_range = range(first_hr, last_hr + 1)
requests_per_minute_override = dbutils.widgets.get("requests_per_minute_override")
if requests_per_minute_override:
    requests_per_minute_limit = max(1, int(requests_per_minute_override))
else:
    requests_per_minute_limit = noaa[dataset]["request_rate_limit_per_minute"]

bronze_folder = noaa[dataset]["bronze_folder"]
variable_key = noaa[dataset]["variable_regex_list"]
variable_regex_list = noaa["variable_regex_lists"][variable_key]
first_run_download_start_time = dt.time(
    *[int(i) for i in noaa[dataset]["first_run_download_start_time"].split(":")]
)
download_start_day_offset = noaa[dataset]["download_start_day_offset"]
maximum_warmup_time_in_minutes = noaa[dataset]["maximum_warmup_time_in_minutes"]
maximum_warmup_time = dt.timedelta(minutes=maximum_warmup_time_in_minutes)
file_status_table_name = noaa["metrics"]["bronze_file_status_table_name"]
task_status_table_name = noaa["metrics"]["bronze_task_status_table_name"]
bronze_metrics_folder_name = noaa["metrics"]["bronze_metrics_folder_name"]
file_status_table = f"{catalog}.{bronze_schema}.{file_status_table_name}"
task_status_table = f"{catalog}.{bronze_schema}.{task_status_table_name}"
runs = noaa[dataset]["runs"]
AVG_SLEEP_TIME = 2.5
NUM_EXCEPTIONS_TOLERANCE = 20


def align_at_eq(lines: str, max_pad: int):
    """
    Aligns the lines at the equal sign.
    """
    kvs = [line.split("=", 1) for line in lines.strip().split("\n")]
    ks, vs = zip(*kvs)
    pad = min(max_pad, max(len(k) for k in ks))
    return "\n".join(f"{k.ljust(pad)} = {v}" for k, v in zip(ks, vs))


def aligned_print(lines: str, max_pad: int = 30):
    print(align_at_eq(lines, max_pad))


aligned_print(
    f"{dataset=}\n"
    f"{run_datetime=}\n"
    f"{catalog=}\n"
    f"{bronze_schema=}\n"
    f"{url_template=}\n"
    f"{file_regex=}\n"
    f"{expected_file_count=}\n"
    f"{forecast_range=}\n"
    f"{requests_per_minute_override=}\n"
    f"{requests_per_minute_limit=}\n"
    f"{bronze_folder=}\n"
    f"{variable_key=}\n"
    f"{variable_regex_list=}\n"
    f"{first_run_download_start_time=}\n"
    f"{maximum_warmup_time_in_minutes=}\n"
    f"{runs=}\n"
    f"{AVG_SLEEP_TIME=}\n"
    f"{NUM_EXCEPTIONS_TOLERANCE=}\n"
    f"{bronze_metrics_folder_name=}\n"
    f"{file_status_table=}\n"
    f"{task_status_table=}"
)

# COMMAND ----------

# DBTITLE 1,Computed and other variables
# Initialize task metrics manager and log start time
task_mm = NOAABronzeTaskMetricsManager(spark, task_status_table)
task_run_context = task_mm.get_task_run_context()
print(f"{task_run_context=}")
task_mm.log_task_start()

metrics_manager_kwargs = {
    "spark": spark,
    "state_table_name": file_status_table,
    "task_run_context": task_run_context,
}

# Calculate focus_date and run

focus_date, run = get_focus_date_and_run(
    run_datetime,
    first_run_download_start_time,
    shift=maximum_warmup_time,
    runs=runs,
)

# adjust date by the download_start_day_offset (e.g. for extended runs)
focus_date = focus_date + dt.timedelta(days=download_start_day_offset)

variable_regex = regex_list_to_regex(variable_regex_list)


# URL of the page to scrape
file_list_url = url_template.format(focus_date=focus_date.strftime("%Y%m%d"), run=run)
target_folder = os.path.join(
    "/Volumes",
    catalog,
    bronze_schema,
    bronze_folder,
    focus_date.strftime("%Y/%m/%d"),
    run,
)
metrics_folder = os.path.join(
    "/Volumes",
    catalog,
    bronze_schema,
    bronze_metrics_folder_name,
    dataset,
    focus_date.strftime("%Y/%m/%d"),
    run,
)
max_retries = 5

aligned_print(
    f"{focus_date=}\n"
    f"{run=}\n"
    f"{file_list_url=}\n"
    f"{target_folder=}\n"
    f"{metrics_folder=}\n"
    f"{variable_regex.pattern=}\n"
    f"{max_retries=}"
)

# COMMAND ----------

# DBTITLE 1,Create directories
makedirs(target_folder)
make_metric_tmp_dir(metrics_folder)

# COMMAND ----------

# DBTITLE 1,Wait for event to start

time_to_event_start = (
    dt.datetime.combine(focus_date, first_run_download_start_time)
    + dt.timedelta(hours=int(run))
    - dt.timedelta(days=download_start_day_offset)  # remove offset for time calculation
    - dt.datetime.now()
)

if time_to_event_start.total_seconds() > 0:
    print(f"Waiting for the event to start: {time_to_event_start}")
    time.sleep(time_to_event_start.total_seconds())

# COMMAND ----------

# DBTITLE 1,Download source files to target
file_metrics_manager_kwargs = {
    "spark": spark,
    "state_table_name": file_status_table,
    "metrics_folder": metrics_folder,
    "task_run_context": task_run_context,
}

exceptions = []


def sleep():
    """staggered sleep for about AVG_SLEEP_TIME seconds"""
    time.sleep(random.uniform(0.5, 2 * AVG_SLEEP_TIME - 0.5))


def capture_exception(file_name, exc, exceptions) -> tuple:
    """
    Capture exception details and append to exceptions list. If the number of exceptions
    exceeds NUM_EXCEPTIONS_TOLERANCE, raise a RuntimeError.
    """
    exc_traceback = (
        file_name,
        exc,
        traceback.format_tb(exc.__traceback__),
    )
    exceptions.append(exc_traceback)
    if len(exceptions) > NUM_EXCEPTIONS_TOLERANCE:
        raise RuntimeError(f"Exceptions occurred: {exceptions}")
    return exc_traceback


num_tasks = max(1, requests_per_minute_limit // 2)
# each run of process_file will send 2 requests to NOAA:
# one to download the idx file and the other to download the GRIB file.
# So we send half the rate limit as jobs.

try:
    # this try...finally... block is a 'manual context manager':
    # it allows replacing the session on connection failures.
    session = create_session(max_retries, requests_per_minute_limit)
    tprint(session)
    while True:
        # attempt to get list of available source files
        try:
            source_files = get_source_files(session, file_list_url, file_regex, forecast_range)
        except RetryError as exc:
            exception = capture_exception(file_list_url, exc, exceptions)
            tprint(f"raised {exception}. Recreating session")
            session.close()
            session = create_session(max_retries, requests_per_minute_limit)
            tprint(session)
            sleep()
            continue

        target_files = get_target_files(target_folder, forecast_range)
        files_to_download = find_files_to_download(source_files, target_files)

        source_file_count = len(source_files)
        target_file_count = len(target_files)
        files_to_download_count = len(files_to_download)

        tprint(
            "",
            f"{source_file_count=}",
            f"{target_file_count=}",
            f"{files_to_download_count=}",
            sep="\n",
        )

        if target_file_count == expected_file_count and files_to_download_count == 0:
            break
        if files_to_download_count == 0:
            sleep()
            continue
        with ThreadPoolExecutor(max_workers=num_tasks) as executor:
            future_to_file = {
                executor.submit(
                    process_file,
                    session,
                    file_name,
                    file_list_url,
                    target_folder,
                    variable_regex,
                    file_metrics_manager_kwargs,
                ): file_name
                for file_name in sorted(files_to_download)[:num_tasks]
            }
            for future in as_completed(future_to_file):
                file_name = future_to_file[future]
                try:
                    future.result()
                except NOAAFileError as exc:
                    tprint(f"{file_name} was not fully downloaded: {exc}")
                    continue
                except RetryError as exc:
                    tprint(
                        f"website says it has uploaded the .idx file for {file_name} but it is "
                        f"not available: {exc}. Recreating session"
                    )
                    session.close()
                    session = create_session(max_retries, requests_per_minute_limit)
                    tprint(session)
                    continue
                except Exception as exc:
                    exc_traceback = capture_exception(file_name, exc, exceptions)
                    tprint(f"exception raised: {exc_traceback}")
finally:
    tprint("closing session")
    session.close()

# final sanity check
final_target_files = get_target_files(target_folder, forecast_range)
if not any(int(i) == last_hr for f in final_target_files if (i := f[-3:]).isdigit()):
    _ = capture_exception("", NOAAFileError(f"Last hour file ({last_hr=}) not found"), exceptions)

    raise ExceptionGroup(  # noqa: F821
        "Failed to download all files", [e[1] for e in exceptions]
    )

if exceptions:
    tprint(f"Finished but raised these exceptions: {exceptions}")
else:
    tprint(f"Finished downloading all {expected_file_count} files without exceptions.")

# COMMAND ----------

task_mm.log_task_finish()
