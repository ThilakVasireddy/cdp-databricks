# Databricks notebook source
# MAGIC %md
# MAGIC # Bronze NOAA Metrics
# MAGIC
# MAGIC This notebook implements the bronze-level metrics collection for NOAA data processing. It reads
# MAGIC processed file metadata, applies a configurable date threshold, and merges metrics into a Delta table
# MAGIC for monitoring and auditing. The job is fully configurable and decoupled from the main data processing
# MAGIC pipeline.
# MAGIC

# COMMAND ----------

# MAGIC %load_ext autoreload
# MAGIC %autoreload 2

# COMMAND ----------

# DBTITLE 1,Add Sys Path

from nb_helpers import append_to_sys_path

append_to_sys_path("src/config")
append_to_sys_path("src/weather_package")

# COMMAND ----------

# DBTITLE 1,Imports
import pickle
import os

from pyspark.sql.functions import split, to_date, lit, col, concat_ws, current_timestamp

from delta.tables import DeltaTable

from config import Config
from metrics.noaa_metrics_manager import (
    FILE_STATE_TABLE_SCHEMA,
)

# COMMAND ----------

# DBTITLE 1,Variables from Widgets and Config
config = Config()
catalog = config["weather"]["catalog_name"]
bronze_schema = config["weather"]["bronze_schema_name"]

noaa: dict = config["weather"]["noaa"]
file_status_table_name = noaa["metrics"]["bronze_file_status_table_name"]
bronze_metrics_folder_name = noaa["metrics"]["bronze_metrics_folder_name"]
metrics_min_date = noaa["metrics"]["metrics_min_date"]
bronze_metrics_checkpoint_folder = noaa["metrics"]["bronze_metrics_checkpoint_folder"]
file_status_table = f"{catalog}.{bronze_schema}.{file_status_table_name}"

metrics_folder = os.path.join("/Volumes", catalog, bronze_schema, bronze_metrics_folder_name)

checkpoint_path = os.path.join(
    "/Volumes", catalog, bronze_schema, bronze_metrics_checkpoint_folder
)


def align_at_eq(lines: str, max_pad: int):
    """
    Aligns the lines at the equal sign.
    """
    kvs = [line.split("=", 1) for line in lines.strip().split("\n")]
    ks, vs = zip(*kvs)
    pad = min(max_pad, max(len(k) for k in ks))
    return "\n".join(f"{k.ljust(pad)} = {v}" for k, v in zip(ks, vs))


def aligned_print(lines: str, max_pad: int = 30):
    print(align_at_eq(lines, max_pad))


aligned_print(
    f"{catalog=}\n{bronze_schema=}\n{metrics_folder=}\n{checkpoint_path=}\n{file_status_table=}"
)


# COMMAND ----------


def process_pkl_files(df, batch_id):
    if df.isEmpty():
        return  # Skip processing for empty micro-batch

    pickle_paths = [row["pkl_file_path"] for row in df.select("pkl_file_path").collect()]

    rows = []
    for path in pickle_paths:
        with open(path, "rb") as pf:
            row = pickle.load(pf)
            rows.append(row)

    df_new = spark.createDataFrame(rows, schema=FILE_STATE_TABLE_SCHEMA)
    df_new = df_new.withColumn("record_created_time", current_timestamp())

    key_columns = df_new.columns
    merge_condition = " AND ".join([f"target.{k} = source.{k}" for k in key_columns])

    delta_table = DeltaTable.forName(spark, file_status_table)
    # Insert only new records, do nothing on match
    delta_table.alias("target").merge(
        df_new.alias("source"), merge_condition
    ).whenNotMatchedInsert(values={c: f"source.{c}" for c in df_new.columns}).execute()

    # Remove processed pickle files
    for path in pickle_paths:
        os.remove(path)


# COMMAND ----------

spark.conf.set("spark.sql.files.ignoreMissingFiles", "true")

df = (
    spark.readStream.format("cloudFiles")
    .option("cloudFiles.format", "binaryFile")
    .load(metrics_folder)
    .withColumn("pkl_file_path", col("_metadata.file_path"))
    .filter(col("pkl_file_path").endswith(".pkl"))
    .select("pkl_file_path")
)

df = (
    df.withColumn("path_parts", split(col("pkl_file_path"), "/"))
    .withColumn("year", col("path_parts")[8])
    .withColumn("month", col("path_parts")[9])
    .withColumn("day", col("path_parts")[10])
    .withColumn("file_date_str", concat_ws("-", "year", "month", "day"))
    .withColumn("file_date", to_date(col("file_date_str"), "yyyy-MM-dd"))
    .filter(col("file_date") >= lit(metrics_min_date))
    .select("pkl_file_path", "file_date")
)

query = (
    df.writeStream.trigger(processingTime="1 seconds")
    .foreachBatch(process_pkl_files)
    .option("checkpointLocation", checkpoint_path)
    .start()
)

# COMMAND ----------

# MAGIC %md
# MAGIC COMMON error for auto laoder with checkpoint path or job rerun if microbatch processing fails before updating checkpoint path
# MAGIC  org.apache.spark.SparkException: [FAILED_READ_FILE.DBR_FILE_NOT_EXIST] Error while reading file /Volumes/cdp_prd_sandbox_catalog_01/weather_bronze/bronze/noaa/metrics/GEFS_pgrb2a_0p50/2025/07/03/18/tmp_file_state/geavg.t18z.pgrb2a.0p50.f276.pkl. [CLOUD_FILE_SOURCE_FILE_NOT_FOUND] A file notification was received for file: /Volumes/cdp_prd_sandbox_catalog_01/weather_bronze/bronze/noaa/metrics/GEFS_pgrb2a_0p50/2025/07/03/18/tmp_file_state/geavg.t18z.pgrb2a.0p50.f276.pkl but it does not exist anymore. Please ensure that files are not deleted before they are processed. To continue your stream, you can set the Spark SQL configuration spark.sql.files.ignoreMissingFiles to true. SQLSTATE: 42K03 SQLSTATE: KD001

# COMMAND ----------
