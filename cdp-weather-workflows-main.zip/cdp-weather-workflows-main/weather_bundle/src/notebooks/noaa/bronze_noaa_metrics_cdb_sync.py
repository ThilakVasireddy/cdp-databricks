# Databricks notebook source
# MAGIC %md
# MAGIC # Bronze NOAA Metrics
# MAGIC
# MAGIC This notebook orchestrates the bronze-level metrics collection for NOAA data ingestion. It reads processed NOAA file
# MAGIC metadata, applies configurable thresholds, and merges metrics into a Delta table for monitoring and auditing. The
# MAGIC workflow is designed to be fully configurable and decoupled from the main data pipeline, supporting streaming updates
# MAGIC and robust checkpointing for reliable, incremental metric synchronization to the cloud data lake.
# MAGIC

# COMMAND ----------

# MAGIC %load_ext autoreload
# MAGIC %autoreload 2

# COMMAND ----------

# DBTITLE 1,Add Sys Path

from nb_helpers import append_to_sys_path


append_to_sys_path("src/config")
append_to_sys_path("src/weather_package")

# COMMAND ----------

# DBTITLE 1,Imports
import os

from config import Config

from metrics.noaa_metric_files_helper import (
    process_source_row,
    create_base_metric_file,
    update_metric_file,
)
from metrics.noaa_cdb_sync_helper import transfer_to_cdb

# COMMAND ----------

# DBTITLE 1,Variables from Widgets and Config
config = Config()
catalog = config["weather"]["catalog_name"]
bronze_schema = config["weather"]["bronze_schema_name"]

noaa: dict = config["weather"]["noaa"]
file_status_table_name = noaa["metrics"]["bronze_file_status_table_name"]
file_status_table = f"{catalog}.{bronze_schema}.{file_status_table_name}"

metric_source_mapping = noaa["metrics"]["metric_source_mapping"]
cdb_sync_folder = noaa["metrics"]["cdb_sync_folder"]
cdb_sync_checkpoint_folder = noaa["metrics"]["cdb_sync_checkpoint_folder"]
cdb_sync_path = f"/Volumes/{catalog}/{bronze_schema}/{cdb_sync_folder}"

checkpoint_path = os.path.join(
    "/Volumes", catalog, bronze_schema, cdb_sync_checkpoint_folder
)

print(
    f"{catalog=}\n"
    f"{bronze_schema=}\n"
    f"{metric_source_mapping=}\n"
    f"{cdb_sync_path=}\n"
    f"{checkpoint_path=}\n"
    f"{file_status_table=}"
)

# COMMAND ----------


def update_metric_files(df, batch_id):
    df = process_source_row(df, metric_source_mapping, cdb_sync_path)

    if df.isEmpty():
        return

    df_selected = df.select(
        "file_write_target_path", "target_metric_file_path", "source_metric_row"
    )
    rows = df_selected.collect()

    grouped = {}
    for row in rows:
        grouped.setdefault(row["target_metric_file_path"], []).append(row)

    for metric_file_path, group_rows in grouped.items():
        if not os.path.exists(metric_file_path):
            os.makedirs(os.path.dirname(metric_file_path), exist_ok=True)
            create_base_metric_file(metric_file_path)
            transfer_to_cdb(metric_file_path)

        grib_name_mapping = update_metric_file(metric_file_path, group_rows)

        transfer_to_cdb(metric_file_path, grib_name_mapping)


# COMMAND ----------

df = spark.readStream.format("delta").table(file_status_table)

df.writeStream.trigger(processingTime="5 seconds").foreachBatch(
    update_metric_files
).option("checkpointLocation", checkpoint_path).start()
