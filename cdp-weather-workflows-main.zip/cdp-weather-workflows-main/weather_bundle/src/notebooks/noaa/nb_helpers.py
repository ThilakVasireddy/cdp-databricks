def append_to_sys_path(folder: str, base_folder: str = "weather_bundle") -> str:
    """
    Append the specified folder to the system path if it is not already present.
    Allows importing packages from the folder.
    """
    import re
    import os
    import sys

    if not (match := re.search(rf"(.+[\\/]{base_folder})", os.getcwd())):
        raise FileNotFoundError(f"Could not find {base_folder} in current path: {os.getcwd()}")

    base_path = match.group(1)
    for root, dirs, _ in os.walk(base_path):
        if "src" in dirs:
            base_path = root
            break

    if (path := os.path.join(base_path, folder)) not in sys.path:
        sys.path.append(path)
    return path


def set_prd_sandbox_env():
    """
    Set environment variables for production sandbox.
    """
    import os

    if not os.environ.get("ENV") and not os.environ.get("STAGE"):
        os.environ["ENV"] = "prd"
        os.environ["STAGE"] = "sandbox"
        print("Environment set to prd sandbox.")
