# Databricks notebook source
# MAGIC %md
# MAGIC # NOAA GRIB to NetCDF Conversion Documentation
# MAGIC This document describes the methodology for converting NOAA GRIB data into standardized
# MAGIC NetCDF format with climate metadata, focusing on accumulated variables like total
# MAGIC precipitation (`tp`). It explains how accumulation is detected, how `cell_methods` are
# MAGIC interpreted, and how time bounds are derived.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 📦 Variable Configuration: Example `tp` (Total Precipitation)
# MAGIC Two styles of accumulated variable definitions are supported. Both describe a quantity
# MAGIC accumulated between two time points, with slightly different metadata.
# MAGIC
# MAGIC ### ✅ Sample 1: Accumulation via `cell_methods`
# MAGIC ```toml
# MAGIC [variables.tp]
# MAGIC title = "Total (accumulated) precipitation"
# MAGIC out_name = "tp"
# MAGIC modeling_realm = "atmos"
# MAGIC standard_name = "total_precipitation"
# MAGIC units = "m"
# MAGIC cell_methods = "area: mean time: sum"
# MAGIC accumulation_period_start = "forecast_reference_time"
# MAGIC accumulation_period_stop = "valid_time"
# MAGIC long_name = "Total precipitation accumulated since forecast reference time"
# MAGIC comment = "Total precipitation accumulated since forecast reference time"
# MAGIC dimensions = "longitude latitude time"
# MAGIC type = "real"
# MAGIC positive = "true"
# MAGIC valid_min = 0
# MAGIC valid_max = ""
# MAGIC ```
# MAGIC
# MAGIC ### ✅ Sample 2: Accumulation via `processing` flag
# MAGIC ```toml
# MAGIC [variables.tp]
# MAGIC title = "Total (accumulated) precipitation"
# MAGIC processing = "accumulated"
# MAGIC out_name = "tp"
# MAGIC modeling_realm = "atmos"
# MAGIC standard_name = "total_precipitation"
# MAGIC units = "m"
# MAGIC cell_methods = "area: mean time: point"
# MAGIC accumulation_period_start = "forecast_reference_time"
# MAGIC accumulation_period_stop = "valid_time"
# MAGIC long_name = "Total precipitation accumulated since forecast reference time"
# MAGIC comment = "Total precipitation accumulated since forecast reference time"
# MAGIC dimensions = "longitude latitude time"
# MAGIC type = "real"
# MAGIC positive = "true"
# MAGIC valid_min = 0
# MAGIC valid_max = ""
# MAGIC ```
# MAGIC
# MAGIC In this second case, even though `cell_methods` contains `time: point`, the presence of
# MAGIC `processing = "accumulated"` triggers accumulated handling.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## ⏱️ Accumulation Logic
# MAGIC For **accumulated variables**, the accumulation period is defined by:
# MAGIC - `accumulation_period_start`: the start of integration
# MAGIC - `accumulation_period_stop`: the end of integration
# MAGIC
# MAGIC ### Common configurations:
# MAGIC - `forecast_reference_time` → `valid_time`: accumulation starts at forecast
# MAGIC   initialization (step=0) and ends at forecast time.
# MAGIC - `valid_time_minus_one_hour` → `valid_time`: for hourly accumulation as in
# MAGIC   standard ERA5 hourly data.
# MAGIC - `valid_time_minus_mod_six` → `valid_time`: for hourly accumulation up to 6-hour
# MAGIC   windows. Each file represents **one hour** of data. When the file contains
# MAGIC   an accumulated variable (e.g., `tp`), the data corresponds to the total accumulation
# MAGIC   from **forecast reference time to the current time** (up to 6 hours). The **time boundaries**
# MAGIC   for each file are dynamically adjusted, reflecting the **start and end of the accumulation period**.
# MAGIC   For example:
# MAGIC   - **File 1**: Accumulated data from `2025-01-01:00:00:00` to `2025-01-01:01:00:00`.
# MAGIC   - **File 2**: Accumulated data from `2025-01-01:00:00:00` to `2025-01-01:02:00:00`.
# MAGIC   - **File 3**: Accumulated data from `2025-01-01:00:00:00` to `2025-01-01:03:00:00`.
# MAGIC   - **File 4**: Accumulated data from `2025-01-01:00:00:00` to `2025-01-01:04:00:00`, etc.
# MAGIC   This ensures the accumulated values reflect the appropriate **up-to-6-hour accumulation window**.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 📐 `cell_methods` Explained
# MAGIC `cell_methods` describe how the variable is aggregated in space and time. These follow
# MAGIC CF-conventions and help clarify whether a value represents an instantaneous measurement,
# MAGIC a sum, or a statistical operation.
# MAGIC
# MAGIC | `cell_methods`                 | Meaning                                                                  |
# MAGIC |-------------------------------|---------------------------------------------------------------------------|
# MAGIC | `area: mean time: sum`        | Grid-cell mean over area, **summed** over time interval (e.g. total precipitation)       |
# MAGIC | `area: mean time: point`      | Grid-cell mean over area, **instantaneous** in time (e.g. temperature at step)    |
# MAGIC | `area: mean time: max`        | Grid-cell mean over area, **maximum** value during the time interval      |
# MAGIC | `area: mean time: min`        | Grid-cell mean over area, **minimum** value during the time interval      |
# MAGIC
# MAGIC ### Additional notes:
# MAGIC - `area: mean` is standard for gridded datasets: each cell is interpreted as an average
# MAGIC   over its area
# MAGIC - `time: point` implies no temporal aggregation — an instantaneous value
# MAGIC - `time: sum`, `max`, or `min` imply aggregation across a time interval
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 🔎 Accumulation Detection Logic
# MAGIC The conversion tool considers a variable **accumulated** if:
# MAGIC - `processing = "accumulated"` is set in the config, or
# MAGIC - `cell_methods` contains `time:` with any value **other than `point`**
# MAGIC   (e.g. `sum`, `max`, `min`)
# MAGIC
# MAGIC In either case, the tool uses the configured `accumulation_period_start` and
# MAGIC `accumulation_period_stop` to calculate and set `time_bounds`.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## ⚖️ Unit Conversion for NOAA Data
# MAGIC
# MAGIC ### 🌍 Conversion Examples:
# MAGIC Certain variables in NOAA datasets may need unit conversion to standardize their values when converting from GRIB to NetCDF format. Here are some common conversions:
# MAGIC
# MAGIC 1. **Grams per square meter (`kg m-2 -> m`)**
# MAGIC - For variables that are expressed in `kg m-2` (kilograms per square meter), the conversion would involve dividing by a scale factor to express the value in meters.
# MAGIC - **Example:** For some variables like precipitation rate or snow depth, this conversion ensures that the final units match the intended format for NetCDF (meters, in this case).
# MAGIC
# MAGIC 2. **Percentage to fractions (`% -> 1`)**
# MAGIC - Variables that use percentages (`%`) will be converted into their fractional equivalents (i.e., dividing by 100).
# MAGIC - **Example:** A value of 50% would be converted to 0.5, as the data should be represented as a fraction in the NetCDF format for consistent mathematical operations.
# MAGIC
# MAGIC ### Conversion Process:
# MAGIC When converting variables, the following rules apply:
# MAGIC - The variable’s original unit is checked against the conversion rule.
# MAGIC - If a conversion is required, the appropriate scale factor (or division) is applied.
# MAGIC - The final converted unit is checked to ensure it is compatible with the desired NetCDF output.
# MAGIC
# MAGIC This ensures that all data is consistently represented in terms of its correct physical dimensions.
# MAGIC
# MAGIC ### Metadata path:
# MAGIC ../weather_bundle/src/weather_package/grib2netcdf/config

# COMMAND ----------

import sys
import os
import re

if (config_path := re.split(r"notebooks", os.getcwd())[0] + "config") not in sys.path:
    sys.path.append(config_path)

if (
    package_path := re.split(r"notebooks", os.getcwd())[0] + "weather_package"
) not in sys.path:
    sys.path.append(package_path)

# COMMAND ----------

# DBTITLE 1,Imports
from pyspark.sql import Row
from pyspark.sql.functions import col

from config import Config
from grib2netcdf.noaa_converter import NOAAGrib2NetCDFConverter


# COMMAND ----------

# DBTITLE 1,Variables from Widgets and Config
dbutils.widgets.dropdown(  # noqa: F821
    "dataset", "", ["", "GFS_pgrb2_0p25", "GEFS_pgrb2a_0p50", "GEFS_pgrb2b_0p50"]
)

# COMMAND ----------

# DBTITLE 1,Variables from Widgets and Config
dataset = dbutils.widgets.get("dataset")
if not dataset:
    raise ValueError("Choose a dataset to download")

config = Config()

system_catalog_name = config["shared"]["system_catalog_name"]
bronze_schema = config["weather"]["bronze_schema_name"]
bronze_folder = config["weather"]["noaa"][dataset]["bronze_folder"]
bronze_folder_path = f"/Volumes/{system_catalog_name}/{bronze_schema}/{bronze_folder}"

silver_schema_name = config["weather"]["silver_schema_name"]
silver_folder = config["weather"]["noaa"][dataset]["silver_folder"]
silver_base_path = (
    f"/Volumes/{system_catalog_name}/{silver_schema_name}/{silver_folder}"
)

silver_checkpoint_folder = config["weather"]["noaa"][dataset][
    "silver_checkpoint_folder"
]

silver_checkpoint_folder_path = (
    f"/Volumes/{system_catalog_name}/{silver_schema_name}/{silver_checkpoint_folder}"
)

short_names = config["weather"]["noaa"][dataset]["short_names"]
product_family = config["weather"]["noaa"][dataset]["product_family"]

print(f"{bronze_folder_path=}")
print(f"{silver_base_path=}")
print(f"{silver_checkpoint_folder_path=}")
print(f"{short_names=}")
print(f"{product_family=}")


# COMMAND ----------

# %load_ext autoreload
# %autoreload 2

# COMMAND ----------

converter = NOAAGrib2NetCDFConverter(product_family=product_family)


def convert_file(row: Row) -> None:

    # Import only once per worker node
    if "cf_xarray" not in sys.modules:
        import cf_xarray as cfxr  # Required import, though not used in code

    source_file_path = row["cdp_file_path"]
    converter.convert(source_file_path, silver_base_path, short_names)


# COMMAND ----------

df = (
    spark.readStream.format("cloudFiles")
    .option("cloudFiles.format", "binaryFile")
    .load(bronze_folder_path)
    .withColumn("cdp_file_path", col("_metadata.file_path"))
).select("cdp_file_path")

# Exclude 'index' and 'telemetry' folders
df = df.filter(
    ~col("cdp_file_path").rlike(r"/(index|telemetry|metrics)/")
).select("cdp_file_path")

# Set up the streaming query
query = (
    df.writeStream.trigger(processingTime="1 seconds")
    .foreach(convert_file)
    .option("checkpointLocation", f"{silver_checkpoint_folder_path}")
    .start()
)