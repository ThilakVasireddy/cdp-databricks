# Databricks notebook source
import sys
import os
import itertools


# Function to dynamically append config path to sys.path
def append_config_path_to_sys_path():
    def get_config_path(current_notebook_absolute_path: str = os.getcwd()) -> str:
        path_components = current_notebook_absolute_path.split("/")
        config_components = list(
            itertools.takewhile(lambda x: x != "notebooks", path_components)
        ) + ["config"]
        return "/".join(config_components)

    config_path = get_config_path()

    if config_path not in sys.path:
        sys.path.append(config_path)


append_config_path_to_sys_path()


# COMMAND ----------

# Import configuration
# ruff: noqa: E402
# import os # removed as already imported above
from config import Config

# COMMAND ----------

# Load configuration
config = Config()

sys_catalog = config["shared"]["system_catalog_name"]
sys_schema = config["shared"]["system_schema_name"]

# COMMAND ----------

# Ensure the schema_migrations table exists
spark.sql(f"""
    CREATE TABLE IF NOT EXISTS {sys_catalog}.{sys_schema}.schema_migrations(
        migration_version STRING,
        folder_path STRING,
        description STRING,
        timestamp TIMESTAMP,
        status STRING
    )
""")

# Fetch already executed migrations from the schema_migrations table
executed_migrations = set(
    (row["migration_version"], row["folder_path"])
    for row in spark.sql(f"""
        SELECT migration_version, folder_path FROM {sys_catalog}.{sys_schema}.schema_migrations
    """).collect()
)

# Get the base directory dynamically (current working directory in CI/CD)
base_dir = os.getcwd()

# Traverse all subdirectories and list versioned notebooks
for root, _, files in os.walk(base_dir):
    if not os.path.basename(root).startswith("migration"):
        continue
    print(f"Scanning folder: {root}")
    versioned_notebooks = [file for file in files if file.split("_")[0].isdigit()]
    versioned_notebooks = sorted(versioned_notebooks)  # Ensure execution order

    for notebook in versioned_notebooks:
        migration_version = notebook.split("_")[0]  # Extract version (e.g., "000")
        folder_path = root.replace(base_dir, "")  # Relative folder path for logging
        all_migrations = (migration_version, folder_path)
        notebook_path = os.path.join(root, notebook)  # Full path to the notebook

        # Debug: Check if the notebook is already executed
        if all_migrations in executed_migrations:
            print(f"Skipping already executed notebook: {notebook}")
            continue

        print(f"Executing notebook: {notebook} from folder {folder_path}")
        try:
            # Run the notebook
            result = dbutils.notebook.run(notebook_path, 600)
            print(f"Notebook {notebook} executed successfully. Result: {result}")

            # Log success in schema_migrations table
            spark.sql(f"""
                INSERT INTO {sys_catalog}.{sys_schema}.schema_migrations
                VALUES ('{migration_version}', '{folder_path}', '{notebook}', \
                    current_timestamp(), 'SUCCESS')
            """)
        except Exception as e:
            # Log failure in schema_migrations table
            print(f"Error running notebook {notebook} in folder {folder_path}: {e}")
            spark.sql(f"""
                INSERT INTO {sys_catalog}.{sys_schema}.schema_migrations
                VALUES ('{migration_version}', '{folder_path}', '{notebook}', \
                    current_timestamp(), 'FAILED')
            """)
