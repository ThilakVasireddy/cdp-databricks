# Grib2NetCDFConverter: A tool for converting GRIB2 weather data to NetCDF format.

# This module provides functionality to:
# - Parse configuration files containing metadata, dataset mappings, and variable definitions.
# - Retrieve metadata for datasets and specific weather variables.
# - Apply CF-compliant data models to GRIB2 datasets.
# - Convert GRIB2 files into NetCDF format while preserving metadata and dimensions.

# Main Features:
# - Uses `cfgrib` and `xarray` for reading GRIB2 files.
# - Applies CF-compliant transformations via `cf2cdm`.
# - Dynamically loads metadata from TOML configuration files.
# - Supports renaming and adding metadata to variables in NetCDF output.

# Usage Example:
#     from grib2netcdf.converter import Grib2NetCDFConverter
#
#     converter = Grib2NetCDFConverter(
#         data_provider="ecmwf",
#     )
#
#     converter.convert(
#         input_file_path="input.grib2",
#         target_folder_path="output_folder"
#     )
from pathlib import Path
import glob
import tomllib
import xarray as xr
import numpy as np
from importlib import resources
import tempfile
import shutil
import os

import cf2cdm
import cf_xarray as cfxr  # Required import, though not used in code


class Grib2NetCDFConverter:
    """
    A converter for transforming GRIB2 weather data into NetCDF format.

    This class provides methods to parse configuration files, retrieve metadata,
    apply data models, and convert GRIB2 files to NetCDF format.
    """

    CONFIG_FOLDER = "grib2netcdf.config"

    DATAMODEL_NAME = "datamodels.toml"

    DATASET_NAME = "datasets.toml"
    VARIABLES_FILE_NAME = "variables.toml"

    ENSEMBLE_CATEGORY = "ensemble"
    OPERATIOINAL_CATEGORY = "operational"

    SUCCESS_FOLDER = "conversion_state"
    SUCCESS_FILE_PREFIX = "success"

    def __init__(self, data_provider: str):
        """Initializes the converter with default values.
        Args:
            data_provider (str): The data provider name (e.g., "ECMWF").
        """
        self.data_provider = data_provider

        self.delete_pattern = "GRIB_"

        # Get configuration from files
        self.datamodel = self.get_datamodel()
        self.provider_meta, self.products_meta, self.variable_mappings = self.get_metadata()

        self.variables_metadata = self.get_variables_metadata()

    def parse_toml_file(self, file_name: str) -> dict:
        """
        Parses a TOML configuration file.

        Args:
            file_name (str): File name of the TOML file.

        Returns:
            dict: The parsed TOML content.

        Raises:
            ValueError: If no data provider is specified.
        """

        with resources.files(self.CONFIG_FOLDER).joinpath(file_name).open("rb") as file:
            parsed_file = tomllib.load(file)

        return parsed_file

    def get_metadata(self) -> tuple[dict, dict]:
        """
        Retrieves metadata and variable mappings from configuration files.

        Returns:
            tuple[dict, dict]: A tuple containing the dataset metadata and an inverse mapping
            of variables.
        """
        dataset_meta_raw = self.parse_toml_file(f"{self.data_provider}/{self.DATASET_NAME}")
        provider_meta = dataset_meta_raw["provider_meta"]
        products_meta = dataset_meta_raw["products_meta"]
        variable_mappings = dataset_meta_raw["variable_mappings"]

        return provider_meta, products_meta, variable_mappings

    def get_variables_metadata(self) -> dict:
        """
        Retrieves metadata for a specific variable.

        Returns:
            dict: The metadata for the specified variable.
        """
        variables_metadata = self.parse_toml_file(self.VARIABLES_FILE_NAME)["variables"]

        return variables_metadata

    def find_input_data(self, data_path: Path, file_pattern: str) -> list[str]:
        """
        Searches for input GRIB2 files in a directory.

        Args:
            data_path (Path): The directory path to search in.
            file_pattern (str): The file pattern to match (e.g., "*.grib2").

        Returns:
            list[str]: A list of matching file paths.
        """
        list_of_data_files = glob.glob(str(data_path / file_pattern), recursive=True)
        return [filename for filename in list_of_data_files if "." not in filename.split("/")[-1]]

    def get_datamodel(self) -> dict:
        """
        Retrieves the data model configuration.

        Returns:
            dict: The data model configuration.
        """
        return self.parse_toml_file(self.DATAMODEL_NAME)

    def apply_datamodel(self, dataset: xr.Dataset) -> xr.Dataset:
        """
        Applies the data model translation to a dataset.

        Args:
            dataset (xr.Dataset): The dataset to modify.

        Returns:
            xr.Dataset: The modified dataset.
        """
        return cf2cdm.translate_coords(dataset, self.datamodel)

    def apply_dataset_metadata(self, dataset: xr.Dataset) -> xr.Dataset:
        """
        Applies metadata to a dataset and expands necessary dimensions.

        Args:
            dataset (xr.Dataset): The dataset to modify.
        Returns:
            xr.Dataset: The modified dataset.
        """
        # 1. Remove global GRIB attributes
        keys_to_remove = [key for key in dataset.attrs if key.startswith(self.delete_pattern)]
        for key in keys_to_remove:
            del dataset.attrs[key]

        dataset.attrs.update(self.global_meta)
        dataset.attrs["forecast_reference_time"] = np.datetime_as_string(
            dataset["forecast_reference_time"].values
        )

        if "valid_time" not in dataset.dims:
            dataset = dataset.expand_dims("valid_time")

        if "realization" not in dataset.dims:
            dataset = dataset.expand_dims("realization")

        dataset = dataset.cf.add_bounds(["latitude", "longitude"])
        return dataset

    def construct_output_path_template(
        self,
        file_path: str,
        dataset: xr.Dataset,
    ) -> tuple[str, str]:
        """
        Constructs an output filename path template for a NetCDF file.

        Args:
            file_path: Input file path.
            dataset (xr.Dataset): The dataset to extract time information.
        Returns:
            tuple[str, str]: A tuple containing the constructed filename path template and
            the date folder structure (e.g., 'yyyy/mm/dd/hour').
        """
        product_short_name = self.global_meta["short_name"]

        forecast_reference_time = dataset["forecast_reference_time"]
        forecast_reference_time = str(forecast_reference_time.dt.strftime("%Y%m%d%H").values + "z")

        valid_time = dataset["valid_time"]
        valid_time = str(valid_time[-1].dt.strftime("%Y%m%d%H").values + "z")

        leadtime = int(dataset["leadtime"].values / np.timedelta64(1, "h"))

        output_filename = (
            f"{product_short_name}_<resolution_tag>_<variable_name_tag>_<realization_tag>_"
            f"{forecast_reference_time}_{valid_time}_h{leadtime:03}.nc"
        )
        # folder structure
        year = forecast_reference_time[:4]
        file_name = file_path.split("/")[-1]

        month = file_name[3:5]
        day = file_name[5:7]
        hour = file_name[7:9]

        date_folders = f"{year}/{month}/{day}/{hour}"

        output_path = f"{product_short_name}/<variable_name_tag>/{date_folders}"

        output_filename_path = f"{output_path}/{output_filename}"

        return output_filename_path, date_folders

    def construct_output_path(
        self,
        filename_path_template: str,
        cdp_variable: str,
        resolution: str,
        realization: str,
    ) -> str:
        """
        Constructs an output file path by replacing template placeholders with actual values.

        Args:
            filename_path_template (str): A template string containing placeholders.
            cdp_variable (str): The variable name to replace in the template.
            resolution (str): The resolution value to replace in the template.
            realization (str): The realization value to replace in the template.

        Returns:
            str: The formatted output path with placeholders replaced.
        """
        return (
            filename_path_template.replace("<variable_name_tag>", cdp_variable)
            .replace("<resolution_tag>", resolution)
            .replace("<realization_tag>", realization)
        )

    def get_resolution(self, data_array: xr.DataArray) -> str:
        """
        Extracts the smallest resolution from dataset attributes and formats it.

        Args:
            data_array (xr.DataArray): An xarray data array containing GRIB metadata.

        Returns:
            str: The resolution value in "XpY" format.
        """
        res = min(
            data_array.attrs["GRIB_iDirectionIncrementInDegrees"],
            data_array.attrs["GRIB_jDirectionIncrementInDegrees"],
        )
        resolution = f"{res:.2f}".replace(".", "p")

        return resolution

    def map_product_name(self, input_file_path: str) -> str:
        """
        Extracts and maps a product name from the input file path based on the data provider.

        Args:
            input_file_path (str): The file path of the dataset.

        Returns:
            str: The extracted product name.

        Raises:
            ValueError: If the data provider is not supported.
        """
        if self.data_provider == "ecmwf":
            product_name = input_file_path.split("/")[-1][:2]
        else:
            raise ValueError(f"Provider name {self.provider} not suppoorted.")

        return product_name

    def map_category(self, input_file_path: str):
        """
        Determines the category of the product based on the input file path.

        Args:
            input_file_path (str): The path of the input file.

        Returns:
            str: The category of the product, either `ENSEMBLE_CATEGORY` or `OPERATIONAL_CATEGORY`.

        Raises:
            ValueError: If the product name does not match expected patterns.
            ValueError: If the data provider is not supported.
        """
        if self.data_provider == "ecmwf":
            product_name = input_file_path.split("/")[-1][:2]
            if product_name.startswith("E"):
                category = self.ENSEMBLE_CATEGORY
            elif product_name.startswith("C"):
                category = self.OPERATIOINAL_CATEGORY
            else:
                raise ValueError(f"Unknown category for product name {product_name}")
        else:
            raise ValueError(f"Provider name {self.provider} not suppoorted.")

        return category

    def write_netcdf_to_volume(self, dataset: xr.Dataset, file_write_path: Path):
        """
        Writes an xarray dataset to a NetCDF file on a volume.

        Args:
            dataset (xr.Dataset): The dataset to be written.
            file_write_path (Path): The target file path for writing the NetCDF file.

        Notes:
            - `to_netcdf` cannot write directly to a volume, so a temporary file is used.
            - Ensures that the target directory exists before copying the file.
        """
        # Write to NetCDF file
        # to_netcdf cannot write straight to a volume
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_file_path = f"{tmpdir}/{file_write_path.name}"
            dataset.to_netcdf(tmp_file_path, unlimited_dims="valid_time", format="NETCDF4")

            # Ensure the target directory exists
            file_write_path.parent.mkdir(parents=True, exist_ok=True)

            shutil.copy(tmp_file_path, file_write_path)

    def create_success_marker_file(
        self, input_file_path: str, target_folder_path: str, date_folder: str
    ):
        """
        Creates a success marker file to indicate successful processing.

        Args:
            input_file_path (str): The path of the input file.
            target_folder_path (str): The base directory where the success marker should be stored.
            date_folder (str):  date-based subdirectory (e.g. 'yyyy/mm/dd').

        Notes:
            - The success marker file is created under
              `{target_folder_path}/{SUCCESS_FOLDER}/{date_folder}`.
            - An empty file is not sufficient for Auto Loader,
              so a null character (`\0`) is written.
        """
        input_file_name = input_file_path.split("/")[-1]
        success_folder_path = f"{target_folder_path}/{self.SUCCESS_FOLDER}"
        success_file_name = f"{self.SUCCESS_FILE_PREFIX}_{input_file_name}"

        # Format the datetime as a string in yyyy/mm/dd format
        success_folder_path = f"{success_folder_path}/{date_folder}"
        success_marker_file_path = f"{success_folder_path}/{success_file_name}"

        os.makedirs(success_folder_path, exist_ok=True)

        # Create an empty marker file
        with open(success_marker_file_path, "w") as file:
            # auto loader does not see empty files therefore we need to write something to it
            file.write("\0")

    def apply_variable_metadata(
        self,
        data_array: xr.DataArray,
        variable_meta_dict: dict,
    ) -> xr.DataArray:
        """
        Applies metadata to a variable by removing unwanted attributes and adding new metadata.

        Args:
            data_array (xr.DataArray): The data variable to modify.
            variable_meta_dict (dict): Metadata dictionary specific to the variable.

        Returns:
            xr.DataArray: The updated data variable with applied metadata.
        """
        keys_to_remove = [key for key in data_array.attrs if key.startswith(self.delete_pattern)]
        for key in keys_to_remove:
            del data_array.attrs[key]
        data_array.attrs.update(variable_meta_dict)
        return data_array

    def reorganize_variable(self, data_array: xr.DataArray) -> xr.DataArray:
        """
        Reorders the dimensions of a variable to ensure a standard structure.

        Args:
            data_array (xr.DataArray): The data variable to reorganize.

        Returns:
            xr.DataArray: The data variable with reordered dimensions.
        """
        # Determine the correct level dimension
        level_dim = next(
            filter(lambda x: x in data_array.dims, ["level", "pressure_level"]),
            None,
        )

        # Define the expected order dynamically
        expected_order = ["realization", "valid_time", level_dim, "latitude", "longitude"]

        # Remove None values (if no level-like dimension exists)
        expected_order = [dim for dim in expected_order if dim is not None]

        # Apply transpose dynamically
        data_array = data_array.transpose(*expected_order, missing_dims="warn")

        return data_array

    def create_output_dataset(self, dataset: xr.Dataset) -> xr.Dataset:
        """
        Creates an empty output dataset with metadata copied from the input dataset.

        Args:
            dataset (xr.Dataset): The input dataset containing metadata.

        Returns:
            xr.Dataset: A new dataset with copied metadata but no variables.
        """
        out_dataset = xr.Dataset()
        out_dataset.attrs.update(dataset.attrs)
        return out_dataset

    def get_accumulation_start_stop(
        self,
        data_array: xr.DataArray,
        variable_meta_dict: dict,
    ) -> tuple[str | None, str | None]:
        """
        Determines the start and stop times for accumulated or mean variables.

        Args:
            data_array (xr.DataArray): The data variable containing time-related attributes.
            variable_meta_dict (dict): Metadata dictionary defining processing type.

        Returns:
            tuple[str | None, str | None]: The start and stop time attributes, if applicable.
        """
        processing = variable_meta_dict.get("processing", "point")

        if processing == "accumulated":
            start = data_array.attrs["accumulation_period_start"]
            stop = data_array.attrs["accumulation_period_stop"]
        else:
            # includes case processing == "mean"
            start = stop = None

        return start, stop

    def construct_time_bounds(
        self,
        dataset: xr.Dataset,
        data_array: xr.DataArray,
        variable_meta_dict: dict,
    ) -> xr.DataArray:
        """
        Constructs time bounds for accumulated or mean variables based on metadata.

        Args:
            dataset (xr.Dataset): The full dataset containing metadata.
            data_array (xr.DataArray): The variable for which time bounds are created.
            variable_meta_dict (dict): Metadata dictionary defining accumulation periods.

        Returns:
            xr.DataArray: A time bounds array for the variable.
        """
        start, stop = self.get_accumulation_start_stop(data_array, variable_meta_dict)

        if start == "forecast_reference_time" and stop == "valid_time":
            time_bounds = np.array(
                [
                    [
                        data_array.forecast_reference_time.values,
                        data_array.valid_time.values[0],
                    ]
                ]
            )
        else:
            time_bounds = np.empty(shape=(1, 2))

        bounds_da = xr.DataArray(data=time_bounds, coords=[data_array.valid_time, dataset.bounds])
        return bounds_da

    def finalize_output_dataset(
        self,
        out_dataset: xr.Dataset,
        variable_name: str,
        dataset: xr.Dataset,
        valid_time_bounds: xr.DataArray,
    ) -> xr.Dataset:
        """
        Finalizes the dataset by adding spatial and temporal bounds.

        Args:
            out_dataset (xr.Dataset): The output dataset being processed.
            variable_name (str): The variable being processed.
            dataset (xr.Dataset): The original dataset containing metadata.
            valid_time_bounds (xr.DataArray): The computed time bounds.

        Returns:
            xr.Dataset: The finalized dataset with bounds and metadata applied.
        """
        out_dataset["latitude_bounds"] = dataset["latitude_bounds"]
        out_dataset["longitude_bounds"] = dataset["longitude_bounds"]

        try:
            processing = out_dataset[variable_name].attrs["processing"]
        except KeyError:
            processing = None

        if processing in ["accumulated"] or "time: mean" in out_dataset[variable_name].attrs.get(
            "cell_methods", ""
        ):
            out_dataset["valid_time_bounds"] = valid_time_bounds

        return out_dataset

    def open_dataset(self, input_file_path: str) -> xr.Dataset:
        """
        Opens a GRIB2 dataset using xarray.

        Args:
            input_file_path (str): The path to the GRIB2 file.

        Returns:
            xr.Dataset: The loaded dataset.
        """
        dataset = xr.open_dataset(
            input_file_path, engine="cfgrib", backend_kwargs={"indexpath": ""}
        )
        return dataset

    def process_single_file(
        self,
        category: str,
        var_dataset: xr.Dataset,
        filename_path_template: str,
        cdp_variable: str,
        resolution: str,
        target_folder_path: Path,
    ) -> None:
        """
        Process and save a single NetCDF file.

        Args:
            category (str): The category of the dataset (ensemble or operational).
            var_dataset (xr.Dataset): The dataset to be saved.
            filename_path_template (str): Template for the output filename.
            cdp_variable (str): The variable name.
            resolution (str): The resolution string.
            target_folder_path (Path): The target directory for saving.

        Raises:
            ValueError: If the category is unknown.
        """
        if category == self.ENSEMBLE_CATEGORY:
            realization = "eALL"
        elif category == self.OPERATIOINAL_CATEGORY:
            realization = var_dataset["realization"].item()
            realization = f"e{realization:03}"
        else:
            raise ValueError(f"Unknown category {category}")

        out_filename_path = self.construct_output_path(
            filename_path_template, cdp_variable, resolution, realization
        )
        file_write_path = target_folder_path / out_filename_path

        self.write_netcdf_to_volume(var_dataset, file_write_path)

    def convert(
        self,
        input_file_path: str,
        target_folder_path: str,
        split_by_ensemble_member: bool = False,
    ):
        """
        Converts a GRIB2 file to NetCDF format.

        Args:
            input_file_path (str): The path to the input GRIB2 file.
            target_folder_path (str): The directory to save the NetCDF files.
            split_by_ensemble_member (bool): Flag whether to split files by ensemble member.
            Works only for ensemble files.

        Raises:
            ValueError: If the converter is not properly configured.
        """
        try:
            # If you're only reading the file once and never reopening it,
            # then you don't need the .idx file. It's safe to set: backend_kwargs={"indexpath": ""}
            dataset = self.open_dataset(input_file_path)

            dataset = self.apply_datamodel(dataset)

            product_name = self.map_product_name(input_file_path)
            self.global_meta = self.provider_meta | self.products_meta[product_name]
            dataset = self.apply_dataset_metadata(dataset)

            variable_mapping = self.variable_mappings[product_name]

            category = self.map_category(input_file_path)

            filename_path_template, date_folders = self.construct_output_path_template(
                input_file_path, dataset
            )

            for cdp_variable, provider_variable in variable_mapping.items():
                if provider_variable not in dataset:
                    print(
                        f"{provider_variable=} is not available in file {input_file_path}.\n"
                        f"Available variables in the dataset: {dataset.data_vars}"
                    )
                    continue

                # Extract and rename variable
                # var_dataset = dataset[[provider_variable]].copy()
                var_dataset = self.create_output_dataset(dataset)
                data_array = dataset[provider_variable].rename(cdp_variable)
                variable_metadata = self.variables_metadata.get(cdp_variable, {})
                resolution = self.get_resolution(data_array)
                data_array = self.apply_variable_metadata(data_array, variable_metadata)

                data_array = self.reorganize_variable(data_array)
                var_dataset[cdp_variable] = data_array

                valid_time_bounds = self.construct_time_bounds(
                    dataset, data_array, variable_metadata
                )

                var_dataset = self.finalize_output_dataset(
                    var_dataset, cdp_variable, dataset, valid_time_bounds
                )

                # Define output path
                target_folder_path = Path(target_folder_path)
                target_folder_path.mkdir(parents=True, exist_ok=True)

                if split_by_ensemble_member and category == self.ENSEMBLE_CATEGORY:
                    grouped = var_dataset.groupby("realization")

                    # Iterate over each group and process or save them separately
                    for realization, ensemble_member_dataset in grouped:
                        realization = f"e{realization:03}"

                        out_filename_path = self.construct_output_path(
                            filename_path_template,
                            cdp_variable,
                            resolution,
                            realization,
                        )
                        file_write_path = target_folder_path / out_filename_path

                        self.write_netcdf_to_volume(ensemble_member_dataset, file_write_path)
                else:
                    self.process_single_file(
                        category,
                        var_dataset,
                        filename_path_template,
                        cdp_variable,
                        resolution,
                        target_folder_path,
                    )

            self.create_success_marker_file(input_file_path, target_folder_path, date_folders)

        except Exception as ex:
            # Wrapper for logging which source file caused the error
            raise RuntimeError(
                f"During '{input_file_path}' conversion following error occured:\n{ex}"
            ) from ex
