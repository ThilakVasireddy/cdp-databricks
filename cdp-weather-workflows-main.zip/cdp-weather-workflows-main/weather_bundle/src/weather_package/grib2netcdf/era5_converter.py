# Grib2NetCDFConverter: A tool for converting GRIB2 weather data to NetCDF format.

# This module provides functionality to:
# - Parse configuration files containing metadata, dataset mappings, and variable definitions.
# - Retrieve metadata for datasets and specific weather variables.
# - Apply CF-compliant data models to GRIB2 datasets.
# - Convert GRIB2 files into NetCDF format while preserving metadata and dimensions.

# Main Features:
# - Uses `cfgrib` and `xarray` for reading GRIB2 files.
# - Applies CF-compliant transformations via `cf2cdm`.
# - Dynamically loads metadata from TOML configuration files.
# - Supports renaming and adding metadata to variables in NetCDF output.

# Usage Example:
#     from grib2netcdf.converter import Grib2NetCDFConverter
#
#     converter = ERA5Grib2NetCDFConverter()
#
#     converter.convert(
#         input_file_path="input.grib2",
#         target_folder_path="output_folder".
#         category="single_hourly"
#     )
from pathlib import Path
import xarray as xr
import numpy as np
import tempfile
import shutil

import cf2cdm
import cf_xarray as cfxr  # Required import, though not used in code
from grib2netcdf.helpers import (
    parse_toml_config,
    parse_raw_dataset_meta,
    create_output_dataset,
    get_accumulation_start_stop,
)


class ERA5Grib2NetCDFConverter:
    """
    A converter for transforming GRIB2 weather data into NetCDF format.

    This class provides methods to parse configuration files, retrieve metadata,
    apply data models, and convert GRIB2 files to NetCDF format.
    """

    HOURLY = "hourly"
    MONTHLY = "monthly"
    SINGLE = "single"
    PRESSURE = "pressure"

    SINGLE_HOURLY_CATEGORY = f"{SINGLE}_{HOURLY}"
    SINGLE_MONTHLY_CATEGORY = f"{SINGLE}_{MONTHLY}"
    PRESSURE_HOURLY_CATEGORY = f"{PRESSURE}_{HOURLY}"
    PRESSURE_MONTHLY_CATEGORY = f"{PRESSURE}_{MONTHLY}"

    VALID_TIME_PLACEHOLDER = "<valid_time>"

    SUCCESS_FOLDER = "conversion_state"
    SUCCESS_FILE_PREFIX = "success"

    def __init__(self):
        """
        Initializes the converter with default values.
        """

        self.delete_pattern = "GRIB_"
        self.data_provider = "copernicus"
        self.product_family = "ERA5"

        # Get configuration from files
        self.datamodel, self.dataset_meta_raw, self.variables_metadata = (
            parse_toml_config(self.data_provider)
        )

    def apply_datamodel(self, dataset: xr.Dataset) -> xr.Dataset:
        """
        Applies the data model translation to a dataset.

        Args:
            dataset (xr.Dataset): The dataset to modify.

        Returns:
            xr.Dataset: The modified dataset.
        """
        return cf2cdm.translate_coords(dataset, self.datamodel)

    def apply_dataset_metadata(self, dataset: xr.Dataset) -> xr.Dataset:
        """
        Applies metadata to a dataset and expands necessary dimensions.

        Args:
            dataset (xr.Dataset): The dataset to modify.
        Returns:
            xr.Dataset: The modified dataset.
        """
        # Remove global GRIB attributes
        keys_to_remove = [
            key for key in dataset.attrs if key.startswith(self.delete_pattern)
        ]
        for key in keys_to_remove:
            del dataset.attrs[key]

        dataset.attrs.update(self.global_meta)

        if "number" in dataset.coords:
            dataset = dataset.drop_vars("number")
        if "realization" in dataset.coords:
            dataset = dataset.drop_vars("realization")

        dataset = dataset.cf.add_bounds(["latitude", "longitude"])
        return dataset

    def get_categories(self) -> list[str]:
        """
        Returns a list of all supported data categories.

        These categories typically describe temporal resolution (hourly/monthly)
        and vertical structure (single level or pressure level).

        Returns:
            list[str]: A list of category names defined as class constants.
        """
        return [
            self.SINGLE_HOURLY_CATEGORY,
            self.SINGLE_MONTHLY_CATEGORY,
            self.PRESSURE_HOURLY_CATEGORY,
            self.PRESSURE_MONTHLY_CATEGORY,
        ]

    def construct_output_path(
        self,
        input_file_path: str,
        cdp_variable: str,
        resolution: str,
        category: str,
    ) -> str:
        """
        Constructs an output file path by replacing template placeholders with actual values.

        Args:


        Returns:
            str: The constructed output file path.
        """
        product_short_name = self.global_meta["short_name"]

        date = input_file_path.split("/")[-1].split("_")[0]
        year = date[:4]
        month = date[4:6]
        filename = f"{product_short_name}_{resolution}_{cdp_variable}"
        if self.HOURLY in category:
            day = date[6:8]
            date_folders = f"{year}/{month}/{day}"
            filename = f"{filename}_{self.VALID_TIME_PLACEHOLDER}"
        elif self.MONTHLY in category:
            date_folders = f"{year}/{month}"
        else:
            raise ValueError(f"Invalid category provided: {category}")

        return f"{product_short_name}/{cdp_variable}/{date_folders}/{filename}.nc"

    def get_resolution(self, data_array: xr.DataArray) -> str:
        """
        Extracts the smallest resolution from dataset attributes and formats it.

        Args:
            dataset (xr.Dataset): An xarray dataset containing GRIB metadata.

        Returns:
            str: The resolution value in "XpY" format.
        """
        res = min(
            data_array.attrs["GRIB_iDirectionIncrementInDegrees"],
            data_array.attrs["GRIB_jDirectionIncrementInDegrees"],
        )
        resolution = f"{res:.2f}".replace(".", "p")

        return resolution

    def map_product_name(self, category: str) -> str:
        """
        Maps a category string to a standardized product name used in metadata lookup.

        Args:
            category (str): Category string such as 'single_hourly'.

        Returns:
            str: Product name like 'ERA5SH' or 'ERA5PM'.
        """
        product_name = (
            self.product_family + "".join([word[0] for word in category.split("_")])
        ).upper()
        return product_name

    def write_netcdf_to_volume(self, dataset: xr.Dataset, file_write_path: Path):
        """
        Writes an xarray dataset to a NetCDF file on a volume.

        Args:
            dataset (xr.Dataset): The dataset to be written.
            file_write_path (Path): The target file path for writing the NetCDF file.

        Notes:
            - `to_netcdf` cannot write directly to a volume, so a temporary file is used.
            - Ensures that the target directory exists before copying the file.
        """
        # Write to NetCDF file
        # to_netcdf cannot write straight to a volume
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_file_path = f"{tmpdir}/{file_write_path.name}"
            dataset.to_netcdf(
                tmp_file_path, unlimited_dims="valid_time", format="NETCDF4"
            )

            # Ensure the target directory exists
            file_write_path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy(tmp_file_path, file_write_path)

    def apply_variable_metadata(
        self,
        data_array: xr.DataArray,
        variable_meta_dict: dict,
    ) -> xr.DataArray:
        """
        Applies metadata to a variable by removing unwanted attributes and adding new metadata.

        Args:
            data_array (xr.DataArray): The data variable to modify.
            variable_meta_dict (dict): Metadata dictionary specific to the variable.

        Returns:
            xr.DataArray: The updated data variable with applied metadata.
        """
        keys_to_remove = [
            key for key in data_array.attrs if key.startswith(self.delete_pattern)
        ]
        for key in keys_to_remove:
            del data_array.attrs[key]
        data_array.attrs.update(variable_meta_dict)
        return data_array

    def reorganize_variable(self, data_array: xr.DataArray) -> xr.DataArray:
        """
        Reorders the dimensions of a variable to ensure a standard structure.

        Args:
            data_array (xr.DataArray): The data variable to reorganize.

        Returns:
            xr.DataArray: The data variable with reordered dimensions.
        """
        # Determine the correct level dimension
        level_dim = next(
            filter(lambda x: x in data_array.dims, ["level", "pressure_level"]),
            None,
        )

        # Define the expected order dynamically
        expected_order = [
            "valid_time",
            level_dim,
            "latitude",
            "longitude",
        ]

        # Remove None values (if no level-like dimension exists)
        expected_order = [dim for dim in expected_order if dim is not None]

        # Apply transpose dynamically
        data_array = data_array.transpose(*expected_order, missing_dims="warn")

        return data_array

    def construct_time_bounds(
        self,
        dataset: xr.Dataset,
        data_array: xr.DataArray,
        variable_meta_dict: dict,
    ) -> xr.DataArray:
        """
        Constructs time bounds for accumulated or mean variables based on metadata.

        Args:
            dataset (xr.Dataset): The full dataset containing metadata.
            data_array (xr.DataArray): The variable for which time bounds are created.
            variable_meta_dict (dict): Metadata dictionary defining accumulation periods.

        Returns:
            xr.DataArray: A time bounds array for the variable.
        """
        start, stop = get_accumulation_start_stop(data_array, variable_meta_dict)

        if start == "forecast_reference_time" and stop == "valid_time":
            time_bounds = np.array(
                [
                    [
                        data_array.forecast_reference_time.values[0],
                        data_array.valid_time.values[0],
                    ]
                ]
            )
        elif start == "valid_time_minus_one_hour" and stop == "valid_time":
            time_bounds = np.array(
                [
                    [
                        data_array.valid_time.values[0] - np.timedelta64(1, "h"),
                        data_array.valid_time.values[0],
                    ]
                ]
            )
        else:
            return xr.DataArray(np.array([]))

        bounds_da = xr.DataArray(
            data=time_bounds, coords=[data_array.valid_time, dataset.bounds]
        )
        return bounds_da

    def finalize_output_dataset(
        self,
        out_dataset: xr.Dataset,
        dataset: xr.Dataset,
        valid_time_bounds: xr.DataArray,
    ) -> xr.Dataset:
        """
        Finalizes the dataset by adding spatial and temporal bounds.

        Args:
            out_dataset (xr.Dataset): The output dataset being processed.
            dataset (xr.Dataset): The original dataset containing metadata.
            valid_time_bounds (xr.DataArray): The computed time bounds.

        Returns:
            xr.Dataset: The finalized dataset with bounds and metadata applied.
        """
        out_dataset["latitude_bounds"] = dataset["latitude_bounds"]
        out_dataset["longitude_bounds"] = dataset["longitude_bounds"]

        if valid_time_bounds.size != 0:
            out_dataset["valid_time_bounds"] = valid_time_bounds

        values = out_dataset["forecast_reference_time"].values

        if np.size(values) != 1:
            raise ValueError(
                "Expected a single forecast_reference_time value, but found multiple."
            )

        out_dataset.attrs["forecast_reference_time"] = np.datetime_as_string(
            values[0], unit="s"
        )

        return out_dataset

    def open_dataset(self, input_file_path: str) -> xr.Dataset:
        """
        Opens a GRIB2 dataset using xarray.

        Args:
            input_file_path (str): The path to the GRIB2 file.

        Returns:
            xr.Dataset: The loaded dataset.
        """
        # If you're only reading the file once and never reopening it,
        # then you don't need the .idx file. It's safe to set: backend_kwargs={"indexpath": ""}
        dataset = xr.open_dataset(
            input_file_path, engine="cfgrib", backend_kwargs={"indexpath": ""}
        )
        return dataset

    def get_valid_time_str(self, sub_ds: xr.Dataset | xr.DataArray) -> str:
        """
        Extracts and formats the 'valid_time' coordinate from a DataArray or Dataset.

        The timestamp is converted to hour-level precision and formatted as a string
        in 'YYYYMMDDHH' format (e.g., '2025050612').

        Args:
            sub_ds (xarray.Dataset or xarray.DataArray):
                The input containing a 'valid_time' coordinate.

        Returns:
            str: A formatted string representing the valid time.
        """
        valid_time_val = sub_ds.valid_time.values.item()
        formatted_time = (
            str(np.datetime64(valid_time_val, "ns").astype("datetime64[h]"))
            .replace("-", "")
            .replace("T", "")
        )
        return formatted_time

    def promote_valid_time_independent(self, da: xr.DataArray) -> xr.DataArray:
        """
        Promote 'valid_time' to an independent dimension in a DataArray.

        Handles two cases:
        - If valid_time is 2D (e.g. [forecast_reference_time x leadtime]),
        the data is flattened and mapped to a new 'valid_time' dimension.
        - If valid_time is 1D (e.g. [forecast_reference_time]), it is renamed
        and promoted directly as the new dimension.

        Parameters:
            da (xarray.DataArray): Input DataArray with 'valid_time' coordinate.

        Returns:
            xarray.DataArray: New DataArray with 'valid_time' as its own dimension.
        """
        if "valid_time" not in da.coords:
            raise ValueError("'valid_time' coordinate is required but missing.")

        valid_time_shape = da.valid_time.shape

        if len(valid_time_shape) == 2:
            # 2D valid_time: (forecast_reference_time, leadtime)
            # Stack over both time-related axes
            da_stacked = da.stack(vt_index=("forecast_reference_time", "leadtime"))
            valid_time_flat = da.valid_time.values.ravel()

            # Assign and promote
            da_stacked = da_stacked.assign_coords(
                valid_time=("vt_index", valid_time_flat)
            )
            da_promoted = da_stacked.swap_dims({"vt_index": "valid_time"}).drop_vars(
                "vt_index"
            )

        elif len(valid_time_shape) == 1:
            # 1D valid_time: (forecast_reference_time,)
            da = da.assign_coords(
                valid_time=("forecast_reference_time", da.valid_time.values)
            )
            da_promoted = da.swap_dims({"forecast_reference_time": "valid_time"})

        else:
            raise ValueError(f"Unexpected 'valid_time' shape: {valid_time_shape}")

        return da_promoted

    def normalize_forecast_times(self, dataset: xr.Dataset) -> xr.Dataset:
        """
        Adjusts the dataset's forecast reference time and lead time to conform to
        operational constraints where forecast_reference_time must align to 06:00 or 18:00 UTC.

        This method:
        - Snaps the existing valid_time to the most recent allowed forecast_reference_time
        - Recalculates leadtime as valid_time - forecast_reference_time
        - Updates the dataset's forecast_reference_time, leadtime, and valid_time coordinates
        - Stores the forecast_reference_time also in dataset attributes

        Parameters:
            dataset (xr.Dataset): The input dataset with scalar valid_time coordinate.

        Returns:
            xr.Dataset: The updated dataset with standardized time fields.
        """

        def snap_to_forecast_hour_np(valid_time: np.datetime64) -> np.datetime64:
            """
            Snap valid_time down to the nearest allowed forecast_reference_time (06:00 or 18:00 UTC)
            using only NumPy.
            """
            vt = valid_time.astype("datetime64[h]")
            hour = int(str(vt).split("T")[1].split(":")[0])
            base_date = vt.astype("datetime64[D]")

            if hour >= 18:
                frt = base_date + np.timedelta64(18, "h")
            elif hour >= 6:
                frt = base_date + np.timedelta64(6, "h")
            else:
                frt = base_date - np.timedelta64(1, "D") + np.timedelta64(18, "h")

            return frt

        vt: np.datetime64 = dataset.valid_time.values[0]
        new_frt: np.datetime64 = snap_to_forecast_hour_np(vt)
        new_leadtime: np.timedelta64 = vt - new_frt
        new_valid_time: np.datetime64 = new_frt + new_leadtime

        # Update coordinates
        dataset["forecast_reference_time"] = new_frt
        dataset["leadtime"] = new_leadtime
        dataset["valid_time"] = ("valid_time", [new_valid_time])

        # Optional: store for metadata traceability
        dataset.attrs["forecast_reference_time"] = np.datetime_as_string(
            new_frt, unit="s"
        )

        return dataset

    def convert(
        self,
        input_file_path: str,
        target_folder_path: str,
        category: str,
    ):
        """
        Converts a GRIB2 file to NetCDF format.

        Args:
            input_file_path (str): The path to the input GRIB2 file.
            target_folder_path (str): The directory to save the NetCDF files.
            category (str): The category of the data, e.g., "single_hourly", "single_monthly", ...
        Raises:
            ValueError: If the converter is not properly configured.
        """
        try:
            dataset = self.open_dataset(input_file_path)

            dataset = self.apply_datamodel(dataset)

            product = self.map_product_name(category)

            dataset_meta = parse_raw_dataset_meta(
                self.dataset_meta_raw, self.product_family, product
            )

            self.global_meta = (
                dataset_meta["provider_meta"] | dataset_meta["products_meta"]
            )

            dataset = self.apply_dataset_metadata(dataset)

            if len(dataset.data_vars) != 1:
                raise ValueError(
                    f"Expected only one variable in the source dataset. "
                    f"Found {len(dataset.data_vars)} variables: {dataset.data_vars}"
                )
            provider_variable = list(dataset.data_vars)[0]

            var_dataset = dataset[[provider_variable]].copy()
            var_dataset = create_output_dataset(dataset)

            cdp_variable = dataset_meta["variable_mapping"][provider_variable]
            data_array = dataset[provider_variable].rename(cdp_variable)
            variable_metadata = self.variables_metadata.get(cdp_variable, {})
            resolution = self.get_resolution(data_array)
            data_array = self.apply_variable_metadata(data_array, variable_metadata)

            data_array = self.promote_valid_time_independent(data_array)

            data_array = self.reorganize_variable(data_array)

            var_dataset[cdp_variable] = data_array

            target_folder_path = Path(target_folder_path)

            output_path = self.construct_output_path(
                input_file_path, cdp_variable, resolution, category
            )

            if self.HOURLY in category:
                for i in range(var_dataset.sizes["valid_time"]):
                    hourly_dataset = var_dataset.isel(valid_time=slice(i, i + 1))
                    valid_time = self.get_valid_time_str(hourly_dataset)
                    hourly_output_path = output_path.replace(
                        self.VALID_TIME_PLACEHOLDER, valid_time
                    )
                    file_write_path = target_folder_path / hourly_output_path
                    # filter out files with wrong valid time
                    date = input_file_path.split("/")[-1].split("_")[0]
                    if date == valid_time[:-2]:
                        valid_time_bounds = self.construct_time_bounds(
                            dataset, hourly_dataset[cdp_variable], variable_metadata
                        )
                        hourly_dataset = self.finalize_output_dataset(
                            hourly_dataset, dataset, valid_time_bounds
                        )

                        hourly_dataset = self.normalize_forecast_times(hourly_dataset)

                        self.write_netcdf_to_volume(hourly_dataset, file_write_path)

            else:
                file_write_path = target_folder_path / output_path
                self.write_netcdf_to_volume(var_dataset, file_write_path)

        except Exception as ex:
            # Wrapper for logging which source file caused the error
            raise RuntimeError(
                f"During '{input_file_path}' conversion following error occured:\n{ex}"
            )
