import xarray as xr
import tomllib
from importlib import resources


def parse_raw_dataset_meta(
    raw_dataset_meta: dict, product_family: str, product: str
) -> dict:
    """
    Parses the dataset metadata for a specific product family and product.

    This function processes a nested metadata dictionary structure and merges base metadata
    with overrides from a given product family and product. Each top-level metadata section
    is processed individually.

    Args:
        raw_dataset_meta (dict): The raw dataset metadata containing nested dictionaries
            for different metadata sections and override levels.
        product_family (str): The product family name (e.g. "ERA5").
        product (str): The specific product name (e.g. "ERA5SH").

    Returns:
        dict: A dictionary containing parsed metadata for each top-level metadata section,
            with overrides applied from the product family and product if available.
    """
    META_KEYS = ["provider_meta", "products_meta", "variable_mapping"]

    parsed_dataset_meta = {}
    for meta_key in META_KEYS:
        meta_dict = raw_dataset_meta.get(meta_key, {})
        result = {
            key: val for key, val in meta_dict.items() if not isinstance(val, dict)
        }

        # Merge in product_family-level overrides if present
        pf_meta_dict = meta_dict.get(product_family, {})
        pf_result = {
            key: val for key, val in pf_meta_dict.items() if not isinstance(val, dict)
        }
        result.update(pf_result)

        # Merge in product-level overrides if present
        product_meta_dict = pf_meta_dict.get(product, {})
        result.update(product_meta_dict)

        parsed_dataset_meta[meta_key] = result

    return parsed_dataset_meta


def parse_toml_config(data_provider):
    """
    Parses TOML configuration files related to a given data provider.

    It loads the datamodel, dataset metadata, and variable metadata by reading from a
    structured set of TOML files located in a predefined config folder.

    Args:
        data_provider (str): The name of the data provider. Used to locate provider-specific
            configuration files within the config folder.

    Returns:
        tuple: A tuple containing:
            - dict: The datamodel definition.
            - dict: The raw dataset metadata.
            - dict: Combined global and provider-specific variable metadata.
    """
    CONFIG_FOLDER = "grib2netcdf.config"
    DATAMODEL_NAME = "datamodels.toml"
    DATASET_NAME = "datasets.toml"
    VARIABLES_FILE_NAME = "variables.toml"

    def parse_toml_file(file_name: str) -> dict:
        """
        Parses a TOML file and returns its contents as a dictionary.

        Args:
            file_name (str): The relative path to the TOML file within the config folder.

        Returns:
            dict: Parsed content of the TOML file.
        """
        with resources.files(CONFIG_FOLDER).joinpath(file_name).open("rb") as file:
            parsed_file = tomllib.load(file)

        return parsed_file

    def get_metadata() -> dict:
        """
        Retrieves the raw dataset metadata for the specified data provider.

        Returns:
            dict: Dataset metadata parsed from the provider-specific TOML file.
        """
        raw_dataset_meta = parse_toml_file(f"{data_provider}/{DATASET_NAME}")

        return raw_dataset_meta

    def get_variables_metadata() -> dict:
        """
        Combines global and provider-specific variable metadata.

        Returns:
            dict: Merged variable metadata dictionary.
        """
        variables_meta = parse_toml_file(VARIABLES_FILE_NAME)["variables"]
        try:
            provider_vars_meta = parse_toml_file(
                f"{data_provider}/{VARIABLES_FILE_NAME}"
            ).get("variables", {})
        except FileNotFoundError:
            provider_vars_meta = {}
        variables_meta.update(provider_vars_meta)

        return variables_meta

    def get_datamodel() -> dict:
        """
        Loads the datamodel configuration from the TOML file.

        Returns:
            dict: Datamodel definition parsed from the TOML file.
        """
        return parse_toml_file(DATAMODEL_NAME)

    datamodel = get_datamodel()
    raw_dataset_meta = get_metadata()
    variables_metadata = get_variables_metadata()

    return datamodel, raw_dataset_meta, variables_metadata


def create_output_dataset(dataset: xr.Dataset) -> xr.Dataset:
    """
    Creates an empty output dataset with metadata copied from the input dataset.

    Args:
        dataset (xr.Dataset): The input dataset containing metadata.

    Returns:
        xr.Dataset: A new dataset with copied metadata but no variables.
    """
    out_dataset = xr.Dataset()
    out_dataset.attrs.update(dataset.attrs)
    return out_dataset


def parse_cell_methods(variable_meta_dict: dict) -> dict:
    """
    Parses the 'cell_methods' string from variable metadata into a dictionary.

    Args:
        variable_meta_dict (dict): Metadata dictionary containing 'cell_methods'.

    Returns:
        dict: Parsed cell methods as a dictionary.
    """
    cell_methods_string = variable_meta_dict["cell_methods"]
    parts = cell_methods_string.split()
    result = {}
    for i in range(0, len(parts), 2):
        key = parts[i].strip(":")
        value = parts[i + 1]
        result[key] = value
    return result


def get_accumulation_start_stop(
    data_array: xr.DataArray, variable_meta_dict: dict
) -> tuple[str | None, str | None]:
    """
    Determines the start and stop times for accumulated or mean variables.

    Args:
        data_array (xr.DataArray): The data variable containing time-related attributes.
        variable_meta_dict (dict): Metadata dictionary defining processing type.

    Returns:
        tuple[str | None, str | None]: The start and stop time attributes, if applicable.
    """
    processing = variable_meta_dict.get("processing", "point")
    cell_methods = parse_cell_methods(variable_meta_dict)
    time_cell_method = cell_methods["time"]
    if processing == "accumulated" or time_cell_method not in ["point", "mean"]:
        start = data_array.attrs["accumulation_period_start"]
        stop = data_array.attrs["accumulation_period_stop"]
    else:
        start = stop = None
    return start, stop
