# install system dependencies on the cluster
sudo apt-get update && apt-get install -y gdal-bin libeccodes-dev libnetcdf-dev libhdf5-dev

# install required python libraries 
pip install numpy==1.24.4 eccodes==1.7.1 xarray==2024.9.0 cf_xarray==0.10.0 cfgrib==0.9.14.1 netcdf4==1.7.2

pip install --no-cache-dir --force-reinstall cfgrib==0.9.14.1 numpy==1.24.4

sudo apt-get install -y libudunits2-dev

pip install cfunits==3.3.7