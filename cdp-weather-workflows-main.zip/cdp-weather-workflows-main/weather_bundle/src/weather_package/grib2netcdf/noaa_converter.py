# Grib2NetCDFConverter: A tool for converting GRIB2 weather data to NetCDF format.

# This module provides functionality to:
# - Parse configuration files containing metadata, dataset mappings, and variable definitions.
# - Retrieve metadata for datasets and specific weather variables.
# - Apply CF-compliant data models to GRIB2 datasets.
# - Convert GRIB2 files into NetCDF format while preserving metadata and dimensions.

# Main Features:
# - Uses `cfgrib` and `xarray` for reading GRIB2 files.
# - Applies CF-compliant transformations via `cf2cdm`.
# - Dynamically loads metadata from TOML configuration files.
# - Supports renaming and adding metadata to variables in NetCDF output.

# Usage Example:
#     from grib2netcdf.converter import Grib2NetCDFConverter
#
#     converter = NOAAGrib2NetCDFConverter()
#
#     converter.convert(
#         input_file_path="input.grib2",
#         target_folder_path="output_folder"
#     )
from pathlib import Path
import xarray as xr
import numpy as np
import tempfile
import shutil
import re

from cfunits import Units
import cf2cdm
import cf_xarray as cfxr  # Required import, though not used in code
from grib2netcdf.helpers import (
    parse_toml_config,
    parse_raw_dataset_meta,
    create_output_dataset,
    get_accumulation_start_stop,
)


class NOAAGrib2NetCDFConverter:
    """
    A converter for transforming GRIB2 weather data into NetCDF format.

    This class provides methods to parse configuration files, retrieve metadata,
    apply data models, and convert GRIB2 files to NetCDF format.
    """

    VALID_TIME_PLACEHOLDER = "<valid_time>"

    def __init__(self, product_family: str):
        """
        Initializes the converter with the specified product family.

        Args:
            product_family (str): The name of the NOAA product family (e.g., "GFS", "GEFS").

        Raises:
            ValueError: If the product family is not supported.
        """

        self.delete_pattern = "GRIB_"
        self.data_provider = "noaa"
        self.product_family = product_family

        # Get configuration from files
        self.datamodel, self.dataset_meta_raw, self.variables_metadata = (
            parse_toml_config(self.data_provider)
        )

    def apply_datamodel(self, dataset: xr.Dataset) -> xr.Dataset:
        """
        Applies the CF-compliant data model translation to a dataset.

        Args:
            dataset (xr.Dataset): The input xarray dataset.

        Returns:
            xr.Dataset: A dataset with coordinate conventions translated to CF standards.
        """
        return cf2cdm.translate_coords(dataset, self.datamodel)

    def apply_dataset_metadata(self, dataset: xr.Dataset) -> xr.Dataset:
        """
        Cleans up GRIB-specific attributes and applies global metadata to the dataset.

        Also adds bounds to latitude and longitude coordinates.

        Args:
            dataset (xr.Dataset): The xarray dataset to modify.

        Returns:
            xr.Dataset: The updated dataset with metadata and dimension expansions.
        """
        # 1. Remove global GRIB attributes
        keys_to_remove = [
            key for key in dataset.attrs if key.startswith(self.delete_pattern)
        ]
        for key in keys_to_remove:
            del dataset.attrs[key]

        dataset.attrs.update(self.global_meta)

        dataset = dataset.cf.add_bounds(["latitude", "longitude"])

        return dataset

    def format_datetime64_to_compact(
        self, dt64: np.datetime64 | np.ndarray, add_z: bool = True
    ) -> str | list[str]:
        """
        Formats a datetime64 or array of datetime64 into 'YYYYMMDDHH' or 'YYYYMMDDHHZ'.

        Args:
            dt64 (numpy.datetime64 or np.ndarray): Date/time to format.
            add_z (bool): Whether to append 'Z' for UTC indicator.

        Returns:
            str or list[str]: Formatted date string(s).
        """

        def format_single(dt):
            s = np.datetime_as_string(dt, unit="h")
            compact = s.replace("-", "").replace("T", "")
            return compact + "z" if add_z else compact

        if isinstance(dt64, np.ndarray):
            return [format_single(dt) for dt in dt64]
        else:
            return format_single(dt64)

    def construct_output_path(
        self,
        input_file_path: str,
        cdp_variable: str,
        data_array: xr.DataArray,
        product: str,
    ) -> str:
        """
        Generates an output NetCDF file path using metadata and input file naming conventions.

        Args:
            input_file_path (str): Path to the input GRIB2 file.
            cdp_variable (str): The standardized variable name for the NetCDF output.
            data_array (xr.DataArray): Data array containing time metadata.
            product (str): Product name e.g. gfs, geavg, gecXX, gepXX
        Returns:
            str: Constructed relative file path for the NetCDF output.
        """
        ens_member_placeholder = "<ens_member_placeholder>"

        forecast_reference_time = self.format_datetime64_to_compact(
            data_array["forecast_reference_time"].values
        )
        valid_time = self.format_datetime64_to_compact(data_array["valid_time"].values)

        product_short_name = self.global_meta["short_name"]

        date_folders = "/".join(input_file_path.split("/")[-5:-1])

        _, _, _, resolution, lead_time = input_file_path.split("/")[-1].split(".")
        lead_time = lead_time.replace("f", "h")

        filename = (
            f"{product_short_name}_{resolution}_{cdp_variable}_{ens_member_placeholder}_"
            + f"{forecast_reference_time}_{valid_time}_{lead_time}"
        )

        if product not in ["geavg", "gfs"]:
            realization = data_array["realization"].values
            realization = f"e{realization:03}"
            filename = filename.replace(ens_member_placeholder, realization)
        else:
            filename = filename.replace(f"{ens_member_placeholder}_", "")

        return f"{product_short_name}/{cdp_variable}/{date_folders}/{filename}.nc"

    def map_product_name(self, file_path: str) -> str:
        """
        Extracts and formats the product name from the file name.

        Args:
            file_path (str): The input GRIB2 file path.

        Returns:
            str: Uppercased product name string.
        """
        product_name = file_path.split("/")[-1].split(".")[0]
        product_name = re.sub(r"\d{1,2}$", "", product_name)

        return product_name

    def write_netcdf_to_volume(
        self, dataset: xr.Dataset, file_write_path: Path, n_write_retries: int = 3
    ):
        """
        Writes an xarray dataset to a NetCDF file on a volume.

        Args:
            dataset (xr.Dataset): The dataset to be written.
            file_write_path (Path): The target file path for writing the NetCDF file.
            n_write_retries (int): number of retries for writing to volume

        Notes:
            - `to_netcdf` cannot write directly to a volume, so a temporary file is used.
            - Ensures that the target directory exists before copying the file.
        """
        # Write to NetCDF file
        # to_netcdf cannot write straight to a volume
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_file_path = f"{tmpdir}/{file_write_path.name}"
            dataset.to_netcdf(
                tmp_file_path, unlimited_dims="valid_time", format="NETCDF4"
            )

            # Ensure the target directory exists
            file_write_path.parent.mkdir(parents=True, exist_ok=True)

            exception_list = []
            for i in range(n_write_retries):
                try:
                    shutil.copy(tmp_file_path, file_write_path)
                    break  # Success
                except FileNotFoundError as ex:
                    exception_list.append(FileNotFoundError)
                    if i == n_write_retries - 1:
                        raise FileNotFoundError(
                            f"[Reached max retires {i + 1}/{n_write_retries}] {ex}\n"
                            f"Temp file: {tmp_file_path} exists? {Path(tmp_file_path).exists()}\n"
                            f"Target directory: {file_write_path.parent} exists?"
                            f"{file_write_path.parent.exists()}\n"
                            f"Target file path: {file_write_path}\n"
                            f"List of exceptions that occured: {exception_list}"
                        )
                    else:
                        print(
                            f"[Retry {i + 1}/{n_write_retries}] "
                            f"FileNotFoundError during shutil.copy(): {ex}"
                        )
                except OSError as ex:
                    exception_list.append(OSError)
                    if i == n_write_retries - 1:
                        raise OSError(
                            f"[Reached max retires {i + 1}/{n_write_retries}] {ex}\n"
                            f"Temp file: {tmp_file_path} exists? {Path(tmp_file_path).exists()}\n"
                            f"Target directory: {file_write_path.parent} exists?"
                            f"{file_write_path.parent.exists()}\n"
                            f"Target file path: {file_write_path}\n"
                            f"List of exceptions that occured: {exception_list}"
                        )
                    else:
                        print(
                            f"[Retry {i + 1}/{n_write_retries}] OSError during shutil.copy(): {ex}"
                        )

    def apply_variable_metadata(
        self,
        data_array: xr.DataArray,
        variable_meta_dict: dict,
    ) -> xr.DataArray:
        """
        Applies metadata to a variable by removing unwanted GRIB attributes
        and adding new metadata.

        Args:
            data_array (xr.DataArray): The data variable to modify.
            variable_meta_dict (dict): Metadata dictionary specific to the variable.

        Returns:
            xr.DataArray: The updated data variable with applied metadata.
        """
        keys_to_remove = [
            key for key in data_array.attrs if key.startswith(self.delete_pattern)
        ]
        for key in keys_to_remove:
            del data_array.attrs[key]
        data_array.attrs.update(variable_meta_dict)
        return data_array

    def construct_time_bounds(
        self,
        dataset: xr.Dataset,
        data_array: xr.DataArray,
        variable_meta_dict: dict,
        input_file_path: str,
    ) -> xr.DataArray:
        """
        Constructs time bounds for accumulated or mean variables based on metadata.

        Args:
            dataset (xr.Dataset): The full dataset containing metadata.
            data_array (xr.DataArray): The variable for which time bounds are created.
            variable_meta_dict (dict): Metadata dictionary defining accumulation periods.

        Returns:
            xr.DataArray: A time bounds array for the variable.
        """
        start, stop = get_accumulation_start_stop(data_array, variable_meta_dict)

        if start == "forecast_reference_time" and stop == "valid_time":
            time_bounds = np.array(
                [
                    [
                        data_array.forecast_reference_time.values,
                        data_array.valid_time.values,
                    ]
                ]
            )
        elif start == "valid_time_minus_mod_six" and stop == "valid_time":
            forecast_hour = int(input_file_path.split("/")[-1].split(".")[-1][1:])
            offset_from_previous_6hr = forecast_hour % 6

            time_bounds = np.array(
                [
                    [
                        data_array.valid_time.values
                        - np.timedelta64(offset_from_previous_6hr, "h"),
                        data_array.valid_time.values,
                    ]
                ]
            )
        else:
            return xr.DataArray(np.array([]))

        bounds_da = xr.DataArray(
            data=time_bounds,
            coords={
                "time": np.array([data_array.valid_time.values]),
                "bounds": dataset.bounds.values,
            },
            dims=["time", "bounds"],
        )

        return bounds_da

    def finalize_output_dataset(
        self,
        out_dataset: xr.Dataset,
        dataset: xr.Dataset,
        valid_time_bounds: xr.DataArray,
    ) -> xr.Dataset:
        """
        Finalizes the dataset by adding spatial and temporal bounds.

        Args:
            out_dataset (xr.Dataset): The output dataset being processed.
            dataset (xr.Dataset): The original dataset containing metadata.
            valid_time_bounds (xr.DataArray): The computed time bounds.

        Returns:
            xr.Dataset: The finalized dataset with bounds and metadata applied.
        """
        out_dataset["latitude_bounds"] = dataset["latitude_bounds"]
        out_dataset["longitude_bounds"] = dataset["longitude_bounds"]

        if valid_time_bounds.size != 0:
            out_dataset["valid_time_bounds"] = valid_time_bounds

        forecast_reference_time = out_dataset["forecast_reference_time"].values

        out_dataset.attrs["forecast_reference_time"] = np.datetime_as_string(
            forecast_reference_time, unit="s"
        )

        return out_dataset

    def conform_units_inplace_domain_specific(
        self, data_array: xr.DataArray, from_units: Units, to_units: Units
    ) -> None:
        """
        Conforms the data in-place from one unit to another using domain-specific
        knowledge where standard dimensional analysis does not apply.

        Supported conversions:
        - gpm → m (treated as equivalent)
        - kg m-2 → m (precipitation: 1 kg/m² = 1 mm = 0.001 m)

        Args:
            data_array (xr.DataArray): The data array to modify in-place.
            from_units (Units): The source units.
            to_units (Units): The target units.

        Raises:
            ValueError: If the conversion is not supported.
        """
        if str(from_units) == "gpm" and to_units.equals(Units("m")):
            # No change needed: gpm and m are equivalent for geopotential height
            pass
        elif from_units.equals(Units("kg m-2")) and to_units.equals(Units("m")):
            # Convert precipitation from kg/m² to m
            # Assumes 1 kg/m² = 1 mm = 0.001 m of water
            data_array.data = data_array.data / 1000
        else:
            raise ValueError(
                f"No domain-specific unit conforming logic defined for {from_units} → {to_units}"
            )

    def conform_units(self, data_array: xr.DataArray, from_unit: str) -> xr.DataArray:
        """
        Convert a DataArray from one unit to another using cfunits.

        Parameters:
            data_array (xarray.DataArray): The data to convert.
            from_unit (str): The current unit (must be CF-compliant).

        Returns:
            xarray.DataArray: Converted data_array if units differ, else original.
        """
        to_unit = data_array.attrs.get("units")
        if to_unit is None:
            raise ValueError("Target unit is not defined in data_array.attrs['units'].")

        from_units = Units(from_unit)
        to_units = Units(to_unit)

        if from_units.equals(to_units):
            return data_array  # No conversion needed

        try:
            converted_values = Units.conform(data_array.data, from_units, to_units)

            data_array.data = converted_values
        except ValueError:
            self.conform_units_inplace_domain_specific(data_array, from_units, to_units)

        return data_array

    def convert_valid_time_to_dimension(self, dataset: xr.Dataset) -> xr.Dataset:
        """
        Converts 'valid_time' from a scalar coordinate to a proper dimension in the dataset.

        This is useful for standardizing temporal alignment across variables and enabling
        concatenation along the 'valid_time' axis. If a legacy 'time' dimension is present,
        it will be removed. If 'valid_time_bounds' uses 'time' as a dimension, it will be
        reshaped to align with the new 'valid_time' dimension.

        Parameters:
            dataset (xr.Dataset): The input dataset with scalar 'valid_time' coordinate.

        Returns:
            xr.Dataset: A new dataset with 'valid_time' as a dimension.
        """
        dataset = dataset.expand_dims(valid_time=[dataset.valid_time.values])

        if "time" in dataset.dims:
            dataset = dataset.drop_vars("time")

            if "valid_time_bounds" in dataset:
                dataset["valid_time_bounds"] = dataset["valid_time_bounds"].isel(time=0)

        if "valid_time" in dataset["latitude_bounds"].dims:
            dataset["latitude_bounds"] = dataset["latitude_bounds"].isel(valid_time=0)

        if "valid_time" in dataset["longitude_bounds"].dims:
            dataset["longitude_bounds"] = dataset["longitude_bounds"].isel(valid_time=0)

        return dataset

    def convert_realization_to_dimension(self, dataset: xr.Dataset) -> xr.Dataset:
        """
        Converts 'realization' from a scalar coordinate to a proper dimension
        only for relevant data variables in the dataset, if it exists.

        Parameters:
            dataset (xr.Dataset): The input dataset with scalar 'realization' coordinate.

        Returns:
            xr.Dataset: A new dataset with 'realization' as a dimension where appropriate.
        """
        if "realization" in dataset.coords and "realization" not in dataset.dims:
            realization_value = dataset.realization.item()

            new_vars = {}
            # Only add 'realization' as a new dimension to main
            # forecast fields (3D over time and space)
            for name, var in dataset.data_vars.items():
                if {"valid_time", "latitude", "longitude"}.issubset(var.dims):
                    new_vars[name] = var.expand_dims(realization=[realization_value])
                else:
                    new_vars[name] = var

            new_coords = {k: v for k, v in dataset.coords.items() if k != "realization"}
            new_coords["realization"] = ("realization", [realization_value])

            dataset = xr.Dataset(data_vars=new_vars, coords=new_coords)

        return dataset

    def open_dataset(self, input_file_path: str, short_name: str) -> xr.Dataset:
        """
        Opens and filters a GRIB2 dataset using cfgrib engine and variable short name.
        Args:
            input_file_path (str): Path to the GRIB2 input file.
            short_name (str): Variable short name to extract.

        Returns:
            xr.Dataset: The filtered xarray dataset.
        """
        # If you're only reading the file once and never reopening it,
        # then you don't need the .idx file. It's safe to set: backend_kwargs={"indexpath": ""}
        if short_name == "tcc":
            filter_by_keys = {"shortName": short_name, 'stepType': 'avg'}
        else:
            filter_by_keys = {"shortName": short_name}

        dataset = xr.open_dataset(
            input_file_path,
            engine="cfgrib",
            backend_kwargs={
                "indexpath": "",
                "filter_by_keys": filter_by_keys,
            },
        )

        return dataset

    def convert(
        self,
        input_file_path: str,
        target_folder_path: str,
        short_names: list[str],
    ):
        """
        Performs full GRIB2 to NetCDF conversion for selected variables.

        Args:
            input_file_path (str): Path to the source GRIB2 file.
            target_folder_path (str): Directory for output NetCDF files.
            short_names (list[str]): Short names of the variables to convert.

        Raises:
            Exception: Wraps errors with input file information.
        """
        try:
            for short_name in short_names:
                dataset = self.open_dataset(input_file_path, short_name)
                if not dataset:
                    # skip if there is no data for provided short_name
                    continue

                data_vars = list(dataset.data_vars)
                if len(data_vars) == 1:
                    provider_variable = data_vars[0]
                else:
                    raise ValueError(
                        f"Expected only one variable in the dataset. Found: {data_vars}"
                    )

                original_unit = dataset[provider_variable].attrs["units"]

                dataset = self.apply_datamodel(dataset)

                product = self.map_product_name(input_file_path)

                dataset_meta = parse_raw_dataset_meta(
                    self.dataset_meta_raw, self.product_family, product
                )

                self.global_meta = (
                    dataset_meta["provider_meta"] | dataset_meta["products_meta"]
                )

                dataset = self.apply_dataset_metadata(dataset)

                try:
                    var_dataset = dataset[[provider_variable]].copy()
                except Exception as ex:
                    raise ValueError(
                        f"{ex}\nVariable not found in dataset: " + provider_variable
                    )
                var_dataset = create_output_dataset(dataset)

                cdp_variable = dataset_meta["variable_mapping"].get(
                    provider_variable, provider_variable
                )

                data_array = dataset[provider_variable].rename(cdp_variable)
                variable_metadata = self.variables_metadata.get(cdp_variable, {})

                data_array = self.apply_variable_metadata(data_array, variable_metadata)

                self.conform_units(data_array, original_unit)

                var_dataset[cdp_variable] = data_array

                var_dataset["latitude_bounds"] = dataset["latitude_bounds"]
                var_dataset["longitude_bounds"] = dataset["longitude_bounds"]

                target_folder_path = Path(target_folder_path)

                output_path = self.construct_output_path(
                    input_file_path, cdp_variable, data_array, product
                )

                file_write_path = target_folder_path / output_path

                valid_time_bounds = self.construct_time_bounds(
                    dataset,
                    var_dataset[cdp_variable],
                    variable_metadata,
                    input_file_path,
                )
                var_dataset = self.finalize_output_dataset(
                    var_dataset, dataset, valid_time_bounds
                )

                var_dataset = self.convert_valid_time_to_dimension(var_dataset)
                var_dataset = self.convert_realization_to_dimension(var_dataset)

                self.write_netcdf_to_volume(var_dataset, file_write_path)

        except Exception as ex:
            # Wrapper for logging which source file caused the error
            raise RuntimeError(
                f"{type(ex).__name__} - During '{input_file_path}' "
                f"conversion following error occured:\n{ex}"
            )
