from datetime import datetime, timezone
import os

from pyspark.sql import DataFrame
from pyspark.sql.types import StringType
from pyspark.sql.functions import (
    udf,
    concat_ws,
    lit,
    col,
    create_map,
    format_string,
    regexp_extract,
    split,
)

METRIC_TYPE_SOURCE = "source"
METRIC_TYPE_DELIVERY = "delivery"
ENS_PLACEHOLDER = "<ENSEMBLE_PLACEHOLDER>"
METRICS_FOLDER = "metrics"

ENSEMBLE_CATEGORY = "GFSens"
OPERATIONAL_CATEGORY = "GFSops"


def format_http_date(dt: "datetime|None") -> "str|None":
    """
    Converts a datetime object to HTTP-date format: 'Tue, 18 Jun 2024 05:16:11 GMT'.
    Returns None if input is None.

    Args:
        dt (datetime | None): The datetime object to format.

    Returns:
        str | None: The formatted HTTP-date string or None if input is None.
    """
    if dt is None:
        return None
    dt_utc = dt.astimezone(timezone.utc)
    return dt_utc.strftime("%a, %d %b %Y %H:%M:%S GMT")


def generate_new_file_name(file_path: str | None) -> str | None:
    """
    Converts a GRIB file path into a standardized file name format.
    Example:
      Input: '/.../2025/06/16/00/gep12.t00z.pgrb2a.0p50.f384'
      Output: 'gep12.t2025061600z.pgrbf384.grib2.global'

    Args:
        file_path (str | None): The file path to convert.

    Returns:
        str | None: The standardized file name or None if input is None.
    """
    if file_path is None:
        return None

    parts = file_path.strip().split("/")
    file_name = parts[-1]

    year, month, day, run = parts[-5:-1]
    forecast_datetime = f"{year}{month}{day}{run}"

    lead_time = [
        s for s in file_name.split(".") if s.startswith("f") and s[1:].isdigit()
    ]
    if not lead_time:
        raise ValueError(f"Cannot extract lead time from: {file_name}")
    lead_time = lead_time[0]

    prefix = file_name.split(".t")[0]

    if prefix == "geavg":
        prefix = "gefsavg"
    elif len(prefix) == 5 and prefix[-2:].isdigit():
        prefix = "gefs" + prefix[-2:]
    elif prefix != "gfs":
        raise ValueError(f"Unhandled prefix {prefix} in file name {file_name}")

    return f"{prefix}.t{forecast_datetime}z.pgrb{lead_time}.grib2.global"


def get_datetime_diff(start: datetime, end: datetime) -> str:
    """
    Calculates the datetime diff in seconds.

    Args:
        start (datetime): Start time.
        end (datetime): End time.

    Returns:
        str: The difference in seconds as a string.
    """
    return str(int((end - start).total_seconds()))


def to_unix_timestamp(dt: datetime) -> int:
    """
    Converts a datetime object to a Unix timestamp (seconds since epoch, as int).
    If dt is not timezone-aware, it assumes UTC.

    Args:
        dt (datetime): The datetime object to convert.

    Returns:
        int: The Unix timestamp.
    """
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    else:
        dt = dt.astimezone(timezone.utc)
    return int(dt.timestamp())


@udf(StringType())
def build_source_metric_row_udf(
    file_write_target_path: str,
    source_file_url: str,
    file_available_time: datetime,
    file_download_start_time: datetime,
    file_download_finish_time: datetime,
    file_written_to_volume_time: datetime,
) -> str:
    """
    Builds a metric row string: "<http_date>;<new_file_name>;<download_time>;...".
    Uses '-' for missing values.

    Args:
        file_write_target_path (str): Target file path.
        source_file_url (str): Source file URL.
        file_available_time (datetime): File available time.
        file_download_start_time (datetime): Download start time.
        file_download_finish_time (datetime): Download finish time.
        file_written_to_volume_time (datetime): File written to volume time.

    Returns:
        str: The metric row string.
    """
    if file_write_target_path is None:
        raise ValueError("file_write_target_path is None")
    new_file_name: str = generate_new_file_name(file_write_target_path)
    http_date: str = (
        format_http_date(file_available_time) if file_available_time else "-"
    )
    download_time: str = (
        get_datetime_diff(file_download_start_time, file_download_finish_time)
        if file_download_start_time and file_download_finish_time
        else "-"
    )
    total_time: str = (
        get_datetime_diff(file_download_start_time, file_written_to_volume_time)
        if file_download_start_time and file_written_to_volume_time
        else "-"
    )
    write_timestamp = (
        to_unix_timestamp(file_written_to_volume_time)
        if file_written_to_volume_time
        else "-"
    )
    source_file_url = source_file_url if source_file_url else "-"
    return (
        f"{new_file_name};{source_file_url};{http_date};{download_time};"
        f"{total_time};{write_timestamp};1;"
    )


@udf(StringType())
def extract_ens_member_id(group_key: str) -> str:
    """
    Extracts the ensemble member ID from the group key.

    Args:
        group_key (str): The group key string.

    Returns:
        str: The ensemble member ID.
    """
    if group_key == "gfs":
        return "00"
    elif group_key == "geavg":
        return "avg"
    elif len(group_key) == 5 and group_key[-2:].isdigit():
        return group_key[-2:]
    else:
        raise ValueError(f"Invalid group key: {group_key}")


def filter_metric_rows(df: DataFrame) -> DataFrame:
    """
    Filters metric rows DataFrame to keep only every 3rd hour 
    for operational (lead times 000, 003, 006, ...)
    and every 6th hour for ensemble (lead times 000, 006, 012, ...).
    Assumes the metric row column is 'file_name'.

    Args:
        df: Input DataFrame.

    Returns:
        DataFrame: Filtered DataFrame.
    """
    metric_col = "file_name"
    # Extract lead time (e.g., 000, 003, 006, ...) 
    # from the file name at the end (f000, f003, ...)
    lead_time_expr = r"f(\d{3})$"
    # Extract ensemble/operational from the file name prefix
    is_oper_expr = r"^(gfs)\."

    df = df.filter(~col(metric_col).contains("geavg"))

    df = df.withColumn(
        "lead_time", regexp_extract(col(metric_col), lead_time_expr, 1).cast("int")
    ).withColumn(
        "is_oper_expr", (regexp_extract(col(metric_col), is_oper_expr, 0) != "")
    )
    # Filter: ensemble every 6h, operational every 3h
    df = df.filter(
        (~col("is_oper_expr") & (col("lead_time") % 6 == 0))
        | ((col("is_oper_expr")) & (col("lead_time") % 3 == 0))
    ).drop("lead_time", "is_oper_expr")

    return df


def get_target_path(df: DataFrame, cdb_sync_path: str) -> DataFrame:
    """
    Adds a column with the target metric file path to the DataFrame.

    Args:
        df: Input DataFrame.
        cdb_sync_path (str): Base sync path.

    Returns:
        DataFrame: DataFrame with target_metric_file_path column.
    """
    df = df.withColumn(
        "target_metric_file_path",
        concat_ws(
            "/",
            lit(cdb_sync_path),
            format_string("%04d", col("year")),
            format_string("%02d", col("month")),
            format_string("%02d", col("day")),
            format_string("%02d", col("run")),
            col("dataset"),
            lit("metrics"),
            concat_ws(
                ".",
                concat_ws(
                    "",
                    format_string("%04d", col("year")),
                    format_string("%02d", col("month")),
                    format_string("%02d", col("day")),
                    format_string("%02d", col("run")),
                ),
                col("ens_member"),
                lit("source"),
                col("source_product"),
                lit("metric"),
            ),
        ),
    )
    return df


def process_source_row(
    df: DataFrame, metric_source_mapping: dict, cdb_sync_path: str
) -> DataFrame:
    """
    Processes the source DataFrame, filters, maps, and adds metric row columns.

    Args:
        df: Input DataFrame.
        metric_source_mapping (dict): Mapping of dataset to source product.
        cdb_sync_path (str): Base sync path.

    Returns:
        DataFrame: Processed DataFrame.
    """
    df = df.filter(col("dataset").isin(list(metric_source_mapping.keys())))

    df = filter_metric_rows(df)

    if df.isEmpty():
        return df

    mapping_expr = create_map(
        [lit(x) for pair in metric_source_mapping.items() for x in pair]
    )
    df = df.withColumn("source_product", mapping_expr.getItem(col("dataset")))

    df = df.withColumn("group_key", split(col("file_name"), "\\.")[0])

    df = df.withColumn("ens_member", extract_ens_member_id(col("group_key")))

    df = get_target_path(df, cdb_sync_path)

    df = df.withColumn(
        "source_metric_row",
        build_source_metric_row_udf(
            df["file_write_target_path"],
            df["source_file_url"],
            df["file_available_time"],
            df["file_download_start_time"],
            df["file_download_finish_time"],
            df["file_written_to_volume_time"],
        ),
    )

    return df


def create_base_metric_file(metric_file_path: str) -> None:
    """
    Creates a base metric file with default records for the given metric file path.

    Args:
        metric_file_path (str): Path to the metric file to create.
    """
    filename = os.path.basename(metric_file_path)
    category = filename.split(".")[3].split("-")[0]
    if category == ENSEMBLE_CATEGORY:
        step = 6
        ens_member = filename.split(".")[1]
        prefix = f"gefs{ens_member}"
        n_records = 65
    elif category == OPERATIONAL_CATEGORY:
        step = 3
        prefix = "gfs"
        n_records = 129
    else:
        raise ValueError(f"Unhandled category: {category}")

    forecast_datetime = filename.split(".")[0]

    base_records = list()
    for leadtime in range(0, n_records * step, step):
        leadtime_str = str(leadtime).zfill(3)
        new_grib_name = (
            f"{prefix}.t{forecast_datetime}z.pgrbf{leadtime_str}.grib2.global"
        )
        base_record = f"{new_grib_name};-;0;-999;-999;-999;-999;0;"
        base_records.append(base_record)

    if len(base_records) != n_records:
        raise ValueError(
            f"Incorrect number of base records.\n"
            f"Expected {n_records}, got {len(base_records)} instead."
        )

    with open(metric_file_path, "w") as f:
        for base_record in base_records:
            f.write(f"{base_record}\n")


def update_metric_file(metric_file_path: str, group_rows: list) -> dict:
    """
    Updates the metric file with new or updated metric rows.

    Args:
        metric_file_path (str): Path to the metric file to update.
        group_rows (list): List of dicts with 'source_metric_row' and 'file_write_target_path'.

    Returns:
        dict: Mapping of grib file names to their target paths.
    """
    with open(metric_file_path, "r") as f:
        records = [record.strip() for record in f.readlines()]

    new_record_map = {
        row["source_metric_row"].split(";")[0]: row["source_metric_row"]
        for row in group_rows
    }
    grib_name_mapping = {
        row["source_metric_row"].split(";")[0]: row["file_write_target_path"]
        for row in group_rows
    }

    updated_records = []
    n_updates = 0
    for record in records:
        current_grib_filename = record.split(";")[0]
        if current_grib_filename in new_record_map:
            updated_records.append(new_record_map[current_grib_filename])
            n_updates += 1
        else:
            updated_records.append(record)

    if len(records) != len(updated_records):
        raise ValueError(
            f"Number of records in new file is different from the source.\n"
            f"len(records) != len(updated_records)\n"
            f"{len(records)} != {len(updated_records)}"
        )

    if n_updates != len(grib_name_mapping):
        raise ValueError(
            f"Number of gribs to transfer must be equal to the number of records updated.\n"
            f"n_updates != len(grib_name_mapping)\n"
            f"{n_updates} != {len(grib_name_mapping)}\n"
            f"{metric_file_path=}\n"
            f"{grib_name_mapping.keys()=}"
        )

    with open(metric_file_path, "w") as f:
        for updated_record in updated_records:
            f.write(f"{updated_record}\n")

    return grib_name_mapping
