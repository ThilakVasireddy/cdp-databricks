"""
NOAA Bronze Metrics Manager

This module provides utilities for logging file-level and task-level telemetry metrics
in Databricks jobs, using PySpark to write data into Delta tables. It extracts context
automatically from the Databricks job environment or accepts a user-supplied context
for testing or local development.

Classes:
- AttrDict: A helper class to enable attribute-style access to dictionary keys.
- NOAABronzeMetricsManager: Base class providing shared logic for all metrics managers.
- NOAABronzeFileMetricsManager: Tracks and logs metrics related to individual files.
- NOAABronzeTaskMetricsManager: Logs job and task-level execution metadata.

---
📘 Overview

The metrics managers help with observability in data pipelines by:
- Recording metrics at different granularities (task-level and file-level)
- Persisting those metrics into Delta Lake tables
- Supporting both Databricks-native context extraction and manual overrides

---
🧱 Requirements

- Databricks Runtime with Delta Lake enabled
- PySpark (`SparkSession` available)
- Access to the `dbutils` object (automatically available in Databricks)
- A destination Delta table name for storing metrics

---
📂 File Metrics Example

```python
from metrics.noaa_metrics_manager import NOAABronzeFileMetricsManager
from datetime import datetime

# Instantiate file metrics manager
file_mm = NOAABronzeFileMetricsManager(
    spark=spark,
    state_table_name="metrics_db.file_metrics"
)

# Populate telemetry fields
file_mm.state_row.file_name = "sample.nc"
file_mm.state_row.thread_name = "Worker-Thread-1"
file_mm.state_row.source_file_url = "https://example.com/sample.nc"
file_mm.state_row.file_write_target_path = "/mnt/bronze/sample.nc"
file_mm.state_row.file_available_time = datetime.utcnow()
file_mm.state_row.file_download_start = datetime.utcnow()
file_mm.state_row.file_download_finish = datetime.utcnow()
file_mm.state_row.file_written_to_volume_time = datetime.utcnow()
file_mm.state_row.content_length = 5242880
file_mm.state_row.byte_ranges = [(0, 1024), (2048, 4096)]

# Persist metrics in volume
file_mm.persist_file_status_in_volume()

# When ready, flush to Delta table
file_mm.flush_volume_file_status_to_delta()
"""

from pyspark.sql import SparkSession
from datetime import datetime
import json
import os
import shutil
import time
import pickle
from py4j.protocol import Py4JError

from pyspark.sql.types import (
    ArrayType,
    StructType,
    StructField,
    StringType,
    IntegerType,
    LongType,
    TimestampType,
)

try:
    from pyspark.dbutils import DBUtils
except ModuleNotFoundError:
    DBUtils = None


PICKLE_TMP_FOLDER_NAME = "tmp_file_state"

FILE_STATE_TABLE_SCHEMA = StructType(
    [
        StructField("file_name", StringType(), False),
        StructField("task_run_id", LongType(), False),
        StructField("thread_name", StringType(), True),
        StructField("source_file_url", StringType(), True),
        StructField("file_write_target_path", StringType(), True),
        StructField("file_available_time", TimestampType(), True),
        StructField("file_download_start_time", TimestampType(), True),
        StructField("file_download_finish_time", TimestampType(), True),
        StructField("file_written_to_volume_time", TimestampType(), True),
        StructField("content_length", LongType(), True),
        StructField(
            "byte_ranges",
            ArrayType(
                StructType(
                    [
                        StructField("start", LongType(), False),
                        StructField("end", LongType(), False),
                    ]
                )
            ),
            True,
        ),
        StructField("year", IntegerType(), True),
        StructField("month", IntegerType(), True),
        StructField("day", IntegerType(), True),
        StructField("run", IntegerType(), True),
        StructField("dataset", StringType(), True),
        StructField("record_created_time", TimestampType(), True),
    ]
)


def make_metric_tmp_dir(
    target_path: str, pickle_tmp_folder_name: str = PICKLE_TMP_FOLDER_NAME
):
    """Creates a temporary directory for storing file metrics."""
    metric_tmp_dir = os.path.join(target_path, pickle_tmp_folder_name)
    os.makedirs(metric_tmp_dir, exist_ok=True)


class AttrDict(dict):
    """A dictionary that allows attribute-style access."""

    def __getattr__(self, name: str):
        """Enables attribute-style access to dictionary keys."""
        try:
            return self[name]
        except KeyError as e:
            raise AttributeError(f"'AttrDict' object has no attribute '{name}'") from e

    def __setattr__(self, name: str, value) -> None:
        """Assigns a value to a key using attribute-style syntax."""
        self[name] = value

    def __delattr__(self, name: str) -> None:
        """Deletes a key using attribute-style syntax."""
        try:
            del self[name]
        except KeyError as e:
            raise AttributeError(f"'AttrDict' object has no attribute '{name}'") from e


class NOAABronzeMetricsManager:
    def __init__(
        self,
        spark: SparkSession,
        state_table_name: str,
        task_run_context: AttrDict = None,
    ):
        """Initializes the metrics manager with Spark, a table name, and optional job context."""
        self.spark = spark
        self.task_run_context = (
            task_run_context
            if task_run_context is not None
            else self.get_task_run_context()
        )
        self.state_table_name = state_table_name
        self.state_row = AttrDict()
        self.create_table()

    def get_task_run_context(self) -> AttrDict:
        """
        Retrieves Databricks job context using dbutils.

        Returns a fallback context if the notebook is run outside a job.
        """
        dbutils = DBUtils(self.spark)
        try:
            ctx_json = (
                dbutils.notebook.entry_point.getDbutils()
                .notebook()
                .getContext()
                .toJson()
            )
            ctx = json.loads(ctx_json)
        except Py4JError:
            print(
                "Warning: dbutils.notebook.getContext() failed. "
                "Are you running this notebook outside a Databricks job?"
            )
            return AttrDict(
                task_run_id=-1,
                task_key=None,
                job_id=None,
                job_run_id=None,
                job_name=None,
            )
        else:
            task_run_id = ctx["tags"].get("runId")
            task_key = ctx["tags"].get("taskKey")
            job_id = ctx["tags"].get("jobId")
            job_run_id = ctx.get("currentRunId") or ctx["tags"].get(
                "multitaskParentRunId"
            )
            job_run_id = job_run_id.get("id") if job_run_id else None
            job_name = ctx["tags"].get("jobName")

            return AttrDict(
                task_run_id=int(task_run_id) if task_run_id else -1,
                task_key=task_key,
                job_id=int(job_id) if job_id else None,
                job_run_id=int(job_run_id) if job_run_id else None,
                job_name=job_name,
            )


class NOAABronzeFileMetricsManager(NOAABronzeMetricsManager):
    def __init__(
        self,
        spark: SparkSession,
        state_table_name: str,
        metrics_folder: str,
        task_run_context: dict,
    ):

        super().__init__(spark, state_table_name, task_run_context)
        self.state_tmp_path = os.path.join(metrics_folder, PICKLE_TMP_FOLDER_NAME)

    def create_table(self) -> None:
        """Creates a Delta table to store file-level metrics."""
        self.schema = FILE_STATE_TABLE_SCHEMA

        field_sql = []
        for field in self.schema.fields:
            dtype = field.dataType.simpleString().upper()
            nullable = "NOT NULL" if not field.nullable else ""
            field_sql.append(f"{field.name} {dtype} {nullable}".strip())

        sql = f"""
            CREATE TABLE IF NOT EXISTS {self.state_table_name} (
                {', '.join(field_sql)}
            )
            USING DELTA
            PARTITIONED BY (year, month, day)
            TBLPROPERTIES (
                'delta.autoOptimize.optimizeWrite' = 'true',
                'delta.autoOptimize.autoCompact' = 'true'
            )
        """
        self.spark.sql(sql)

    def persist_file_status_in_volume(self) -> None:
        """
        Logs the current file's telemetry state to the Delta table.

        Includes byte ranges, timestamps, and metadata for tracing.
        """
        byte_ranges = [{"start": s, "end": e} for s, e in self.state_row.byte_ranges]
        task_run_id = self.task_run_context.task_run_id
        file_name = self.state_row.file_name

        year, month, day, run = map(int, self.state_tmp_path.split("/")[-5:-1])
        dataset = self.state_tmp_path.split("/")[-6]

        row = {
            "task_run_id": task_run_id,
            "file_name": file_name,
            "thread_name": self.state_row.thread_name,
            "source_file_url": self.state_row.source_file_url,
            "file_write_target_path": self.state_row.file_write_target_path,
            "file_available_time": self.state_row.file_available_time,
            "file_download_start_time": self.state_row.file_download_start,
            "file_download_finish_time": self.state_row.file_download_finish,
            "file_written_to_volume_time": self.state_row.file_written_to_volume_time,
            "content_length": self.state_row.content_length,
            "byte_ranges": byte_ranges,
            "year": year,
            "month": month,
            "day": day,
            "run": run,
            "dataset": dataset,
        }
        volume_path = os.path.join(self.state_tmp_path, f"{file_name}.pkl")

        t_start = time.time()
        with open(volume_path, "wb") as f:
            pickle.dump(row, f)
        print(
            f"Logging to volume took {time.time() - t_start :.6f}s for {volume_path}\n"
        )

        self.state_row = AttrDict()

    def flush_volume_file_status_to_delta(self) -> int | None:
        """
        Flushes all file status logs from the temporary volume directory to the Delta table.

        Reads all .pkl files in the temporary directory, loads their contents,
        writes them to the Delta table,
        deletes the processed files, and removes the directory if empty.
        Returns the number of rows written.

        Returns:
            int: The number of rows written to the Delta table.
        """
        t_start = time.time()

        if not os.path.exists(self.state_tmp_path):
            print(f"Path {self.state_tmp_path} does not exists")
            return None

        all_files = [
            f
            for f in os.listdir(self.state_tmp_path)
            if f.endswith(".pkl")
            and os.path.isfile(os.path.join(self.state_tmp_path, f))
        ]

        total_log_files = len(all_files)
        if total_log_files == 0:
            print(f"No log files to ingest in: {self.state_tmp_path}")
            return None

        print(f"Found {total_log_files} log file(s) in: {self.state_tmp_path}")

        rows = []
        for f in all_files:
            with open(os.path.join(self.state_tmp_path, f), "rb") as pf:
                row = pickle.load(pf)
                rows.append(row)

        df = self.spark.createDataFrame(rows, schema=self.schema)

        data_context = (
            df.select("year", "month", "day", "run", "dataset").distinct().collect()
        )
        print(f"Data context: {data_context}")
        if len(data_context) != 1:
            print("WARNING: data context is not unique")

        df.write.format("delta").mode("append").saveAsTable(self.state_table_name)

        written_count = df.count()

        print(f"Appended {written_count} row(s) to table: {self.state_table_name}")

        removed_files = 0
        for f in all_files:
            try:
                os.remove(os.path.join(self.state_tmp_path, f))
                removed_files += 1
            except Exception as e:
                print(f"Failed to delete {f}: {e}")

        remaining_files = [
            f
            for f in os.listdir(self.state_tmp_path)
            if os.path.isfile(os.path.join(self.state_tmp_path, f))
        ]

        if not remaining_files:
            shutil.rmtree(self.state_tmp_path)
            print(f"Removed empty directory: {self.state_tmp_path}")
        else:
            print(f"Remaining {len(remaining_files)} file(s): {remaining_files}")

        print(
            f"Initial: {total_log_files}, Written: {written_count}, "
            f"Removed: {removed_files}, Remaining: {len(remaining_files)}"
        )
        print(f"Logging to delta table took {time.time() - t_start :.3f}s")

        return written_count


class NOAABronzeTaskMetricsManager(NOAABronzeMetricsManager):
    def create_table(self) -> None:
        """Creates a Delta table to store task-level metrics."""
        self.schema = StructType(
            [
                StructField("task_run_id", LongType(), False),
                StructField("task_key", StringType(), True),
                StructField("job_run_id", LongType(), True),
                StructField("job_id", LongType(), True),
                StructField("job_name", StringType(), True),
                StructField("task_start_time", TimestampType(), True),
                StructField("task_finish_time", TimestampType(), True),
            ]
        )

        field_sql = []
        for field in self.schema.fields:
            dtype = field.dataType.simpleString().upper()
            nullable = "NOT NULL" if not field.nullable else ""
            field_sql.append(f"{field.name} {dtype} {nullable}".strip())

        sql = f"""
            CREATE TABLE IF NOT EXISTS {self.state_table_name} (
                {', '.join(field_sql)}
            )
            USING DELTA
            TBLPROPERTIES (
                'delta.autoOptimize.optimizeWrite' = 'true',
                'delta.autoOptimize.autoCompact' = 'true'
            )
        """
        self.spark.sql(sql)

    def log_task_start(self) -> None:
        """
        Logs the start time of a task run into the metrics table.

        Captures task and job identifiers and leaves finish time blank.
        """
        self.state_row.task_start_time = datetime.now()
        self.state_row.task_finish_time = None
        row: dict[str, object] = {
            "task_run_id": self.task_run_context.task_run_id,
            "task_key": self.task_run_context.task_key,
            "job_run_id": self.task_run_context.job_run_id,
            "job_id": self.task_run_context.job_id,
            "job_name": self.task_run_context.job_name,
            "task_start_time": self.state_row.task_start_time,
            "task_finish_time": self.state_row.task_finish_time,
        }
        df = self.spark.createDataFrame([row], schema=self.schema)
        df.write.format("delta").mode("append").saveAsTable(self.state_table_name)

    def log_task_finish(self) -> None:
        """
        Updates the Delta table with the finish time of the current task run.

        Identifies the row to update using `task_run_id`.
        """
        self.state_row.task_finish_time = datetime.now()
        update_sql: str = f"""
            UPDATE {self.state_table_name}
            SET task_finish_time = TIMESTAMP('{self.state_row.task_finish_time.isoformat()}')
            WHERE task_run_id = {self.task_run_context.task_run_id}
        """
        self.spark.sql(update_sql)
        self.state_row = AttrDict()
