import os
import re
import datetime as dt
import requests
from typing import Literal
import threading

from metrics.noaa_metrics_manager import NOAABronzeFileMetricsManager


class NOAAFileError(Exception):
    pass

def timestamp():
    return dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def tprint(*args, **kwargs):
    print(f"[{(ts:=timestamp())}]", *args, **kwargs)
    return ts

def ts2dt(timestamp_str: str) -> dt.datetime:
    return dt.datetime.strptime(timestamp_str, "%Y-%m-%d %H:%M:%S")

LINK_PATTERN = re.compile(r'<a href="[^>]*">([^<]+)</a>')
_RUNS = [0, 6, 12, 18]

INDEX_FOLDER = "index"


def makedirs(
    target_folder: str,
    index_folder: str = INDEX_FOLDER,
) -> None:
    """
    Initializes the target folder, index folder, and telemetry log folder.

    Args:
        target_folder (str): Path to the target folder.
        index_folder (str): Path to the index folder.

    Returns:
        None
    """
    os.makedirs(target_folder, exist_ok=True)
    os.makedirs(os.path.join(target_folder, index_folder), exist_ok=True)


def get_focus_date_and_run(
    now: dt.datetime,
    first_run_download_start_time: dt.time,
    shift: dt.timedelta,
    runs: list[int],  # Required parameter, no default value
) -> tuple[dt.date, str]:
    """
    Calculate the focus date and run based on the current time, the expected first arrival time,
    and a time shift.

    The day is divided into buckets according to the runs and the expected first arrival time.
    The function returns the left endpoint of the bucket that contains
    the datetime given by now + shift.

    Args:
        now (dt.datetime): The current datetime.
        first_run_download_start_time (dt.time): The expected arrival time of the first file.
        shift (dt.timedelta): A time shift to adjust the current time for calculations.
                              This is useful if we want to start the workflow before the
                              first file arrival.
        runs (list[int]): List of run hours to consider.

    Returns:
        tuple[dt.date, str]: A tuple containing the focus date (as a datetime.date object)
                             and the corresponding run (as a zero-padded string).

    Examples:
        >>> now = dt.datetime(2023, 10, 5, 3, 35) # after expected first file arrival time
        >>> first_run_download_start_time = dt.time(3, 30)
        >>> shift = dt.timedelta()
        >>> get_focus_date_and_run(now, first_run_download_start_time, shift, [0, 6, 12, 18])
        (datetime.date(2023, 10, 5), '00')

        >>> now = dt.datetime(2023, 10, 5, 3, 25) # before expected first file arrival time
        >>> first_run_download_start_time = dt.time(3, 30)
        >>> shift = dt.timedelta()
        >>> get_focus_date_and_run(now, first_run_download_start_time, shift, [0, 6, 12, 18])
        (datetime.date(2023, 10, 4), '18')

        >>> now = dt.datetime(2023, 10, 5, 3, 25) # before expected but shifted
        >>> first_run_download_start_time = dt.time(3, 30)
        >>> shift = dt.timedelta(minutes=10) # this means run is computed using the time 3:35
        >>> get_focus_date_and_run(now, first_run_download_start_time, shift, [0, 6, 12, 18])
        (datetime.date(2023, 10, 5), '00')
    """

    def run_fmt(x):
        return f"{x:02}"  # zero pad up to 2 digits

    shifted_now = now + shift

    first_run_datetime = dt.datetime.combine(
        shifted_now.date(), first_run_download_start_time
    )

    if shifted_now < first_run_datetime:
        # last run of yesterday
        focus_date = (shifted_now - dt.timedelta(days=1)).date()
        run = run_fmt(runs[-1])
        return focus_date, run

    focus_date = shifted_now.date()
    offset_runs = [
        first_run_datetime + dt.timedelta(hours=i) - dt.timedelta(hours=runs[0])
        for i in runs
    ]
    for run_hour, left, right in zip(runs, offset_runs, offset_runs[1:]):
        if left <= shifted_now < right:
            run = run_fmt(run_hour)
            return focus_date, run
    return focus_date, run_fmt(runs[-1])


def get_source_files(
    session: requests.Session,
    file_list_url: str,
    file_pattern: re.Pattern,
    forecast_range: range,
) -> set[str]:
    """
    Retrieves a list of source files from a given URL.

    Args:
        session (requests.Session): Configured session object for making requests.
        file_list_url (str): URL containing the list of files.
        file_pattern (Pattern): Regular expression pattern to match file names.
        forecast_range (range): Range of forecast values to filter files by,
                                based on the last three digits of the file name.

    Returns:
        set[str]: set of source files matching the pattern.
    """
    file_list_url_response = session.get(file_list_url)
    if file_list_url_response.history:
        redirect_info = [f"req to {file_list_url=} redirected."]
        for resp in response.history:
            redirect_info.append(f"Redirected from {resp.url} to {response.url}")
        tprint("\n".join(redirect_info))
    file_list_url_response.raise_for_status()
    file_list_url_html_content = file_list_url_response.text
    return parse_source_files(file_list_url_html_content, file_pattern, forecast_range)


def parse_source_files(
    html_content: str,
    file_pattern: re.Pattern,
    forecast_range: range,
    link_pattern: re.Pattern = LINK_PATTERN,
) -> set[str]:
    """
    Parses the HTML content to retrieve a list of source files.

    Args:
        html_content (str): HTML content containing the list of files.
        file_pattern (Pattern): Regular expression pattern to match file names.
        forecast_range (range): Range of forecast hours to filter files
        link_pattern (Pattern): Regular expression pattern to match links.

    Returns:
        set[str]: set of source files matching the pattern.
    """
    # Use regular expressions to find all links
    matches = link_pattern.findall(html_content)
    return {
        match
        for match in matches
        if file_pattern.match(match) and int(match[-3:]) in forecast_range
    }


def log_output(
    file_url: str,
    write_time_dt: dt.datetime,
    last_modified: str | None,
    content_length: int,
    byte_ranges: list[tuple[int, int | None]] | None = None,
) -> None:
    """
    Print output information about a file that was downloaded.

    Args:
        file_url (str): URL of the file that was downloaded.
        write_time_dt (dt.datetime): Datetime when the file was written.
        last_modified (str|None): Last-Modified header from response when file was downloaded.
        content_length (int): Content length of the file.

    Returns:
        None
    """
    write_time = write_time_dt.isoformat()
    if last_modified:
        last_modified_dt = dt.datetime.strptime(
            last_modified, "%a, %d %b %Y %H:%M:%S %Z"
        )
        # td for timedelta, dt for datetime
        last_modified_to_write_time_td = write_time_dt - last_modified_dt
        last_modified_to_write_time = str(last_modified_to_write_time_td)
    else:
        last_modified_to_write_time = ""

    log = (
        f"file_url={file_url}\n"
        f"last_modified={last_modified}\n"
        f"write_time={write_time}\n"
        f"last_modified_to_write_time={last_modified_to_write_time}\n"
        f"content_length={content_length}\n"
        f"byte_ranges={byte_ranges}"
    )

    tprint(log)


def get_total_unfiltered_size(headers: bytes) -> int:
    """
    Extracts the total unfiltered size from the Content-Range header of a multipart response part.

    Args:
        headers (bytes): The headers of a multipart response part.

    Returns:
        int: The total unfiltered size.

    Raises:
        ValueError: If the Content-Range header is missing or cannot be parsed.
    """
    content_range_header = next(
        (
            h
            for h in headers.decode().split("\r\n")
            if h.casefold().startswith("content-range")
        ),
        None,
    )
    if content_range_header:
        try:
            return int(content_range_header.split("/")[1])
        except ValueError:
            raise ValueError(
                f"Failed to parse Content-Range header: {content_range_header}"
            )
    else:
        raise ValueError(f"Content-Range header not found in part headers: {headers}")


def parse_multipart_response(response: requests.Response) -> tuple[bytes, int]:
    """
    Parses a multipart/byteranges response to extract the content.

    Args:
        response (requests.Response): The HTTP response object containing
                                      multipart/byteranges content.

    Returns:
        tuple[bytes, int]: The combined content from all parts of the multipart response
        and the total unfiltered size of the content.

    Raises:
        ValueError: If the boundary is not found in the Content-Type header or if the parts
        cannot be split correctly.

    Note:
        This function follows the specifications outlined in RFC 7233.
        See: https://www.rfc-editor.org/rfc/rfc7233
    """
    content_type = response.headers.get("Content-Type", "")
    boundary = None
    if "multipart/byteranges" in content_type:
        split = content_type.split("boundary=")
        if len(split) < 2:
            raise ValueError(
                "Boundary not found in Content-Type header for multipart response."
            )
        boundary = split[-1]

    parts = response.content.split(f"--{boundary}".encode())
    total_content = bytearray()
    total_unfiltered_size = -1

    for part in parts:
        if part.strip(b"-\r\n"):
            split_part = part.split(b"\r\n\r\n", 1)
            if len(split_part) != 2:
                raise ValueError(
                    f"Failed to split part into headers and content: {part}"
                )
            headers, content = split_part
            total_content.extend(content.strip(b"\r\n"))

            # pull total unfiltered size from Content-Range header
            if total_unfiltered_size == -1:
                total_unfiltered_size = get_total_unfiltered_size(headers)

    return total_content, total_unfiltered_size


def download_file(
    session: requests.Session,
    file_url: str,
    target_file_path: str,
    file_mm: NOAABronzeFileMetricsManager,
    byte_ranges: list[tuple[int, int | None]] | None = None,
) -> None:
    """
    Downloads a file from a given URL and saves it to the specified target file path.

    Args:
        session (requests.Session): Configured session object for making requests.
        file_url (str): URL of the file to be downloaded.
        target_file_path (str): Path where the downloaded file will be saved.
        file_mm (NOAABronzeFileMetricsManager): Metrics manager for file status.
        byte_ranges (list[tuple[int,int | None]] | None): List of byte ranges to download.

    Raises:
        NOAAFileError: If the downloaded file size does not match the intended size.
        FileExistsError: If the target file already exists.

    Returns:
        None
    """

    headers = {}
    if byte_ranges:
        byte_ranges_str = ",".join(f"{start}-{end}" for start, end in byte_ranges)
        headers["Range"] = f"bytes={byte_ranges_str}"

    file_response = session.get(file_url, headers=headers)
    file_response.raise_for_status()
    download_finish_time = dt.datetime.now()

    if "multipart/byteranges" in file_response.headers.get("Content-Type", ""):
        total_content, total_unfiltered_size = parse_multipart_response(file_response)
    else:
        total_content, total_unfiltered_size = file_response.content, None

    last_modified = file_response.headers.get("last-modified", None)
    content_length = len(total_content)
    expected_final_size = byte_ranges_to_size(byte_ranges, total_unfiltered_size)
    if content_length != expected_final_size:
        raise NOAAFileError(
            f"Downloaded file size ({content_length} bytes) does not match "
            f"the intended size ({expected_final_size} bytes)."
        )

    with open(target_file_path, "wb") as f:
        f.write(total_content)

    write_time = dt.datetime.now()
    file_mm.state_row.file_available_time = dt.datetime.strptime(
        last_modified, "%a, %d %b %Y %H:%M:%S %Z"
    )
    file_mm.state_row.file_download_finish = download_finish_time
    file_mm.state_row.file_written_to_volume_time = write_time
    file_mm.state_row.content_length = content_length
    file_mm.state_row.byte_ranges = byte_ranges
    file_mm.persist_file_status_in_volume()
    log_output(
        file_url,
        write_time,
        last_modified,
        content_length,
        byte_ranges,
    )


def get_target_files(target_folder: str, forecast_range: range) -> set[str]:
    """
    Retrieves a set of target files in the specified folder.

    Args:
        target_folder (str): Path to the folder containing target files.
        forecast_range (range): Range of forecast values to filter files by,
        based on the last three digits of the file name.

    Returns:
        set[str]: set of target files.
    """

    with os.scandir(target_folder) as entries:
        return {
            entry.name
            for entry in entries
            if entry.is_file()
            and (i := entry.name[-3:]).isdigit()
            and int(i) in forecast_range
        }


def find_files_to_download(source_files: set[str], target_files: set[str]) -> set[str]:
    """
    Finds the files that need to be downloaded by comparing source files and target files.

    Args:
        source_files (set[str]): set of source files.
        target_files (set[str]): set of target files.

    Returns:
        set[str]: set of files to be downloaded.
    """
    return source_files - target_files


def process_line_pair(
    line1: str, line2: str | None, regex: re.Pattern, skip_identical_line_pairs
) -> tuple[int, int | Literal[""], bool]:
    """Process a pair of lines and return the byte range information."""
    if not re.search(regex, line1):
        return 0, 0, False

    split1 = line1.split(":", 2)
    split2 = line2.split(":", 2) if line2 else None

    # Skip line pairs that are identical (apart from line number and byte range)
    if skip_identical_line_pairs and split2 and split1[-1] == split2[-1]:
        return 0, 0, False

    left = int(split1[1])
    right = int(split2[1]) - 1 if line2 else ""
    return left, right, True


def handle_single_unbounded_range(
    byte_ranges: list[tuple[int, int | Literal[""]]],
) -> list[tuple[int, int | Literal[""]]]:
    """Handle the case of a single unbounded range by splitting it."""
    if len(byte_ranges) == 1 and byte_ranges[-1][1] == "":
        start = byte_ranges[-1][0]
        return [(start, start), (start + 1, "")]
    return byte_ranges


def filter_index_file_to_byte_ranges(
    lines: list[str], regex: re.Pattern, skip_identical_line_pairs: bool = False
) -> list[tuple[int, int | Literal[""]]]:
    """
    Filters the lines of the index file based on regex patterns.
    Returns a list of byte ranges for matching content.
    """
    byte_ranges = []
    left = right = None

    for line1, line2 in zip(lines, lines[1:] + [None]):
        new_left, new_right, is_valid = process_line_pair(
            line1, line2, regex, skip_identical_line_pairs
        )

        if not is_valid:
            continue

        if left is None:
            left, right = new_left, new_right
        elif right + 1 == new_left:
            right = new_right
        else:
            byte_ranges.append((left, right))
            left, right = new_left, new_right

    if left is not None:
        byte_ranges.append((left, right))

    return handle_single_unbounded_range(byte_ranges)


def byte_ranges_to_size(
    byte_ranges: list[tuple[int, int | Literal[""]]],
    total_unfiltered_size: int | Literal[""] = Literal[""],
) -> int:
    """
    Computes the total size of the byte ranges.
    Accepts optional total unfiltered size for the last byte range.

    Args:
        byte_ranges (list[tuple[int, int | Literal[""]]]): List of byte ranges.
        total_unfiltered_size (int | Literal[""]): The total unfiltered size of the content.

    Returns:
        int: Total size of the byte ranges.
    """
    if byte_ranges and byte_ranges[-1][1] == "":
        if total_unfiltered_size != "":
            byte_ranges[-1] = (byte_ranges[-1][0], total_unfiltered_size - 1)
        else:
            raise ValueError(
                f"Invalid byte range: {byte_ranges[-1]} with {total_unfiltered_size=}"
            )
    return sum(b + 1 - a for (a, b) in byte_ranges)


def download_idx_file(session: requests.Session, idx_file_url: str) -> str:
    """
    Downloads the .idx file content.

    Args:
        session (requests.Session): Configured session object for making requests.
        idx_file_url (str): URL of the .idx file to be downloaded.

    Returns:
        str: Content of the downloaded .idx file.
    """
    idx_file_response = session.get(idx_file_url)
    idx_file_response.raise_for_status()
    if not idx_file_response.text.endswith("\n"):
        raise NOAAFileError(
            r"Downloaded index file does not end with \n, likely incomplete. "
            f"{idx_file_url=}, {idx_file_response.text[-1]=}"
        )
    return idx_file_response.text


def process_idx_file(
    idx_content: str, variable_pattern_list: list[re.Pattern]
) -> list[tuple[int, int | None]]:
    """
    Processes the .idx file content to compute the required byte ranges.

    Args:
        idx_content (str): Content of the .idx file.
        variable_pattern_list (list[re.Pattern]): List of regex patterns to filter the index file.

    Returns:
        list[tuple[int, int | None]]: List of byte ranges.
    """
    return filter_index_file_to_byte_ranges(
        idx_content.splitlines(), variable_pattern_list
    )


def download_save_and_process_idx_file(
    session: requests.Session,
    idx_file_url: str,
    idx_file_path: str,
    variable_pattern_list: list[re.Pattern],
) -> list[tuple[int, int | None]]:
    """
    Downloads and processes the .idx file to compute the required byte ranges.

    Implementation detail: Requests are expensive - we want to avoid them if possible.
    So we check if the file already exists and is readable. If it is, we skip the download.

    Args:
        session (requests.Session): Configured session object for making requests.
        idx_file_url (str): URL of the .idx file to be downloaded.
        idx_file_path (str): Path where the .idx file will be saved.
        variable_pattern_list (list[re.Pattern]): List of regex patterns to filter the index file.

    Returns:
        list[tuple[int, int | None]]: List of byte ranges.
    """

    if os.path.exists(idx_file_path):
        try:
            with open(idx_file_path, "r") as f:
                idx_content = f.read()
            tprint(f"File {idx_file_path} already exists, skipping download")
            return process_idx_file(idx_content, variable_pattern_list)
        except OSError:
            tprint(
                f"File {idx_file_path} already exists, but cannot be read. "
                f"Removing it and downloading it again."
            )
            os.remove(idx_file_path)

    idx_content = download_idx_file(session, idx_file_url)

    with open(idx_file_path, "x") as f:
        f.write(idx_content)
    return process_idx_file(idx_content, variable_pattern_list)


def regex_list_to_regex(regex_list: list[str]) -> re.Pattern:
    """
    Converts a list of regex patterns into a single regex pattern.

    Args:
        regex_list (list[str]): List of regex patterns.

    Returns:
        re.Pattern: Combined regex pattern.
    """
    # note: (?:...) is a non-capturing group, which stops the regex engine
    # from creating unnecessary backreferences
    return re.compile("|".join(f"(?:{s})" for s in regex_list))


def process_file(
    session: requests.Session,
    file_name: str,
    file_list_url: str,
    target_folder: str,
    variable_pattern_list: list[re.Pattern],
    metrics_manager_kwargs: dict,
) -> None:
    """
    Downloads a file and its associated .idx file, and computes the required byte ranges.

    Args:
        session (requests.Session): Configured session object for making requests.
        file_name (str): Name of the file to be processed.
        file_list_url (str): Base URL for the file list.
        target_folder (str): Path to the folder where the downloaded file will be saved.
        variable_pattern_list (list[re.Pattern]): List of regex patterns to filter the index file.
        metrics_manager_kwargs (dict): Keyword arguments for the MetricsManager.

    Returns:
        None
    """
    file_mm = NOAABronzeFileMetricsManager(**metrics_manager_kwargs)
    # paths and urls
    index_folder = INDEX_FOLDER
    file_url = f"{file_list_url}{file_name}"
    idx_file_url = f"{file_url}.idx"
    target_file_path = os.path.join(target_folder, file_name)
    idx_file_path = os.path.join(target_folder, index_folder, f"{file_name}.idx")

    timestamp1 = dt.datetime.now()
    byte_ranges = download_save_and_process_idx_file(
        session, idx_file_url, idx_file_path, variable_pattern_list
    )


    idx_time = (timestamp2 := dt.datetime.now()) - timestamp1
    tprint(f"time to process {idx_file_path}: {idx_time}")

    file_mm.state_row.file_name = file_name
    file_mm.state_row.source_file_url = file_url
    file_mm.state_row.file_write_target_path = target_file_path
    file_mm.state_row.file_download_start = dt.datetime.now()
    file_mm.state_row.thread_name = threading.current_thread().name

    # Download the file with byte ranges
    tprint(f"Downloading the file {file_url} to {target_file_path}")
    download_file(session, file_url, target_file_path, file_mm, byte_ranges)
    tprint(f"time to download {target_file_path}: {dt.datetime.now() - timestamp2}")