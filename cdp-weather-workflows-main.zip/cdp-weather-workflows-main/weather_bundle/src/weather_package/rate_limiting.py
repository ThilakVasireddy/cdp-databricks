import time
from threading import Lock, current_thread
from collections import deque
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import requests


class RateLimiter:
    def __init__(self, max_calls: int, period: float):
        self.max_calls = max_calls
        self.period = period  # in seconds
        self.call_times = deque()
        self.lock = Lock()

    def acquire(self):
        with self.lock:
            current_time = time.monotonic()
            # Remove timestamps older than the period
            while self.call_times and self.call_times[0] <= current_time - self.period:
                self.call_times.popleft()

            if len(self.call_times) < self.max_calls:
                # We can make a request immediately
                self.call_times.append(current_time)
            else:
                # Need to wait before making the next request
                earliest_call = self.call_times[0]
                sleep_time = self.period - (current_time - earliest_call)
                print(
                    f"Thread {current_thread().name} - Rate limit reached. "
                    f"Sleeping for {sleep_time:.2f} seconds."
                )
                time.sleep(sleep_time)
                # After sleeping, remove outdated timestamps
                while self.call_times and self.call_times[0] <= time.monotonic() - self.period:
                    self.call_times.popleft()
                # Record the current time
                self.call_times.append(time.monotonic())


class RateLimitHTTPAdapter(HTTPAdapter):
    def __init__(self, rate_limiter: RateLimiter, timeout: int | None = 10, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.rate_limiter = rate_limiter
        self.timeout = timeout

    def send(self, request, **kwargs):
        self.rate_limiter.acquire()
        kwargs["timeout"] = self.timeout if self.timeout else kwargs.get("timeout")
        response = super().send(request, **kwargs)
        return response


def create_session(max_retries: int, request_rate_limit_per_minute: int) -> requests.Session:
    retry_strategy = Retry(
        total=max_retries,
        backoff_factor=1,
        status_forcelist=list(range(300, 600)),
        redirect=True,
        raise_on_redirect=False,
    )
    rate_limiter = RateLimiter(request_rate_limit_per_minute, 60)
    adapter = RateLimitHTTPAdapter(
        rate_limiter=rate_limiter,
        max_retries=retry_strategy,
        pool_connections=request_rate_limit_per_minute,
        pool_maxsize=request_rate_limit_per_minute,
    )
    session = requests.Session()
    session.mount("https://", adapter)
    return session
