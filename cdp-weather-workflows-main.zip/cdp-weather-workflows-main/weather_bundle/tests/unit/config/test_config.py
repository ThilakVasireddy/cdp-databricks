def append_to_sys_path(folder: str, base_folder: str = "weather_bundle") -> str:
    """
    Append the specified folder to the system path if it is not already present.
    Allows importing packages from the folder.
    """
    import re
    import os
    import sys

    if not (match := re.search(rf"(.*[\\/]{base_folder})", os.getcwd())):
        raise FileNotFoundError(f"Could not find {base_folder} in current path: {os.getcwd()}")

    base_path = match.group(1)
    for root, dirs, _ in os.walk(base_path):
        if "src" in dirs:
            base_path = root
            break

    path = os.path.normpath(os.path.join(base_path, folder))
    if path not in sys.path:
        sys.path.append(path)
    return path


config_path = append_to_sys_path("src/config")


# ruff: noqa: E402
import os
import pytest
import warnings
from itertools import zip_longest

from config import Config

ENVS = ["dev", "ppr", "prd"]
STAGES = ["sandbox", "staging", "live"]
envs_stages_pairs = [(e, s) for e in ENVS for s in STAGES]


# Configurable list of paths (in dot notation) that are expected to differ across configs
EXPECTED_DIFFERENT_KEYS = [
    "shared.storage_account",
    "shared.container_name",
    "shared.system_catalog_name",
    "testing.test_catalog_name",
    "weather.catalog_name",
    *[
        f"weather.noaa.{dataset}.request_rate_limit_per_minute"
        for dataset in [
            "GFS_pgrb2_0p25",
            "GFS_pgrb2_0p50",
            "GFS_pgrb2_1p00",
            "GEFS_pgrb2a_0p50",
            "GEFS_pgrb2b_0p50",
            "GEFS_extended_pgrb2a_0p50",
            "GEFS_extended_pgrb2b_0p50",
        ]
    ],
]


def check_config(obj1, obj2, path="", compare_values=False) -> tuple[bool, str]:
    """
    Checks if two dicts representing JSON have the same structure and optionally the same values.

    Args:
        obj1, obj2: Objects to compare
        path: Current path in dot notation for nested objects
        compare_values: If True, terminal values are also compared

    Returns:
        tuple[bool, str]: (is_same, error_message)
    """
    # Check if this path should be skipped
    if path and any(path == key or path.startswith(f"{key}.") for key in EXPECTED_DIFFERENT_KEYS):
        return True, ""  # Skip comparison for this path

    # Handle dictionaries
    if isinstance(obj1, dict) and isinstance(obj2, dict):
        if list(obj1.keys()) != list(obj2.keys()):
            first_error_pair = next(
                (k1, k2) for k1, k2 in zip_longest(obj1.keys(), obj2.keys()) if k1 != k2
            )
            return (
                False,
                f"Key mismatch at {path}\n"
                f"{first_error_pair=}\n"
                f"left: {list(obj1.keys())}\n"
                f"right:{list(obj2.keys())}",
            )
        for key in obj1:
            next_path = f"{path}.{key}" if path else key
            same_shape, message = check_config(obj1[key], obj2[key], next_path, compare_values)
            if not same_shape:
                return False, message
        return True, ""

    # Handle lists
    elif isinstance(obj1, list) and isinstance(obj2, list):
        if len(obj1) != len(obj2):
            return False, f"List length mismatch at {path}: {len(obj1)} != {len(obj2)}"

        for i, (item1, item2) in enumerate(zip(obj1, obj2)):
            next_path = f"{path}[{i}]"
            same_shape, message = check_config(item1, item2, next_path, compare_values)
            if not same_shape:
                return False, message
        return True, ""

    # Handle terminal values
    else:
        if compare_values and obj1 != obj2:
            return False, f"Value mismatch at {path}: {obj1} != {obj2}"
        return True, ""


@pytest.mark.parametrize("env, stage", envs_stages_pairs)
def test_config_initialization(monkeypatch, env, stage):
    """
    check that Config object can be initialized for all envs and stages that have folders.
    Fails e.g. if config.json is not valid JSON.
    """
    env_stage_path = os.path.join(config_path, env, stage)
    if not os.path.exists(env_stage_path):
        # Skip test with warning if no config for env and stage
        warnings.warn(f"No config found for env: {env}, stage: {stage}", UserWarning)
        return
    monkeypatch.setenv("ENV", env)
    monkeypatch.setenv("STAGE", stage)
    config = Config()
    assert config is not None


def test_config_keys_consistency_in_envs(monkeypatch):
    """
    Checks that all config files for one env have the same keys, recursively: see have_same_shape for details.
    Configs between different envs could have different keys.
    """
    for env in ENVS:
        dicts = []
        for stage in STAGES:
            env_stage_path = os.path.join(config_path, env, stage)
            if not os.path.exists(env_stage_path):
                continue
            monkeypatch.setenv("ENV", env)
            monkeypatch.setenv("STAGE", stage)
            config = Config()
            dicts.append(config._config_content)
        for i, d in enumerate(dicts[1:], start=1):
            same_config, message = check_config(dicts[0], d)
            assert same_config, (
                f"Config mismatch between {env}.{STAGES[0]} and {env}.{STAGES[i]}: {message}"
            )


def test_config_structure_and_values_consistency(monkeypatch):
    """
    Checks that all config files for one env have:
    1. The same structure (keys and nested structure)
    2. The same values for all fields, except those listed in EXPECTED_DIFFERENT_KEYS

    Configs between different envs could have different structures and values.
    """
    for env in ENVS:
        dicts = []
        stages_found = []

        for stage in STAGES:
            env_stage_path = os.path.join(config_path, env, stage)
            if not os.path.exists(env_stage_path):
                continue
            monkeypatch.setenv("ENV", env)
            monkeypatch.setenv("STAGE", stage)
            config = Config()
            dicts.append(config._config_content)
            stages_found.append(stage)

        if len(dicts) <= 1:
            continue  # Skip if there's only one or no config for this env

        for i, d in enumerate(dicts[1:], start=1):
            # First check structure
            same_shape, message = check_config(dicts[0], d)
            assert same_shape, (
                f"Config shape mismatch between {env}.{stages_found[0]} and {env}.{stages_found[i]}: {message}"
            )

            # Then check values, excluding specified paths
            same_values, message = check_config(dicts[0], d, compare_values=True)
            assert same_values, (
                f"Config value mismatch between {env}.{stages_found[0]} and {env}.{stages_found[i]}: {message}"
            )
