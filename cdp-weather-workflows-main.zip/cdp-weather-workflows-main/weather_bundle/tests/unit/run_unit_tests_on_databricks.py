# Databricks notebook source
# MAGIC %sh sudo apt-get update && apt-get install -y gdal-bin libeccodes-dev libnetcdf-dev libhdf5-dev  

# COMMAND ----------

# MAGIC %sh sudo apt-get install -y libudunits2-dev 

# COMMAND ----------

# MAGIC  %pip install numpy==1.24.4 eccodes==1.7.1 xarray==2024.9.0 cf_xarray==0.10.0 cfgrib==0.9.14.1 netcdf4==1.7.2  

# COMMAND ----------

# MAGIC %pip install --no-cache-dir --force-reinstall cfgrib==0.9.14.1 numpy==1.24.4  

# COMMAND ----------

# MAGIC %pip install setuptools flake8 wheel pytest pytest-mock coverage cdsapi>=0.7.2 cfunits==3.3.7

# COMMAND ----------

# MAGIC %restart_python

# COMMAND ----------

import os

workdir = os.getcwd().split("tests")[0]
print(f"{workdir=}")  
os.chdir(workdir)
os.environ["PYTHONDONTWRITEBYTECODE"] = '1' 

# COMMAND ----------

!pytest tests/unit/weather_package/test_noaa_stat_files_helper.py
