# requirements: numpy==1.24.4 eccodes==1.7.1 xarray==2024.9.0 cf_xarray==0.10.0 cfgrib==0.9.14.1 netcdf4==1.7.2

from unittest.mock import patch
import pytest
import xarray as xr
from pathlib import Path
import shutil
import numpy as np


def append_to_sys_path(folder: str, base_folder: str = "weather_bundle") -> str:
    """
    Append the specified folder to the system path if it is not already present. Allows importing packages from the folder.
    """
    import re
    import os
    import sys

    if not (match := re.search(rf"(.*[\\/]{base_folder})", os.getcwd())):
        raise Exception(f"Could not find {base_folder} in current path: {os.getcwd()}")

    base_path = match.group(1)
    for root, dirs, _ in os.walk(base_path):
        if "src" in dirs:
            base_path = root
            break

    path = os.path.join(base_path, folder)
    if path not in sys.path:
        sys.path.append(path)
    return path


append_to_sys_path("src/config")
append_to_sys_path("src/weather_package")
append_to_sys_path("tests/unit")

from grib2netcdf.converter import Grib2NetCDFConverter
from mocked_data.ecwmf_data_mock import (
    INPUT_GRIB_DATA,
    OUTPUT_NC_DATA_LIST,
)


@pytest.fixture
def mock_xarray_open_dataset(mocker):
    mock_dataset = INPUT_GRIB_DATA
    mocker.patch("xarray.open_dataset", return_value=mock_dataset)


@pytest.fixture
def mock_create_success_marker_file(mocker):
    mocker.patch(
        "grib2netcdf.converter.Grib2NetCDFConverter.create_success_marker_file"
    )


@pytest.fixture
def converter():
    return Grib2NetCDFConverter(
        data_provider="ecmwf",
    )


@pytest.fixture
def mock_shutil_copy(mocker):
    mocker.patch("shutil.copy")


def mock_write_to_netcdf(self, file_path, *args, **kwargs):
    file_name = Path(file_path).name
    variable = file_name.split("_")[2]
    # raise RuntimeError(f"{self}\n\n{OUTPUT_NC_DATA_LIST.get(file_name)}")
    if variable in ["tcc", "tp"]:
        assert self.equals(OUTPUT_NC_DATA_LIST.get(file_name))
        mock_write_to_netcdf._calls.append(variable)


mock_write_to_netcdf._calls = []


def test_convert(
    converter,
    mock_xarray_open_dataset,
    mock_shutil_copy,
    mock_create_success_marker_file,
):
    with patch.object(xr.Dataset, "to_netcdf", mock_write_to_netcdf):

        converter.convert("src_path/C1E01020000010502001", "target_path")

        # Assert that .equals was called exactly two times
        assert len(mock_write_to_netcdf._calls) == 2

    shutil.copy.assert_called()


def test_map_product_name_ecmwf(converter):
    path = "/path/to/C9_example_file.grib2"
    assert converter.map_product_name(path) == "C9"


def test_map_category_operational(converter):
    assert converter.map_category("/path/to/C9_file.grib2") == "operational"


def test_map_category_ensemble(converter):
    assert converter.map_category("/path/to/E1_file.grib2") == "ensemble"


def test_map_category_unknown(converter):
    with pytest.raises(ValueError):
        converter.map_category("/path/to/X1_file.grib2")


def test_get_resolution_rounds_and_formats(converter):
    mock_array = xr.DataArray(
        attrs={
            "GRIB_iDirectionIncrementInDegrees": 0.25,
            "GRIB_jDirectionIncrementInDegrees": 0.125,
        }
    )
    res = converter.get_resolution(mock_array)
    assert res == "0p12"


def test_apply_variable_metadata_removes_grib(converter):
    array = xr.DataArray(attrs={"GRIB_param": "temp", "foo": "bar"})
    metadata = {"units": "K"}
    result = converter.apply_variable_metadata(array, metadata)
    assert "GRIB_param" not in result.attrs
    assert result.attrs["units"] == "K"


def test_construct_output_path(converter):
    template = "OUT/<variable_name_tag>_<resolution_tag>_<realization_tag>.nc"
    result = converter.construct_output_path(template, "tas", "0p25", "e001")
    assert result == "OUT/tas_0p25_e001.nc"


def test_get_accumulation_start_stop_accumulated(converter):
    da = xr.DataArray(
        attrs={"accumulation_period_start": "t0", "accumulation_period_stop": "t1"}
    )
    meta = {"processing": "accumulated"}
    start, stop = converter.get_accumulation_start_stop(da, meta)
    assert start == "t0" and stop == "t1"


def test_get_accumulation_start_stop_default(converter):
    da = xr.DataArray(attrs={})
    start, stop = converter.get_accumulation_start_stop(da, {})
    assert start is None and stop is None


def test_reorganize_variable_with_pressure_level(converter):
    # Create a 5D array of shape (1,1,1,1,1) matching the dims
    data = np.random.rand(1, 1, 1, 1, 1)
    arr = xr.DataArray(
        data,
        dims=["realization", "valid_time", "pressure_level", "latitude", "longitude"],
    )

    result = converter.reorganize_variable(arr)

    assert result.dims == (
        "realization",
        "valid_time",
        "pressure_level",
        "latitude",
        "longitude",
    )


def test_create_output_dataset_copies_attrs(converter):
    ds = xr.Dataset(attrs={"source": "mock"})
    out = converter.create_output_dataset(ds)
    assert out.attrs["source"] == "mock"
    assert len(out.data_vars) == 0
