# requirements: numpy==1.24.4 eccodes==1.7.1 xarray==2024.9.0 cf_xarray==0.10.0 cfgrib==0.9.14.1 netcdf4==1.7.2

from unittest.mock import patch
import pytest
import xarray as xr
from pathlib import Path
import shutil
import datetime


def append_to_sys_path(folder: str, base_folder: str = "weather_bundle") -> str:
    """
    Append the specified folder to the system path if it is not already present. Allows importing packages from the folder.
    """
    import re
    import os
    import sys

    if not (match := re.search(rf"(.*[\\/]{base_folder})", os.getcwd())):
        raise Exception(f"Could not find {base_folder} in current path: {os.getcwd()}")

    base_path = match.group(1)
    for root, dirs, _ in os.walk(base_path):
        if "src" in dirs:
            base_path = root
            break

    path = os.path.join(base_path, folder)
    if path not in sys.path:
        sys.path.append(path)
    return path


append_to_sys_path("src/config")
append_to_sys_path("src/weather_package")

from grib2netcdf.era5_converter import ERA5Grib2NetCDFConverter


INPUT_RAW_DATA_1VT = {
    "coords": {
        "number": {
            "dims": (),
            "attrs": {
                "long_name": "ensemble member numerical id",
                "units": "1",
                "standard_name": "realization",
            },
            "data": 0,
        },
        "time": {
            "dims": ("time",),
            "attrs": {
                "long_name": "initial time of forecast",
                "standard_name": "forecast_reference_time",
            },
            "data": [
                datetime.datetime(2025, 3, 5, 0, 0),
                datetime.datetime(2025, 3, 5, 1, 0),
                datetime.datetime(2025, 3, 5, 2, 0),
                datetime.datetime(2025, 3, 5, 3, 0),
                datetime.datetime(2025, 3, 5, 4, 0),
                datetime.datetime(2025, 3, 5, 5, 0),
                datetime.datetime(2025, 3, 5, 6, 0),
                datetime.datetime(2025, 3, 5, 7, 0),
                datetime.datetime(2025, 3, 5, 8, 0),
                datetime.datetime(2025, 3, 5, 9, 0),
                datetime.datetime(2025, 3, 5, 10, 0),
                datetime.datetime(2025, 3, 5, 11, 0),
                datetime.datetime(2025, 3, 5, 12, 0),
                datetime.datetime(2025, 3, 5, 13, 0),
                datetime.datetime(2025, 3, 5, 14, 0),
                datetime.datetime(2025, 3, 5, 15, 0),
                datetime.datetime(2025, 3, 5, 16, 0),
                datetime.datetime(2025, 3, 5, 17, 0),
                datetime.datetime(2025, 3, 5, 18, 0),
                datetime.datetime(2025, 3, 5, 19, 0),
                datetime.datetime(2025, 3, 5, 20, 0),
                datetime.datetime(2025, 3, 5, 21, 0),
                datetime.datetime(2025, 3, 5, 22, 0),
                datetime.datetime(2025, 3, 5, 23, 0),
            ],
        },
        "step": {
            "dims": (),
            "attrs": {
                "long_name": "time since forecast_reference_time",
                "standard_name": "forecast_period",
            },
            "data": datetime.timedelta(0),
        },
        "surface": {
            "dims": (),
            "attrs": {
                "long_name": "original GRIB coordinate for key: level(surface)",
                "units": "1",
            },
            "data": 0.0,
        },
        "latitude": {
            "dims": ("latitude",),
            "attrs": {
                "units": "degrees_north",
                "standard_name": "latitude",
                "long_name": "latitude",
                "stored_direction": "decreasing",
            },
            "data": [53.0, 52.75],
        },
        "longitude": {
            "dims": ("longitude",),
            "attrs": {
                "units": "degrees_east",
                "standard_name": "longitude",
                "long_name": "longitude",
            },
            "data": [13.0, 13.25],
        },
        "valid_time": {
            "dims": ("time",),
            "attrs": {"standard_name": "time", "long_name": "time"},
            "data": [
                datetime.datetime(2025, 3, 5, 0, 0),
                datetime.datetime(2025, 3, 5, 1, 0),
                datetime.datetime(2025, 3, 5, 2, 0),
                datetime.datetime(2025, 3, 5, 3, 0),
                datetime.datetime(2025, 3, 5, 4, 0),
                datetime.datetime(2025, 3, 5, 5, 0),
                datetime.datetime(2025, 3, 5, 6, 0),
                datetime.datetime(2025, 3, 5, 7, 0),
                datetime.datetime(2025, 3, 5, 8, 0),
                datetime.datetime(2025, 3, 5, 9, 0),
                datetime.datetime(2025, 3, 5, 10, 0),
                datetime.datetime(2025, 3, 5, 11, 0),
                datetime.datetime(2025, 3, 5, 12, 0),
                datetime.datetime(2025, 3, 5, 13, 0),
                datetime.datetime(2025, 3, 5, 14, 0),
                datetime.datetime(2025, 3, 5, 15, 0),
                datetime.datetime(2025, 3, 5, 16, 0),
                datetime.datetime(2025, 3, 5, 17, 0),
                datetime.datetime(2025, 3, 5, 18, 0),
                datetime.datetime(2025, 3, 5, 19, 0),
                datetime.datetime(2025, 3, 5, 20, 0),
                datetime.datetime(2025, 3, 5, 21, 0),
                datetime.datetime(2025, 3, 5, 22, 0),
                datetime.datetime(2025, 3, 5, 23, 0),
            ],
        },
    },
    "attrs": {
        "GRIB_edition": 1,
        "GRIB_centre": "ecmf",
        "GRIB_centreDescription": "European Centre for Medium-Range Weather Forecasts",
        "GRIB_subCentre": 0,
        "Conventions": "CF-1.7",
        "institution": "European Centre for Medium-Range Weather Forecasts",
        "history": '2025-04-08T10:15 GRIB to CDM+CF via cfgrib-0.9.14.1/ecCodes-2.40.1 with {"source": "../../../../../../../../../Volumes/cdp_prd_sandbox_catalog_01/weather_bronze/bronze/era5_dummy/20250305_100m_u_component_of_wind.grib", "filter_by_keys": {}, "encode_cf": ["parameter", "time", "geography", "vertical"]}',
    },
    "dims": {"time": 24, "latitude": 2, "longitude": 2},
    "data_vars": {
        "u100": {
            "dims": ("time", "latitude", "longitude"),
            "attrs": {
                "GRIB_paramId": 228246,
                "GRIB_dataType": "an",
                "GRIB_numberOfPoints": 1038240,
                "GRIB_typeOfLevel": "surface",
                "GRIB_stepUnits": 1,
                "GRIB_stepType": "instant",
                "GRIB_gridType": "regular_ll",
                "GRIB_uvRelativeToGrid": 0,
                "GRIB_NV": 0,
                "GRIB_Nx": 1440,
                "GRIB_Ny": 721,
                "GRIB_cfName": "unknown",
                "GRIB_cfVarName": "u100",
                "GRIB_gridDefinitionDescription": "Latitude/Longitude Grid",
                "GRIB_iDirectionIncrementInDegrees": 0.25,
                "GRIB_iScansNegatively": 0,
                "GRIB_jDirectionIncrementInDegrees": 0.25,
                "GRIB_jPointsAreConsecutive": 0,
                "GRIB_jScansPositively": 0,
                "GRIB_latitudeOfFirstGridPointInDegrees": 90.0,
                "GRIB_latitudeOfLastGridPointInDegrees": -90.0,
                "GRIB_longitudeOfFirstGridPointInDegrees": 0.0,
                "GRIB_longitudeOfLastGridPointInDegrees": 359.75,
                "GRIB_missingValue": 3.4028234663852886e38,
                "GRIB_name": "100 metre U wind component",
                "GRIB_shortName": "100u",
                "GRIB_totalNumber": 0,
                "GRIB_units": "m s**-1",
                "long_name": "100 metre U wind component",
                "units": "m s**-1",
                "standard_name": "unknown",
            },
            "data": [
                [
                    [6.964141845703125, 7.099884033203125],
                    [6.513946533203125, 6.633087158203125],
                ],
                [
                    [6.99908447265625, 7.14166259765625],
                    [6.63482666015625, 6.74224853515625],
                ],
                [
                    [7.24468994140625, 7.42535400390625],
                    [6.97320556640625, 7.10992431640625],
                ],
                [
                    [7.389495849609375, 7.593597412109375],
                    [7.122894287109375, 7.278167724609375],
                ],
                [
                    [7.492034912109375, 7.736175537109375],
                    [7.113128662109375, 7.304534912109375],
                ],
                [
                    [7.524871826171875, 7.755340576171875],
                    [7.061981201171875, 7.247528076171875],
                ],
                [[7.569091796875, 7.772216796875], [7.041748046875, 7.199951171875]],
                [
                    [7.3763885498046875, 7.5873260498046875],
                    [6.7357635498046875, 6.8968963623046875],
                ],
                [
                    [7.5469970703125, 7.8135986328125],
                    [6.6075439453125, 6.8370361328125],
                ],
                [
                    [6.2215576171875, 6.5203857421875],
                    [5.5750732421875, 5.8231201171875],
                ],
                [
                    [5.5285186767578125, 5.8185577392578125],
                    [4.8117218017578125, 5.0636749267578125],
                ],
                [
                    [6.107391357421875, 6.374969482421875],
                    [5.408172607421875, 5.640594482421875],
                ],
                [
                    [6.291107177734375, 6.544036865234375],
                    [5.623138427734375, 5.836029052734375],
                ],
                [
                    [6.2699432373046875, 6.4574432373046875],
                    [5.7328338623046875, 5.9027557373046875],
                ],
                [
                    [5.647125244140625, 6.003570556640625],
                    [5.331695556640625, 5.537750244140625],
                ],
                [
                    [6.29742431640625, 6.63726806640625],
                    [5.54351806640625, 5.85113525390625],
                ],
                [
                    [6.6173248291015625, 6.9405670166015625],
                    [5.8868560791015625, 6.1749420166015625],
                ],
                [
                    [6.926483154296875, 7.233123779296875],
                    [6.333709716796875, 6.598358154296875],
                ],
                [
                    [7.22271728515625, 7.50201416015625],
                    [6.66021728515625, 6.90240478515625],
                ],
                [
                    [7.31451416015625, 7.57525634765625],
                    [6.69244384765625, 6.92486572265625],
                ],
                [
                    [7.0905609130859375, 7.3425140380859375],
                    [6.4440765380859375, 6.6764984130859375],
                ],
                [
                    [6.551727294921875, 6.804656982421875],
                    [5.989227294921875, 6.214813232421875],
                ],
                [
                    [6.3308258056640625, 6.5896148681640625],
                    [5.8415679931640625, 6.0642242431640625],
                ],
                [[6.033447265625, 6.261962890625], [5.547119140625, 5.738525390625]],
            ],
        }
    },
}


INPUT_RAW_DATA_2VT = {
    "coords": {
        "number": {
            "dims": (),
            "attrs": {
                "long_name": "ensemble member numerical id",
                "units": "1",
                "standard_name": "realization",
            },
            "data": 0,
        },
        "time": {
            "dims": ("time",),
            "attrs": {
                "long_name": "initial time of forecast",
                "standard_name": "forecast_reference_time",
            },
            "data": [
                datetime.datetime(2025, 3, 4, 18, 0),
                datetime.datetime(2025, 3, 5, 6, 0),
                datetime.datetime(2025, 3, 5, 18, 0),
            ],
        },
        "step": {
            "dims": ("step",),
            "attrs": {
                "long_name": "time since forecast_reference_time",
                "standard_name": "forecast_period",
            },
            "data": [
                datetime.timedelta(seconds=3600),
                datetime.timedelta(seconds=7200),
                datetime.timedelta(seconds=10800),
                datetime.timedelta(seconds=14400),
                datetime.timedelta(seconds=18000),
                datetime.timedelta(seconds=21600),
                datetime.timedelta(seconds=25200),
                datetime.timedelta(seconds=28800),
                datetime.timedelta(seconds=32400),
                datetime.timedelta(seconds=36000),
                datetime.timedelta(seconds=39600),
                datetime.timedelta(seconds=43200),
            ],
        },
        "surface": {
            "dims": (),
            "attrs": {
                "long_name": "original GRIB coordinate for key: level(surface)",
                "units": "1",
            },
            "data": 0.0,
        },
        "latitude": {
            "dims": ("latitude",),
            "attrs": {
                "units": "degrees_north",
                "standard_name": "latitude",
                "long_name": "latitude",
                "stored_direction": "decreasing",
            },
            "data": [51.0, 50.75, 50.5],
        },
        "longitude": {
            "dims": ("longitude",),
            "attrs": {
                "units": "degrees_east",
                "standard_name": "longitude",
                "long_name": "longitude",
            },
            "data": [9.5, 9.75, 10.0],
        },
        "valid_time": {
            "dims": ("time", "step"),
            "attrs": {"standard_name": "time", "long_name": "time"},
            "data": [
                [
                    datetime.datetime(2025, 3, 4, 19, 0),
                    datetime.datetime(2025, 3, 4, 20, 0),
                    datetime.datetime(2025, 3, 4, 21, 0),
                    datetime.datetime(2025, 3, 4, 22, 0),
                    datetime.datetime(2025, 3, 4, 23, 0),
                    datetime.datetime(2025, 3, 5, 0, 0),
                    datetime.datetime(2025, 3, 5, 1, 0),
                    datetime.datetime(2025, 3, 5, 2, 0),
                    datetime.datetime(2025, 3, 5, 3, 0),
                    datetime.datetime(2025, 3, 5, 4, 0),
                    datetime.datetime(2025, 3, 5, 5, 0),
                    datetime.datetime(2025, 3, 5, 6, 0),
                ],
                [
                    datetime.datetime(2025, 3, 5, 7, 0),
                    datetime.datetime(2025, 3, 5, 8, 0),
                    datetime.datetime(2025, 3, 5, 9, 0),
                    datetime.datetime(2025, 3, 5, 10, 0),
                    datetime.datetime(2025, 3, 5, 11, 0),
                    datetime.datetime(2025, 3, 5, 12, 0),
                    datetime.datetime(2025, 3, 5, 13, 0),
                    datetime.datetime(2025, 3, 5, 14, 0),
                    datetime.datetime(2025, 3, 5, 15, 0),
                    datetime.datetime(2025, 3, 5, 16, 0),
                    datetime.datetime(2025, 3, 5, 17, 0),
                    datetime.datetime(2025, 3, 5, 18, 0),
                ],
                [
                    datetime.datetime(2025, 3, 5, 19, 0),
                    datetime.datetime(2025, 3, 5, 20, 0),
                    datetime.datetime(2025, 3, 5, 21, 0),
                    datetime.datetime(2025, 3, 5, 22, 0),
                    datetime.datetime(2025, 3, 5, 23, 0),
                    datetime.datetime(2025, 3, 6, 0, 0),
                    datetime.datetime(2025, 3, 6, 1, 0),
                    datetime.datetime(2025, 3, 6, 2, 0),
                    datetime.datetime(2025, 3, 6, 3, 0),
                    datetime.datetime(2025, 3, 6, 4, 0),
                    datetime.datetime(2025, 3, 6, 5, 0),
                    datetime.datetime(2025, 3, 6, 6, 0),
                ],
            ],
        },
    },
    "attrs": {
        "GRIB_edition": 1,
        "GRIB_centre": "ecmf",
        "GRIB_centreDescription": "European Centre for Medium-Range Weather Forecasts",
        "GRIB_subCentre": 0,
        "Conventions": "CF-1.7",
        "institution": "European Centre for Medium-Range Weather Forecasts",
        "history": '2025-05-07T10:41 GRIB to CDM+CF via cfgrib-0.9.14.1/ecCodes-2.41.0 with {"source": "../../../../../../../../../Volumes/cdp_prd_sandbox_catalog_01/weather_bronze/bronze/era5_dummy/20250305_maximum_2m_temperature_since_previous_post_processing.grib", "filter_by_keys": {}, "encode_cf": ["parameter", "time", "geography", "vertical"]}',
    },
    "dims": {"time": 3, "step": 12, "latitude": 3, "longitude": 3},
    "data_vars": {
        "mx2t": {
            "dims": ("time", "step", "latitude", "longitude"),
            "attrs": {
                "GRIB_paramId": 201,
                "GRIB_dataType": "fc",
                "GRIB_numberOfPoints": 1038240,
                "GRIB_typeOfLevel": "surface",
                "GRIB_stepUnits": 1,
                "GRIB_stepType": "max",
                "GRIB_gridType": "regular_ll",
                "GRIB_uvRelativeToGrid": 0,
                "GRIB_NV": 0,
                "GRIB_Nx": 1440,
                "GRIB_Ny": 721,
                "GRIB_cfName": "unknown",
                "GRIB_cfVarName": "mx2t",
                "GRIB_gridDefinitionDescription": "Latitude/Longitude Grid",
                "GRIB_iDirectionIncrementInDegrees": 0.25,
                "GRIB_iScansNegatively": 0,
                "GRIB_jDirectionIncrementInDegrees": 0.25,
                "GRIB_jPointsAreConsecutive": 0,
                "GRIB_jScansPositively": 0,
                "GRIB_latitudeOfFirstGridPointInDegrees": 90.0,
                "GRIB_latitudeOfLastGridPointInDegrees": -90.0,
                "GRIB_longitudeOfFirstGridPointInDegrees": 0.0,
                "GRIB_longitudeOfLastGridPointInDegrees": 359.75,
                "GRIB_missingValue": 3.4028234663852886e38,
                "GRIB_name": "Maximum temperature at 2 metres since previous post-processing",
                "GRIB_shortName": "mx2t",
                "GRIB_totalNumber": 0,
                "GRIB_units": "K",
                "long_name": "Maximum temperature at 2 metres since previous post-processing",
                "units": "K",
                "standard_name": "unknown",
            },
            "data": [
                [
                    [[None, None, None], [None, None, None], [None, None, None]],
                    [[None, None, None], [None, None, None], [None, None, None]],
                    [[None, None, None], [None, None, None], [None, None, None]],
                    [[None, None, None], [None, None, None], [None, None, None]],
                    [[None, None, None], [None, None, None], [None, None, None]],
                    [
                        [272.1742858886719, 272.2738952636719, 272.2621765136719],
                        [272.7680358886719, 273.2934265136719, 273.7055358886719],
                        [271.7270202636719, 272.3969421386719, 273.3207702636719],
                    ],
                    [
                        [273.357666015625, 272.410400390625, 271.404541015625],
                        [272.228759765625, 272.804931640625, 273.308837890625],
                        [273.592041015625, 273.672119140625, 272.953369140625],
                    ],
                    [
                        [274.7164306640625, 273.1343994140625, 270.6129150390625],
                        [271.9508056640625, 272.4273681640625, 272.7672119140625],
                        [273.8902587890625, 274.0601806640625, 273.9312744140625],
                    ],
                    [
                        [274.4200134277344, 272.8692321777344, 270.3848571777344],
                        [271.6094665527344, 271.9825134277344, 272.2969665527344],
                        [273.5528259277344, 273.9043884277344, 274.5625915527344],
                    ],
                    [
                        [272.34405517578125, 271.25421142578125, 270.07843017578125],
                        [271.23858642578125, 271.57452392578125, 271.98663330078125],
                        [273.83233642578125, 274.24835205078125, 275.09600830078125],
                    ],
                    [
                        [270.62554931640625, 270.31890869140625, 270.26812744140625],
                        [271.08843994140625, 271.57867431640625, 272.14508056640625],
                        [273.65875244140625, 274.20758056640625, 275.00640869140625],
                    ],
                    [
                        [270.41357421875, 270.57177734375, 270.65185546875],
                        [271.30419921875, 271.97998046875, 272.53466796875],
                        [272.67333984375, 273.58935546875, 274.89599609375],
                    ],
                ],
                [
                    [
                        [272.64764404296875, 272.80389404296875, 272.86053466796875],
                        [273.03240966796875, 273.36639404296875, 273.55389404296875],
                        [272.14959716796875, 272.58123779296875, 273.08514404296875],
                    ],
                    [
                        [275.8693542480469, 276.0412292480469, 276.1545104980469],
                        [276.3068542480469, 276.4435729980469, 276.4631042480469],
                        [275.8654479980469, 275.9357604980469, 275.7560729980469],
                    ],
                    [
                        [278.8763732910156, 279.0345764160156, 279.1537170410156],
                        [279.4603576660156, 279.5423889160156, 279.4779357910156],
                        [279.2337951660156, 279.2025451660156, 278.7845764160156],
                    ],
                    [
                        [281.14044189453125, 281.28106689453125, 281.37677001953125],
                        [281.62872314453125, 281.74200439453125, 281.68731689453125],
                        [281.34161376953125, 281.34356689453125, 280.94708251953125],
                    ],
                    [
                        [282.626953125, 282.8046875, 282.974609375],
                        [282.9765625, 283.1484375, 283.201171875],
                        [282.61328125, 282.693359375, 282.470703125],
                    ],
                    [
                        [283.5916748046875, 283.7889404296875, 283.9998779296875],
                        [283.8240966796875, 283.9998779296875, 284.0975341796875],
                        [283.4100341796875, 283.5057373046875, 283.3631591796875],
                    ],
                    [
                        [284.0689697265625, 284.2701416015625, 284.4908447265625],
                        [284.2330322265625, 284.4029541015625, 284.5220947265625],
                        [283.7877197265625, 283.8853759765625, 283.7857666015625],
                    ],
                    [
                        [284.146240234375, 284.347412109375, 284.564208984375],
                        [284.282958984375, 284.443115234375, 284.556396484375],
                        [283.825927734375, 283.915771484375, 283.808349609375],
                    ],
                    [
                        [284.06060791015625, 284.25201416015625, 284.45513916015625],
                        [284.15631103515625, 284.28326416015625, 284.36334228515625],
                        [283.66217041015625, 283.72076416015625, 283.58795166015625],
                    ],
                    [
                        [283.52142333984375, 283.67962646484375, 283.82025146484375],
                        [283.33197021484375, 283.32220458984375, 283.26947021484375],
                        [282.81829833984375, 282.74603271484375, 282.49017333984375],
                    ],
                    [
                        [281.3694152832031, 281.3928527832031, 281.3225402832031],
                        [280.5705871582031, 280.5256652832031, 280.5315246582031],
                        [279.7639465332031, 279.7405090332031, 279.8459777832031],
                    ],
                    [
                        [276.7205810546875, 276.7049560546875, 276.4803466796875],
                        [275.9139404296875, 276.3826904296875, 276.9686279296875],
                        [275.1795654296875, 275.6424560546875, 276.3768310546875],
                    ],
                ],
                [
                    [
                        [275.81024169921875, 275.78875732421875, 275.65008544921875],
                        [276.03289794921875, 276.13055419921875, 276.09539794921875],
                        [275.14227294921875, 275.49969482421875, 276.26727294921875],
                    ],
                    [
                        [274.82501220703125, 274.79376220703125, 274.54376220703125],
                        [274.52423095703125, 275.02032470703125, 275.52618408203125],
                        [274.22149658203125, 274.59844970703125, 274.89727783203125],
                    ],
                    [
                        [273.6299133300781, 273.5869445800781, 273.3584289550781],
                        [273.9599914550781, 274.4717102050781, 274.8857727050781],
                        [273.5654602050781, 274.0459289550781, 274.4912414550781],
                    ],
                    [
                        [272.93365478515625, 272.91607666015625, 272.77935791015625],
                        [273.68951416015625, 274.23638916015625, 274.64849853515625],
                        [273.25006103515625, 273.78521728515625, 274.28717041015625],
                    ],
                    [
                        [272.6619873046875, 272.6502685546875, 272.4842529296875],
                        [273.5408935546875, 274.1346435546875, 274.5526123046875],
                        [273.2088623046875, 273.7440185546875, 274.1072998046875],
                    ],
                    [[None, None, None], [None, None, None], [None, None, None]],
                    [[None, None, None], [None, None, None], [None, None, None]],
                    [[None, None, None], [None, None, None], [None, None, None]],
                    [[None, None, None], [None, None, None], [None, None, None]],
                    [[None, None, None], [None, None, None], [None, None, None]],
                    [[None, None, None], [None, None, None], [None, None, None]],
                    [[None, None, None], [None, None, None], [None, None, None]],
                ],
            ],
        }
    },
}


# input grib data with valid time of shape 1 (forecast_reference_time)
INPUT_GRIB_DATA_1VT = xr.Dataset.from_dict(INPUT_RAW_DATA_1VT)

# input grib data with valid time of shape 2 (forecast_reference_time x leadtime)
INPUT_GRIB_DATA_2VT = xr.Dataset.from_dict(INPUT_RAW_DATA_2VT)

OUTPUT_NC_DATA_LIST = {
    "ERA5SH_0p25_u100_2025030500.nc": {'coords': {'forecast_reference_time': {'dims': (), 'attrs': {}, 'data': datetime.datetime(2025, 3, 4, 18, 0)}, 'leadtime': {'dims': (), 'attrs': {}, 'data': datetime.timedelta(seconds=21600)}, 'surface': {'dims': (), 'attrs': {'long_name': 'original GRIB coordinate for key: level(surface)', 'units': '1'}, 'data': 0.0}, 'valid_time': {'dims': ('valid_time',), 'attrs': {}, 'data': [datetime.datetime(2025, 3, 5, 0, 0)]}, 'latitude': {'dims': ('latitude',), 'attrs': {'units': 'degrees_north', 'standard_name': 'latitude', 'long_name': 'latitude', 'stored_direction': 'decreasing', 'bounds': 'latitude_bounds'}, 'data': [52.75, 53.0]}, 'longitude': {'dims': ('longitude',), 'attrs': {'units': 'degrees_east', 'standard_name': 'longitude', 'long_name': 'longitude', 'bounds': 'longitude_bounds'}, 'data': [13.0, 13.25]}}, 'attrs': {'Conventions': 'CF-1.7', 'institution': 'Copernicus Climate Change Service (C3S)', 'history': '2025-04-08T10:15 GRIB to CDM+CF via cfgrib-0.9.14.1/ecCodes-2.40.1 with {"source": "../../../../../../../../../Volumes/cdp_prd_sandbox_catalog_01/weather_bronze/bronze/era5_dummy/20250305_100m_u_component_of_wind.grib", "filter_by_keys": {}, "encode_cf": ["parameter", "time", "geography", "vertical"]}', 'provider': 'Copernicus C3S', 'provider_shortname': 'C3S', 'product': 'ERA5 Single Hourly', 'alias': 'ERA5 Single Hourly', 'description': 'ERA5 Single Hourly', 'short_name': 'ERA5SH', 'run_frequency': '', 'schedule': '', 'forecast_reference_time': '2025-03-04T18:00:00'}, 'dims': {'valid_time': 1, 'latitude': 2, 'longitude': 2, 'bounds': 2}, 'data_vars': {'u100': {'dims': ('valid_time', 'latitude', 'longitude'), 'attrs': {'long_name': '100 meter eastward wind speed', 'units': 'm s-1', 'standard_name': 'eastward_wind', 'title': 'eastward / zonal wind speed at 100 meter', 'out_name': 'u100', 'modeling_realm': 'atmos', 'cell_methods': 'area: mean time: point', 'dimensions': 'longitude latitude time height100m', 'type': 'real', 'positive': '', 'valid_min': '', 'valid_max': ''}, 'data': [[[6.513946533203125, 6.633087158203125], [6.964141845703125, 7.099884033203125]]]}, 'latitude_bounds': {'dims': ('latitude', 'bounds'), 'attrs': {}, 'data': [[52.625, 52.875], [52.875, 53.125]]}, 'longitude_bounds': {'dims': ('longitude', 'bounds'), 'attrs': {}, 'data': [[12.875, 13.125], [13.125, 13.375]]}}},
    "ERA5SH_0p25_tasmax_2025030500.nc":  {'coords': {'surface': {'dims': (), 'attrs': {'long_name': 'original GRIB coordinate for key: level(surface)', 'units': '1'}, 'data': 0.0}, 'valid_time': {'dims': ('valid_time',), 'attrs': {}, 'data': [datetime.datetime(2025, 3, 5, 0, 0)]}, 'latitude': {'dims': ('latitude',), 'attrs': {'units': 'degrees_north', 'standard_name': 'latitude', 'long_name': 'latitude', 'stored_direction': 'decreasing', 'bounds': 'latitude_bounds'}, 'data': [50.5, 50.75, 51.0]}, 'longitude': {'dims': ('longitude',), 'attrs': {'units': 'degrees_east', 'standard_name': 'longitude', 'long_name': 'longitude', 'bounds': 'longitude_bounds'}, 'data': [9.5, 9.75, 10.0]}, 'forecast_reference_time': {'dims': (), 'attrs': {}, 'data': datetime.datetime(2025, 3, 4, 18, 0)}, 'leadtime': {'dims': (), 'attrs': {}, 'data': datetime.timedelta(seconds=21600)}, 'bounds': {'dims': ('bounds',), 'attrs': {}, 'data': [0, 1]}}, 'attrs': {'Conventions': 'CF-1.7', 'institution': 'Copernicus Climate Change Service (C3S)', 'history': '2025-05-07T10:41 GRIB to CDM+CF via cfgrib-0.9.14.1/ecCodes-2.41.0 with {"source": "../../../../../../../../../Volumes/cdp_prd_sandbox_catalog_01/weather_bronze/bronze/era5_dummy/20250305_maximum_2m_temperature_since_previous_post_processing.grib", "filter_by_keys": {}, "encode_cf": ["parameter", "time", "geography", "vertical"]}', 'provider': 'Copernicus C3S', 'provider_shortname': 'C3S', 'product': 'ERA5 Single Hourly', 'alias': 'ERA5 Single Hourly', 'description': 'ERA5 Single Hourly', 'short_name': 'ERA5SH', 'run_frequency': '', 'schedule': '', 'forecast_reference_time': '2025-03-04T18:00:00'}, 'dims': {'valid_time': 1, 'latitude': 3, 'longitude': 3, 'bounds': 2}, 'data_vars': {'tasmax': {'dims': ('valid_time', 'latitude', 'longitude'), 'attrs': {'long_name': 'Near-Surface Maximum Air Temperature', 'units': 'K', 'standard_name': 'air_temperature', 'title': 'Max of surface air temperature / 2m air temperature or similar', 'out_name': 'tasmax', 'modeling_realm': 'atmos', 'cell_methods': 'area: mean time: maximum', 'accumulation_period_start': 'valid_time_minus_one_hour', 'accumulation_period_stop': 'valid_time', 'comment': 'near-surface (usually 2 meter) maximum air temperature', 'dimensions': 'longitude latitude time height2m', 'type': 'real', 'positive': '', 'valid_min': '', 'valid_max': ''}, 'data': [[[271.7270202636719, 272.3969421386719, 273.3207702636719], [272.7680358886719, 273.2934265136719, 273.7055358886719], [272.1742858886719, 272.2738952636719, 272.2621765136719]]]}, 'latitude_bounds': {'dims': ('latitude', 'bounds'), 'attrs': {}, 'data': [[50.375, 50.625], [50.625, 50.875], [50.875, 51.125]]}, 'longitude_bounds': {'dims': ('longitude', 'bounds'), 'attrs': {}, 'data': [[9.375, 9.625], [9.625, 9.875], [9.875, 10.125]]}, 'valid_time_bounds': {'dims': ('valid_time', 'bounds'), 'attrs': {}, 'data': [[datetime.datetime(2025, 3, 4, 23, 0), datetime.datetime(2025, 3, 5, 0, 0)]]}}},
}
for key, val in OUTPUT_NC_DATA_LIST.items():
    OUTPUT_NC_DATA_LIST[key] = xr.Dataset.from_dict(val)


@pytest.fixture
def mock_xarray_open_dataset_1vt(mocker):
    mocker.patch("xarray.open_dataset", return_value=INPUT_GRIB_DATA_1VT)


@pytest.fixture
def mock_xarray_open_dataset_2vt(mocker):
    mocker.patch("xarray.open_dataset", return_value=INPUT_GRIB_DATA_2VT)


@pytest.fixture
def converter():
    return ERA5Grib2NetCDFConverter()


@pytest.fixture
def mock_shutil_copy(mocker):
    mocker.patch("shutil.copy")


written_file_names = {}


def mock_write_to_netcdf(self, file_path, *args, **kwargs):
    file_name = Path(file_path).name
    if file_name in OUTPUT_NC_DATA_LIST.keys():
        pref = "_".join(file_name.split("_")[:-1])
        written_file_names.setdefault(pref, []).append(file_name)
        # raise RuntimeError(f"{self}\n\n{OUTPUT_NC_DATA_LIST.get(file_name)}")
        assert self.equals(OUTPUT_NC_DATA_LIST.get(file_name))


def test_convert_1vt(
    converter,
    mock_xarray_open_dataset_1vt,
    mock_shutil_copy,
):
    category = "single_hourly"
    with patch.object(xr.Dataset, "to_netcdf", mock_write_to_netcdf):
        converter.convert(
            "src_path/20250305_100m_u_component_of_wind.grib", "target_path", category
        )

    assert len(written_file_names["ERA5SH_0p25_u100"]) == 1
    shutil.copy.assert_called()


def test_convert_2vt(
    converter,
    mock_xarray_open_dataset_2vt,
    mock_shutil_copy,
):
    category = "single_hourly"
    with patch.object(xr.Dataset, "to_netcdf", mock_write_to_netcdf):
        converter.convert(
            "src_path/20250305_maximum_2m_temperature_since_previous_post_processing.grib",
            "target_path",
            category,
        )

    assert len(written_file_names["ERA5SH_0p25_tasmax"]) == 1
    shutil.copy.assert_called()