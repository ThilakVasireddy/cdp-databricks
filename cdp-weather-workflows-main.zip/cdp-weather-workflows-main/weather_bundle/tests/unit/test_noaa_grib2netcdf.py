# requirements: numpy==1.24.4 eccodes==1.7.1 xarray==2024.9.0 cf_xarray==0.10.0 cfgrib==0.9.14.1 netcdf4==1.7.2

from unittest.mock import patch
import pytest
import xarray as xr
from pathlib import Path
import shutil
import datetime


def append_to_sys_path(folder: str, base_folder: str = "weather_bundle") -> str:
    """
    Append the specified folder to the system path if it is not already present. Allows importing packages from the folder.
    """
    import re
    import os
    import sys

    if not (match := re.search(rf"(.*[\\/]{base_folder})", os.getcwd())):
        raise Exception(f"Could not find {base_folder} in current path: {os.getcwd()}")

    base_path = match.group(1)
    for root, dirs, _ in os.walk(base_path):
        if "src" in dirs:
            base_path = root
            break

    path = os.path.join(base_path, folder)
    if path not in sys.path:
        sys.path.append(path)
    return path


append_to_sys_path("src/config")
append_to_sys_path("src/weather_package")

from grib2netcdf.noaa_converter import NOAAGrib2NetCDFConverter


INPUT_RAW_GFS_DATA = {
    "coords": {
        "time": {
            "dims": (),
            "attrs": {
                "long_name": "initial time of forecast",
                "standard_name": "forecast_reference_time",
            },
            "data": datetime.datetime(2025, 4, 17, 0, 0),
        },
        "step": {
            "dims": (),
            "attrs": {
                "long_name": "time since forecast_reference_time",
                "standard_name": "forecast_period",
            },
            "data": datetime.timedelta(seconds=14400),
        },
        "heightAboveGround": {
            "dims": (),
            "attrs": {
                "long_name": "height above the surface",
                "units": "m",
                "positive": "up",
                "standard_name": "height",
            },
            "data": 100.0,
        },
        "latitude": {
            "dims": ("latitude",),
            "attrs": {
                "units": "degrees_north",
                "standard_name": "latitude",
                "long_name": "latitude",
                "stored_direction": "decreasing",
            },
            "data": [
                51.0,
                50.75,
                50.5,
                50.25,
                50.0,
                49.75,
                49.5,
                49.25,
                49.0,
                48.75,
                48.5,
                48.25,
                48.0,
            ],
        },
        "longitude": {
            "dims": ("longitude",),
            "attrs": {
                "units": "degrees_east",
                "standard_name": "longitude",
                "long_name": "longitude",
            },
            "data": [9.5, 9.75, 10.0, 10.25, 10.5, 10.75, 11.0],
        },
        "valid_time": {
            "dims": (),
            "attrs": {"standard_name": "time", "long_name": "time"},
            "data": datetime.datetime(2025, 4, 17, 4, 0),
        },
    },
    "attrs": {
        "GRIB_edition": 2,
        "GRIB_centre": "kwbc",
        "GRIB_centreDescription": "US National Weather Service - NCEP",
        "GRIB_subCentre": 0,
        "Conventions": "CF-1.7",
        "institution": "US National Weather Service - NCEP",
        "history": '2025-04-28T16:00 GRIB to CDM+CF via cfgrib-0.9.14.1/ecCodes-2.41.0 with {"source": "../../../../../../../../../Volumes/cdp_prd_sandbox_catalog_01/weather_bronze/bronze/noaa/operational/0p25/2025/04/17/00/gfs.t00z.pgrb2.0p25.f004", "filter_by_keys": {"shortName": "100u"}, "encode_cf": ["parameter", "time", "geography", "vertical"]}',
    },
    "dims": {"latitude": 13, "longitude": 7},
    "data_vars": {
        "u100": {
            "dims": ("latitude", "longitude"),
            "attrs": {
                "GRIB_paramId": 228246,
                "GRIB_dataType": "fc",
                "GRIB_numberOfPoints": 1038240,
                "GRIB_typeOfLevel": "heightAboveGround",
                "GRIB_stepUnits": 1,
                "GRIB_stepType": "instant",
                "GRIB_gridType": "regular_ll",
                "GRIB_uvRelativeToGrid": 0,
                "GRIB_NV": 0,
                "GRIB_Nx": 1440,
                "GRIB_Ny": 721,
                "GRIB_cfName": "eastward_wind",
                "GRIB_cfVarName": "u100",
                "GRIB_gridDefinitionDescription": "Latitude/longitude. Also called equidistant cylindrical, or Plate Carree",
                "GRIB_iDirectionIncrementInDegrees": 0.25,
                "GRIB_iScansNegatively": 0,
                "GRIB_jDirectionIncrementInDegrees": 0.25,
                "GRIB_jPointsAreConsecutive": 0,
                "GRIB_jScansPositively": 0,
                "GRIB_latitudeOfFirstGridPointInDegrees": 90.0,
                "GRIB_latitudeOfLastGridPointInDegrees": -90.0,
                "GRIB_longitudeOfFirstGridPointInDegrees": 0.0,
                "GRIB_longitudeOfLastGridPointInDegrees": 359.75,
                "GRIB_missingValue": 3.4028234663852886e38,
                "GRIB_name": "100 metre U wind component",
                "GRIB_shortName": "100u",
                "GRIB_units": "m s**-1",
                "long_name": "100 metre U wind component",
                "units": "m s**-1",
                "standard_name": "eastward_wind",
            },
            "data": [
                [
                    2.0061888694763184,
                    2.606189012527466,
                    2.206188917160034,
                    1.806188941001892,
                    2.106189012527466,
                    2.8061890602111816,
                    3.206188917160034,
                ],
                [
                    0.5061889886856079,
                    1.006188988685608,
                    1.006188988685608,
                    1.1061890125274658,
                    0.40618896484375,
                    0.0061889649368822575,
                    0.40618896484375,
                ],
                [
                    -0.39381104707717896,
                    0.5061889886856079,
                    0.8061889410018921,
                    0.706188976764679,
                    -0.893811047077179,
                    -1.3938109874725342,
                    -0.893811047077179,
                ],
                [
                    0.40618896484375,
                    0.706188976764679,
                    0.706188976764679,
                    0.8061889410018921,
                    -0.6938110589981079,
                    -1.8938109874725342,
                    -1.2938110828399658,
                ],
                [
                    1.806188941001892,
                    1.6061890125274658,
                    0.606188952922821,
                    0.0061889649368822575,
                    0.20618896186351776,
                    -0.4938110411167145,
                    -0.19381102919578552,
                ],
                [
                    2.706188917160034,
                    2.3061890602111816,
                    1.506188988685608,
                    0.706188976764679,
                    0.5061889886856079,
                    0.10618896782398224,
                    0.10618896782398224,
                ],
                [
                    4.40618896484375,
                    4.106188774108887,
                    4.40618896484375,
                    4.106188774108887,
                    3.106189012527466,
                    2.5061888694763184,
                    2.3061890602111816,
                ],
                [
                    5.90618896484375,
                    6.106188774108887,
                    5.806189060211182,
                    5.106188774108887,
                    4.40618896484375,
                    3.706188917160034,
                    3.106189012527466,
                ],
                [
                    6.40618896484375,
                    6.106188774108887,
                    5.606188774108887,
                    5.306189060211182,
                    4.40618896484375,
                    3.706188917160034,
                    3.106189012527466,
                ],
                [
                    4.706189155578613,
                    4.706189155578613,
                    5.206189155578613,
                    4.806189060211182,
                    3.706188917160034,
                    3.3061890602111816,
                    3.0061888694763184,
                ],
                [
                    3.3061890602111816,
                    4.40618896484375,
                    3.706188917160034,
                    2.90618896484375,
                    2.606189012527466,
                    2.706188917160034,
                    2.8061890602111816,
                ],
                [
                    2.206188917160034,
                    1.306188941001892,
                    1.6061890125274658,
                    2.5061888694763184,
                    2.8061890602111816,
                    2.40618896484375,
                    2.0061888694763184,
                ],
                [
                    0.706188976764679,
                    1.1061890125274658,
                    1.506188988685608,
                    2.0061888694763184,
                    2.5061888694763184,
                    2.5061888694763184,
                    2.0061888694763184,
                ],
            ],
        }
    },
}

INPUT_RAW_GEFS_DATA = {
    "coords": {
        "number": {
            "dims": (),
            "attrs": {
                "long_name": "ensemble member numerical id",
                "units": "1",
                "standard_name": "realization",
            },
            "data": 4,
        },
        "time": {
            "dims": (),
            "attrs": {
                "long_name": "initial time of forecast",
                "standard_name": "forecast_reference_time",
            },
            "data": datetime.datetime(2025, 6, 9, 12, 0),
        },
        "step": {
            "dims": (),
            "attrs": {
                "long_name": "time since forecast_reference_time",
                "standard_name": "forecast_period",
            },
            "data": datetime.timedelta(days=2, seconds=21600),
        },
        "surface": {
            "dims": (),
            "attrs": {
                "long_name": "original GRIB coordinate for key: level(surface)",
                "units": "1",
            },
            "data": 0.0,
        },
        "latitude": {
            "dims": ("latitude",),
            "attrs": {
                "units": "degrees_north",
                "standard_name": "latitude",
                "long_name": "latitude",
                "stored_direction": "decreasing",
            },
            "data": [70.0, 69.5],
        },
        "longitude": {
            "dims": ("longitude",),
            "attrs": {
                "units": "degrees_east",
                "standard_name": "longitude",
                "long_name": "longitude",
            },
            "data": [70.5, 71.0],
        },
        "valid_time": {
            "dims": (),
            "attrs": {"standard_name": "time", "long_name": "time"},
            "data": datetime.datetime(2025, 6, 11, 18, 0),
        },
    },
    "attrs": {
        "GRIB_edition": 2,
        "GRIB_centre": "kwbc",
        "GRIB_centreDescription": "US National Weather Service - NCEP",
        "GRIB_subCentre": 2,
        "Conventions": "CF-1.7",
        "institution": "US National Weather Service - NCEP",
        "history": '2025-06-09T16:50 GRIB to CDM+CF via cfgrib-0.9.14.1/ecCodes-2.41.0 with {"source": "../../../../../../../../../Volumes/cdp_prd_sandbox_catalog_01/weather_bronze/bronze/noaa/GEFS_pgrb2a_0p50/2025/06/09/12/gep04.t12z.pgrb2a.0p50.f054", "filter_by_keys": {"shortName": "sdswrf"}, "encode_cf": ["parameter", "time", "geography", "vertical"]}',
    },
    "dims": {"latitude": 2, "longitude": 2},
    "data_vars": {
        "sdswrf": {
            "dims": ("latitude", "longitude"),
            "attrs": {
                "GRIB_paramId": 260087,
                "GRIB_dataType": "pf",
                "GRIB_numberOfPoints": 259920,
                "GRIB_typeOfLevel": "surface",
                "GRIB_stepUnits": 1,
                "GRIB_stepType": "avg",
                "GRIB_gridType": "regular_ll",
                "GRIB_uvRelativeToGrid": 0,
                "GRIB_NV": 0,
                "GRIB_Nx": 720,
                "GRIB_Ny": 361,
                "GRIB_cfName": "unknown",
                "GRIB_cfVarName": "sdswrf",
                "GRIB_gridDefinitionDescription": "Latitude/longitude. Also called equidistant cylindrical, or Plate Carree",
                "GRIB_iDirectionIncrementInDegrees": 0.5,
                "GRIB_iScansNegatively": 0,
                "GRIB_jDirectionIncrementInDegrees": 0.5,
                "GRIB_jPointsAreConsecutive": 0,
                "GRIB_jScansPositively": 0,
                "GRIB_latitudeOfFirstGridPointInDegrees": 90.0,
                "GRIB_latitudeOfLastGridPointInDegrees": -90.0,
                "GRIB_longitudeOfFirstGridPointInDegrees": 0.0,
                "GRIB_longitudeOfLastGridPointInDegrees": 359.5,
                "GRIB_missingValue": 3.4028234663852886e38,
                "GRIB_name": "Surface downward short-wave radiation flux",
                "GRIB_shortName": "sdswrf",
                "GRIB_totalNumber": 30,
                "GRIB_units": "W m**-2",
                "long_name": "Surface downward short-wave radiation flux",
                "units": "W m**-2",
                "standard_name": "unknown",
            },
            "data": [[194.0, 189.0], [197.0, 193.0]],
        }
    },
}

INPUT_GRIB_GEFS_DATA = xr.Dataset.from_dict(INPUT_RAW_GEFS_DATA)

INPUT_GRIB_GFS_DATA = xr.Dataset.from_dict(INPUT_RAW_GFS_DATA)

OUTPUT_NC_DATA_LIST = {
    "GFSENS_0p50_ssrd_e004_2025060912z_2025061118z_h054.nc": {'coords': {'realization': {'dims': ('realization',), 'attrs': {}, 'data': [4]}, 'valid_time': {'dims': ('valid_time',), 'attrs': {}, 'data': [datetime.datetime(2025, 6, 11, 18, 0)]}, 'forecast_reference_time': {'dims': (), 'attrs': {'long_name': 'initial time of forecast', 'standard_name': 'forecast_reference_time'}, 'data': datetime.datetime(2025, 6, 9, 12, 0)}, 'leadtime': {'dims': (), 'attrs': {'long_name': 'time since forecast_reference_time', 'standard_name': 'forecast_period'}, 'data': datetime.timedelta(days=2, seconds=21600)}, 'surface': {'dims': (), 'attrs': {'long_name': 'original GRIB coordinate for key: level(surface)', 'units': '1'}, 'data': 0.0}, 'latitude': {'dims': ('latitude',), 'attrs': {'units': 'degrees_north', 'standard_name': 'latitude', 'long_name': 'latitude', 'stored_direction': 'decreasing', 'bounds': 'latitude_bounds'}, 'data': [69.5, 70.0]}, 'longitude': {'dims': ('longitude',), 'attrs': {'units': 'degrees_east', 'standard_name': 'longitude', 'long_name': 'longitude', 'bounds': 'longitude_bounds'}, 'data': [70.5, 71.0]}, 'bounds': {'dims': ('bounds',), 'attrs': {}, 'data': [0, 1]}}, 'attrs': {}, 'dims': {'realization': 1, 'valid_time': 1, 'latitude': 2, 'longitude': 2, 'bounds': 2}, 'data_vars': {'ssrd': {'dims': ('realization', 'valid_time', 'latitude', 'longitude'), 'attrs': {'long_name': 'Surface Downwelling Shortwave Radiation Flux averaged since previous synoptic time', 'units': 'W m-2', 'standard_name': 'surface_downwelling_shortwave_flux_in_air', 'title': 'Surface Downwelling Shortwave Radiation Flux', 'processing': 'accumulated', 'out_name': 'ssrd', 'modeling_realm': 'atmos', 'cell_methods': 'area: mean time: point', 'accumulation_period_start': 'valid_time_minus_mod_six', 'accumulation_period_stop': 'valid_time', 'comment': 'Instantaneous downwelling shortwave radiation at surface averaged since previous synoptic time', 'dimensions': 'longitude latitude time', 'type': 'real', 'positive': 'true', 'valid_min': 0, 'valid_max': ''}, 'data': [[[[197.0, 193.0], [194.0, 189.0]]]]}, 'latitude_bounds': {'dims': ('latitude', 'bounds'), 'attrs': {}, 'data': [[69.25, 69.75], [69.75, 70.25]]}, 'longitude_bounds': {'dims': ('longitude', 'bounds'), 'attrs': {}, 'data': [[70.25, 70.75], [70.75, 71.25]]}, 'valid_time_bounds': {'dims': ('valid_time', 'bounds'), 'attrs': {}, 'data': [[datetime.datetime(2025, 6, 11, 18, 0), datetime.datetime(2025, 6, 11, 18, 0)]]}}},
    "GFSOP_0p25_u100_2025041700z_2025041704z_h004.nc": {'coords': {'valid_time': {'dims': ('valid_time',), 'attrs': {}, 'data': [datetime.datetime(2025, 4, 17, 4, 0)]}, 'forecast_reference_time': {'dims': (), 'attrs': {'long_name': 'initial time of forecast', 'standard_name': 'forecast_reference_time'}, 'data': datetime.datetime(2025, 4, 17, 0, 0)}, 'leadtime': {'dims': (), 'attrs': {'long_name': 'time since forecast_reference_time', 'standard_name': 'forecast_period'}, 'data': datetime.timedelta(seconds=14400)}, 'heightAboveGround': {'dims': (), 'attrs': {'long_name': 'height above the surface', 'units': 'm', 'positive': 'up', 'standard_name': 'height'}, 'data': 100.0}, 'latitude': {'dims': ('latitude',), 'attrs': {'units': 'degrees_north', 'standard_name': 'latitude', 'long_name': 'latitude', 'stored_direction': 'decreasing', 'bounds': 'latitude_bounds'}, 'data': [48.0, 48.25, 48.5, 48.75, 49.0, 49.25, 49.5, 49.75, 50.0, 50.25, 50.5, 50.75, 51.0]}, 'longitude': {'dims': ('longitude',), 'attrs': {'units': 'degrees_east', 'standard_name': 'longitude', 'long_name': 'longitude', 'bounds': 'longitude_bounds'}, 'data': [9.5, 9.75, 10.0, 10.25, 10.5, 10.75, 11.0]}}, 'attrs': {'Conventions': 'CF-1.7', 'institution': 'National Oceanic and Atmospheric Administration', 'history': '2025-04-28T16:00 GRIB to CDM+CF via cfgrib-0.9.14.1/ecCodes-2.41.0 with {"source": "../../../../../../../../../Volumes/cdp_prd_sandbox_catalog_01/weather_bronze/bronze/noaa/operational/0p25/2025/04/17/00/gfs.t00z.pgrb2.0p25.f004", "filter_by_keys": {"shortName": "100u"}, "encode_cf": ["parameter", "time", "geography", "vertical"]}', 'provider': 'NOAA', 'provider_shortname': 'NOAA', 'run_frequency': '6h', 'schedule': '0;6;12;18', 'product': 'Global Forecast System operational grid', 'alias': 'gfsop', 'description': 'GFS operational', 'short_name': 'GFSOP', 'forecast_reference_time': '2025-04-17T00:00:00'}, 'dims': {'valid_time': 1, 'latitude': 13, 'longitude': 7, 'bounds': 2}, 'data_vars': {'u100': {'dims': ('valid_time', 'latitude', 'longitude'), 'attrs': {'long_name': '100 meter eastward wind speed', 'units': 'm s-1', 'standard_name': 'eastward_wind', 'title': 'eastward / zonal wind speed at 100 meter', 'out_name': 'u100', 'modeling_realm': 'atmos', 'cell_methods': 'area: mean time: point', 'dimensions': 'longitude latitude time height100m', 'type': 'real', 'positive': '', 'valid_min': '', 'valid_max': ''}, 'data': [[[0.706188976764679, 1.1061890125274658, 1.506188988685608, 2.0061888694763184, 2.5061888694763184, 2.5061888694763184, 2.0061888694763184], [2.206188917160034, 1.306188941001892, 1.6061890125274658, 2.5061888694763184, 2.8061890602111816, 2.40618896484375, 2.0061888694763184], [3.3061890602111816, 4.40618896484375, 3.706188917160034, 2.90618896484375, 2.606189012527466, 2.706188917160034, 2.8061890602111816], [4.706189155578613, 4.706189155578613, 5.206189155578613, 4.806189060211182, 3.706188917160034, 3.3061890602111816, 3.0061888694763184], [6.40618896484375, 6.106188774108887, 5.606188774108887, 5.306189060211182, 4.40618896484375, 3.706188917160034, 3.106189012527466], [5.90618896484375, 6.106188774108887, 5.806189060211182, 5.106188774108887, 4.40618896484375, 3.706188917160034, 3.106189012527466], [4.40618896484375, 4.106188774108887, 4.40618896484375, 4.106188774108887, 3.106189012527466, 2.5061888694763184, 2.3061890602111816], [2.706188917160034, 2.3061890602111816, 1.506188988685608, 0.706188976764679, 0.5061889886856079, 0.10618896782398224, 0.10618896782398224], [1.806188941001892, 1.6061890125274658, 0.606188952922821, 0.0061889649368822575, 0.20618896186351776, -0.4938110411167145, -0.19381102919578552], [0.40618896484375, 0.706188976764679, 0.706188976764679, 0.8061889410018921, -0.6938110589981079, -1.8938109874725342, -1.2938110828399658], [-0.39381104707717896, 0.5061889886856079, 0.8061889410018921, 0.706188976764679, -0.893811047077179, -1.3938109874725342, -0.893811047077179], [0.5061889886856079, 1.006188988685608, 1.006188988685608, 1.1061890125274658, 0.40618896484375, 0.0061889649368822575, 0.40618896484375], [2.0061888694763184, 2.606189012527466, 2.206188917160034, 1.806188941001892, 2.106189012527466, 2.8061890602111816, 3.206188917160034]]]}, 'latitude_bounds': {'dims': ('latitude', 'bounds'), 'attrs': {}, 'data': [[47.875, 48.125], [48.125, 48.375], [48.375, 48.625], [48.625, 48.875], [48.875, 49.125], [49.125, 49.375], [49.375, 49.625], [49.625, 49.875], [49.875, 50.125], [50.125, 50.375], [50.375, 50.625], [50.625, 50.875], [50.875, 51.125]]}, 'longitude_bounds': {'dims': ('longitude', 'bounds'), 'attrs': {}, 'data': [[9.375, 9.625], [9.625, 9.875], [9.875, 10.125], [10.125, 10.375], [10.375, 10.625], [10.625, 10.875], [10.875, 11.125]]}}},
}
for key, val in OUTPUT_NC_DATA_LIST.items():
    OUTPUT_NC_DATA_LIST[key] = xr.Dataset.from_dict(val)


@pytest.fixture
def mock_xarray_open_dataset_gfs(mocker):
    mocker.patch("xarray.open_dataset", return_value=INPUT_GRIB_GFS_DATA)


@pytest.fixture
def mock_xarray_open_dataset_gefs(mocker):
    mocker.patch("xarray.open_dataset", return_value=INPUT_GRIB_GEFS_DATA)


@pytest.fixture
def gfs_converter():
    return NOAAGrib2NetCDFConverter(product_family="GFS_pgrb2_0p25")


@pytest.fixture
def gefs_converter():
    return NOAAGrib2NetCDFConverter(product_family="GEFS_pgrb2a_0p50")


@pytest.fixture
def mock_shutil_copy(mocker):
    mocker.patch("shutil.copy")


written_file_names = {}


def mock_write_to_netcdf(self, file_path, *args, **kwargs):
    file_name = Path(file_path).name

    if file_name in OUTPUT_NC_DATA_LIST.keys():
        pref = file_name.split("_")[0]
        written_file_names.setdefault(pref, []).append(file_name)
        # raise RuntimeError(f"{self}\n\n{OUTPUT_NC_DATA_LIST.get(file_name)}")
        assert self.equals(OUTPUT_NC_DATA_LIST.get(file_name))


def test_gfs_convert(
    gfs_converter,
    mock_xarray_open_dataset_gfs,
    mock_shutil_copy,
):
    short_names = ["100u"]
    with patch.object(xr.Dataset, "to_netcdf", mock_write_to_netcdf):
        gfs_converter.convert(
            "src_path/noaa/GFS_pgrb2_0p25/2025/04/17/00/gfs.t00z.pgrb2.0p25.f004",
            "target_path",
            short_names,
        )

    assert len(written_file_names["GFSOP"]) == 1
    shutil.copy.assert_called()


def test_gefs_convert(
    gefs_converter,
    mock_xarray_open_dataset_gefs,
    mock_shutil_copy,
):
    short_names = ["sdswrf"]
    with patch.object(xr.Dataset, "to_netcdf", mock_write_to_netcdf):
        gefs_converter.convert(
            "src_path/noaa/operational/GEFS_pgrb2a_0p50/2025/06/09/12/gep04.t12z.pgrb2a.0p50.f054",
            "target_path",
            short_names,
        )

    assert len(written_file_names["GFSENS"]) == 1
    shutil.copy.assert_called()
