"""
This module contains unit tests for validating the consistency between YAML configuration files
and Python notebook scripts in a Databricks workflow. The tests ensure that all parameters
defined in the YAML files as `base_parameters` for notebook tasks have corresponding
`dbutils.widgets` setters and getters in the respective Python notebook scripts.

These tests help maintain the integrity of the workflow by ensuring that the YAML configuration
and the Python scripts are in sync, reducing the risk of runtime errors due to missing or
mismatched parameters.
"""

import os
import yaml
import ast
import pytest
from typing import Generator


def get_full_path(folder: str, base_folder: str = "weather_bundle") -> str:
    """
    Append the specified folder to the system path if it is not already present.
    Allows importing packages from the folder.
    """
    import re
    import os

    if not (match := re.search(rf"(.+{os.sep}{base_folder})", os.getcwd())):
        raise FileNotFoundError(f"Could not find {base_folder} in current path: {os.getcwd()}")

    base_path = match.group(1)
    for root, dirs, _ in os.walk(base_path):
        if "src" in dirs:
            base_path = root
            break

    return os.path.join(base_path, folder)


def get_all_files_in_directory(directory: str) -> list:
    """Recursively find all files in the given directory."""
    files = []
    for entry in os.scandir(directory):
        if entry.is_file():
            files.append(entry.path)
        elif entry.is_dir():
            files.extend(get_all_files_in_directory(entry.path))
    return files


resources_dir = get_full_path("resources")
yamls = get_all_files_in_directory(resources_dir)


def resolve_attribute_name(node: ast.AST) -> str | None:
    """Recursively resolve the full name of an attribute."""
    if isinstance(node, ast.Attribute):
        return f"{resolve_attribute_name(node.value)}.{node.attr}"
    elif isinstance(node, ast.Name):
        return node.id
    return None


def parse_dbutils_widgets_setters(file_path: str) -> set[str]:
    """Parse a Python file for dbutils.widgets definitions using AST."""

    with open(file_path, "r", encoding="utf-8") as f:
        tree = ast.parse(f.read(), filename=file_path)

    widget_params = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
            full_name = resolve_attribute_name(node.func.value)
            if full_name == "dbutils.widgets" and node.func.attr in [
                "text",
                "dropdown",
                "combobox",
                "multiselect",
            ]:
                if len(node.args) > 0 and isinstance(node.args[0], ast.Constant):
                    widget_params.add(node.args[0].value)
    return widget_params


def parse_dbutils_widgets_get_calls(file_path: str) -> set[str]:
    """Parse a Python file for dbutils.widgets.get calls using AST."""

    with open(file_path, "r", encoding="utf-8") as f:
        tree = ast.parse(f.read(), filename=file_path)

    widget_gets = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
            full_name = resolve_attribute_name(node.func.value)
            if full_name == "dbutils.widgets" and node.func.attr == "get":
                if len(node.args) > 0 and isinstance(node.args[0], ast.Constant):
                    widget_gets.add(node.args[0].value)
    return widget_gets


def parse_yaml_file(file_path: str) -> Generator[tuple[str, set[str]], None, None]:
    """Parse a YAML file for notebook_task base_parameters."""
    with open(file_path, "r") as f:
        data = yaml.safe_load(f)
    tasks = data.get("resources", {}).get("jobs", {}).values()
    for task in tasks:
        notebook_task = task.get("tasks", [])[0].get("notebook_task", {})
        notebook_path = notebook_task.get("notebook_path")
        base_parameters = notebook_task.get("base_parameters", {}).keys()
        yield notebook_path, set(base_parameters)


@pytest.mark.parametrize("yaml_file", yamls)
def test_yaml_base_params_have_setters(yaml_file: str) -> None:
    yaml_path = os.path.join(resources_dir, yaml_file)
    for notebook_path, base_parameters in parse_yaml_file(yaml_path):
        notebook_path: str = os.path.normpath(notebook_path)
        # Remove everything before 'src' in the notebook path
        if "src" in notebook_path:
            notebook_path = notebook_path.split("src", 1)[1].lstrip(os.sep)
        # Adjust path resolution to correctly construct <parent_dir>/src/<rest of notebook_path>
        parent_dir = os.path.dirname(resources_dir)
        python_file_path = os.path.normpath(os.path.join(parent_dir, "src", notebook_path))

        assert os.path.exists(python_file_path), (
            f"Notebook file {python_file_path} does not exist."
        )
        widget_params = parse_dbutils_widgets_setters(python_file_path)
        missing_params = base_parameters - widget_params
        assert not missing_params, (
            f"Missing dbutils.widgets for parameters: {missing_params} in {python_file_path}"
        )


@pytest.mark.parametrize("yaml_file", yamls)
def test_yaml_base_params_have_getters(yaml_file: str) -> None:
    yaml_path = os.path.join(resources_dir, yaml_file)
    for notebook_path, base_parameters in parse_yaml_file(yaml_path):
        notebook_path = os.path.normpath(notebook_path)
        # Remove everything before 'src' in the notebook path
        if "src" in notebook_path:
            notebook_path = notebook_path.split("src", 1)[1]
        # Adjust path resolution to correctly construct <parent_dir>/src/<rest of notebook_path>
        parent_dir = os.path.dirname(resources_dir)
        python_file_path = os.path.normpath(
            os.path.join(parent_dir, "src", notebook_path.lstrip(os.sep))
        )

        assert os.path.exists(python_file_path), (
            f"Notebook file {python_file_path} does not exist."
        )
        widget_getters = parse_dbutils_widgets_get_calls(python_file_path)
        missing_getters = base_parameters - widget_getters
        assert not missing_getters, (
            f"Missing dbutils.widgets.get for parameters: {missing_getters} in {python_file_path}"
        )
