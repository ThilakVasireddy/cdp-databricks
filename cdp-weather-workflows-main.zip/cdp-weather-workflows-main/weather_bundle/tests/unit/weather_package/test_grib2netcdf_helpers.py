import pytest
import pytest
from unittest import mock


def append_to_sys_path(folder: str, base_folder: str = "weather_bundle") -> str:
    """
    Append the specified folder to the system path if it is not already present. Allows importing packages from the folder.
    """
    import re
    import os
    import sys

    if not (match := re.search(rf"(.*[\\/]{base_folder})", os.getcwd())):
        raise Exception(f"Could not find {base_folder} in current path: {os.getcwd()}")

    base_path = match.group(1)
    for root, dirs, _ in os.walk(base_path):
        if "src" in dirs:
            base_path = root
            break

    path = os.path.join(base_path, folder)
    if path not in sys.path:
        sys.path.append(path)
    return path


append_to_sys_path("src/config")
append_to_sys_path("src/weather_package")

from grib2netcdf.helpers import parse_raw_dataset_meta, parse_toml_config

DATAMODELS_TOML = {
    "latitude": {"out_name": "latitude", "stored_direction": "increasing"},
    "longitude": {"out_name": "longitude", "stored_direction": "increasing"},
    "isobaricInhPa": {
        "out_name": "pressure_level",
        "units": "hPa",
        "stored_direction": "decreasing",
    },
    "hybrid": {"out_name": "hybrid_level", "stored_direction": "increasing"},
    "number": {"out_name": "realization", "stored_direction": "increasing"},
    "time": {"out_name": "forecast_reference_time", "stored_direction": "increasing"},
    "valid_time": {"out_name": "valid_time", "stored_direction": "increasing"},
    "step": {"out_name": "leadtime", "stored_direction": "increasing"},
}

VARIABLES_TOML_MAIN = {
    "title": "Variable definitions for weather data",
    "variables": {
        "tas": {
            "title": "surface air temperature / 2m air temperature or similar",
            "out_name": "tas",
            "modeling_realm": "atmos",
            "standard_name": "air_temperature",
            "units": "K",
            "cell_methods": "area: mean time: point",
            "long_name": "Near-Surface Air Temperature",
            "comment": "near-surface (usually 2 meter) air temperature",
            "dimensions": "longitude latitude time height2m",
            "type": "real",
            "positive": "",
            "valid_min": "",
            "valid_max": "",
        },
        "ta": {
            "title": "Air temperature at other positions in the atmosphere",
            "out_name": "ta",
            "modeling_realm": "atmos",
            "standard_name": "air_temperature",
            "units": "K",
            "cell_methods": "area: mean time: point",
            "long_name": "Air Temperature",
            "comment": "Air Temperature",
            "dimensions": "longitude latitude pressure_level time",
            "type": "real",
            "positive": "",
            "valid_min": "",
            "valid_max": "",
        },
    },
}

VARIABLES_TOML_NESTED = {
    "title": "Variable definitions for weather data",
    "variables": {
        "tas": {
            "title": "override test",
            "out_name": "tas",
            "modeling_realm": "",
            "standard_name": "air_temperature",
            "units": "K",
            "cell_methods": "area: mean time: point",
            "long_name": "Near-Surface Air Temperature",
            "comment": "near-surface (usually 2 meter) air temperature",
            "dimensions": "longitude latitude time height2m",
            "type": "real",
            "positive": "",
            "valid_min": "5",
            "valid_max": "10",
        },
        "ta2": {
            "title": "Air temperature at other positions in the atmosphere",
            "out_name": "ta",
            "modeling_realm": "atmos",
            "standard_name": "air_temperature",
            "units": "K",
            "cell_methods": "area: mean time: point",
            "long_name": "Air Temperature",
            "comment": "Air Temperature",
            "dimensions": "longitude latitude pressure_level time",
            "type": "real",
            "positive": "",
            "valid_min": "",
            "valid_max": "",
        },
    },
}

DATASETS_TOML = {
    "provider_meta": {
        "institution": "Copernicus Climate Change Service (C3S)",
        "provider": "Copernicus C3S",
        "provider_shortname": "C3S",
    },
    "variable_mapping": {
        "u10": "u10",
        "v10": "v10",
        "u100": "u100",
        "v100": "v100",
        "t2m": "tas",
        "mx2t": "tasmax",
        "mn2t": "tasmin",
        "msl": "mslp",
        "ssrd": "itssrd",
        "tcc": "tcc",
        "tp": "pr",
        "ERA5": {
            "msl": "mslp2",
            "ssrd": "itssrd2",
            "tcc": "tcc2",
            "tp": "pr2",
            "ERA5SH": {
                "tcc": "tcc3sh",
                "tp": "pr3sh",
            },
            "ERA5SM": {
                "tcc": "tcc3sm",
                "tp": "pr3sm",
            },
        },
    },
    "products_meta": {
        "product": "products_meta placeholder",
        "alias": "products_meta placeholder",
        "description": "products_meta placeholder",
        "short_name": "products_meta placeholder",
        "ERA5": {
            "description": "ERA5",
            "short_name": "ERA5",
            "ERA5SH": {
                "product": "ERA5 Single Hourly",
                "alias": "ERA5 Single Hourly",
                "description": "ERA5 Single Hourly",
                "short_name": "ERA5SH",
                "run_frequency": "",
                "schedule": "",
            },
            "ERA5PH": {},
            "ERA5SM": {"run_frequency": "", "schedule": ""},
            "ERA5PM": {
                "product": "ERA5 Pressure Monthly",
                "alias": "ERA5 Pressure Monthly",
                "description": "ERA5 Pressure Monthly",
                "short_name": "ERA5PM",
                "run_frequency": "",
                "schedule": "",
            },
        },
        "ERA5_Land": {},
    },
}

PARSED_VARIABLES_META = {
    "tas": {
        "title": "override test",
        "out_name": "tas",
        "modeling_realm": "",
        "standard_name": "air_temperature",
        "units": "K",
        "cell_methods": "area: mean time: point",
        "long_name": "Near-Surface Air Temperature",
        "comment": "near-surface (usually 2 meter) air temperature",
        "dimensions": "longitude latitude time height2m",
        "type": "real",
        "positive": "",
        "valid_min": "5",
        "valid_max": "10",
    },
    "ta": {
        "title": "Air temperature at other positions in the atmosphere",
        "out_name": "ta",
        "modeling_realm": "atmos",
        "standard_name": "air_temperature",
        "units": "K",
        "cell_methods": "area: mean time: point",
        "long_name": "Air Temperature",
        "comment": "Air Temperature",
        "dimensions": "longitude latitude pressure_level time",
        "type": "real",
        "positive": "",
        "valid_min": "",
        "valid_max": "",
    },
    "ta2": {
        "title": "Air temperature at other positions in the atmosphere",
        "out_name": "ta",
        "modeling_realm": "atmos",
        "standard_name": "air_temperature",
        "units": "K",
        "cell_methods": "area: mean time: point",
        "long_name": "Air Temperature",
        "comment": "Air Temperature",
        "dimensions": "longitude latitude pressure_level time",
        "type": "real",
        "positive": "",
        "valid_min": "",
        "valid_max": "",
    },
}

PARSED_RAW_DATASET_META = {
    "provider_meta": {
        "institution": "Copernicus Climate Change Service (C3S)",
        "provider": "Copernicus C3S",
        "provider_shortname": "C3S",
    },
    "variable_mapping": {
        "u10": "u10",
        "v10": "v10",
        "u100": "u100",
        "v100": "v100",
        "t2m": "tas",
        "mx2t": "tasmax",
        "mn2t": "tasmin",
        "msl": "mslp",
        "ssrd": "itssrd",
        "tcc": "tcc",
        "tp": "pr",
        "ERA5": {
            "msl": "mslp2",
            "ssrd": "itssrd2",
            "tcc": "tcc2",
            "tp": "pr2",
            "ERA5SH": {"tcc": "tcc3sh", "tp": "pr3sh"},
            "ERA5SM": {"tcc": "tcc3sm", "tp": "pr3sm"},
        },
    },
    "products_meta": {
        "product": "products_meta placeholder",
        "alias": "products_meta placeholder",
        "description": "products_meta placeholder",
        "short_name": "products_meta placeholder",
        "ERA5": {
            "description": "ERA5",
            "short_name": "ERA5",
            "ERA5SH": {
                "product": "ERA5 Single Hourly",
                "alias": "ERA5 Single Hourly",
                "description": "ERA5 Single Hourly",
                "short_name": "ERA5SH",
                "run_frequency": "",
                "schedule": "",
            },
            "ERA5PH": {},
            "ERA5SM": {"run_frequency": "", "schedule": ""},
            "ERA5PM": {
                "product": "ERA5 Pressure Monthly",
                "alias": "ERA5 Pressure Monthly",
                "description": "ERA5 Pressure Monthly",
                "short_name": "ERA5PM",
                "run_frequency": "",
                "schedule": "",
            },
        },
        "ERA5_Land": {},
    },
}

PARSED_DATAMODEL = {
    "latitude": {"out_name": "latitude", "stored_direction": "increasing"},
    "longitude": {"out_name": "longitude", "stored_direction": "increasing"},
    "isobaricInhPa": {
        "out_name": "pressure_level",
        "units": "hPa",
        "stored_direction": "decreasing",
    },
    "hybrid": {"out_name": "hybrid_level", "stored_direction": "increasing"},
    "number": {"out_name": "realization", "stored_direction": "increasing"},
    "time": {"out_name": "forecast_reference_time", "stored_direction": "increasing"},
    "valid_time": {"out_name": "valid_time", "stored_direction": "increasing"},
    "step": {"out_name": "leadtime", "stored_direction": "increasing"},
}

PARSED_DATASET_META = {
    "ERA5SH": {
        "provider_meta": {
            "institution": "Copernicus Climate Change Service (C3S)",
            "provider": "Copernicus C3S",
            "provider_shortname": "C3S",
        },
        "products_meta": {
            "product": "ERA5 Single Hourly",
            "alias": "ERA5 Single Hourly",
            "description": "ERA5 Single Hourly",
            "short_name": "ERA5SH",
            "run_frequency": "",
            "schedule": "",
        },
        "variable_mapping": {
            "u10": "u10",
            "v10": "v10",
            "u100": "u100",
            "v100": "v100",
            "t2m": "tas",
            "mx2t": "tasmax",
            "mn2t": "tasmin",
            "msl": "mslp2",
            "ssrd": "itssrd2",
            "tcc": "tcc3sh",
            "tp": "pr3sh",
        },
    },
    "ERA5SM": {
        "provider_meta": {
            "institution": "Copernicus Climate Change Service (C3S)",
            "provider": "Copernicus C3S",
            "provider_shortname": "C3S",
        },
        "products_meta": {
            "product": "products_meta placeholder",
            "alias": "products_meta placeholder",
            "description": "ERA5",
            "short_name": "ERA5",
            "run_frequency": "",
            "schedule": "",
        },
        "variable_mapping": {
            "u10": "u10",
            "v10": "v10",
            "u100": "u100",
            "v100": "v100",
            "t2m": "tas",
            "mx2t": "tasmax",
            "mn2t": "tasmin",
            "msl": "mslp2",
            "ssrd": "itssrd2",
            "tcc": "tcc3sm",
            "tp": "pr3sm",
        },
    },
    "ERA5PH": {
        "provider_meta": {
            "institution": "Copernicus Climate Change Service (C3S)",
            "provider": "Copernicus C3S",
            "provider_shortname": "C3S",
        },
        "products_meta": {
            "product": "products_meta placeholder",
            "alias": "products_meta placeholder",
            "description": "ERA5",
            "short_name": "ERA5",
        },
        "variable_mapping": {
            "u10": "u10",
            "v10": "v10",
            "u100": "u100",
            "v100": "v100",
            "t2m": "tas",
            "mx2t": "tasmax",
            "mn2t": "tasmin",
            "msl": "mslp2",
            "ssrd": "itssrd2",
            "tcc": "tcc2",
            "tp": "pr2",
        },
    },
    "ERA5PM": {
        "provider_meta": {
            "institution": "Copernicus Climate Change Service (C3S)",
            "provider": "Copernicus C3S",
            "provider_shortname": "C3S",
        },
        "products_meta": {
            "product": "ERA5 Pressure Monthly",
            "alias": "ERA5 Pressure Monthly",
            "description": "ERA5 Pressure Monthly",
            "short_name": "ERA5PM",
            "run_frequency": "",
            "schedule": "",
        },
        "variable_mapping": {
            "u10": "u10",
            "v10": "v10",
            "u100": "u100",
            "v100": "v100",
            "t2m": "tas",
            "mx2t": "tasmax",
            "mn2t": "tasmin",
            "msl": "mslp2",
            "ssrd": "itssrd2",
            "tcc": "tcc2",
            "tp": "pr2",
        },
    },
}


@pytest.fixture
def mock_toml_files(mocker):
    def mock_load(file_obj):
        file_path = file_obj.name
        if "copernicus" in file_path:
            if "datasets.toml" in file_path:
                return DATASETS_TOML
            elif "variables.toml" in file_path:
                return VARIABLES_TOML_NESTED
        else:
            if "variables.toml" in file_path:
                return VARIABLES_TOML_MAIN
            elif "datamodels.toml" in file_path:
                return DATAMODELS_TOML

        raise FileNotFoundError(f"Unhandled file path: {file_path}")

    mocker.patch("grib2netcdf.helpers.tomllib.load", side_effect=mock_load)

    def joinpath_side_effect(file_name):
        mock_open_ctx = mocker.mock_open(read_data=b"")
        mock_file_obj = mock_open_ctx.return_value
        mock_file_obj.name = file_name

        mock_path = mocker.Mock()
        mock_path.open = mock_open_ctx
        return mock_path

    mocker.patch(
        "grib2netcdf.helpers.resources.files"
    ).return_value.joinpath.side_effect = joinpath_side_effect


def test_variables_metadata_merging(mock_toml_files):
    _, _, variables_metadata = parse_toml_config("copernicus")
    assert variables_metadata == PARSED_VARIABLES_META


def test_raw_dataset_meta_extraction(mock_toml_files):
    _, raw_dataset_meta, _ = parse_toml_config("copernicus")
    assert raw_dataset_meta == PARSED_RAW_DATASET_META


def test_datamodel_extraction(mock_toml_files):
    datamodel, _, _ = parse_toml_config("copernicus")
    assert datamodel == PARSED_DATAMODEL


def test_get_variables_metadata_exception(mock_toml_files):
    with pytest.raises(FileNotFoundError):
        _, _, _ = parse_toml_config("non_existent_directory")


def test_raw_dataset_meta_parsing(mock_toml_files):
    _, raw_dataset_meta, _ = parse_toml_config("copernicus")
    product_family = "ERA5"
    for product in ["ERA5SH", "ERA5SM", "ERA5PH", "ERA5PM"]:
        parsed_dataset_meta = parse_raw_dataset_meta(
            raw_dataset_meta, product_family, product
        )
        assert parsed_dataset_meta == PARSED_DATASET_META[product]
