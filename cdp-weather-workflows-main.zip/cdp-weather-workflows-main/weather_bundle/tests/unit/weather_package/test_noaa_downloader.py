def append_to_sys_path(folder: str, base_folder: str = "weather_bundle") -> str:
    """
    Append the specified folder to the system path if it is not already present.
    Allows importing packages from the folder.
    """
    import re
    import os
    import sys

    if not (match := re.search(rf"(.*[\\/]{base_folder})", os.getcwd())):
        raise FileNotFoundError(
            f"Could not find {base_folder} in current path: {os.getcwd()}"
        )

    base_path = match.group(1)
    for root, dirs, _ in os.walk(base_path):
        if "src" in dirs:
            base_path = root
            break

    if (path := os.path.join(base_path, folder)) not in sys.path:
        sys.path.append(path)
    return path


append_to_sys_path("src/config")
append_to_sys_path("src/weather_package")
append_to_sys_path("tests/unit/mocked_data")


# ruff: noqa: E402
import os
import unittest
from unittest.mock import Mock, MagicMock, patch
from typing import cast
import requests

import datetime as dt
import re

from noaa_downloader import (  # type: ignore
    download_file,
    makedirs,
    tprint,
    get_focus_date_and_run,
    filter_index_file_to_byte_ranges,
    byte_ranges_to_size,
    regex_list_to_regex,
    parse_source_files,
    get_source_files,
    get_target_files,
    log_output,
    parse_multipart_response,
)
from mock_noaa_downloader import (  # type: ignore
    variable_regex_list,
    test_idx_file_contents_042,
    test_idx_file_contents_000,
)


class TestMakedirs(unittest.TestCase):
    @patch("os.makedirs")
    def test_makedirs(self, mock_makedirs):
        target_folder = "test_target"
        index_folder = "custom_index"
        makedirs(target_folder, index_folder)
        mock_makedirs.assert_any_call(target_folder, exist_ok=True)
        mock_makedirs.assert_any_call(
            os.path.join(target_folder, index_folder), exist_ok=True
        )
        mock_makedirs.assert_any_call(os.path.join(target_folder), exist_ok=True)
        self.assertEqual(mock_makedirs.call_count, 2)


class TestGetFocusDateAndRun(unittest.TestCase):
    def test_before_first_event(self):
        now = dt.datetime(2025, 3, 5, 3, 20, 0)
        file_arrival_time = dt.time(3, 30, 0)
        # shift = dt.timedelta(minutes=10)
        expected_focus_date = dt.date(2025, 3, 4)
        expected_run = "18"
        focus_date, run = get_focus_date_and_run(
            now, file_arrival_time, shift=dt.timedelta(), runs=[0, 6, 12, 18]
        )
        self.assertEqual((focus_date, run), (expected_focus_date, expected_run))

    def test_after_first_event(self):
        now = dt.datetime(2025, 3, 5, 4, 0, 0)
        file_arrival_time = dt.time(3, 30, 0)
        expected_focus_date = dt.date(2025, 3, 5)
        expected_run = "00"
        focus_date, run = get_focus_date_and_run(
            now, file_arrival_time, shift=dt.timedelta(), runs=[0, 6, 12, 18]
        )
        self.assertEqual(focus_date, expected_focus_date)
        self.assertEqual(run, expected_run)

    def test_exact_first_event(self):
        now = dt.datetime(2025, 3, 5, 3, 30, 0)
        file_arrival_time = dt.time(3, 30, 0)

        expected_focus_date = dt.date(2025, 3, 5)
        expected_run = "00"
        focus_date, run = get_focus_date_and_run(
            now, file_arrival_time, shift=dt.timedelta(), runs=[0, 6, 12, 18]
        )
        self.assertEqual(focus_date, expected_focus_date)
        self.assertEqual(run, expected_run)

    def test_single_run_before_midnight(self):
        now = dt.datetime(2025, 3, 4, 20, 0, 0)
        file_arrival_time = dt.time(0, 0, 0)
        expected_focus_date = dt.date(2025, 3, 4)
        expected_run = "00"
        focus_date, run = get_focus_date_and_run(
            now, file_arrival_time, shift=dt.timedelta(), runs=[0]
        )
        self.assertEqual(focus_date, expected_focus_date)
        self.assertEqual(run, expected_run)

    def test_single_run_after_midnight(self):
        now = dt.datetime(2025, 3, 5, 4, 0, 0)
        file_arrival_time = dt.time(0, 0, 0)
        expected_focus_date = dt.date(2025, 3, 5)
        expected_run = "00"
        focus_date, run = get_focus_date_and_run(
            now, file_arrival_time, shift=dt.timedelta(), runs=[0]
        )
        self.assertEqual(focus_date, expected_focus_date)
        self.assertEqual(run, expected_run)

    def test_single_run_at_midnight(self):
        now = dt.datetime(2025, 3, 5, 0, 0, 0)
        file_arrival_time = dt.time(0, 0, 0)
        expected_focus_date = dt.date(2025, 3, 5)
        expected_run = "00"
        focus_date, run = get_focus_date_and_run(
            now, file_arrival_time, shift=dt.timedelta(), runs=[0]
        )
        self.assertEqual(focus_date, expected_focus_date)
        self.assertEqual(run, expected_run)

    def test_single_run_with_shift(self):
        now = dt.datetime(2025, 3, 4, 23, 55, 0)
        file_arrival_time = dt.time(0, 0, 0)
        shift = dt.timedelta(minutes=20)
        expected_focus_date = dt.date(2025, 3, 5)
        expected_run = "00"
        focus_date, run = get_focus_date_and_run(
            now, file_arrival_time, shift, runs=[0]
        )
        self.assertEqual(focus_date, expected_focus_date)
        self.assertEqual(run, expected_run)

    def test_runs(self):
        now = dt.datetime(2025, 3, 5, 0, 0, 0)
        file_arrival_time = dt.time(0, 0, 0)

        expected_runs = ["00", "06", "12", "18"]
        for i, expected_run in enumerate(expected_runs):
            focus_date, run = get_focus_date_and_run(
                now + dt.timedelta(hours=6 * i),
                file_arrival_time,
                shift=dt.timedelta(),
                runs=[0, 6, 12, 18],
            )
            self.assertEqual(run, expected_run)

    def test_shift_before_first_event(self):
        now = dt.datetime(2025, 3, 5, 3, 20, 0)
        file_arrival_time = dt.time(3, 30, 0)
        shift = dt.timedelta(minutes=10)
        expected_focus_date = dt.date(2025, 3, 5)
        expected_run = "00"
        focus_date, run = get_focus_date_and_run(
            now, file_arrival_time, shift, runs=[0, 6, 12, 18]
        )
        self.assertEqual((focus_date, run), (expected_focus_date, expected_run))

    def test_before_midnight_with_shift_crossing_day(self):
        now = dt.datetime(2025, 3, 4, 23, 45, 0)
        file_arrival_time = dt.time(0, 0, 0)
        shift = dt.timedelta(minutes=20)  # Makes shifted time 00:05 next day
        expected_focus_date = dt.date(2025, 3, 5)  # Next day's date
        expected_run = "00"  # First run of the day
        focus_date, run = get_focus_date_and_run(
            now, file_arrival_time, shift, runs=[0, 6, 12, 18]
        )
        self.assertEqual(focus_date, expected_focus_date)
        self.assertEqual(run, expected_run)

    def test_exactly_at_midnight(self):
        now = dt.datetime(2025, 3, 5, 0, 0, 0)  # Exactly at midnight
        file_arrival_time = dt.time(0, 0, 0)  # Download starts at midnight
        expected_focus_date = dt.date(2025, 3, 5)
        expected_run = "00"
        focus_date, run = get_focus_date_and_run(
            now, file_arrival_time, shift=dt.timedelta(), runs=[0, 6, 12, 18]
        )
        self.assertEqual(focus_date, expected_focus_date)
        self.assertEqual(run, expected_run)

    def test_shortly_after_midnight(self):
        now = dt.datetime(2025, 3, 5, 0, 10, 0)  # 10 minutes after midnight
        file_arrival_time = dt.time(0, 0, 0)  # Download starts at midnight
        expected_focus_date = dt.date(2025, 3, 5)
        expected_run = "00"
        focus_date, run = get_focus_date_and_run(
            now, file_arrival_time, shift=dt.timedelta(), runs=[0, 6, 12, 18]
        )
        self.assertEqual(focus_date, expected_focus_date)
        self.assertEqual(run, expected_run)

    def test_before_midnight_large_shift(self):
        now = dt.datetime(2025, 3, 4, 23, 45, 0)
        file_arrival_time = dt.time(0, 0, 0)
        shift = dt.timedelta(hours=7)  # Shifts to next day, past the 06 run
        expected_focus_date = dt.date(2025, 3, 5)
        expected_run = "06"  # Second run of the day
        focus_date, run = get_focus_date_and_run(
            now, file_arrival_time, shift, runs=[0, 6, 12, 18]
        )
        self.assertEqual(focus_date, expected_focus_date)
        self.assertEqual(run, expected_run)


class TestFilterIndexFileToByteRanges(unittest.TestCase):
    def test_single_match(self):
        lines = ["1:0:line1", "2:10:line2", "3:20:line3"]
        regex_list = [r"line1"]
        expected = [(0, 9)]
        result = filter_index_file_to_byte_ranges(
            lines, regex_list_to_regex(regex_list)
        )
        self.assertEqual(result, expected)

    def test_multiple_matches(self):
        lines = ["1:0:line1", "2:10:line2", "3:20:line3", "4:30:line4"]
        regex_list = [r"line1", r"line3"]
        expected = [(0, 9), (20, 29)]
        result = filter_index_file_to_byte_ranges(
            lines, regex_list_to_regex(regex_list)
        )
        self.assertEqual(result, expected)

    def test_consecutive_matches(self):
        lines = ["1:0:line1", "2:10:line2", "3:20:line3", "4:30:line4"]
        regex_list = [r"line1", r"line2"]
        expected = [(0, 19)]
        result = filter_index_file_to_byte_ranges(
            lines, regex_list_to_regex(regex_list)
        )
        self.assertEqual(result, expected)

    def test_no_matches(self):
        lines = ["1:0:line1", "2:10:line2", "3:20:line3"]
        regex_list = [r"line4"]
        expected = []
        result = filter_index_file_to_byte_ranges(
            lines, regex_list_to_regex(regex_list)
        )
        self.assertEqual(result, expected)

    def test_multiple_ranges_with_last_byte_range(self):
        lines = ["1:0:line1", "2:10:line2", "3:20:line3"]
        regex_list = [r"line1", r"line3"]
        expected = [(0, 9), (20, "")]
        result = filter_index_file_to_byte_ranges(
            lines, regex_list_to_regex(regex_list)
        )
        self.assertEqual(result, expected)

    def test_single_last_byte_range(self):
        lines = ["1:0:line1", "2:10:line2", "3:20:line3"]
        regex_list = [r"line3"]
        expected = [(20, 20), (21, "")]
        result = filter_index_file_to_byte_ranges(
            lines, regex_list_to_regex(regex_list)
        )
        self.assertEqual(result, expected)

    def test_repeated_line_read_once(self):
        lines = ["1:0:AAA", "2:10:BBB", "3:20:BBB", "4:30:CCC"]
        regex_list = [r"BBB"]
        expected = [(20, 29)]
        result = filter_index_file_to_byte_ranges(
            lines, regex_list_to_regex(regex_list), True
        )
        self.assertEqual(result, expected)

    def test_real_data_000(self):
        result = filter_index_file_to_byte_ranges(
            test_idx_file_contents_000.splitlines(),
            regex_list_to_regex(variable_regex_list),
        )
        self.assertEqual(
            result,
            [
                (0, 1003942),
                (115553089, 116481031),
                (176300895, 178130444),
                (254735184, 255538837),
                (298371189, 299229000),
                (333098053, 333943362),
                (339041326, 340919990),
                (401531625, 402526070),
                (412003516, 412521874),
                (414259376, 415024656),
                (428517545, 429345792),
                (461099581, 463041235),
            ],
        )

    def test_real_data_042(self):
        result = filter_index_file_to_byte_ranges(
            test_idx_file_contents_042.splitlines(),
            regex_list_to_regex(variable_regex_list),
        )
        self.assertEqual(
            result,
            [
                (0, 880805),
                (126374991, 127966507),
                (190666694, 192473488),
                (269906290, 270721131),
                (313676227, 314504515),
                (348537632, 349382666),
                (354345666, 356238131),
                (416683389, 417642518),
                (427834110, 428342940),
                (430069754, 430845456),
                (431405150, 432404379),
                (457083776, 457906828),
                (474469409, 475431314),
                (510343096, 512287178),
            ],
        )


class TestByteRangesToSize(unittest.TestCase):
    def test_single_range(self):
        byte_ranges = [(0, 9)]
        expected_size = 10
        result = byte_ranges_to_size(byte_ranges)
        self.assertEqual(result, expected_size)

    def test_multiple_ranges(self):
        byte_ranges = [(0, 9), (20, 29)]
        expected_size = 20
        result = byte_ranges_to_size(byte_ranges)
        self.assertEqual(result, expected_size)

    def test_consecutive_ranges(self):
        byte_ranges = [(0, 9), (10, 19)]
        expected_size = 20
        result = byte_ranges_to_size(byte_ranges)
        self.assertEqual(result, expected_size)

    def test_no_ranges(self):
        byte_ranges = []
        expected_size = 0
        result = byte_ranges_to_size(byte_ranges)
        self.assertEqual(result, expected_size)

    def test_single_byte_range(self):
        byte_ranges = [(5, 5)]
        expected_size = 1
        result = byte_ranges_to_size(byte_ranges)
        self.assertEqual(result, expected_size)

    def test_byte_range_with_empty_string_and_unfiltered_size(self):
        byte_ranges = [(0, "")]
        total_unfiltered_size = 200
        expected_size = 200
        result = byte_ranges_to_size(byte_ranges, total_unfiltered_size)
        self.assertEqual(result, expected_size)


class TestParseSourceFiles(unittest.TestCase):
    def test_single_match(self):
        html_content = '<a href="file001">file001</a>'
        file_pattern = re.compile(r"file001")
        link_pattern = re.compile(r'href="([^"]+)"')
        expected = {"file001"}
        result = parse_source_files(html_content, file_pattern, range(2), link_pattern)
        self.assertEqual(result, expected)

    def test_multiple_matches(self):
        html_content = '<a href="file001">file001</a><a href="file002">file002</a>'
        file_pattern = re.compile(r"file00[12]")
        link_pattern = re.compile(r'href="([^"]+)"')
        expected = {"file001", "file002"}
        result = parse_source_files(
            html_content, file_pattern, range(1, 3), link_pattern
        )
        self.assertEqual(result, expected)

    def test_no_matches(self):
        html_content = '<a href="file003">file003</a>'
        file_pattern = re.compile(r"file00[12]")
        link_pattern = re.compile(r'href="([^"]+)"')
        expected = set()
        result = parse_source_files(
            html_content, file_pattern, range(1, 3), link_pattern
        )
        self.assertEqual(result, expected)

    def test_partial_matches(self):
        html_content = '<a href="file001">file001</a><a href="file003">file003</a>'
        file_pattern = re.compile(r"file001")
        link_pattern = re.compile(r'href="([^"]+)"')
        expected = {"file001"}
        result = parse_source_files(
            html_content,
            file_pattern,
            range(1, 2),
            link_pattern,
        )
        self.assertEqual(result, expected)

    def test_empty_html(self):
        html_content = ""
        file_pattern = re.compile(r"file001")
        link_pattern = re.compile(r'href="([^"]+)"')
        expected = set()
        result = parse_source_files(html_content, file_pattern, range(1), link_pattern)
        self.assertEqual(result, expected)


class TestGetSourceFiles(unittest.TestCase):
    def test_valid_response(self):
        mock_session = cast(requests.Session, Mock(spec=requests.Session))
        mock_response = cast(requests.Response, Mock(spec=requests.Response))
        mock_response.text = (
            '<a href="file001">file001</a><a href="file002">file002</a>'
        )
        mock_response.raise_for_status = Mock()
        mock_response.history = []
        mock_response.url = "http://example.com/files"
        mock_session.get.return_value = mock_response

        file_list_url = "http://example.com/files"
        file_pattern = re.compile(r"file00[12]")
        expected = {"file001", "file002"}

        result = get_source_files(
            mock_session, file_list_url, file_pattern, range(1, 3)
        )
        self.assertEqual(result, expected, f"{result} != {expected}")
        mock_session.get.assert_called_once_with(file_list_url)
        mock_response.raise_for_status.assert_called_once()

    def test_valid_response_outside_range(self):
        mock_session = cast(requests.Session, Mock(spec=requests.Session))
        mock_response = cast(requests.Response, Mock(spec=requests.Response))
        mock_response.text = (
            '<a href="file001">file001</a><a href="file002">file002</a>'
        )
        mock_response.raise_for_status = Mock()
        mock_response.history = []
        mock_response.url = "http://example.com/files"
        mock_session.get.return_value = mock_response

        file_list_url = "http://example.com/files"
        file_pattern = re.compile(r"file00[12]")
        expected = set()

        result = get_source_files(
            mock_session, file_list_url, file_pattern, range(99, 999)
        )
        self.assertEqual(result, expected, f"{result} != {expected}")
        mock_session.get.assert_called_once_with(file_list_url)
        mock_response.raise_for_status.assert_called_once()

    def test_empty_response(self):
        mock_session = Mock(spec=requests.Session)
        mock_response = Mock(spec=requests.Response)
        mock_response.text = ""
        mock_response.raise_for_status = Mock()
        mock_response.history = []
        mock_response.url = "http://example.com/files"
        mock_session.get.return_value = mock_response

        file_list_url = "http://example.com/files"
        file_pattern = re.compile(r"file[012]\.txt")
        expected = set()

        result = get_source_files(
            mock_session, file_list_url, file_pattern, range(12, 13)
        )
        self.assertEqual(result, expected)
        mock_session.get.assert_called_once_with(file_list_url)
        mock_response.raise_for_status.assert_called_once()

    def test_raise_for_status_called(self):
        mock_session = Mock(spec=requests.Session)
        mock_response = Mock(spec=requests.Response)
        mock_response.text = '<a href="file100">file100</a>'
        mock_response.raise_for_status = Mock()
        mock_response.history = []
        mock_response.url = "http://example.com/files"
        mock_session.get.return_value = mock_response

        file_list_url = "http://example.com/files"
        file_pattern = re.compile(r"file100")

        get_source_files(mock_session, file_list_url, file_pattern, range(1000))
        mock_response.raise_for_status.assert_called_once()

    def test_http_error(self):
        mock_session = Mock(spec=requests.Session)
        mock_response = Mock(spec=requests.Response)
        mock_response.raise_for_status.side_effect = requests.HTTPError("HTTP Error")
        mock_response.history = []
        mock_response.url = "http://example.com/files"
        mock_session.get.return_value = mock_response

        file_list_url = "http://example.com/files"
        file_pattern = re.compile(r"file100\.txt")

        with self.assertRaises(requests.HTTPError):
            get_source_files(mock_session, file_list_url, file_pattern, range(1))
        mock_session.get.assert_called_once_with(file_list_url)
        mock_response.raise_for_status.assert_called_once()


class TestLogOutput(unittest.TestCase):
    @unittest.mock.patch("noaa_downloader.tprint")
    def test_log_output_with_last_modified(self, mock_tprint):
        file_url = "http://example.com/file"
        write_time_dt = dt.datetime(2025, 3, 5, 12, 0, 0)
        last_modified = "Wed, 05 Mar 2025 10:00:00 GMT"
        content_length = 1024
        byte_ranges = [(0, 512), (513, 1023)]

        log_output(
            file_url,
            write_time_dt,
            last_modified,
            content_length,
            byte_ranges,
        )

        expected_log = (
            f"file_url={file_url}\n"
            f"last_modified={last_modified}\n"
            f"write_time={write_time_dt.isoformat()}\n"
            f"last_modified_to_write_time=2:00:00\n"
            f"content_length={content_length}\n"
            f"byte_ranges={byte_ranges}"
        )
        mock_tprint.assert_called_once_with(expected_log)

    @unittest.mock.patch("noaa_downloader.tprint")
    def test_log_output_without_last_modified(self, mock_tprint):
        file_url = "http://example.com/file"
        write_time_dt = dt.datetime(2025, 3, 5, 12, 0, 0)
        last_modified = ""
        content_length = 1024
        byte_ranges = [(0, 512), (513, 1023)]

        log_output(
            file_url,
            write_time_dt,
            last_modified,
            content_length,
            byte_ranges,
        )

        expected_log = (
            f"file_url={file_url}\n"
            f"last_modified={last_modified}\n"
            f"write_time={write_time_dt.isoformat()}\n"
            f"last_modified_to_write_time=\n"
            f"content_length={content_length}\n"
            f"byte_ranges={byte_ranges}"
        )
        mock_tprint.assert_called_once_with(expected_log)

    @unittest.mock.patch("noaa_downloader.tprint")
    def test_log_output_with_invalid_last_modified(self, mock_tprint):
        file_url = "http://example.com/file"
        write_time_dt = dt.datetime(2025, 3, 5, 12, 0, 0)
        last_modified = "Invalid Date Format"
        content_length = 1024
        byte_ranges = [(0, 512), (513, 1023)]

        with self.assertRaises(ValueError):
            log_output(
                file_url,
                write_time_dt,
                last_modified,
                content_length,
                byte_ranges,
            )
        mock_tprint.assert_not_called()


class TestParseMultipartResponse(unittest.TestCase):
    def test_valid_multipart_response(self):
        mock_response = Mock(spec=requests.Response)
        mock_response.headers = {
            "Content-Type": "multipart/byteranges; boundary=boundary123"
        }
        mock_response.content = (
            b"--boundary123\r\n"
            b"Content-Range: bytes 0-4/10\r\n\r\n"
            b"Hello\r\n"
            b"--boundary123\r\n"
            b"Content-Range: bytes 5-9/10\r\n\r\n"
            b"World\r\n"
            b"--boundary123--"
        )

        content, total_unfiltered_size = parse_multipart_response(mock_response)
        self.assertEqual(content, b"HelloWorld")
        self.assertEqual(total_unfiltered_size, 10)

    def test_valid_ncep_style_multipart_response(self):
        mock_response = Mock(spec=requests.Response)
        mock_response.headers = {
            "Content-Type": "multipart/byteranges; boundary=boundary123"
        }
        mock_response.content = (
            b"--boundary123\r\n"
            b"Content-range: bytes 0-4/100\r\n\r\n"
            b"Hello\r\n"
            b"--boundary123\r\n"
            b"Content-range: bytes 5-9/100\r\n\r\n"
            b"World\r\n"
            b"--boundary123--"
        )

        content, total_unfiltered_size = parse_multipart_response(mock_response)
        self.assertEqual(content, b"HelloWorld")
        self.assertEqual(total_unfiltered_size, 100)

    def test_missing_boundary(self):
        mock_response = Mock(spec=requests.Response)
        mock_response.headers = {"Content-Type": "multipart/byteranges"}
        mock_response.content = b""

        with self.assertRaises(ValueError) as context:
            parse_multipart_response(mock_response)
        self.assertIn("Boundary not found", str(context.exception))

    def test_invalid_content_range_header(self):
        mock_response = Mock(spec=requests.Response)
        mock_response.headers = {
            "Content-Type": "multipart/byteranges; boundary=boundary123"
        }
        mock_response.content = b"--boundary123\r\nContent-Range: bytes 0-4/invalid\r\n\r\nHello\r\n--boundary123--"

        with self.assertRaises(ValueError) as context:
            parse_multipart_response(mock_response)
        self.assertIn("Failed to parse Content-Range header", str(context.exception))


class TestGetTargetFiles(unittest.TestCase):
    @patch("os.scandir")
    def test_get_target_files_with_files(self, mock_scandir):
        # Mock entries returned by os.scandir
        mock_entry1 = MagicMock()
        mock_entry1.name = "file001"
        mock_entry1.is_file.return_value = True

        mock_entry2 = MagicMock()
        mock_entry2.name = "file002"
        mock_entry2.is_file.return_value = True

        mock_entry3 = MagicMock()
        mock_entry3.name = "subfolder"
        mock_entry3.is_file.return_value = False

        mock_scandir.return_value.__enter__.return_value = [
            mock_entry1,
            mock_entry2,
            mock_entry3,
        ]

        # Call the function
        result = get_target_files("/mock/folder", range(999))

        # Assert the result
        self.assertEqual(result, {"file001", "file002"})

    @patch("os.scandir")
    def test_get_target_files_with_files_outside_range(self, mock_scandir):
        # Mock entries returned by os.scandir
        mock_entry1 = MagicMock()
        mock_entry1.name = "file001"
        mock_entry1.is_file.return_value = True

        mock_entry2 = MagicMock()
        mock_entry2.name = "file002"
        mock_entry2.is_file.return_value = True

        mock_entry3 = MagicMock()
        mock_entry3.name = "subfolder"
        mock_entry3.is_file.return_value = False

        mock_scandir.return_value.__enter__.return_value = [
            mock_entry1,
            mock_entry2,
            mock_entry3,
        ]

        # Call the function
        result = get_target_files("/mock/folder", range(999, 9999))

        # Assert the result
        self.assertEqual(result, set())

    @patch("os.scandir")
    def test_get_target_files_with_no_files(self, mock_scandir):
        # Mock empty directory
        mock_scandir.return_value.__enter__.return_value = []

        # Call the function
        result = get_target_files("/mock/empty_folder", range(999))

        # Assert the result
        self.assertEqual(result, set())

    @patch("os.scandir")
    def test_get_target_files_with_only_folders(self, mock_scandir):
        # Mock entries with only folders
        mock_entry1 = MagicMock()
        mock_entry1.name = "folder1"
        mock_entry1.is_file.return_value = False

        mock_entry2 = MagicMock()
        mock_entry2.name = "folder2"
        mock_entry2.is_file.return_value = False

        mock_scandir.return_value.__enter__.return_value = [
            mock_entry1,
            mock_entry2,
        ]

        # Call the function
        result = get_target_files("/mock/folder_with_folders", range(999))

        # Assert the result
        self.assertEqual(result, set())


class TestDownloadFile(unittest.TestCase):
    @patch("os.path.exists")
    @patch("builtins.open", new_callable=unittest.mock.mock_open)
    @patch("noaa_downloader.log_output")
    def test_download_file_happy_path(self, mock_log_output, mock_open, mock_exists):
        # Setup
        mock_file_mm = Mock()
        mock_file_mm.state_row = MagicMock()

        mock_session = Mock(spec=requests.Session)
        mock_response = Mock(spec=requests.Response)
        mock_response.headers = {
            "Content-Type": "multipart/byteranges; boundary=boundary123",
            "last-modified": "Wed, 05 Mar 2025 10:00:00 GMT",
        }
        mock_response.content = b"--boundary123\r\nContent-Range: bytes 0-10/11\r\n\r\nHello World\r\n--boundary123--"
        mock_response.raise_for_status = Mock()
        mock_session.get.return_value = mock_response

        file_url = "http://example.com/file"
        target_file_path = "/path/to/target/file"
        byte_ranges = [(0, 10)]

        # Call the function
        download_file(
            mock_session, file_url, target_file_path, mock_file_mm, byte_ranges
        )

        # Assertions
        mock_session.get.assert_called_once_with(
            file_url, headers={"Range": "bytes=0-10"}
        )
        mock_response.raise_for_status.assert_called_once()
        mock_open.assert_called_once_with(target_file_path, "wb")
        mock_open().write.assert_called_once_with(b"Hello World")

        # Validate file_mm was updated
        self.assertTrue(mock_file_mm.state_row.file_available_time)
        self.assertTrue(mock_file_mm.state_row.file_download_finish)
        self.assertTrue(mock_file_mm.state_row.file_written_to_volume_time)
        self.assertEqual(mock_file_mm.state_row.content_length, 11)
        self.assertEqual(mock_file_mm.state_row.byte_ranges, byte_ranges)

        mock_file_mm.persist_file_status_in_volume.assert_called_once()

        # Verify log_output was called
        mock_log_output.assert_called_once()
        args = mock_log_output.call_args[0]
        self.assertEqual(args[0], file_url)
        # args[2] is write_time which we can't easily test
        self.assertEqual(args[2], "Wed, 05 Mar 2025 10:00:00 GMT")
        self.assertEqual(args[3], 11)  # length of "Hello World"
        self.assertEqual(args[4], byte_ranges)


class TestDownloadFileWithoutMultipart(unittest.TestCase):
    @patch("os.path.exists", return_value=False)
    @patch("builtins.open", new_callable=unittest.mock.mock_open)
    @patch("noaa_downloader.log_output")
    def test_download_file_single_range_non_multipart(
        self, mock_log_output, mock_open, mock_exists
    ):
        mock_file_mm = Mock()
        mock_file_mm.state_row = MagicMock()

        mock_session = Mock(spec=requests.Session)
        mock_response = Mock(spec=requests.Response)

        # Simulated response for a single-range, NOT multipart
        mock_response.headers = {
            "Content-Type": "application/octet-stream",  # <-- Not multipart
            "last-modified": "Wed, 05 Mar 2025 10:00:00 GMT",
        }
        # Raw bytes only — no boundaries, no content-range headers in content
        mock_response.content = b"Hello"  # byte range (0–4)
        mock_response.raise_for_status = Mock()
        mock_session.get.return_value = mock_response

        file_url = "http://example.com/file"
        target_file_path = "/path/to/target/file"
        byte_ranges = [(0, 4)]

        download_file(
            mock_session,
            file_url,
            target_file_path,
            mock_file_mm,
            byte_ranges=byte_ranges,
        )

        # Check headers used in request
        mock_session.get.assert_called_once_with(
            file_url, headers={"Range": "bytes=0-4"}
        )

        # Check content written to file
        mock_open.assert_called_once_with(target_file_path, "wb")
        mock_open().write.assert_called_once_with(b"Hello")

        # Validate file_mm was updated
        self.assertTrue(mock_file_mm.state_row.file_available_time)
        self.assertTrue(mock_file_mm.state_row.file_download_finish)
        self.assertTrue(mock_file_mm.state_row.file_written_to_volume_time)
        self.assertEqual(mock_file_mm.state_row.content_length, 5)
        self.assertEqual(mock_file_mm.state_row.byte_ranges, byte_ranges)

        mock_file_mm.persist_file_status_in_volume.assert_called_once()

        # Check log_output called correctly
        mock_log_output.assert_called_once()
        args = mock_log_output.call_args[0]
        assert args[0] == file_url
        assert args[2] == "Wed, 05 Mar 2025 10:00:00 GMT"
        assert args[3] == 5  # length of "Hello"
        assert args[4] == byte_ranges


if __name__ == "__main__":
    unittest.main(argv=[""], verbosity=2, exit=False)