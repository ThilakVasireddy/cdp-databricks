import unittest
from datetime import datetime, timezone
from weather_package.metrics import noaa_metric_files_helper as helper
import os
import tempfile


class TestNoaaMetricFilesHelper(unittest.TestCase):
    def test_format_http_date_none(self):
        self.assertIsNone(helper.format_http_date(None))

    def test_format_http_date_valid(self):
        dt = datetime(2024, 6, 18, 5, 16, 11, tzinfo=timezone.utc)
        self.assertEqual(helper.format_http_date(dt), "Tue, 18 Jun 2024 05:16:11 GMT")

    def test_generate_new_file_name_none(self):
        self.assertIsNone(helper.generate_new_file_name(None))

    def test_generate_new_file_name_gfs(self):
        path = "/some/path/2025/06/16/00/gfs.t00z.pgrb2a.0p50.f384"
        expected = "gfs.t2025061600z.pgrbf384.grib2.global"
        self.assertEqual(helper.generate_new_file_name(path), expected)

    def test_generate_new_file_name_geavg(self):
        path = "/some/path/2025/06/16/00/geavg.t00z.pgrb2a.0p50.f384"
        expected = "gefsavg.t2025061600z.pgrbf384.grib2.global"
        self.assertEqual(helper.generate_new_file_name(path), expected)

    def test_generate_new_file_name_gep12(self):
        path = "/some/path/2025/06/16/00/gep12.t00z.pgrb2a.0p50.f384"
        expected = "gefs12.t2025061600z.pgrbf384.grib2.global"
        self.assertEqual(helper.generate_new_file_name(path), expected)

    def test_generate_new_file_name_unhandled_prefix(self):
        path = "/some/path/2025/06/16/00/unknown.t00z.pgrb2a.0p50.f384"
        with self.assertRaises(ValueError):
            helper.generate_new_file_name(path)

    def test_generate_new_file_name_no_lead_time(self):
        # Should raise ValueError if no lead time is present
        path = "/some/path/2025/06/16/00/gfs.t00z.pgrb2a.0p50"
        with self.assertRaises(ValueError):
            helper.generate_new_file_name(path)

    def test_get_datetime_diff(self):
        start = datetime(2024, 6, 18, 5, 0, 0)
        end = datetime(2024, 6, 18, 5, 0, 10)
        self.assertEqual(helper.get_datetime_diff(start, end), "10")

    def test_to_unix_timestamp_naive(self):
        dt = datetime(2024, 6, 18, 5, 0, 0)
        self.assertEqual(
            helper.to_unix_timestamp(dt),
            int(dt.replace(tzinfo=timezone.utc).timestamp()),
        )

    def test_to_unix_timestamp_aware(self):
        dt = datetime(2024, 6, 18, 5, 0, 0, tzinfo=timezone.utc)
        self.assertEqual(helper.to_unix_timestamp(dt), int(dt.timestamp()))

    def test_create_base_metric_file_operational(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            metric_file_path = os.path.join(
                tmpdir, "2024061800.00.source.GFSops-nomads-http-0p25.metric"
            )
            helper.create_base_metric_file(metric_file_path)
            with open(metric_file_path, "r") as f:
                lines = f.readlines()
            self.assertEqual(len(lines), 129)
            self.assertTrue(lines[0].startswith("gfs.t2024061800z.pgrbf000.grib2.global"))
            self.assertTrue(lines[-1].startswith("gfs.t2024061800z.pgrbf384.grib2.global"))

    def test_create_base_metric_file_ensemble(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            metric_file_path = os.path.join(
                tmpdir, "2024061800.01.source.GFSens-nomads-http-0p25.metric"
            )
            helper.create_base_metric_file(metric_file_path)
            with open(metric_file_path, "r") as f:
                lines = f.readlines()
            self.assertEqual(len(lines), 65)
            self.assertTrue(lines[0].startswith("gefs01.t2024061800z.pgrbf000.grib2.global"))
            self.assertTrue(lines[-1].startswith("gefs01.t2024061800z.pgrbf384.grib2.global"))

    def test_update_metric_file(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            metric_file_path = os.path.join(
                tmpdir, "2024061800.00.source.GFSops-nomads-http-0p25.metric"
            )
            helper.create_base_metric_file(metric_file_path)
            # Read the actual lines to get the correct prefix for f003
            with open(metric_file_path, "r") as f:
                lines = f.readlines()
            target_line = lines[1].strip().split(";")[0]  # Should be gfsops.t2024061800z.pgrbf003.grib2.global
            updated_row = {
                "source_metric_row": f"{target_line};http://example.com;Tue, 18 Jun 2024 05:00:00 GMT;10;15;1718686800;1;",
                "file_write_target_path": target_line
            }
            result = helper.update_metric_file(metric_file_path, [updated_row])
            self.assertIn(target_line, result)
            with open(metric_file_path, "r") as f:
                lines = f.readlines()
            found = any("http://example.com" in line for line in lines)
            self.assertTrue(found)