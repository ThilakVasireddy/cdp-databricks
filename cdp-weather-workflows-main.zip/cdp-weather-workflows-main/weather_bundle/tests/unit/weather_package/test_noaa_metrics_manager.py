def append_to_sys_path(folder: str, base_folder: str = "weather_bundle") -> str:
    """
    Append the specified folder to the system path if it is not already present.
    Allows importing packages from the folder.
    """
    import re
    import os
    import sys

    if not (match := re.search(rf"(.*[\\/]{base_folder})", os.getcwd())):
        raise FileNotFoundError(
            f"Could not find {base_folder} in current path: {os.getcwd()}"
        )

    base_path = match.group(1)
    for root, dirs, _ in os.walk(base_path):
        if "src" in dirs:
            base_path = root
            break

    if (path := os.path.join(base_path, folder)) not in sys.path:
        sys.path.append(path)
    return path


append_to_sys_path("src/weather_package")


from unittest import TestCase
from unittest.mock import MagicMock, patch, mock_open
from datetime import datetime
from py4j.protocol import Py4JError
import json
import pickle

from metrics.noaa_metrics_manager import (
    NOAABronzeFileMetricsManager,
    NOAABronzeTaskMetricsManager,
    NOAABronzeMetricsManager,
    AttrDict,
)


class TestNOAABronzeManagers(TestCase):

    def setUp(self):
        self.spark = MagicMock()
        self.df = MagicMock()
        self.spark.createDataFrame.return_value = self.df
        self.df.write.format.return_value.mode.return_value.saveAsTable = MagicMock()

        self.task_run_context = AttrDict(
            task_run_id=123,
            task_key="some_key",
            job_id=456,
            job_run_id=123123,
            job_name="some_job",
        )

    @patch("metrics.noaa_metrics_manager.open", new_callable=mock_open)
    @patch("pickle.dump")
    def test_persist_file_status_in_volume(self, mock_pickle, mock_file):
        mgr = NOAABronzeFileMetricsManager(
            self.spark, "some_table", "/tmp/dataset_name/2024/06/01/00/", self.task_run_context
        )
        mgr.state_row = AttrDict(
            file_name="file.nc",
            thread_name="T1",
            source_file_url="https://x",
            file_write_target_path="/mnt/file.nc",
            file_available_time=datetime.utcnow(),
            file_download_start=datetime.utcnow(),
            file_download_finish=datetime.utcnow(),
            file_written_to_volume_time=datetime.utcnow(),
            content_length=123,
            byte_ranges=[(0, 100)],
        )
        mgr.persist_file_status_in_volume()

        mock_file.assert_called_once()
        mock_pickle.assert_called_once()

    @patch("metrics.noaa_metrics_manager.os.makedirs")
    @patch("metrics.noaa_metrics_manager.open", new_callable=mock_open)
    @patch("metrics.noaa_metrics_manager.pickle.dump")
    @patch("metrics.noaa_metrics_manager.os.listdir", return_value=["file.nc.pkl"])
    @patch("metrics.noaa_metrics_manager.os.path.exists", return_value=True)
    @patch("metrics.noaa_metrics_manager.os.path.isfile", return_value=True)
    @patch("metrics.noaa_metrics_manager.os.remove")
    @patch("metrics.noaa_metrics_manager.pickle.load")
    def test_file_metrics(
        self,
        mock_pickle_load,
        mock_remove,
        mock_path_exists,
        mock_path_isfile,
        mock_listdir,
        mock_pickle_dump,
        mock_open_file,
        mock_makedirs,
    ):
        mgr = NOAABronzeFileMetricsManager(
            self.spark, "some_table", "/tmp/dataset_name/2024/06/01/00/", self.task_run_context
        )

        # Mocked state row to be pickled
        test_row = {
            "file_name": "file.nc",
            "task_run_id": 123,
            "thread_name": "T1",
            "source_file_url": "https://x",
            "file_write_target_path": "/mnt/file.nc",
            "file_available_time": datetime.utcnow(),
            "file_download_start": datetime.utcnow(),
            "file_download_finish": datetime.utcnow(),
            "file_written_to_volume_time": datetime.utcnow(),
            "content_length": 123,
            "byte_ranges": [{"start": 0, "end": 100}],
        }

        # Set the current state row
        mgr.state_row = AttrDict(**test_row)
        mgr.state_row.byte_ranges = [
            (0, 100)
        ]  # Must be a tuple list before serialization

        # Simulate volume persist
        mgr.persist_file_status_in_volume()
        mock_pickle_dump.assert_called_once()

        # Simulate flush (this triggers Spark writes)
        import io

        pickled_row = pickle.dumps(test_row)
        mock_open_file.return_value = io.BytesIO(pickled_row)

        mgr.flush_volume_file_status_to_delta()

        self.df.write.format.return_value.mode.return_value.saveAsTable.assert_called_once_with(
            "some_table"
        )

    def test_task_metrics(self):
        mgr = NOAABronzeTaskMetricsManager(
            self.spark, "task_table", self.task_run_context
        )
        mgr.log_task_start()
        self.df.write.format.return_value.mode.return_value.saveAsTable.assert_called_with(
            "task_table"
        )

        mgr.log_task_finish()
        self.assertEqual(self.spark.sql.call_count, 2)

    def test_attrdict_delattr_missing_key_raises(self):
        d = AttrDict()
        with self.assertRaises(AttributeError) as context:
            del d.missing_key
        self.assertIn("no attribute 'missing_key'", str(context.exception))

    def test_attrdict_getattr_missing_key_raises(self):
        d = AttrDict()
        with self.assertRaises(AttributeError) as context:
            _ = d.missing_key
        self.assertIn("no attribute 'missing_key'", str(context.exception))

    @patch("metrics.noaa_metrics_manager.DBUtils")
    def test_get_task_run_context_fallback_on_py4j_error(self, mock_dbutils_class):
        mock_dbutils = mock_dbutils_class.return_value
        mock_dbutils.notebook.entry_point.getDbutils.side_effect = Py4JError("fail")

        class TestableNOAABronzeManager(NOAABronzeMetricsManager):
            def create_table(self):
                pass

        mgr = TestableNOAABronzeManager(self.spark, "table_name")
        ctx = mgr.get_task_run_context()

        self.assertEqual(ctx.task_run_id, -1)
        self.assertIsNone(ctx.task_key)

    @patch("metrics.noaa_metrics_manager.DBUtils")
    def test_get_task_run_context_success(self, mock_dbutils_class):
        fake_ctx = {
            "tags": {
                "runId": "101",
                "taskKey": "test_task",
                "jobId": "202",
                "jobName": "demo_job",
            },
            "currentRunId": {"id": "303"},
        }

        mock_ctx_json = json.dumps(fake_ctx)
        mock_dbutils = mock_dbutils_class.return_value
        mock_entry_point = mock_dbutils.notebook.entry_point
        mock_entry_point.getDbutils.return_value.notebook().getContext().toJson.return_value = (
            mock_ctx_json
        )

        class TestableNOAABronzeManager(NOAABronzeMetricsManager):
            def create_table(self):
                pass

        mgr = TestableNOAABronzeManager(self.spark, "table_name")
        ctx = mgr.get_task_run_context()

        self.assertEqual(ctx.task_run_id, 101)
        self.assertEqual(ctx.task_key, "test_task")
        self.assertEqual(ctx.job_id, 202)
        self.assertEqual(ctx.job_run_id, 303)
        self.assertEqual(ctx.job_name, "demo_job")

    @patch("metrics.noaa_metrics_manager.os.path.exists", return_value=False)
    def test_flush_skips_if_dir_missing(self, mock_exists):
        mgr = NOAABronzeFileMetricsManager(self.spark, "some_table", "/tmp/dataset_name/2024/06/01/00/", self.task_run_context)
        mgr.flush_volume_file_status_to_delta()
        mock_exists.assert_called_once()

    @patch("metrics.noaa_metrics_manager.os.path.exists", return_value=True)

    def test_flush_skips_if_no_files(self, mock_listdir, mock_exists):
        mgr = NOAABronzeFileMetricsManager(self.spark, "some_table", "/tmp/dataset_name/2024/06/01/00/", self.task_run_context)
        mgr.flush_volume_file_status_to_delta()
        mock_listdir.assert_called_once()

    @patch("metrics.noaa_metrics_manager.os.path.exists", return_value=True)
    @patch("metrics.noaa_metrics_manager.os.listdir", return_value=["file1.pkl"])

    def test_flush_skips_if_no_files(self, mock_listdir, mock_exists):
        mgr = NOAABronzeFileMetricsManager(self.spark, "some_table", "/tmp/dataset_name/2024/06/01/00/", self.task_run_context)
        mgr.flush_volume_file_status_to_delta()
        mock_listdir.assert_called_once()

    @patch("metrics.noaa_metrics_manager.os.path.exists", return_value=True)
    @patch("metrics.noaa_metrics_manager.os.listdir", return_value=["file1.pkl"])
    @patch("metrics.noaa_metrics_manager.os.path.isfile", return_value=True)
    @patch("metrics.noaa_metrics_manager.open", new_callable=mock_open, read_data=pickle.dumps({"row": 1}))
    @patch("metrics.noaa_metrics_manager.pickle.load", return_value={"row": 1})
    @patch("metrics.noaa_metrics_manager.os.remove", side_effect=Exception("mock fail"))
    def test_flush_handles_failed_delete(
        self, mock_remove, mock_pickle_load, mock_open_file, mock_isfile, mock_listdir, mock_exists
    ):
        mgr = NOAABronzeFileMetricsManager(self.spark, "some_table", "/tmp/dataset_name/2024/06/01/00/", self.task_run_context)
        mgr.schema = None
        mgr.flush_volume_file_status_to_delta()
        mock_remove.assert_called_once()

    @patch("metrics.noaa_metrics_manager.os.path.exists", return_value=True)
    @patch("metrics.noaa_metrics_manager.os.listdir", side_effect=[["file1.pkl"], []])
    @patch("metrics.noaa_metrics_manager.os.path.isfile", return_value=True)
    @patch("metrics.noaa_metrics_manager.open", new_callable=mock_open, read_data=pickle.dumps({"row": 1}))
    @patch("metrics.noaa_metrics_manager.pickle.load", return_value={"row": 1})
    @patch("metrics.noaa_metrics_manager.os.remove")
    @patch("metrics.noaa_metrics_manager.shutil.rmtree")
    def test_flush_removes_empty_dir(
        self, mock_rmtree, mock_remove, mock_pickle_load, mock_open_file, mock_isfile, mock_listdir, mock_exists
    ):
        mgr = NOAABronzeFileMetricsManager(self.spark, "some_table", "/tmp/dataset_name/2024/06/01/00/", self.task_run_context)
        mgr.schema = None
        mgr.flush_volume_file_status_to_delta()
        mock_rmtree.assert_called_once()