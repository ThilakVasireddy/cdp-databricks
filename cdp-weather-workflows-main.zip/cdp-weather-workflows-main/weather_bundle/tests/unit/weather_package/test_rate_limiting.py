import time
from concurrent.futures import ThreadPoolExecutor
from threading import Thread

from weather_package.rate_limiting import RateLimiter


def test_rate_limiter_single_thread():
    """
    Test that the RateLimiter enforces the rate limit in a single-threaded setting.
    """
    rate_limiter = RateLimiter(max_calls=10, period=0.1)  # 10 calls per 0.1 second
    start_time = time.monotonic()

    for _ in range(11):  # Just one more than max_calls
        rate_limiter.acquire()

    elapsed_time = time.monotonic() - start_time
    assert elapsed_time >= 0.09, "RateLimiter did not enforce the rate limit correctly."


def test_rate_limiter_multithreaded():
    """
    Test that the RateLimiter enforces the rate limit in a multithreaded setting.
    """
    rate_limiter = RateLimiter(max_calls=10, period=0.1)  # 10 calls per 0.1 second
    start_time = time.monotonic()
    num_threads = 2
    calls_per_thread = 3

    def worker():
        for _ in range(calls_per_thread):
            rate_limiter.acquire()

    with ThreadPoolExecutor(max_workers=num_threads) as executor:
        futures = [executor.submit(worker) for _ in range(num_threads)]
        for future in futures:
            future.result()

    elapsed_time = time.monotonic() - start_time
    total_calls = num_threads * calls_per_thread

    # subtract rate_limiter.max_calls to account for the fact that 
    # we can make max_calls calls without waiting at the start
    expected_min_time = (
        (total_calls - rate_limiter.max_calls)
        / rate_limiter.max_calls
        * rate_limiter.period
    )
    assert elapsed_time >= expected_min_time, (
        f"RateLimiter did not enforce the rate limit correctly in multithreaded setting. "
        f"Expected at least {expected_min_time:.2f} seconds, but got {elapsed_time:.2f} seconds."
    )


def test_rate_limiter_multithreaded_with_explicit_start_and_join():
    """
    Test that the RateLimiter enforces the rate limit in a multithreaded setting
    using explicit thread start and join.
    """
    rate_limiter = RateLimiter(max_calls=10, period=0.1)  # 10 calls per 0.1 second
    start_time = time.monotonic()
    num_threads = 2
    calls_per_thread = 3

    def worker():
        for _ in range(calls_per_thread):
            rate_limiter.acquire()

    threads = [Thread(target=worker) for _ in range(num_threads)]

    # Start all threads
    for thread in threads:
        thread.start()

    # Join all threads
    for thread in threads:
        thread.join()

    elapsed_time = time.monotonic() - start_time
    # Adjusted to account for overlapping calls across threads
    total_calls = num_threads * calls_per_thread
    expected_min_time = (
        (total_calls - rate_limiter.max_calls)
        / rate_limiter.max_calls
        * rate_limiter.period
    )
    assert elapsed_time >= expected_min_time, (
        f"RateLimiter did not enforce the rate limit correctly in multithreaded setting. "
        f"Expected at least {expected_min_time:.2f} seconds, but got {elapsed_time:.2f} seconds."
    )
